#!/usr/bin/env python3
"""Lanzador de la app ux-infra.

Funciona en Windows, Linux y macOS. Si falta la dependencia ``paramiko``, crea un
entorno aislado ``.venv`` junto a este archivo, la instala y se relanza dentro de
él (así el sistema del operador no se ensucia). El resto de la app usa solo la
biblioteca estándar.
"""

from __future__ import annotations

import os
import subprocess
import sys
import venv
from pathlib import Path

AQUI = Path(__file__).resolve().parent
VENV = AQUI / ".venv"
REQUISITOS = AQUI / "requisitos.txt"


def _python_del_venv() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def _tiene_paramiko(ejecutable: str | os.PathLike[str]) -> bool:
    try:
        subprocess.run(
            [str(ejecutable), "-c", "import paramiko"],
            check=True,
            capture_output=True,
        )
        return True
    except Exception:  # noqa: BLE001
        return False


def _crear_entorno() -> Path:
    print("-> Preparando el entorno de la app (.venv)...", file=sys.stderr)
    venv.EnvBuilder(with_pip=True, clear=False).create(VENV)
    python = _python_del_venv()
    print("-> Instalando dependencias...", file=sys.stderr)
    subprocess.run(
        [str(python), "-m", "pip", "install", "--quiet", "--upgrade", "pip"], check=True
    )
    subprocess.run(
        [str(python), "-m", "pip", "install", "--quiet", "-r", str(REQUISITOS)], check=True
    )
    return python


def main() -> int:
    if _tiene_paramiko(sys.executable) and VENV not in Path(sys.executable).parents:
        # Ya hay paramiko donde corremos: adelante.
        return _ejecutar(sys.executable)

    python = _python_del_venv()
    if not python.exists() or not _tiene_paramiko(python):
        try:
            python = _crear_entorno()
        except Exception as exc:  # noqa: BLE001
            print(
                "No pude preparar el entorno automáticamente:\n"
                f"  {exc}\n\nHazlo a mano:\n"
                f"  python -m venv {VENV}\n"
                f"  {python} -m pip install -r {REQUISITOS}\n",
                file=sys.stderr,
            )
            return 1
    return _ejecutar(python)


def _ejecutar(python: str | os.PathLike[str]) -> int:
    proceso = subprocess.run(
        [str(python), "-m", "ux_infra", *sys.argv[1:]], cwd=str(AQUI)
    )
    return proceso.returncode


if __name__ == "__main__":
    raise SystemExit(main())
