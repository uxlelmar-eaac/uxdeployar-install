"""Abre una URL en el navegador del escritorio.

Sin escritorio (SSH, servidor) ``webbrowser`` recurre a lynx o w3m dentro de la misma terminal y se queda con
el teclado que espera una respuesta; ahí no se abre nada y basta con la URL impresa.
"""

from __future__ import annotations

import os
import sys
import webbrowser
from typing import Mapping


def hay_escritorio(entorno: Mapping[str, str] = os.environ, plataforma: str = sys.platform) -> bool:
    if plataforma.startswith("linux") or "bsd" in plataforma:
        return bool(entorno.get("DISPLAY") or entorno.get("WAYLAND_DISPLAY"))
    return True


def abrir(url: str) -> bool:
    """True si el navegador se abrió."""
    if not hay_escritorio():
        return False
    try:
        return bool(webbrowser.open(url))
    except Exception:  # noqa: BLE001 - sin navegador basta con la URL impresa
        return False
