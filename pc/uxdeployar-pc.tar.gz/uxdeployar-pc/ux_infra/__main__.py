"""Interfaz de línea de comandos de ``ux-infra``.

Dos órdenes, ambas de **solo lectura** sobre el servidor:

* ``huella``   — lee la clave del host sin autenticar y muestra su huella.
* ``revisar``  — se conecta y comprueba que el VPS cumple el estándar
  (plataforma ``ux-*``, Podman, Caddy, grupos, sshd, sudo, memoria y disco).

La contraseña de sudo **nunca** viaja como argumento: se lee de una variable de
entorno (por defecto ``UX_SUDO_PASS``).
"""

from __future__ import annotations

import argparse
import os
import sys

from . import __version__, ssh


def _huella(args: argparse.Namespace) -> int:
    clave = ssh.escanear_clave_host(args.host, args.puerto, timeout=args.timeout)
    print(f"{clave.get_name()} {ssh.huella(clave)}")
    return 0


# Comprobaciones de solo lectura: (etiqueta, comando, valor esperado o None).
_SIN_SUDO: list[tuple[str, str, str | None]] = [
    ("sistema", "cat /etc/os-release | head -1 | cut -d'\"' -f2", None),
    ("podman", "podman --version 2>/dev/null | cut -d' ' -f3", None),
    ("ux-proyecto", "command -v ux-proyecto || echo FALTA", None),
    ("ux-deploy", "command -v ux-deploy || echo FALTA", None),
    ("disco /", "df -h / | tail -1 | awk '{print $4\" libres (\"$5\" usado)\"}'", None),
    ("memoria", "free -h | awk 'NR==2 {print $7\" disponibles\"}'", None),
]
_CON_SUDO: list[tuple[str, str, str | None]] = [
    ("sshd", "sshd -T | grep -Ei '^(maxsessions|passwordauthentication|permitrootlogin|port) ' | tr '\\n' ' '", None),
    ("puertos fuera de loopback", "ss -lnt | awk 'NR>1 {print $4}' | grep -Ev '^(127\\.|\\[::1\\])' | sort -u | tr '\\n' ' '", None),
    ("ufw", "ufw status | head -1", "Status: active"),
    ("fail2ban", "fail2ban-client status | head -2 | tail -1 | tr -d '\\n'", None),
]


def _revisar(args: argparse.Namespace) -> int:
    clave = ssh.escanear_clave_host(args.host, args.puerto, timeout=args.timeout)
    obtenida = ssh.huella(clave)
    print(f"Huella del servidor: {obtenida} ({clave.get_name()})")
    if args.huella and args.huella != obtenida:
        print(f"  FALLO NO coincide con la indicada ({args.huella}): se detiene.")
        return 2
    if not args.huella:
        print("  (sin huella indicada: se ancla la de esta primera conexión)")

    cfg = ssh.Config(
        host=args.host,
        puerto=args.puerto,
        usuario=args.usuario,
        contrasena=args.contrasena or "",
        ruta_llave=args.llave or "",
        totp=args.totp or "",
        anclada=clave,
        timeout=args.timeout,
    )
    try:
        cliente = ssh.Cliente.dial(cfg)
    except ssh.ErrorHuellaAnclada as exc:
        print(f"  FALLO {exc}")
        return 2
    except (ssh.ErrorAuth, ssh.ErrorRed) as exc:
        print(f"  FALLO {exc}")
        return 1

    fallos = 0
    with cliente:
        print("\n— Comprobaciones sin privilegios —")
        for etiqueta, cmd, esperado in _SIN_SUDO:
            r = cliente.ejecutar(cmd)
            valor = (r.stdout or r.stderr).strip().replace("\n", " ")
            fallos += _informar(etiqueta, r.codigo, valor, esperado)

        contrasena = os.environ.get(args.sudo_env, "") if args.sudo_env else ""
        if contrasena:
            print("\n— Comprobaciones con sudo (contraseña por variable de entorno) —")
            prueba = cliente.ejecutar_sudo("true", contrasena)
            if prueba.codigo == 0:
                for etiqueta, cmd, esperado in _CON_SUDO:
                    r = cliente.ejecutar_sudo(cmd, contrasena)
                    valor = (r.stdout or r.stderr).strip().replace("\n", " ")
                    fallos += _informar(etiqueta, r.codigo, valor, esperado)
            else:
                print("  FALLO la contraseña de sudo no es válida; se omiten estas comprobaciones")
                fallos += 1
        else:
            print(f"\n(sin ${args.sudo_env}: se omiten las comprobaciones con sudo)")

    print()
    if fallos:
        print(f"REVISIÓN CON {fallos} AVISO(S)")
        return 1
    print("REVISIÓN OK")
    return 0


def _informar(etiqueta: str, codigo: int, valor: str, esperado: str | None) -> int:
    if esperado is None:
        bien = codigo == 0 and valor not in ("", "FALTA")
    else:
        bien = esperado.lower() in valor.lower()
    print(f"  {'ok   ' if bien else 'FALLO'} {etiqueta}: {valor[:200]}")
    return 0 if bien else 1


def _web(args: argparse.Namespace) -> int:
    """Abre la interfaz local en el navegador (solo 127.0.0.1)."""
    from . import servidor as servidor_mod

    srv = servidor_mod.Servidor(
        puerto=args.puerto,
        dir_config=args.config or "",
        version=args.version or None,
        abrir_navegador=not args.no_abrir,
    )
    return srv.ejecutar()


def _instalar(args: argparse.Namespace) -> int:
    from .instalador import ErrorInstalador, flujo

    try:
        return flujo.ejecutar(args)
    except (ErrorInstalador, TimeoutError, ssh.ErrorHuellaAnclada) as exc:
        print(f"\n✖ {exc}", file=sys.stderr)
        return 1


def _opciones_instalar(sp: argparse.ArgumentParser) -> None:
    from .instalador import github

    oculto = argparse.SUPPRESS
    sp.add_argument("host", nargs="?", help="IP o nombre del VPS recién creado")
    sp.add_argument("--huella", help="huella SHA256:… del VPS (si la tienes, no se pregunta)")
    sp.add_argument("--llave", help="llave privada que ya entra como root (si no, se pide la contraseña)")
    sp.add_argument("--panel", help="dominio del panel (p. ej. panel.ejemplo.com)")
    sp.add_argument("--api", help="dominio de la API (p. ej. api.ejemplo.com)")
    sp.add_argument("--correo", help="tu correo: Let's Encrypt y usuario del panel")
    sp.add_argument("--puerto-ssh", type=int, default=2222, help="puerto SSH final (por defecto 2222)")
    sp.add_argument("--version", dest="version_uxdeployar", help="versión vX.Y.Z (por defecto la última)")
    sp.add_argument(
        "--dns",
        choices=["cloudflare", "manual", "ninguno"],
        help="proveedor DNS: cloudflare o manual (por defecto se detecta)",
    )
    sp.add_argument("--yes", action="store_true", help="no pide la confirmación final")
    sp.add_argument("--no-abrir", action="store_true", help="no abre el navegador")
    sp.add_argument(
        "--release-repo", default=github.REPO_RELEASES, help=f"repo con los releases (por defecto {github.REPO_RELEASES})"
    )
    sp.add_argument("--release-url", help=oculto)
    sp.add_argument("--acme-ca", help=oculto)
    sp.add_argument("--acme-ca-root", help=oculto)
    sp.add_argument("--install-sh", help=oculto)
    sp.add_argument("--registry", help=oculto)
    sp.add_argument("--ip-publica", help=oculto)
    sp.add_argument("--puerto-root", type=int, default=22, help=oculto)


def _github(args: argparse.Namespace) -> int:
    from .publicacion import ErrorPublicacion, preparar, publicar

    try:
        return (preparar if args.accion == "preparar" else publicar).ejecutar(args)
    except ErrorPublicacion as exc:
        print(f"\n✖ {exc}", file=sys.stderr)
        return 1


def _opciones_github(sp: argparse.ArgumentParser) -> None:
    from .publicacion import DUENO

    acciones = sp.add_subparsers(dest="accion", required=True)
    pr = acciones.add_parser("preparar", help="repo público, llave de firma, tokens y GHCR (se puede repetir)")
    pr.add_argument("--dueno", default=DUENO, help=f"cuenta u organización de los repos (por defecto {DUENO})")
    pr.add_argument("--rotar", action="store_true", help="regenera la llave de firma y vuelve a pedir los tokens")
    pu = acciones.add_parser("publicar", help="etiqueta frontend y backend y sigue el release")
    pu.add_argument("version_publicar", metavar="version", help="vX.Y.Z o vX.Y.Z-rc.N")
    pu.add_argument("--dueno", default=DUENO, help=f"cuenta u organización de los repos (por defecto {DUENO})")
    pu.add_argument("--backend", help="copia local del backend para comparar main (por defecto, esta)")
    pu.add_argument("--frontend", help="copia local del frontend (por defecto, junto al backend)")
    pu.add_argument("--sin-seguir", action="store_true", help="solo etiqueta; no sigue el workflow")
    pu.add_argument("--yes", action="store_true", help="no pide la confirmación")


def construir_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ux-infra",
        description=(
            "Instala uxdeployar en un VPS desde tu PC (instalar), prepara un repositorio y "
            "configura/opera el VPS. Comandos: instalar, github, huella, revisar, web, "
            "prep (lado proyecto, heredado de ux-prep) y prep-gui."
        ),
    )
    p.add_argument("--version", action="version", version=f"ux-infra {__version__}")
    sub = p.add_subparsers(dest="orden", required=True)

    def conectar(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("host")
        sp.add_argument("--puerto", type=int, default=22)
        sp.add_argument("--timeout", type=float, default=15.0)

    sp = sub.add_parser("instalar", help="instala uxdeployar en un VPS recién creado, guiado paso a paso")
    _opciones_instalar(sp)
    sp.set_defaults(func=_instalar)

    sp = sub.add_parser("github", help="configura GitHub una vez (preparar) y publica versiones (publicar)")
    _opciones_github(sp)
    sp.set_defaults(func=_github)

    sp = sub.add_parser("huella", help="lee la clave del host sin autenticar y muestra su huella")
    conectar(sp)
    sp.set_defaults(func=_huella)

    sp = sub.add_parser("revisar", help="comprueba (solo lectura) que el VPS cumple el estándar")
    conectar(sp)
    sp.add_argument("--usuario", required=True)
    sp.add_argument("--llave", help="ruta de la llave privada")
    sp.add_argument("--contrasena", help="contraseña SSH (evítala: usa llave)")
    sp.add_argument("--totp", help="código de 6 dígitos si el servidor exige 2FA")
    sp.add_argument("--huella", help="huella SHA256:… esperada (se compara antes de entrar)")
    sp.add_argument(
        "--sudo-env",
        default="UX_SUDO_PASS",
        help="variable de entorno con la contraseña de sudo (por defecto UX_SUDO_PASS)",
    )
    sp.set_defaults(func=_revisar)

    sp = sub.add_parser("web", help="abre la interfaz local de la app en el navegador")
    sp.add_argument("--puerto", type=int, default=0, help="puerto local (0 = aleatorio)")
    sp.add_argument("--config", default="", help="carpeta de configuración (por defecto, la de la app)")
    sp.add_argument("--no-abrir", action="store_true", help="no abre el navegador")
    sp.add_argument("--version", default="", help="versión que muestra la interfaz")
    sp.set_defaults(func=_web)
    return p


def _utf8() -> None:
    """Consola de Windows en cp1252: evita que imprimir acentos o símbolos falle."""
    for flujo in (sys.stdout, sys.stderr):
        try:
            flujo.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        except Exception:  # noqa: BLE001
            pass


def main(argv: list[str] | None = None) -> int:
    _utf8()
    argv = list(sys.argv[1:] if argv is None else argv)
    # «prep» y «prep-gui» reenvían a ux_prep (el antiguo ux-prep, ahora fundido en la app).
    if argv:
        if argv[0] == "prep":
            from ux_prep import cli as prep_cli

            return int(prep_cli.main(argv[1:]) or 0)
        if argv[0] == "prep-gui":
            from pathlib import Path

            os.environ.setdefault(
                "UX_PLANTILLAS",
                str(Path(__file__).resolve().parents[3] / "deploy" / "09-templates"),
            )
            from ux_prep.gui import main as gui_main

            return int(gui_main() or 0)
    args = construir_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except (ssh.ErrorRed, ssh.ErrorAuth, ssh.ErrorPassphrase) as exc:
        print(f"✖ {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
