"""Códigos QR (modo byte, corrección M, versiones 1–10) como SVG, sin dependencias.

Port directo de ``05-vps/app/internal/qr/qr.go``. Basta para enlaces
``otpauth://`` del segundo factor y textos cortos.
"""

from __future__ import annotations

_TABLA_M = [
    ([], 0),
    ([16], 10),
    ([28], 16),
    ([44], 26),
    ([32, 32], 18),
    ([43, 43], 24),
    ([27, 27, 27, 27], 16),
    ([31, 31, 31, 31], 18),
    ([38, 38, 39, 39], 22),
    ([36, 36, 36, 37, 37], 22),
    ([43, 43, 43, 43, 44], 26),
]
_ALINEACIONES = [[], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]]
_RESTO_BITS = [0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0]


def _mul_gf(x: int, y: int) -> int:
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _divisor_rs(grado: int) -> list[int]:
    res = [0] * grado
    res[grado - 1] = 1
    raiz = 1
    for _ in range(grado):
        for j in range(grado):
            res[j] = _mul_gf(res[j], raiz)
            if j + 1 < grado:
                res[j] ^= res[j + 1]
        raiz = _mul_gf(raiz, 0x02)
    return res


def _resto_rs(datos: list[int], divisor: list[int]) -> list[int]:
    res = [0] * len(divisor)
    for b in datos:
        f = b ^ res[0]
        res = res[1:] + [0]
        for i in range(len(res)):
            res[i] ^= _mul_gf(divisor[i], f)
    return res


class Codigo:
    def __init__(self, version: int) -> None:
        self.version = version
        self.tam = 17 + 4 * version
        self.m = [[False] * self.tam for _ in range(self.tam)]
        self.funcion = [[False] * self.tam for _ in range(self.tam)]

    def fijar(self, x: int, y: int, oscuro: bool) -> None:
        self.m[y][x] = oscuro
        self.funcion[y][x] = True

    def dibujar_funciones(self) -> None:
        n = self.tam
        for i in range(n):
            self.fijar(6, i, i % 2 == 0)
            self.fijar(i, 6, i % 2 == 0)

        def buscador(cx: int, cy: int) -> None:
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if x < 0 or y < 0 or x >= n or y >= n:
                        continue
                    d = max(abs(dx), abs(dy))
                    self.fijar(x, y, d != 2 and d != 4)

        buscador(3, 3)
        buscador(n - 4, 3)
        buscador(3, n - 4)
        al = _ALINEACIONES[self.version]
        for i, ax in enumerate(al):
            for j, ay in enumerate(al):
                if (i == 0 and j == 0) or (i == 0 and j == len(al) - 1) or (i == len(al) - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.fijar(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)
        self.formato(0)
        if self.version >= 7:
            rem = self.version
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            bits = (self.version << 12) | rem
            for i in range(18):
                b = ((bits >> i) & 1) == 1
                a, bb = n - 11 + i % 3, i // 3
                self.fijar(a, bb, b)
                self.fijar(bb, a, b)

    def formato(self, mascara: int) -> None:
        n = self.tam
        datos = mascara  # corrección M = 00
        rem = datos
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (datos << 10 | rem) ^ 0x5412

        def bit(i: int) -> bool:
            return ((bits >> i) & 1) == 1

        for i in range(0, 6):
            self.fijar(8, i, bit(i))
        self.fijar(8, 7, bit(6))
        self.fijar(8, 8, bit(7))
        self.fijar(7, 8, bit(8))
        for i in range(9, 15):
            self.fijar(14 - i, 8, bit(i))
        for i in range(0, 8):
            self.fijar(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.fijar(8, n - 15 + i, bit(i))
        self.fijar(8, n - 8, True)

    def colocar(self, datos: list[int]) -> None:
        n = self.tam
        i = 0
        total = len(datos) * 8 + _RESTO_BITS[self.version]
        der = n - 1
        while der >= 1:
            if der == 6:
                der = 5
            for vert in range(n):
                for j in range(2):
                    x = der - j
                    arriba = (der + 1) & 2 == 0
                    y = n - 1 - vert if arriba else vert
                    if not self.funcion[y][x] and i < total:
                        if i < len(datos) * 8:
                            self.m[y][x] = ((datos[i >> 3] >> (7 - (i & 7))) & 1) == 1
                        i += 1
            der -= 2

    def aplicar_mascara(self, mk: int) -> None:
        for y in range(self.tam):
            for x in range(self.tam):
                if self.funcion[y][x]:
                    continue
                if mk == 0:
                    inv = (x + y) % 2 == 0
                elif mk == 1:
                    inv = y % 2 == 0
                elif mk == 2:
                    inv = x % 3 == 0
                elif mk == 3:
                    inv = (x + y) % 3 == 0
                elif mk == 4:
                    inv = (x // 3 + y // 2) % 2 == 0
                elif mk == 5:
                    inv = x * y % 2 + x * y % 3 == 0
                elif mk == 6:
                    inv = (x * y % 2 + x * y % 3) % 2 == 0
                else:
                    inv = ((x + y) % 2 + x * y % 3) % 2 == 0
                if inv:
                    self.m[y][x] = not self.m[y][x]

    def penalizacion(self) -> int:
        n, p = self.tam, 0
        for y in range(n):
            for fila in (True, False):
                run, prev = 0, False
                for x in range(n):
                    v = self.m[y][x] if fila else self.m[x][y]
                    if x > 0 and v == prev:
                        run += 1
                        if run == 5:
                            p += 3
                        elif run > 5:
                            p += 1
                    else:
                        run = 1
                    prev = v
        oscuros = 0
        for y in range(n):
            for x in range(n):
                if self.m[y][x]:
                    oscuros += 1
                if x < n - 1 and y < n - 1:
                    v = self.m[y][x]
                    if v == self.m[y][x + 1] and v == self.m[y + 1][x] and v == self.m[y + 1][x + 1]:
                        p += 3
        p += abs(oscuros * 20 - n * n * 10) // (n * n) * 10
        return p

    def svg(self) -> str:
        borde = 4
        t = self.tam + 2 * borde
        partes = [
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {t} {t}" shape-rendering="crispEdges" role="img" aria-label="Código QR">',
            f'<rect width="{t}" height="{t}" fill="#fff"/><path fill="#000" d="',
        ]
        for y in range(self.tam):
            for x in range(self.tam):
                if self.m[y][x]:
                    partes.append(f"M{x + borde} {y + borde}h1v1h-1z")
        partes.append('"/></svg>')
        return "".join(partes)


def codificar(texto: str) -> Codigo:
    datos = texto.encode("utf-8")
    version = 0
    for v in range(1, 11):
        bits_cuenta = 16 if v >= 10 else 8
        if 4 + bits_cuenta + 8 * len(datos) <= sum(_TABLA_M[v][0]) * 8:
            version = v
            break
    if version == 0:
        raise ValueError("texto demasiado largo para el QR")
    capac = sum(_TABLA_M[version][0])
    bits: list[bool] = []

    def poner(v: int, n: int) -> None:
        for i in range(n - 1, -1, -1):
            bits.append(((v >> i) & 1) == 1)

    poner(4, 4)
    poner(len(datos), 16 if version >= 10 else 8)
    for b in datos:
        poner(b, 8)
    for _ in range(4):
        if len(bits) >= capac * 8:
            break
        bits.append(False)
    while len(bits) % 8 != 0:
        bits.append(False)
    cw: list[int] = []
    for i in range(0, len(bits), 8):
        b = 0
        for j in range(8):
            if bits[i + j]:
                b |= 1 << (7 - j)
        cw.append(b)
    k = 0
    while len(cw) < capac:
        cw.append([0xEC, 0x11][k % 2])
        k += 1
    t = _TABLA_M[version]
    divisor = _divisor_rs(t[1])
    bloques: list[list[int]] = []
    ecs: list[list[int]] = []
    pos = 0
    for n in t[0]:
        b = cw[pos : pos + n]
        pos += n
        bloques.append(b)
        ecs.append(_resto_rs(b, divisor))
    final: list[int] = []
    for i in range(44):
        for b in bloques:
            if i < len(b):
                final.append(b[i])
    for i in range(t[1]):
        for e in ecs:
            final.append(e[i])
    c = Codigo(version)
    c.dibujar_funciones()
    c.colocar(final)
    mejor, pen = 0, -1
    for mk in range(8):
        c.aplicar_mascara(mk)
        c.formato(mk)
        p = c.penalizacion()
        if pen < 0 or p < pen:
            mejor, pen = mk, p
        c.aplicar_mascara(mk)
    c.aplicar_mascara(mejor)
    c.formato(mejor)
    return c
