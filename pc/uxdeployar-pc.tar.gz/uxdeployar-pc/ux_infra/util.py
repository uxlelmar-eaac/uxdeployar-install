"""Validadores y utilidades puras (sin red ni disco).

Espejo de ``05-vps/app/internal/util/util.go`` (el original, ya retirado): **todo dato que
llega de la interfaz se valida aquí ANTES de componer cualquier comando remoto**.
Si un validador discrepa del manual, manda el manual.
"""

from __future__ import annotations

import ipaddress
import os
import re

__all__ = [
    "ErrorValidacion",
    "mensaje",
    "validar_host",
    "validar_puerto",
    "validar_usuario",
    "validar_repo_url",
    "validar_email",
    "validar_nombre_git",
    "validar_password_sudo",
    "normalizar_huella",
    "es_proyecto",
    "es_rol",
    "es_dominio",
    "es_tag",
    "es_respaldo",
    "es_age_recipients",
    "es_age_recipient",
    "es_account_r2",
    "es_alfanumerico",
    "es_llave_ci",
    "es_bucket",
    "es_prefijo_vps",
    "es_zona_horaria",
    "es_ip",
    "es_motivo",
    "comillas",
    "expandir_ruta",
    "truncar",
    "cola",
]


class ErrorValidacion(ValueError):
    """Dato de entrada no válido (equivalente a ``util.ErrValidacion``)."""


def mensaje(err: BaseException | None) -> str:
    """Texto legible de un error (o cadena vacía)."""
    return "" if err is None else str(err)


_USUARIO = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
_HOSTNAME = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")
_REPO = re.compile(r"^[A-Za-z0-9._:/@~-]+\.git$")
_HUELLA = re.compile(r"^SHA256:([A-Za-z0-9+/]+=*)$", re.IGNORECASE)
_PROYECTO = re.compile(r"^[a-z][a-z0-9]{1,30}$")
_ROL = re.compile(r"^[a-z][a-z0-9]{1,20}$")
_DOMINIO = re.compile(r"^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$")
_TAG = re.compile(r"^[0-9a-f]{12}$")
_RESPALDO = re.compile(r"^[a-z0-9-]+-[0-9]{8}-[0-9]{6}-(daily|pre-deploy)\.(dump|tar)\.age$")
_AGE_RECIP = re.compile(r"^age1[a-z0-9]{58}(,age1[a-z0-9]{58})*$")
_AGE_SINGLE = re.compile(r"^age1[a-z0-9]{58}$")
_ACCOUNT = re.compile(r"^[a-f0-9]{32}$")
_ALFANUM = re.compile(r"^[A-Za-z0-9]+$")
_LLAVE_CI = re.compile(
    r"^(ssh-ed25519|ecdsa-sha2-nistp[0-9]+|sk-ssh-ed25519@openssh\.com) [A-Za-z0-9+/=]+( [^\r\n]*)?$"
)
_BUCKET = re.compile(r"^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$")
_PREFIJO_VPS = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")
_ZONA = re.compile(r"^[A-Za-z]+(/[A-Za-z0-9_+-]+){0,2}$")

# Caracteres que nunca se aceptan en un email (igual que el original).
_EMAIL_PROHIBIDOS = set(" '\"`$\\;|&<>")


def _errf(msg: str) -> ErrorValidacion:
    return ErrorValidacion(msg)


def _es_control(s: str) -> bool:
    return any(ord(c) < 32 or ord(c) == 127 for c in s)


def _es_ip(h: str) -> bool:
    try:
        ipaddress.ip_address(h)
    except ValueError:
        try:
            ipaddress.ip_address(h.strip())
        except ValueError:
            return False
        return True
    return True


def es_ip(s: str) -> bool:
    """Valida una IPv4/IPv6 literal."""
    try:
        ipaddress.ip_address(s.strip())
        return True
    except ValueError:
        return False


# --- validadores que devuelven el valor normalizado -------------------------


def validar_host(h: str) -> str:
    h = h.strip()
    if not h:
        raise _errf("falta la dirección IP o el hostname del VPS")
    if es_ip(h):
        return h
    if _HOSTNAME.match(h) and ".." not in h:
        return h
    raise _errf("la dirección o el hostname no tiene un formato válido")


def validar_puerto(v: object) -> int:
    p: int
    if isinstance(v, bool):
        raise _errf("el puerto debe ser un número")
    if isinstance(v, int):
        p = v
    elif isinstance(v, float):
        p = int(v)
    elif isinstance(v, str):
        try:
            p = int(v.strip())
        except ValueError:
            raise _errf("el puerto debe ser un número") from None
    else:
        raise _errf("el puerto debe ser un número")
    if p < 1 or p > 65535:
        raise _errf("el puerto debe estar entre 1 y 65535")
    return p


def validar_usuario(u: str) -> str:
    u = u.strip()
    if not _USUARIO.match(u):
        raise _errf(
            "nombre de usuario no válido (letras minúsculas, números, _ y -; empieza con letra o _)"
        )
    return u


def validar_repo_url(u: str) -> str:
    u = u.strip()
    ok_esquema = u.startswith(("https://", "http://", "ssh://", "git@"))
    if not _REPO.match(u) or not ok_esquema:
        raise _errf(
            "la URL del repositorio no es válida (debe terminar en .git y empezar con "
            "https://, git@ o ssh://; sin espacios ni caracteres especiales)"
        )
    return u


def validar_email(e: str) -> str:
    e = e.strip()
    if not e or "@" not in e:
        raise _errf("el email es obligatorio y debe tener el formato usuario@dominio")
    if len(e) > 200:
        raise _errf("el email es demasiado largo")
    if _es_control(e) or any(c in _EMAIL_PROHIBIDOS for c in e):
        raise _errf("el email contiene caracteres no permitidos")
    return e


def validar_nombre_git(n: str) -> str:
    n = n.strip()
    if not n:
        raise _errf("falta el nombre para git (user.name)")
    if len(n) > 200:
        raise _errf("el nombre para git es demasiado largo")
    if _es_control(n):
        raise _errf("el nombre para git contiene caracteres de control")
    return n


def validar_password_sudo(c: str) -> str:
    if len(c) < 10:
        raise _errf("la contraseña de sudo debe tener al menos 10 caracteres")
    if _es_control(c):
        raise _errf("la contraseña de sudo no puede contener caracteres de control")
    if ":" in c:
        raise _errf("la contraseña de sudo no puede contener ':' (formato de chpasswd)")
    return c


def normalizar_huella(v: str) -> str:
    v = v.strip()
    if not v:
        return ""
    m = _HUELLA.match(v)
    if not m:
        raise _errf(
            "la huella debe tener el formato SHA256:… (la muestra el proveedor o ssh-keygen -lf)"
        )
    return "SHA256:" + m.group(1).rstrip("=")


# --- predicados booleanos (igual que las EsX del original) ------------------


def es_proyecto(s: str) -> bool:
    return bool(_PROYECTO.match(s))


def es_rol(s: str) -> bool:
    return bool(_ROL.match(s))


def es_dominio(s: str) -> bool:
    return bool(_DOMINIO.match(s))


def es_tag(s: str) -> bool:
    return bool(_TAG.match(s))


def es_respaldo(s: str) -> bool:
    return bool(_RESPALDO.match(s))


def es_age_recipients(s: str) -> bool:
    return bool(_AGE_RECIP.match(s))


def es_age_recipient(s: str) -> bool:
    return bool(_AGE_SINGLE.match(s))


def es_account_r2(s: str) -> bool:
    return bool(_ACCOUNT.match(s))


def es_alfanumerico(s: str) -> bool:
    return bool(_ALFANUM.match(s))


def es_llave_ci(s: str) -> bool:
    return bool(_LLAVE_CI.match(s.strip()))


def es_bucket(s: str) -> bool:
    return bool(_BUCKET.match(s))


def es_prefijo_vps(s: str) -> bool:
    return s == "" or bool(_PREFIJO_VPS.match(s))


def es_zona_horaria(s: str) -> bool:
    return bool(_ZONA.match(s))


def es_motivo(s: str) -> bool:
    return s in ("daily", "pre-deploy")


# --- utilidades ------------------------------------------------------------


def comillas(s: str) -> str:
    """Escapa un valor para usarlo como UN argumento POSIX (comillas simples)."""
    return "'" + s.replace("'", "'\"'\"'") + "'"


def expandir_ruta(r: str) -> str:
    """Resuelve ``~`` y normaliza la ruta."""
    r = r.strip()
    if not r:
        return r
    if r == "~" or r.startswith("~/") or r.startswith("~\\"):
        return os.path.normpath(os.path.expanduser(r))
    return os.path.normpath(r)


def truncar(s: str, n: int) -> str:
    """Limita un texto a ``n`` bytes sin cortar un carácter UTF-8 a la mitad."""
    datos = s.encode("utf-8")
    if len(datos) <= n:
        return s
    return datos[:n].decode("utf-8", errors="ignore")


def cola(s: str, n: int) -> str:
    """Devuelve los últimos ``n`` bytes de ``s``."""
    datos = s.encode("utf-8")
    if len(datos) <= n:
        return s
    return datos[-n:].decode("utf-8", errors="ignore")


def sistema_operativo() -> str:
    """``windows`` | ``linux`` | ``darwin`` (informativo para la interfaz)."""
    if os.name == "nt":
        return "windows"
    return "darwin" if os.uname().sysname == "Darwin" else "linux"
