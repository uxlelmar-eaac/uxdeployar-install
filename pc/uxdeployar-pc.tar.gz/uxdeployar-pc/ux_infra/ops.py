"""Catálogo cerrado de operaciones diarias sobre el VPS (proyectos, respaldos,  # uxyngraphar:permitir-idioma
alertas, Caddy, seguridad, sistema). Espejo de ``05-vps/app/internal/ops/``.

La interfaz solo envía un identificador de operación y parámetros; cada  # uxyngraphar:permitir-idioma
parámetro se valida aquí por tipo y el comando se compone con plantillas fijas.  # uxyngraphar:permitir-idioma
Nunca se ejecuta texto libre del navegador.

Desviación documentada: la verificación de respaldos usa el binario ``age``  # uxyngraphar:permitir-idioma
del equipo del administrador (el original lo implementaba nativo en Go); el
estándar ya exige ``age``/``age-keygen`` instalados para las operaciones  # uxyngraphar:permitir-idioma
locales.
"""

from __future__ import annotations

import base64
import hashlib
import re
import socket
import ssl
import subprocess
import tempfile
import threading
from dataclasses import dataclass, field
from typing import Any, Callable

from . import util

LECTURA = "lectura"
CAMBIO = "cambio"
DESTRUCTIVO = "destructivo"

DIR_RESPALDOS_PLATAFORMA = "/var/lib/ux/backups"
MAX_DESCARGA_B64 = 400 * 1024 * 1024


class ErrorOp(Exception):
    """Uso de una operación no válido (parámetros, confirmación…)."""  # uxyngraphar:permitir-idioma


PRELUDIO = 'set -o pipefail\ndie() { echo "ERROR: $*" >&2; exit 1; }\n'


def q(s: str) -> str:
    return util.comillas(s)


def b64(s: str) -> str:
    return base64.b64encode(s.encode("utf-8")).decode("ascii")


def exportar(nombre: str, valor: str) -> str:
    return f"export {nombre}={q(valor)}\n"


def tuberia_contenido(contenido: str) -> str:
    return "printf %s " + q(b64(contenido)) + " | base64 -d"


def nl(*partes: str) -> str:
    return "\n".join(partes) + "\n"


def or_default(v: str, d: str) -> str:
    return d if not v.strip() else v


def ayuda_de_fallo(codigo: int, salida: str) -> str:
    if codigo == 0:
        return ""
    if codigo == 127 or re.search(
        r"(?:ux-[a-z]+|rclone|age|trivy|lynis)(?:: command not found|: not found|: No such file)",
        salida,
    ):
        if "ux-" in salida:
            return (
                "Falta la plataforma ux en el servidor: sus herramientas (ux-proyecto, ux-deploy, "
                "ux-respaldo, ux-alerta…) se instalan en la Fase 2, etapa E11. Completa antes esas etapas."  # uxyngraphar:permitir-idioma
            )
        if "rclone" in salida or "age" in salida:
            return "Falta una herramienta de respaldos (rclone/age): se instala en la Fase 2, etapa E14."
        if "trivy" in salida or "lynis" in salida:
            return "Falta Trivy o Lynis: instálalos desde «Seguridad → Instalar Trivy y Lynis»."  # uxyngraphar:permitir-idioma
    return ""


# ───────────────────────────── campos y validación ─────────────────────────  # uxyngraphar:permitir-idioma


@dataclass
class Campo:
    nombre: str
    etiqueta: str
    tipo: str
    obligatorio: bool = False
    secreto: bool = False
    opciones: list[str] = field(default_factory=list)
    ayuda: str = ""
    defecto: str = ""

    def json(self) -> dict:
        d = {
            "nombre": self.nombre,
            "etiqueta": self.etiqueta,
            "tipo": self.tipo,
            "obligatorio": self.obligatorio,
        }
        if self.secreto:
            d["secreto"] = True
        if self.opciones:
            d["opciones"] = self.opciones
        if self.ayuda:
            d["ayuda"] = self.ayuda
        if self.defecto:
            d["defecto"] = self.defecto
        return d


_GHCR_USER = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$")
_GHCR_TOKEN = re.compile(r"^[A-Za-z0-9_.-]{8,255}$")
_CONTENEDOR = re.compile(r"^[a-z0-9][a-z0-9_.-]{0,80}$")
_IMAGEN = re.compile(r"^[a-z0-9][a-z0-9._:/@-]{0,250}$")
_TG_TOKEN = re.compile(r"^[0-9]{5,12}:[A-Za-z0-9_-]{20,60}$")
_TG_CHAT = re.compile(r"^-?[0-9]{3,20}$")
_HORA = re.compile(r"^([01][0-9]|2[0-3]):[0-5][0-9]$")


def _errv(m: str) -> ValueError:
    return ValueError(m)


def sin_comilla_ni_control(s: str, max_: int) -> None:
    if len(s) > max_:
        raise _errv(f"máximo {max_} caracteres")  # uxyngraphar:permitir-idioma
    for r in s:
        if ord(r) < 32 or ord(r) == 127:
            raise _errv("no admite saltos de línea ni caracteres de control")  # uxyngraphar:permitir-idioma
        if r == "'":
            raise _errv("no admite comillas simples (') porque los archivos de configuración del VPS no las permiten")  # uxyngraphar:permitir-idioma


def _es_cidr(s: str) -> bool:
    """IP v4/v6 con prefijo opcional (`203.0.113.0/24`)."""
    partes = s.split("/")
    if len(partes) not in (1, 2) or not util.es_ip(partes[0]):
        return False
    if len(partes) == 1:
        return True
    return bool(re.fullmatch(r"0|[1-9][0-9]{0,2}", partes[1])) and int(partes[1]) <= (128 if ":" in partes[0] else 32)


def validar_campo(c: Campo, v: str) -> str:
    """Normaliza y valida un valor según el tipo del campo."""  # uxyngraphar:permitir-idioma
    t = c.tipo
    if t == "proyecto":
        v = v.strip()
        if not util.es_proyecto(v):
            raise _errv("nombre de proyecto no válido (minúsculas y dígitos, empieza con letra, 2–31)")  # uxyngraphar:permitir-idioma
    elif t == "usuario_podman":
        v = v.strip()
        if v != "ux-caddy" and not util.es_proyecto(v):
            raise _errv("usuario no válido")  # uxyngraphar:permitir-idioma
    elif t == "rol":
        v = v.strip()
        if not util.es_rol(v):
            raise _errv("nombre de rol no válido (minúsculas y dígitos, empieza con letra, 2–21)")  # uxyngraphar:permitir-idioma
    elif t == "dominio":
        v = v.strip().lower()
        if not util.es_dominio(v):
            raise _errv("dominio no válido (nombre completo en minúsculas, p. ej. api.tudominio.com)")  # uxyngraphar:permitir-idioma
    elif t == "tag":
        v = v.strip()
        if not util.es_tag(v):
            raise _errv("la etiqueta debe tener 12 hexadecimales (los primeros 12 del commit)")
    elif t == "respaldo":
        v = v.strip()
        if v != "ultimo" and not util.es_respaldo(v):
            raise _errv("nombre de respaldo no válido (o «ultimo»)")  # uxyngraphar:permitir-idioma
    elif t == "respaldo_exacto":
        v = v.strip()
        if not util.es_respaldo(v):
            raise _errv("nombre de respaldo no válido (p. ej. proyecto-rol-20260101-030000-pre-deploy.dump.age)")  # uxyngraphar:permitir-idioma
    elif t == "motivo":
        v = v.strip()
        if not util.es_motivo(v):
            raise _errv("el motivo debe ser daily o pre-deploy")
    elif t == "ip":
        v = v.strip()
        if not util.es_ip(v):
            raise _errv("dirección IP no válida")  # uxyngraphar:permitir-idioma
    elif t == "cidr":
        v = v.strip()
        if not _es_cidr(v):
            raise _errv("IP o red no válida (p. ej. 203.0.113.7 o 203.0.113.0/24)")  # uxyngraphar:permitir-idioma
    elif t == "origenes":
        partes = [x for x in re.split(r"[\s,]+", v.strip()) if x]
        if len(partes) > 20:
            raise _errv("como máximo 20 IPs o redes")  # uxyngraphar:permitir-idioma
        for x in partes:
            if not _es_cidr(x):
                raise _errv(f"«{x}» no es una IP o red válida")  # uxyngraphar:permitir-idioma
        v = ",".join(partes)
    elif t == "llave_ci":
        v = v.strip()
        if "\r" in v or "\n" in v or not util.es_llave_ci(v) or len(v) > 800:
            raise _errv("debe ser UNA llave pública en una línea (ssh-ed25519 … o ecdsa-sha2-…)")  # uxyngraphar:permitir-idioma
    elif t == "age":
        v = v.strip().replace(" ", "")
        if not util.es_age_recipients(v):
            raise _errv("claves públicas age1… separadas por coma, sin espacios")  # uxyngraphar:permitir-idioma
    elif t == "cuenta_r2":
        v = v.strip()
        if not util.es_account_r2(v):
            raise _errv("el Account ID de Cloudflare son 32 caracteres hexadecimales")
    elif t == "clave_r2":
        v = v.strip()
        if not util.es_alfanumerico(v) or len(v) > 128:
            raise _errv("solo letras y dígitos (hasta 128)")  # uxyngraphar:permitir-idioma
    elif t == "prefijo_vps":
        v = v.strip()
        if not util.es_prefijo_vps(v):
            raise _errv("prefijo no válido (minúsculas, dígitos y guiones, hasta 40)")  # uxyngraphar:permitir-idioma
    elif t == "bucket":
        v = v.strip()
        if not util.es_bucket(v):
            raise _errv("nombre de bucket no válido (minúsculas, dígitos y guiones)")  # uxyngraphar:permitir-idioma
    elif t == "ghcr_user":
        v = v.strip()
        if not _GHCR_USER.match(v):
            raise _errv("usuario de GitHub no válido")  # uxyngraphar:permitir-idioma
    elif t == "ghcr_token":
        v = v.strip()
        if not _GHCR_TOKEN.match(v):
            raise _errv("token no válido (letras, dígitos, _ . -; 8–255)")  # uxyngraphar:permitir-idioma
    elif t == "email":
        util.validar_email(v)
    elif t == "emails":
        v = v.strip().replace(" ", "")
        for e in v.split(","):
            util.validar_email(e)
            if "'" in e:
                raise _errv("el correo no puede contener comillas")
    elif t == "host":
        return util.validar_host(v)
    elif t == "puerto":
        return str(util.validar_puerto(v))
    elif t == "tg_token":
        v = v.strip()
        if not _TG_TOKEN.match(v):
            raise _errv("token de bot no válido (formato 123456:ABC…)")  # uxyngraphar:permitir-idioma
    elif t == "tg_chat":
        v = v.strip()
        if not _TG_CHAT.match(v):
            raise _errv("chat id no válido (número, puede empezar con -)")  # uxyngraphar:permitir-idioma
    elif t == "hora":
        v = v.strip()
        if not _HORA.match(v):
            raise _errv("hora HH:MM")
    elif t in ("texto_env", "secreto_env"):
        v = v.strip()
        sin_comilla_ni_control(v, 200)
    elif t == "contenedor":
        v = v.strip()
        if not _CONTENEDOR.match(v):
            raise _errv("nombre de contenedor no válido")  # uxyngraphar:permitir-idioma
    elif t == "imagen":
        v = v.strip()
        if not _IMAGEN.match(v):
            raise _errv("referencia de imagen no válida (minúsculas, p. ej. ghcr.io/dueño/repo:abc123def456)")  # uxyngraphar:permitir-idioma
    elif t == "lineas":
        try:
            n = int(v.strip())
        except ValueError:
            raise _errv("entre 10 y 2000 líneas") from None  # uxyngraphar:permitir-idioma
        if n < 10 or n > 2000:
            raise _errv("entre 10 y 2000 líneas")  # uxyngraphar:permitir-idioma
        v = str(n)
    elif t == "select":
        v = v.strip()
        if v not in c.opciones:
            raise _errv("opción no permitida")  # uxyngraphar:permitir-idioma
    elif t == "bool":
        if v.strip().lower() in ("1", "true", "si", "sí", "on"):  # uxyngraphar:permitir-idioma
            return "si"
        if v.strip().lower() in ("0", "false", "no", "off", ""):
            return ""
        raise _errv("valor sí/no")  # uxyngraphar:permitir-idioma
    elif t == "contenido":
        if len(v) == 0:
            raise _errv("el archivo está vacío")  # uxyngraphar:permitir-idioma
        if len(v) > 1024 * 1024:
            raise _errv("el archivo supera 1 MiB")
        if "\x00" in v:
            raise _errv("el archivo debe ser texto UTF-8")
    elif t == "ruta_local":
        import os

        v = util.expandir_ruta(v)
        if not os.path.exists(v):
            raise _errv("no encuentro ese archivo o carpeta en este equipo")
    elif t == "texto":
        v = v.strip()
        if len(v) > 300:
            raise _errv("demasiado largo")
        if any(ord(r) < 32 or ord(r) == 127 for r in v):
            raise _errv("sin caracteres de control")
    else:
        raise _errv("tipo de campo desconocido: " + t)
    return v


# ───────────────────────────── operación ─────────────────────────  # uxyngraphar:permitir-idioma


class Resultado:
    def __init__(self, codigo: int = 0, salida: str = "", datos: Any = None, ayuda: str = ""):
        self.codigo = codigo
        self.salida = salida
        self.datos = datos
        self.ayuda = ayuda

    def json(self) -> dict:
        d: dict = {"codigo": self.codigo, "salida": self.salida}
        if self.datos is not None:
            d["datos"] = self.datos
        if self.ayuda:
            d["ayuda"] = self.ayuda
        return d


FuncionOp = Callable[["Entorno", dict, Callable[[str], None] | None], Resultado]


class Op:
    """Una operación del catálogo."""  # uxyngraphar:permitir-idioma

    def __init__(
        self,
        id_: str,
        panel: str,
        titulo: str,
        descripcion: str,
        riesgo: str,
        campos: list[Campo] | None = None,
        *,
        largo: bool = False,
        reinicia: bool = False,
        confirma: str = "",
        local: bool = False,
        script: Callable[[dict], str] | None = None,
        sin_sudo: bool = False,
        parser: Callable[[str], Any] | None = None,
        ejecutar: FuncionOp | None = None,
    ) -> None:
        self.id = id_
        self.panel = panel
        self.titulo = titulo
        self.descripcion = descripcion
        self.riesgo = riesgo
        self.campos = campos or []
        self.largo = largo
        self.reinicia = reinicia
        self.confirma = confirma
        self.local = local
        self._script = script
        self.sin_sudo = sin_sudo
        self._parser = parser
        self._ejecutar = ejecutar

    def json(self) -> dict:
        d = {
            "id": self.id,
            "panel": self.panel,
            "titulo": self.titulo,
            "descripcion": self.descripcion,
            "riesgo": self.riesgo,
            "campos": [c.json() for c in self.campos],
        }
        if self.largo:
            d["largo"] = True
        if self.reinicia:
            d["reinicia"] = True
        if self.confirma:
            d["confirmacion"] = self.confirma
        if self.local:
            d["local"] = True
        return d

    def confirmacion(self, p: dict) -> str:
        t = self.confirma
        for k, v in p.items():
            t = t.replace("{" + k + "}", v)
        return t

    def validar(self, raw: dict) -> dict:
        declarados = {c.nombre: c for c in self.campos}
        for k in raw:
            if k == "confirmar":
                continue
            if k not in declarados:
                raise ErrorOp(f"parámetro desconocido {k!r}")  # uxyngraphar:permitir-idioma
        p: dict = {}
        for c in self.campos:
            v = raw.get(c.nombre, "")
            if not v or (not v.strip() and c.tipo != "contenido"):
                if c.defecto and not c.secreto:
                    v = c.defecto
                else:
                    v = ""
            if v == "":
                if c.obligatorio:
                    raise ErrorOp(f"falta «{c.etiqueta}»")  # uxyngraphar:permitir-idioma
                p[c.nombre] = ""
                continue
            try:
                p[c.nombre] = validar_campo(c, v)
            except ValueError as exc:
                raise ErrorOp(f"{c.etiqueta}: {exc}") from exc
        if self.riesgo == DESTRUCTIVO:
            esperado = self.confirmacion(p)
            if str(raw.get("confirmar", "")).strip() != esperado:
                raise ErrorOp(f"operación destructiva: teclea exactamente «{esperado}» para confirmar")  # uxyngraphar:permitir-idioma
        return p

    def script_para(self, p: dict) -> str:
        if self._script is None:
            raise ErrorOp("la operación no se compone de un único script")  # uxyngraphar:permitir-idioma
        return self._script(p)

    def correr(self, e: "Entorno", p: dict, emitir: Callable[[str], None] | None) -> Resultado:
        if self._ejecutar is not None:
            return self._ejecutar(e, p, emitir)
        script = self.script_para(p)
        if self.sin_sudo:
            r = e.ses.plano(script, emitir)
        else:
            r = e.ses.sudo(script, emitir)
        res = Resultado(codigo=r.codigo, salida=salida_combinada(r))
        res.ayuda = ayuda_de_fallo(r.codigo, res.salida)
        if res.ayuda and emitir is not None:
            emitir("\n→ " + res.ayuda + "\n")  # uxyngraphar:permitir-idioma
        if self._parser is not None:
            res.datos = self._parser(r.stdout)
        return res


def salida_combinada(r) -> str:
    s = r.stdout.rstrip("\n")
    e2 = r.stderr.rstrip("\n")
    if e2:
        if s:
            s += "\n"
        s += e2
    return s


class Entorno:
    def __init__(self, ses) -> None:
        self.ses = ses


# ───────────────────────────── catálogo ─────────────────────────  # uxyngraphar:permitir-idioma


_CAMPO_PROYECTO = Campo("proyecto", "Proyecto", "proyecto", True)
_CAMPO_ROL = Campo("rol", "Rol", "rol", True)


class Catalogo:
    def __init__(self) -> None:
        self._ops: dict[str, Op] = {}
        self._orden: list[str] = []
        for grupo in (_sistema_ops(), _proyectos_ops(), _respaldos_ops(), _alertas_ops(), _caddy_ops(), _seguridad_ops()):
            for o in grupo:
                self._registrar(o)

    def _registrar(self, o: Op) -> None:
        if o.id in self._ops:
            raise ValueError("operación duplicada: " + o.id)  # uxyngraphar:permitir-idioma
        if o.riesgo == DESTRUCTIVO and not o.confirma:
            raise ValueError("operación destructiva sin confirmación: " + o.id)  # uxyngraphar:permitir-idioma
        self._ops[o.id] = o
        self._orden.append(o.id)

    def lista(self) -> list[Op]:
        return [self._ops[i] for i in self._orden]

    def buscar(self, id_: str) -> Op | None:
        return self._ops.get(id_)

    def ejecutar(self, e: Entorno, id_: str, raw: dict, emitir: Callable[[str], None] | None) -> Resultado:
        o = self._ops.get(id_)
        if o is None:
            raise ErrorOp("operación desconocida")  # uxyngraphar:permitir-idioma
        p = o.validar(raw)
        return o.correr(e, p, emitir)


# ───────────────────────────── sistema ─────────────────────────  # uxyngraphar:permitir-idioma


def _sistema_ops() -> list[Op]:
    return [
        Op(
            "sistema.state", "sistema", "Estado general del servidor",
            "Sistema, carga, memoria, disco, reinicio pendiente, hora, puerto SSH y si Caddy está en marcha.", LECTURA,  # uxyngraphar:permitir-idioma
            parser=parsear_kv,
            script=lambda p: PRELUDIO + nl(
                ". /etc/os-release 2>/dev/null",
                'echo "host=$(hostname -f 2>/dev/null || hostname)"',
                'echo "os=${PRETTY_NAME:-desconocido}"',
                'echo "kernel=$(uname -r)"',
                'echo "uptime=$(uptime -p 2>/dev/null)"',
                'echo "carga=$(cut -d\' \' -f1-3 /proc/loadavg)"',
                'free -m | awk \'/^Mem:/{printf "memoria=%s de %s MiB en uso\\n",$3,$2}\'',
                'df -h / | awk \'NR==2{printf "disco=%s de %s en uso (%s)\\n",$3,$2,$5}\'',
                'if [ -f /var/run/reboot-required ]; then echo "reinicio=pendiente"; else echo "reinicio=no"; fi',
                'echo "zona=$(timedatectl show -p Timezone --value 2>/dev/null)"',
                'echo "ntp=$(timedatectl show -p NTPSynchronized --value 2>/dev/null)"',
                'echo "ssh_puerto=$(sudo sshd -T 2>/dev/null | awk \'$1=="port"{print $2; exit}\')"',
                'echo "actualizaciones=$(apt list --upgradable 2>/dev/null | grep -c upgradable)"',
                'echo "contrato_deploy=$(ux-deploy contrato 2>/dev/null | sed -n \'s/^ux-contrato=//p\' | head -n1)"',
                'echo "deploy_rev=$(ux-deploy contrato 2>/dev/null | sed -n \'s/^ux-deploy-rev=//p\' | head -n1)"',
                'echo "usuario=$(id -un)"',
                'if ! id ux-caddy >/dev/null 2>&1; then echo "caddy=no instalado (E12)"; '
                'elif [ "$(sudo ux-as ux-caddy podman container inspect -f \'{{.State.Running}}\' caddy 2>/dev/null)" = true ]; '
                'then echo "caddy=en ejecución"; else echo "caddy=detenido"; fi',  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.servicios", "sistema", "Servicios del sistema",
            "Estado de SSH, fail2ban, firewall, actualizaciones automáticas y del temporizador de respaldos.", LECTURA,  # uxyngraphar:permitir-idioma
            parser=parsear_kv,
            script=lambda p: PRELUDIO + nl(
                "for u in ssh fail2ban ufw unattended-upgrades ux-backup-platform.timer; do",
                '  printf \'%s=%s\\n\' "$u" "$(systemctl is-active "$u" 2>/dev/null || true)"',
                "done",
                'echo "fallidas=$(systemctl --failed --no-legend --plain 2>/dev/null | awk \'{print $1}\' | paste -sd, -)"',
            ),
        ),
        Op(
            "sistema.puertos", "sistema", "Puertos a la escucha",
            "Solo SSH, 80 y 443 deben escuchar fuera de loopback.", LECTURA,
            script=lambda p: PRELUDIO + "sudo ss -ltnup 2>/dev/null | awk 'NR==1 || /LISTEN|UNCONN/'\n",
        ),
        Op(
            "sistema.timers", "sistema", "Temporizadores programados",
            "Respaldos de la plataforma y de cada proyecto.", LECTURA,
            script=lambda p: PRELUDIO + nl(
                'echo "== Plataforma"',
                "systemctl list-timers --all --no-pager 'ux-*' 2>/dev/null",
                "for d in /etc/ux/projects/*/; do",
                '  [ -d "$d" ] || continue',
                '  p="$(basename "$d")"',
                '  echo; echo "== Proyecto $p"',
                '  sudo ux-as "$p" systemctl --user list-timers --all --no-pager 2>&1 | head -n 20',
                "done",
            ),
        ),
        Op(
            "sistema.journal", "sistema", "Registro del sistema (journal)",
            "Últimas líneas del registro de un servicio.", LECTURA,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("unidad", "Servicio", "select", True, defecto="ssh",
                      opciones=["ssh", "fail2ban", "ufw", "unattended-upgrades", "ux-backup-platform", "systemd-networkd", "podman-restart"]),
                Campo("lineas", "Líneas", "lineas", defecto="100"),  # uxyngraphar:permitir-idioma
            ],
            script=lambda p: PRELUDIO + "sudo journalctl -u " + q(p["unidad"]) + " -n " + q(or_default(p["lineas"], "100")) + " --no-pager\n",
        ),
        Op(
            "sistema.actualizar", "sistema", "Actualizar el sistema operativo",
            "apt update + apt upgrade (rutina mensual, E15.3). No reinicia: te avisa si hace falta.", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + nl(
                'sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y || die "apt update falló"',  # uxyngraphar:permitir-idioma
                'sudo env DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -o Dpkg::Options::=--force-confold || die "apt upgrade falló"',  # uxyngraphar:permitir-idioma
                'if [ -f /var/run/reboot-required ]; then echo; echo "REINICIO PENDIENTE: programa una ventana controlada y usa «Reiniciar servidor»."; else echo; echo "No hace falta reiniciar."; fi',  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.reiniciar", "sistema", "Reiniciar el servidor",
            "Reinicia el VPS en unos segundos. Los contenedores con política de reinicio vuelven solos; después reconecta.",  # uxyngraphar:permitir-idioma
            DESTRUCTIVO, reinicia=True, confirma="REINICIAR",
            script=lambda p: PRELUDIO + nl(
                'sudo systemd-run --no-block --on-active=3s /usr/bin/systemctl reboot >/dev/null 2>&1 || die "no pude programar el reinicio"',
                'echo "Reinicio programado en 3 segundos. Espera ~1 minuto y reconecta."',
            ),
        ),
        Op(
            "sistema.limpiar", "sistema", "Liberar imágenes sin uso",  # uxyngraphar:permitir-idioma
            "podman image prune de uno o de todos los proyectos (ux-deploy ya conserva las 3 imágenes recientes).",  # uxyngraphar:permitir-idioma
            CAMBIO, largo=True,
            campos=[Campo("usuario", "Proyecto (vacío = todos)", "usuario_podman")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO
            + 'limpiar() { echo "== $1"; sudo ux-as "$1" podman image prune -f 2>&1 | tail -n 5; sudo ux-as "$1" podman system df 2>&1 | head -n 6; }\n'
            + (
                "limpiar " + q(p["usuario"]) + "\n"
                if p["usuario"]
                else nl(
                    'for d in /etc/ux/projects/*/; do [ -d "$d" ] && limpiar "$(basename "$d")"; done',
                    "df -h / | tail -n 1",
                )
            ),
        ),
        Op(
            "sistema.podman_diagnostico", "sistema", "Diagnóstico de Podman rootless",  # uxyngraphar:permitir-idioma
            "Comprobación exacta de E11 (Podman rootless) y causas habituales: linger, sesión de usuario, runtime, subuid/subgid, newuidmap, archivos de root, disco y unshare. De uno o de todos los proyectos.",  # uxyngraphar:permitir-idioma
            LECTURA,
            campos=[Campo("usuario", "Proyecto (vacío = todos)", "usuario_podman")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO
            + nl(
                "diag() {",
                "  u=$1",
                "  uid=$(id -u \"$u\" 2>/dev/null) || { echo \"== $u: el usuario no existe\"; return 0; }",
                "  home=$(getent passwd \"$u\" | cut -d: -f6)",
                "  echo; echo \"== $u (uid $uid)\"",
                "  v=$(sudo ux-as \"$u\" podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null)",
                "  li=$(loginctl show-user \"$u\" -p Linger --value 2>/dev/null)",
                "  se=$(systemctl is-active \"user@$uid.service\" 2>/dev/null)",
                "  su=$(grep -c \"^$u:\" /etc/subuid); sg=$(grep -c \"^$u:\" /etc/subgid)",
                "  r=$(sudo find \"$home/.local/share/containers\" \"$home/.config/containers\" \"/run/user/$uid/containers\" \"/run/user/$uid/libpod\" -xdev -user 0 2>/dev/null | head -n 100 | wc -l)",
                "  echo \"verificador=${v:-sin respuesta} (E11 espera true)\"",
                "  echo \"linger=${li:-no} sesion=${se:-inactiva} runtime=$(stat -c '%U %a' \"/run/user/$uid\" 2>/dev/null || echo falta)\"",
                "  echo \"subuid=$su subgid=$sg newuidmap=$(stat -c %A /usr/bin/newuidmap 2>/dev/null) $(getcap /usr/bin/newuidmap 2>/dev/null | awk '{print $2}')\"",
                "  echo \"archivos_de_root=$r libre_home=$(df -h --output=avail \"$home\" 2>/dev/null | tail -n 1 | tr -d ' ')\"",
                "  if o=$(sudo ux-as \"$u\" podman unshare true 2>&1); then echo \"unshare=ok\"; else echo \"unshare=falla: $(printf '%s' \"$o\" | tail -n 3)\"; fi",
                "  [ \"$li\" = yes ] || echo \"pista: falta linger → «Reparar Podman rootless de un proyecto»\"",  # uxyngraphar:permitir-idioma
                "  [ \"$se\" = active ] || echo \"pista: la sesión user@$uid no corre → «Reparar Podman rootless de un proyecto»\"",  # uxyngraphar:permitir-idioma
                "  [ \"$su\" -gt 0 ] && [ \"$sg\" -gt 0 ] || echo \"pista: sin rangos subuid/subgid → repite el alta del proyecto (E13)\"",  # uxyngraphar:permitir-idioma
                "  [ \"$r\" -eq 0 ] || echo \"pista: archivos de root en su almacenamiento → «Reparar Podman rootless de un proyecto»\"",  # uxyngraphar:permitir-idioma
                "  if [ \"$v\" != true ]; then echo \"-- podman info\"; sudo ux-as \"$u\" podman info 2>&1 | tail -n 20; fi",
                "}",
            )
            + (
                "diag " + q(p["usuario"]) + "\n"
                if p["usuario"]
                else 'for d in /etc/ux/projects/*/; do [ -d "$d" ] && diag "$(basename "$d")"; done\n'
            ),
        ),
        Op(
            "sistema.paquetes", "sistema", "Paquetes pendientes y retenidos",
            "Lista lo que falta actualizar y lo retenido (apt-mark hold o «Not upgrading»).", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get update -qq >/dev/null 2>&1 || echo \"AVISO: apt-get update falló\"",  # uxyngraphar:permitir-idioma
                "echo \"== Pendientes\"",
                "apt list --upgradable 2>/dev/null | tail -n +2",
                "echo; echo \"== Retenidos con apt-mark hold\"",
                "apt-mark showhold",
                "echo; echo \"== Simulación de apt-get upgrade (lo que se quedaría sin actualizar)\"",  # uxyngraphar:permitir-idioma
                "apt-get -s upgrade 2>/dev/null | sed -n '/kept back\\|Not upgrading/,/^[^ ]/p'",
            ),
        ),
        Op(
            "sistema.actualizar_completo", "sistema", "Actualización completa (full-upgrade)",  # uxyngraphar:permitir-idioma
            "apt full-upgrade + autoremove: instala también lo que apt upgrade retiene (p. ej. paquetes con dependencias nuevas).", CAMBIO, largo=True,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y || die \"apt update falló\"",  # uxyngraphar:permitir-idioma
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get full-upgrade -y -o Dpkg::Options::=--force-confold || die \"apt full-upgrade falló\"",  # uxyngraphar:permitir-idioma
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get autoremove -y",
                "echo; echo \"Pendientes tras actualizar: $(apt list --upgradable 2>/dev/null | grep -c upgradable)\"",
                "if [ -f /var/run/reboot-required ]; then echo \"REINICIO PENDIENTE: programa una ventana controlada y usa «Reiniciar servidor».\"; else echo \"No hace falta reiniciar.\"; fi",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.procesos", "sistema", "Procesos que más consumen",  # uxyngraphar:permitir-idioma
            "Los 15 procesos con más CPU y los 15 con más memoria.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "echo \"== Por CPU\"",
                "ps -eo pid,user:16,%cpu,%mem,etime,comm --sort=-%cpu | head -n 16",
                "echo; echo \"== Por memoria\"",
                "ps -eo pid,user:16,%cpu,%mem,rss,comm --sort=-%mem | head -n 16",
            ),
        ),
        Op(
            "sistema.disco", "sistema", "Uso de disco detallado",
            "Sistemas de archivos, carpetas más pesadas de /var y /home, journal y almacenamiento de Podman por proyecto.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "echo \"== Sistemas de archivos\"",
                "df -h -x tmpfs -x devtmpfs -x overlay",
                "echo; echo \"== /var\"",
                "sudo du -xh --max-depth=1 /var 2>/dev/null | sort -rh | head -n 10",
                "echo; echo \"== /home\"",
                "sudo du -xh --max-depth=1 /home 2>/dev/null | sort -rh | head -n 10",
                "echo; echo \"== Journal\"",
                "sudo journalctl --disk-usage",
                "for d in /etc/ux/projects/*/; do",
                "  [ -d \"$d\" ] || continue",
                "  p=\"$(basename \"$d\")\"",
                "  echo; echo \"== Podman de $p\"",
                "  sudo ux-as \"$p\" podman system df 2>&1 | head -n 6",
                "done",
            ),
        ),
        Op(
            "sistema.journal_limpiar", "sistema", "Recortar el journal",
            "Borra registros del journal más antiguos que los días elegidos.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("dias", "Conservar (días)", "select", True, defecto="30", opciones=["7", "14", "30", "90"]),  # uxyngraphar:permitir-idioma
            ],
            script=lambda p: PRELUDIO + nl(
                "sudo journalctl --vacuum-time=" + q(p["dias"]) + "d",
                "sudo journalctl --disk-usage",
            ),
        ),
        Op(
            "sistema.servicio_reiniciar", "sistema", "Reiniciar un servicio del sistema",
            "systemctl restart de un servicio de la lista y su estado. SSH valida la configuración antes y no corta la sesión actual.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("unidad", "Servicio", "select", True, defecto="fail2ban", opciones=["ssh", "fail2ban", "crowdsec", "ufw", "unattended-upgrades", "auditd", "systemd-resolved", "cron"]),
            ],
            script=lambda p: PRELUDIO + nl(
                "u=" + q(p["unidad"]),
                "if [ \"$u\" = ssh ]; then sudo sshd -t || die \"sshd -t falló: no reinicio SSH\"; fi",  # uxyngraphar:permitir-idioma
                "sudo systemctl restart \"$u\" || die \"no pude reiniciar $u\"",
                "sleep 1",
                "sudo systemctl status \"$u\" --no-pager -n 15",
            ),
        ),
        Op(
            "sistema.docker_detectar", "sistema", "Detectar Docker o Swarm",
            "La plataforma usa Podman rootless: Docker sobra y publica puertos saltándose UFW. Muestra si está instalado, activo o en Swarm, paquetes retenidos, contenedores, servicios y qué proceso abre cada puerto fuera de loopback.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "echo \"binario=$(command -v docker || echo no)\"",
                "echo \"servicio=$(systemctl is-active docker 2>/dev/null || true)\"",
                "echo \"paquetes=$(dpkg-query -W -f='${Package} ' 'docker*' containerd.io 2>/dev/null | tr -s ' ')\"",
                "echo \"repositorio=$(ls /etc/apt/sources.list.d/ 2>/dev/null | grep -i docker | paste -sd, -)\"",
                "echo \"retenidos=$(apt-mark showhold 2>/dev/null | paste -sd, -)\"",
                "if command -v docker >/dev/null 2>&1; then echo \"swarm=$(sudo docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null)\"; echo \"contenedores=$(sudo docker ps -q 2>/dev/null | wc -l)\"; fi",
                "echo \"puertos_swarm=$(sudo ss -Htulpn 2>/dev/null | awk '$5 ~ /:(2377|7946|4789)$/{print $5}' | paste -sd, -)\"",
                "if command -v docker >/dev/null 2>&1; then",
                "  echo; echo \"== Contenedores (todos)\"",
                "  sudo docker ps -a --format 'table {{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}' 2>&1",
                "  if [ \"$(sudo docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null)\" = active ]; then echo; echo \"== Servicios Swarm\"; sudo docker service ls 2>&1; fi",
                "fi",
                "echo; echo \"== Puertos fuera de loopback (con su proceso)\"",
                "sudo ss -Hltnup 2>/dev/null | awk '$5 !~ /^(127\\.|\\[::1\\]|\\[::ffff:127\\.)/' || true",
            ),
        ),
        Op(
            "sistema.docker_retirar", "sistema", "Retirar Docker",
            "Sale de Swarm, detiene Docker, quita el hold de sus paquetes, los purga y quita su repositorio. /var/lib/docker se conserva. Reinicia después para limpiar sus reglas de iptables.", DESTRUCTIVO, largo=True, confirma="RETIRAR DOCKER",  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "if command -v docker >/dev/null 2>&1; then",
                "  sudo docker swarm leave --force 2>/dev/null || true",
                "  sudo docker ps -q 2>/dev/null | xargs -r sudo docker stop",
                "fi",
                "sudo systemctl disable --now docker.service docker.socket containerd.service 2>/dev/null || true",
                "held=$(apt-mark showhold 2>/dev/null | grep -E '^(docker|containerd)' | paste -sd' ' - || true)",
                "if [ -n \"$held\" ]; then sudo apt-mark unhold $held || die \"no pude quitar el hold de: $held\"; fi",
                "pkgs=$(dpkg-query -W -f='${Package} ${Status}\\n' 'docker*' containerd.io 2>/dev/null | awk '/ installed$/{print $1}')",
                "if [ -n \"$pkgs\" ]; then sudo env DEBIAN_FRONTEND=noninteractive apt-get purge -y $pkgs || die \"apt purge falló\"; else echo \"Docker no estaba instalado.\"; fi",  # uxyngraphar:permitir-idioma
                "sudo rm -f /etc/apt/sources.list.d/docker.list /etc/apt/sources.list.d/docker.sources /etc/apt/keyrings/docker.asc /etc/apt/keyrings/docker.gpg",
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get update -qq || true",
                "sudo env DEBIAN_FRONTEND=noninteractive apt-get autoremove -y",
                "echo; echo \"Docker retirado. Datos conservados en /var/lib/docker (bórralos a mano si no los necesitas).\"",  # uxyngraphar:permitir-idioma
                "echo \"Reinicia el servidor para limpiar las cadenas DOCKER de iptables y vuelve a «Verificar plataforma y proyectos».\"",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.podman_reparar", "sistema", "Reparar Podman rootless de un proyecto",
            "Activa linger y podman-restart.service (autoarranque tras reiniciar el VPS), arranca la sesión systemd del usuario, le devuelve los archivos de root de su almacenamiento, retira runtime huérfano y el proceso pause, ejecuta podman system migrate y comprueba que responde.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("usuario", "Proyecto", "usuario_podman", True),
            ],
            script=lambda p: PRELUDIO + "u=" + q(p["usuario"]) + "\n" + nl(
                "uid=$(id -u \"$u\") || die \"el usuario $u no existe\"",
                "home=$(getent passwd \"$u\" | cut -d: -f6)",
                "sudo loginctl enable-linger \"$u\"",
                "sudo systemctl start \"user@$uid.service\" || die \"no arrancó user@$uid.service\"",  # uxyngraphar:permitir-idioma
                "echo \"▸ Antes: $(sudo ls -lad \"$home\" \"$home/.config\" \"$home/.local\" 2>&1 | tr \"\\n\" \" | \")\"",  # uxyngraphar:permitir-idioma
                "sudo lsattr -d \"$home/.config\" 2>/dev/null || true",
                "sudo /bin/chown \"$u:$u\" \"$home\" 2>/dev/null || true",
                "for sub in .config .local .cache; do",
                "  sudo test -e \"$home/$sub\" || continue",
                "  echo \"▸ reparando dueño de $home/$sub\"",  # uxyngraphar:permitir-idioma
                "  sudo chattr -R -i \"$home/$sub\" 2>/dev/null || sudo chattr -i \"$home/$sub\" 2>/dev/null || true",
                "  sudo /bin/chown -R \"$u:$u\" \"$home/$sub\" 2>&1 || true",
                "  if [ \"$(sudo stat -c %u \"$home/$sub\")\" != \"$uid\" ]; then",
                "    echo \"▸ chown no pegó; aparto $home/$sub y creo uno nuevo de $u\"",  # uxyngraphar:permitir-idioma
                "    sello=$(date +%Y%m%d%H%M%S)",
                "    sudo mv \"$home/$sub\" \"$home/$sub.roto-$sello\"",
                "    sudo mkdir -p \"$home/$sub\"",
                "    sudo /bin/chown -R \"$u:$u\" \"$home/$sub\"",
                "  fi",
                "  [ \"$(sudo stat -c %u \"$home/$sub\")\" = \"$uid\" ] || die \"no pude dejar $home/$sub en uid $uid\"",
                "done",
                "echo \"▸ Después: $(sudo ls -lad \"$home\" \"$home/.config\" \"$home/.local\" 2>&1 | tr \"\\n\" \" | \")\"",  # uxyngraphar:permitir-idioma
                "n=$(sudo find \"$home/.local/share/containers\" \"$home/.config/containers\" -xdev ! -user \"$uid\" 2>/dev/null | wc -l)",
                "if [ \"$n\" -gt 0 ]; then echo \"Devuelvo a $u $n archivo(s) ajenos en carpetas de contenedores.\"; sudo find \"$home/.local/share/containers\" \"$home/.config/containers\" -xdev ! -user \"$uid\" -exec /bin/chown -h \"$u:$u\" {} + 2>/dev/null; fi",
                "for d in \"/run/user/$uid/containers\" \"/run/user/$uid/libpod\"; do if [ -e \"$d\" ] && [ \"$(stat -c %u \"$d\")\" != \"$uid\" ]; then echo \"Retiro runtime huérfano de otro dueño: $d\"; sudo rm -rf \"$d\"; fi; done",  # uxyngraphar:permitir-idioma
                "sudo pkill -u \"$u\" -x catatonit 2>/dev/null || true",
                "sudo chmod 755 /etc/ux /etc/ux/projects 2>/dev/null || true",
                "sudo chmod 755 /etc/ux/projects/\"$u\" 2>/dev/null || true",
                "sudo ux-as \"$u\" podman system migrate 2>&1 | tail -n 20",
                "if [ \"$(sudo ux-as \"$u\" podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null)\" = true ]; then echo \"Podman de $u responde.\"; else echo \"Podman de $u sigue sin responder:\"; sudo ux-as \"$u\" id; sudo ux-as \"$u\" sh -c \"ls -lad \\$HOME \\$HOME/.config; stat -c %u:%g:%n \\$HOME/.config\"; sudo ux-as \"$u\" podman info 2>&1 | tail -n 30; echo \"Último recurso: «Apartar el almacenamiento de Podman de un proyecto».\"; exit 1; fi",  # uxyngraphar:permitir-idioma
                "echo; echo \"== Autoarranque tras reiniciar\"",
                "if [ \"$(loginctl show-user \"$u\" -p Linger --value 2>/dev/null)\" = yes ]; then echo \"✔ linger activo\"; else die \"linger no quedó activo para $u\"; fi",  # uxyngraphar:permitir-idioma
                "if [ \"$(sudo ux-as \"$u\" systemctl --user is-enabled podman-restart.service 2>/dev/null)\" = enabled ]; then echo \"✔ podman-restart.service habilitado\"; else sudo ux-as \"$u\" systemctl --user enable podman-restart.service >/dev/null 2>&1 || die \"no pude habilitar podman-restart.service de $u (¿E10 aplicada?)\"; echo \"→ podman-restart.service habilitado\"; fi",  # uxyngraphar:permitir-idioma
                "[ \"$(sudo ux-as \"$u\" systemctl --user is-enabled podman-restart.service 2>/dev/null)\" = enabled ] || die \"podman-restart.service de $u no quedó habilitado: tras reiniciar, sus contenedores no arrancarían solos\"",  # uxyngraphar:permitir-idioma
                "echo; echo \"== Política de reinicio de contenedores\"",  # uxyngraphar:permitir-idioma
                "sudo ux-as \"$u\" podman ps -a --format \"{{.Names}}\" 2>/dev/null | while read -r name; do",
                "  [ -n \"$name\" ] || continue",
                "  pol=$(sudo ux-as \"$u\" podman inspect -f \"{{.HostConfig.RestartPolicy.Name}}\" \"$name\" 2>/dev/null)",
                "  case \"$pol\" in unless-stopped|always) echo \"✔ $name: restart=$pol\" ;; *) echo \"· $name: restart=${pol:-?} (no vuelve solo tras reiniciar el VPS hasta Arrancar en Entrega)\" ;; esac",  # uxyngraphar:permitir-idioma
                "done",
            ),
        ),
        # Reparación de las faltas de E11 (espejo de catalogo/ops.sistema.reparacion.ts).  # uxyngraphar:permitir-idioma
        Op(
            "sistema.puertos_origen", "sistema", "Origen de los puertos externos",
            "Mismo criterio que la verificación de E11 (TCP y UDP fuera de loopback, salvo SSH, 80, 443 y los aprobados en VPS → Puertos): por cada puerto, proceso, usuario, unidad systemd, contenedor dueño y remedio sugerido.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + _FN_PUERTOS + nl(
                "remedio() {",
                "  case \"$clase\" in",
                "    swarm) echo \"«Retirar Docker» y reiniciar el servidor\" ;;",  # uxyngraphar:permitir-idioma
                "    docker) echo \"«Cerrar un puerto externo» detiene el contenedor; si Docker sobra, «Retirar Docker»\" ;;",  # uxyngraphar:permitir-idioma
                "    podman) echo \"publicar en 127.0.0.1 en el compose de $usr y redesplegar; «Cerrar un puerto externo» lo detiene ya\" ;;",  # uxyngraphar:permitir-idioma
                "    protegido) echo \"unidad protegida ($objetivo): no se cierra desde aquí\" ;;",  # uxyngraphar:permitir-idioma
                "    servicio) echo \"«Cerrar un puerto externo» desactiva $objetivo\" ;;",  # uxyngraphar:permitir-idioma
                "    usuario) echo \"«Cerrar un puerto externo» desactiva la unidad de usuario $objetivo de $usr\" ;;",  # uxyngraphar:permitir-idioma
                "    *) echo \"«Cerrar un puerto externo» termina el proceso $objetivo\" ;;",  # uxyngraphar:permitir-idioma
                "  esac",
                "}",
                "n=0; a=0",
                "while read -r proto _ _ _ local _ proc; do",
                "  [ -n \"$local\" ] || continue",
                "  port=${local##*:}",
                "  case \"$port\" in \"${sshp:-22}\"|80|443) continue ;; esac",
                "  d=$(sudo awk -v k=\"$port/$proto\" '$1==k {print $2; exit}' /etc/ux/puertos.conf 2>/dev/null)",
                "  if [ -n \"$d\" ]; then a=$((a + 1)); echo; echo \"== $proto $local: aprobado ($d) en VPS → Puertos\"; continue; fi",  # uxyngraphar:permitir-idioma
                "  n=$((n + 1)); echo; echo \"== $proto $local\"",
                "  pids=$(printf '%s\\n' \"$proc\" | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -un)",
                "  if [ -z \"$pids\" ]; then echo \"  sin proceso visible: socket del kernel (VXLAN 4789 de Swarm u overlay)\"; echo \"  remedio: «Retirar Docker» y reiniciar el servidor; si Docker no está, reinicia y vuelve a verificar\"; continue; fi",  # uxyngraphar:permitir-idioma
                "  for pid in $pids; do",
                "    dueno \"$pid\" \"$port\" </dev/null",
                "    echo \"  proceso=$comm pid=$pid usuario=$usr unidad=$unit unidad_usuario=$uunit\"",
                "    echo \"  dueño=$clase${objetivo:+ ($objetivo)}\"",  # uxyngraphar:permitir-idioma
                "    echo \"  remedio: $(remedio)\"",
                "  done",
                "done < <(externos)",
                "echo",
                "if [ \"$n\" -eq 0 ]; then echo \"Sin puertos sin aprobar fuera de SSH, 80 y 443 (aprobados: $a): esa falta de E11 ya no aparece.\"; else echo \"Sockets externos sin aprobar: $n (aprobados: $a). Apruébalos o ciérralos en VPS → Puertos (o corrígelos) y vuelve a «Verificar plataforma y proyectos».\"; fi",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.puerto_cerrar", "sistema", "Cerrar un puerto externo",
            "Detiene lo que abre ese puerto fuera de loopback: contenedor Docker o Podman, servicio, unidad de usuario o proceso suelto. Nunca toca SSH, 80, 443, Caddy ni unidades del sistema; Swarm se retira con «Retirar Docker».", DESTRUCTIVO, confirma="CERRAR PUERTO {puerto}",  # uxyngraphar:permitir-idioma
            campos=[
                Campo("puerto", "Puerto", "puerto", True),
            ],
            script=lambda p: PRELUDIO + _FN_PUERTOS + "port=" + q(p["puerto"]) + "\n" + nl(
                "case \"$port\" in \"${sshp:-22}\"|80|443) die \"el puerto $port es de SSH o de Caddy: no se cierra\" ;; esac",
                "lineas=$(externos | en_puerto \"$port\")",
                "[ -n \"$lineas\" ] || { echo \"El puerto $port no escucha fuera de loopback: nada que cerrar.\"; exit 0; }",
                "printf '%s\\n' \"$lineas\"",
                "pids=$(printf '%s\\n' \"$lineas\" | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -un)",
                "[ -n \"$pids\" ] || die \"sin proceso visible: socket del kernel (VXLAN de Swarm u overlay); usa «Retirar Docker» y reinicia\"",  # uxyngraphar:permitir-idioma
                "for pid in $pids; do",
                "  dueno \"$pid\" \"$port\"",
                "  echo \"→ $comm (pid $pid, $usr): $clase${objetivo:+ ($objetivo)}\"",  # uxyngraphar:permitir-idioma
                "  case \"$clase\" in",
                "    swarm) die \"lo abre Docker/Swarm: usa «Retirar Docker» y reinicia\" ;;",  # uxyngraphar:permitir-idioma
                "    protegido) die \"lo abre una unidad protegida ($objetivo): no se cierra desde aquí\" ;;",  # uxyngraphar:permitir-idioma
                "    docker) [ -n \"$objetivo\" ] || die \"no encontré el contenedor Docker que publica $port\"; sudo docker update --restart=no \"$objetivo\" >/dev/null 2>&1 || true; sudo docker stop \"$objetivo\" || die \"no pude detener $objetivo\" ;;",  # uxyngraphar:permitir-idioma
                "    podman) [ -n \"$objetivo\" ] || die \"no encontré el contenedor Podman de $usr que publica $port\"; sudo ux-as \"$usr\" podman update --restart=no \"$objetivo\" >/dev/null 2>&1 || true; sudo ux-as \"$usr\" podman stop \"$objetivo\" || die \"no pude detener $objetivo\"; echo \"Publica el puerto en 127.0.0.1 en el compose de $usr antes de redesplegar.\" ;;",  # uxyngraphar:permitir-idioma
                "    servicio) sudo systemctl disable --now \"$objetivo\" || die \"no pude desactivar $objetivo\" ;;",
                "    usuario) sudo ux-as \"$usr\" systemctl --user disable --now \"$objetivo\" || die \"no pude desactivar $objetivo de $usr\" ;;",
                "    *) sudo kill -TERM \"$pid\" || die \"no pude terminar el proceso $pid\" ;;",
                "  esac",
                "done",
                "sleep 2",
                "resto=$(externos | en_puerto \"$port\")",
                "if [ -n \"$resto\" ]; then echo \"El puerto $port sigue escuchando:\"; printf '%s\\n' \"$resto\"; exit 1; fi",
                "echo \"Puerto $port cerrado. Vuelve a «Verificar plataforma y proyectos».\"",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "sistema.podman_apartar", "sistema", "Apartar el almacenamiento de Podman de un proyecto",
            "Último recurso si «Reparar» no basta: detiene sus contenedores, mueve (no borra) su almacenamiento rootless a *.roto-<fecha>, limpia el runtime y comprueba que Podman responde. Después hay que redesplegar.", DESTRUCTIVO, confirma="APARTAR PODMAN {usuario}",  # uxyngraphar:permitir-idioma
            campos=[
                Campo("usuario", "Proyecto", "usuario_podman", True),
            ],
            script=lambda p: PRELUDIO + "u=" + q(p["usuario"]) + "\n" + nl(
                "[ \"$u\" != ux-caddy ] || die \"Caddy no se aparta desde aquí: repite la etapa E12\"",  # uxyngraphar:permitir-idioma
                "uid=$(id -u \"$u\") || die \"el usuario $u no existe\"",
                "home=$(getent passwd \"$u\" | cut -d: -f6)",
                "sello=$(date +%Y%m%d-%H%M%S)",
                "sudo ux-as \"$u\" podman stop --all -t 10 >/dev/null 2>&1 || true",
                "sudo pkill -u \"$u\" -x conmon 2>/dev/null || true",
                "sudo pkill -u \"$u\" -x catatonit 2>/dev/null || true",
                "d=\"$home/.local/share/containers\"",
                "if [ -e \"$d\" ]; then sudo mv \"$d\" \"$d.roto-$sello\" || die \"no pude apartar $d\"; echo \"Apartado: $d → $d.roto-$sello\"; fi",  # uxyngraphar:permitir-idioma
                "for c in storage.conf containers.conf; do f=\"$home/.config/containers/$c\"; if [ -e \"$f\" ]; then sudo mv \"$f\" \"$f.roto-$sello\"; echo \"Apartado: $f\"; fi; done",
                "sudo rm -rf \"/run/user/$uid/containers\" \"/run/user/$uid/libpod\"",
                "sudo loginctl enable-linger \"$u\"",
                "sudo systemctl start \"user@$uid.service\" || die \"no arrancó user@$uid.service\"",  # uxyngraphar:permitir-idioma
                "sudo ux-as \"$u\" podman system migrate 2>&1 | tail -n 5",
                "if [ \"$(sudo ux-as \"$u\" podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null)\" = true ]; then",
                "  echo \"Podman de $u responde con almacenamiento nuevo. Redespliega el proyecto.\"",
                "  echo \"Volúmenes e imágenes anteriores: $d.roto-$sello (bórralo cuando ya no lo necesites).\"",  # uxyngraphar:permitir-idioma
                "else",
                "  echo \"Podman de $u sigue sin responder:\"; sudo ux-as \"$u\" podman info 2>&1 | tail -n 20; exit 1",
                "fi",
            ),
        ),
    ]


# Shell común de puertos externos (criterio de `ux-proyecto verificar`) y dueño de un PID.  # uxyngraphar:permitir-idioma
_FN_PUERTOS = nl(
    "sshp=$(sudo sshd -T 2>/dev/null | awk '$1==\"port\"{print $2; exit}')",
    "externos() { sudo ss -Hltnup 2>/dev/null | awk '$5 !~ /^(127\\.|\\[::1\\]|::1)/'; }",
    "en_puerto() { awk -v p=\"$1\" '{n=split($5,a,\":\"); if (a[n]==p) print}'; }",
    "dueno() {",
    "  comm=$(ps -o comm= -p \"$1\" 2>/dev/null | tr -d ' '); usr=$(ps -o user:32= -p \"$1\" 2>/dev/null | tr -d ' ')",
    "  unit=$(ps -o unit= -p \"$1\" 2>/dev/null | tr -d ' '); uunit=$(ps -o uunit= -p \"$1\" 2>/dev/null | tr -d ' ')",
    "  cg=$(tail -n 1 \"/proc/$1/cgroup\" 2>/dev/null | cut -d: -f3)",
    "  clase=proceso; objetivo=$1",
    "  [ \"$usr\" = ux-caddy ] && { clase=protegido; objetivo=caddy; return 0; }",
    "  case \"$comm\" in",
    "    dockerd|containerd*) clase=swarm; objetivo=docker; return 0 ;;",
    "    docker-proxy) clase=docker; objetivo=$(sudo docker ps -a --filter \"publish=$2\" --format '{{.Names}}' 2>/dev/null | head -n 1); return 0 ;;",
    "  esac",
    "  case \"$cg\" in *docker-*.scope*) clase=docker; objetivo=$(printf '%s' \"$cg\" | sed -E 's/.*docker-([0-9a-f]{12}).*/\\1/'); return 0 ;; esac",
    "  if [ \"$usr\" != root ]; then",
    "    case \"$comm|$cg\" in rootlessport*|pasta*|slirp4netns*|conmon*|*libpod-*) clase=podman; objetivo=$(sudo ux-as \"$usr\" podman ps -a --filter \"publish=$2\" --format '{{.Names}}' 2>/dev/null | head -n 1); return 0 ;; esac",
    "  fi",
    "  case \"$unit\" in",
    "    ssh.service|sshd*|systemd-*|dbus*|init.scope|ux-*) clase=protegido; objetivo=$unit ;;",
    "    user@*.service) case \"$uunit\" in *.service) clase=usuario; objetivo=$uunit ;; esac ;;",
    "    *.service) clase=servicio; objetivo=$unit ;;",
    "  esac",
    "}",
)


# ───────────────────────────── proyectos ─────────────────────────  # uxyngraphar:permitir-idioma


def _script_r2(p: dict) -> str:
    destino = "--plataforma"
    if p["proyecto"]:
        destino = q(p["proyecto"])
    return PRELUDIO + exportar("R2_ACCOUNT_ID", p["cuenta"]) + exportar("R2_ACCESS_KEY_ID", p["clave_id"]) + exportar("R2_SECRET_ACCESS_KEY", p["clave_secreta"]) + "sudo --preserve-env=R2_ACCOUNT_ID,R2_ACCESS_KEY_ID,R2_SECRET_ACCESS_KEY ux-proyecto r2 " + destino + "\n"


def _script_subir(proyecto: str, rol: str, tipo: str, contenido: str) -> str:
    return PRELUDIO + tuberia_contenido(contenido) + " | sudo ux-as " + q(proyecto) + " ux-deploy subir " + q(rol) + " " + q(tipo) + "\n"


def componer_deploy_env(p: dict) -> str:
    hay_db = p.get("has_db") == "si"
    if hay_db and not p.get("age"):
        raise ErrorOp("con base de datos hace falta la clave age de los respaldos")
    if hay_db and not p.get("bucket"):
        raise ErrorOp("con base de datos hace falta el bucket de R2")
    b: list[str] = []
    b.append("# Generado por la app ux-infra. Formato CLAVE='valor' (sin comillas simples dentro).")

    def linea(k: str, v: str) -> None:
        if v:
            b.append(f"{k}='{v}'")

    linea("DEPLOY_PROJECT", p["proyecto"])
    linea("DEPLOY_ROLE", p["rol"])
    linea("IMAGE_REPO", p["image_repo"])
    linea("DEPLOY_HEALTH_URL", p["health_url"])
    if hay_db:
        linea("DEPLOY_HAS_DB", "true")
        linea("DEPLOY_PG_IMAGE", or_default(p["pg_image"], "docker.io/library/postgres:17"))
        linea("DEPLOY_MIGRATE_CMD", p["migrate_cmd"])
        linea("DEPLOY_AGE_RECIPIENT", p["age"])
        linea("DEPLOY_R2_BUCKET", p["bucket"])
        linea("DEPLOY_BACKUP_TIME", or_default(p["hora"], "03:00"))
        linea("DEPLOY_BACKUP_TZ", or_default(p["zona"], "UTC"))
    else:
        linea("DEPLOY_HAS_DB", "false")
    linea("DEPLOY_ALERT_EMAILS", p["correos"])
    return "\n".join(b) + "\n"


_SQL_VACIAR = (
    "DROP SCHEMA public CASCADE; CREATE SCHEMA public; "
    "GRANT ALL ON SCHEMA public TO CURRENT_USER; GRANT ALL ON SCHEMA public TO public"
)

# Migration history stays so the next deploy does not replay migrations that already ran.
_SQL_TRUNCATE_DATA_KEEP_MIGRATIONS = (
    "DO $$ DECLARE lista text; BEGIN "
    "SELECT string_agg(format('%I.%I', schemaname, tablename), ', ') INTO lista "
    "FROM pg_tables WHERE schemaname = 'public' "
    "AND tablename NOT IN ("
    "'_prisma_migrations', 'schema_migrations', 'flyway_schema_history', "
    "'django_migrations', 'alembic_version', 'knex_migrations', "
    "'knex_migrations_lock', 'mikro_orm_migrations', 'typeorm_metadata'"
    "); "
    "IF lista IS NOT NULL THEN "
    "EXECUTE 'TRUNCATE TABLE ' || lista || ' RESTART IDENTITY CASCADE'; "
    "END IF; END $$"
)


def _contenedor_db(proyecto: str, rol: str) -> str:
    return q(proyecto + "-" + rol + "-db")


def _exige_db(proyecto: str, rol: str) -> str:
    return (
        "sudo ux-as " + q(proyecto) + " podman container exists " + _contenedor_db(proyecto, rol)
        + ' || die "no hay contenedor de base de datos"'
    )


def _psql_db(proyecto: str, rol: str, sql: str) -> str:
    interior = 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1 -c ' + q(sql)
    return (
        "sudo ux-as " + q(proyecto) + " podman exec " + _contenedor_db(proyecto, rol)
        + " sh -c " + q(interior)
    )


def _restaurar_unless_stopped(proyecto: str, contenedor_quoted: str) -> str:
    """After Stop / close-port, RestartPolicy may be `no`; Start restores reboot survival."""
    return (
        "sudo ux-as " + q(proyecto) + " podman update --restart=unless-stopped "
        + contenedor_quoted + " >/dev/null 2>&1 || true\n"
    )


def _script_db(p: dict, accion: str) -> str:
    contenedor = _contenedor_db(p["proyecto"], p["rol"])
    restaurar = (
        _restaurar_unless_stopped(p["proyecto"], contenedor)
        if accion == "podman start"
        else ""
    )
    return (
        PRELUDIO + _exige_db(p["proyecto"], p["rol"]) + "\n"
        + restaurar
        + "sudo ux-as " + q(p["proyecto"]) + " " + accion + " " + contenedor + "\n"
    )


def _contenedor_app(proyecto: str, rol: str) -> str:
    return q(proyecto + "-" + rol + "-app")


def _exige_app(proyecto: str, rol: str) -> str:
    return (
        "sudo ux-as " + q(proyecto) + " podman container exists " + _contenedor_app(proyecto, rol)
        + ' || die "no hay contenedor de la aplicación"'  # uxyngraphar:permitir-idioma
    )


def _script_app(p: dict, accion: str) -> str:
    contenedor = _contenedor_app(p["proyecto"], p["rol"])
    restaurar = (
        _restaurar_unless_stopped(p["proyecto"], contenedor)
        if accion == "podman start"
        else ""
    )
    return (
        PRELUDIO + _exige_app(p["proyecto"], p["rol"]) + "\n"
        + restaurar
        + "sudo ux-as " + q(p["proyecto"]) + " " + accion + " " + contenedor + "\n"
    )


def _script_recrear(p: dict, servicio: str) -> str:
    interior = (
        'cd "$HOME/roles/' + p["rol"] + '" && set -a && . ./deploy.env && set +a && podman-compose -p "'
        + p["proyecto"] + "-" + p["rol"] + '" -f compose.yaml up -d --force-recreate --no-deps ' + servicio
    )
    return (
        PRELUDIO
        + "sudo ux-as " + q(p["proyecto"]) + " sh -c " + q(interior)
        + " || die " + q("no pude recrear " + p["proyecto"] + "-" + p["rol"] + "-" + servicio) + "\n"
    )


def _script_recrear_db(p: dict) -> str:
    return _script_recrear(p, "db")


def _script_borrar_disco_db(p: dict) -> str:
    nombre = p["proyecto"] + "-" + p["rol"]
    interior = (
        'cd "$HOME/roles/' + p["rol"] + '" || die "no esta el rol"'
        + ' && { set -a && . ./deploy.env && set +a; } || die "no pude leer deploy.env"'
        + ' && { podman-compose -p "' + nombre + '" -f compose.yaml stop db || true; }'
        + ' && disco="$HOME/datos/' + p["rol"] + '/postgres"'
        + ' && { case "$disco" in "$HOME"/datos/*/postgres) ;; *) die "ruta de datos inesperada" ;; esac; }'
        + ' && podman unshare rm -rf -- "$disco"'
        + ' && mkdir -p -- "$disco"'
        + ' && podman-compose -p "' + nombre + '" -f compose.yaml up -d --force-recreate --no-deps db'
    )
    return (
        PRELUDIO
        + "sudo ux-as " + q(p["proyecto"]) + " sh -c " + q(interior)
        + " || die " + q("no pude borrar el disco de " + nombre + "-db") + "\n"
    )


def _script_psql_db(p: dict, sql: str) -> str:
    return PRELUDIO + _exige_db(p["proyecto"], p["rol"]) + "\n" + _psql_db(p["proyecto"], p["rol"], sql) + "\n"


# Remedia sin depender de un ux-proyecto actualizado: /etc/ux/projects legible
# para el CI, dueño de ~/.config (Podman) y ux-deploy con auth-ghcr/preparar_podman.  # uxyngraphar:permitir-idioma
REMEDIAR_PROYECTOS_CI_Y_PODMAN = nl(
    'echo "▸ Remediando permisos CI (/etc/ux/projects) y dueño de ~/.config (Podman)"',  # uxyngraphar:permitir-idioma
    'sudo chmod 755 /etc/ux /etc/ux/projects 2>/dev/null || true',
    'for d in /etc/ux/projects/*/; do [ -d "$d" ] && sudo chmod 755 "$d" 2>/dev/null || true; done',
    'sudo find /etc/ux/projects -maxdepth 2 -type f -name "*.env" -exec chmod 644 {} + 2>/dev/null || true',
    'for p in $(sudo find /etc/ux/projects -mindepth 1 -maxdepth 1 -type d -printf "%f\\n" 2>/dev/null); do',
    '  home=$(getent passwd "$p" | cut -d: -f6); uid=$(id -u "$p" 2>/dev/null) || continue',
    '  [ -n "$home" ] || continue',
    '  sudo /bin/chown "$p:$p" "$home" 2>/dev/null || true',
    '  for sub in .config .local .cache; do',
    '    sudo test -e "$home/$sub" || continue',
    '    echo "  · reparando $home/$sub"',  # uxyngraphar:permitir-idioma
    '    sudo chattr -R -i "$home/$sub" 2>/dev/null || sudo chattr -i "$home/$sub" 2>/dev/null || true',
    '    sudo /bin/chown -R "$p:$p" "$home/$sub" 2>/dev/null || true',
    '    if [ "$(sudo stat -c %u "$home/$sub" 2>/dev/null)" != "$uid" ]; then',
    '      sello=$(date +%Y%m%d%H%M%S)',
    '      sudo mv "$home/$sub" "$home/$sub.roto-$sello"',
    '      sudo mkdir -p "$home/$sub"',
    '      sudo /bin/chown -R "$p:$p" "$home/$sub"',
    '    fi',
    '  done',
    '  sudo systemctl start "user@$uid.service" 2>/dev/null || true',
    'done',
    # Hotfixes: install when markers missing OR /opt pack differs from /usr/local/bin.
    'SRC=""',
    'for f in /opt/ux-infra/05-vps/agent/platform/bin/ux-deploy /opt/ux-infra/agent/platform/bin/ux-deploy; do',
    '  if [ -f "$f" ] && grep -q "preparar_podman" "$f"; then SRC="$f"; break; fi',
    'done',
    'if [ -z "$SRC" ]; then',
    '  for f in /opt/ux-infra/05-vps/agent/platform/bin/ux-deploy /opt/ux-infra/agent/platform/bin/ux-deploy; do',
    '    if [ -f "$f" ] && grep -q "auth-ghcr" "$f"; then SRC="$f"; break; fi',
    '  done',
    'fi',
    'need_ux_deploy=0',
    'grep -q "auth-ghcr" /usr/local/bin/ux-deploy 2>/dev/null || need_ux_deploy=1',
    'grep -q "preparar_podman" /usr/local/bin/ux-deploy 2>/dev/null || need_ux_deploy=1',
    'if [ -n "$SRC" ] && { [ ! -f /usr/local/bin/ux-deploy ] || ! cmp -s "$SRC" /usr/local/bin/ux-deploy; }; then need_ux_deploy=1; fi',
    'if [ "$need_ux_deploy" = 1 ] && [ -n "$SRC" ]; then',
    '  echo "▸ Actualizando /usr/local/bin/ux-deploy desde $SRC"',  # uxyngraphar:permitir-idioma
    '  sudo install -m 755 "$SRC" /usr/local/bin/ux-deploy',
    'fi',
    'if grep -q "preparar_podman" /usr/local/bin/ux-deploy 2>/dev/null; then echo "▸ ux-deploy: auth-ghcr+preparar_podman disponible"',  # uxyngraphar:permitir-idioma
    'elif grep -q "auth-ghcr" /usr/local/bin/ux-deploy 2>/dev/null; then echo "▸ ux-deploy: auth-ghcr disponible (sin preparar_podman; resync protocolo)"',  # uxyngraphar:permitir-idioma
    'else echo "▸ AVISO: ux-deploy sin auth-ghcr (resync protocolo)"; fi',  # uxyngraphar:permitir-idioma
    'echo "▸ perms CI: $(sudo ls -lad /etc/ux/projects /etc/ux/projects/*/ /etc/ux/projects/*/*.env 2>&1 | tr "\\n" " · ")"',  # uxyngraphar:permitir-idioma
    'for f in /etc/ux/projects/*/*.env; do',
    '  [ -f "$f" ] || continue',
    '  p=$(echo "$f" | cut -d/ -f5);',
    '  if sudo ux-as "$p" test -r "$f" 2>/dev/null; then echo "▸ legible CI: $f"; else echo "▸ ILEGIBLE CI: $f"; fi',  # uxyngraphar:permitir-idioma
    'done',
)


def _proyectos_ops() -> list[Op]:
    return [
        Op(
            "proyectos.listar", "proyectos", "Proyectos y roles registrados",
            "Proyecto, rol, dominio, puerto y versión desplegada (ux-proyecto listar).", LECTURA,  # uxyngraphar:permitir-idioma
            parser=parsear_listar,
            script=lambda p: PRELUDIO + "sudo ux-proyecto listar\n",
        ),
        Op(
            "proyectos.verificar", "proyectos", "Verificar plataforma y proyectos",
            "Comprueba grupos, herramientas, sshd, Caddy, exposición de puertos y cada proyecto. Remedia permisos de /etc/ux/projects (755) para que el CI pueda leer el registro.",  # uxyngraphar:permitir-idioma
            CAMBIO, parser=parsear_verificar,
            campos=[Campo("proyecto", "Solo este proyecto (vacío = todo)", "proyecto")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + REMEDIAR_PROYECTOS_CI_Y_PODMAN + (
                "sudo ux-proyecto verificar " + q(p["proyecto"]) + "\n"
                if p["proyecto"]
                else "sudo ux-proyecto verificar\n"
            ),
        ),
        Op(
            "proyectos.reconciliar", "proyectos", "Reconciliar plataforma ux-*",
            "Reinstala las herramientas ux-* desde el protocolo del VPS (si está), remedia permisos del CI y dueño de ~/.config (Podman), y verifica.",  # uxyngraphar:permitir-idioma
            CAMBIO, parser=parsear_verificar,
            script=lambda p: PRELUDIO + nl(
                'INST=/opt/ux-infra/05-vps/agent/platform/install.sh',
                '[ -f "$INST" ] || INST=""',
                'if [ -n "$INST" ]; then',
                '  echo "▸ Reinstalando ux-* desde $INST"',  # uxyngraphar:permitir-idioma
                '  sudo bash "$INST" || die "falló install.sh"',  # uxyngraphar:permitir-idioma
                'else',
                '  echo "AVISO: no hay install.sh en el protocolo; solo se verifica lo ya instalado"',
                'fi',
                'command -v ux-proyecto >/dev/null || die "falta ux-proyecto: ejecuta la etapa Plataforma (E11)"',
                'command -v ux-deploy >/dev/null || die "falta ux-deploy en PATH tras reconciliar"',
                'REV="$(ux-deploy contrato 2>/dev/null | sed -n \'s/^ux-deploy-rev=//p\' | head -n1)"',
                'SRC_REV=""',
                'for b in /opt/ux-infra/05-vps/agent/platform/bin/ux-deploy /opt/ux-infra/agent/platform/bin/ux-deploy; do',
                '  [ -f "$b" ] || continue',
                '  SRC_REV="$("$b" contrato 2>/dev/null | sed -n \'s/^ux-deploy-rev=//p\' | head -n1)"',
                '  break',
                'done',
                'if [ -n "$SRC_REV" ] && [ -n "$REV" ] && [ "$SRC_REV" != "$REV" ]; then',
                '  die "ux-deploy-rev en PATH ($REV) != pack en /opt ($SRC_REV): vuelve a Reconciliar o sincroniza el protocolo"',
                'fi',
                'echo "▸ ux-deploy-rev PATH=${REV:-ausente} /opt=${SRC_REV:-ausente}"',  # uxyngraphar:permitir-idioma
            ) + REMEDIAR_PROYECTOS_CI_Y_PODMAN + 'sudo ux-proyecto verificar\n',
        ),
        Op(
            "proyectos.alta", "proyectos", "Dar de alta un proyecto",
            "Crea el usuario Linux rootless del proyecto y registra la llave pública exclusiva de su CI.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[
                _CAMPO_PROYECTO,
                Campo("llave_ci", "Llave pública del CI", "llave_ci", True,  # uxyngraphar:permitir-idioma
                      ayuda="Una línea: ssh-ed25519 AAAA… comentario. La privada vive solo en los secretos del CI."),  # uxyngraphar:permitir-idioma
            ],
            script=lambda p: PRELUDIO + nl(
                'T="$(mktemp -d)" || die "no pude crear un directorio temporal"',
                "printf '%s\\n' " + q(p["llave_ci"]) + ' > "$T/ci.pub"',
                "sudo ux-proyecto alta " + q(p["proyecto"]) + ' --llave-ci "$T/ci.pub"',
                'rc=$?; rm -rf "$T"; exit $rc',
            ),
        ),
        Op(
            "proyectos.rol_alta", "proyectos", "Dar de alta un rol (dominio + puerto)",
            "Registra el rol, reserva un puerto en 127.0.0.1 y publica el sitio en Caddy con HTTPS automático.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("dominio", "Dominio", "dominio", True, ayuda="El DNS A del dominio debe apuntar a la IP de este VPS.")],
            script=lambda p: PRELUDIO + "sudo ux-proyecto rol-alta " + q(p["proyecto"]) + " " + q(p["rol"]) + " --dominio " + q(p["dominio"]) + "\n",
        ),
        Op(
            "proyectos.rol_baja", "proyectos", "Dar de baja un rol",
            "Quita el sitio del proxy y el registro del rol. Los datos NO se tocan.", DESTRUCTIVO,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL], confirma="{proyecto}/{rol}",
            script=lambda p: PRELUDIO + "sudo ux-proyecto rol-baja " + q(p["proyecto"]) + " " + q(p["rol"]) + "\n",
        ),
        Op(
            "proyectos.baja", "proyectos", "Dar de baja un proyecto",
            "Detiene sus contenedores, elimina el usuario y archiva su carpeta en /var/lib/ux/archivo.", DESTRUCTIVO,
            campos=[_CAMPO_PROYECTO], confirma="{proyecto}",
            script=lambda p: PRELUDIO + "sudo ux-proyecto baja " + q(p["proyecto"]) + " --confirmar " + q(p["proyecto"]) + "\n",
        ),
        Op(
            "proyectos.r2", "proyectos", "Credenciales de R2 (rclone)",
            "Escribe el rclone.conf del proyecto (o de la plataforma) con un token de R2 limitado a su bucket.", CAMBIO,
            campos=[
                Campo("proyecto", "Proyecto (vacío = plataforma)", "proyecto"),  # uxyngraphar:permitir-idioma
                Campo("cuenta", "Account ID de Cloudflare", "cuenta_r2", True),
                Campo("clave_id", "Access Key ID", "clave_r2", True, secreto=True),
                Campo("clave_secreta", "Secret Access Key", "clave_r2", True, secreto=True),
            ],
            script=_script_r2,
        ),
        Op(
            "proyectos.ghcr", "proyectos", "Sesión en GHCR",  # uxyngraphar:permitir-idioma
            "Inicia sesión del proyecto en ghcr.io con un token de SOLO lectura de paquetes.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[_CAMPO_PROYECTO,
                    Campo("usuario", "Usuario de GitHub", "ghcr_user", True),
                    Campo("token", "Token (read:packages)", "ghcr_token", True, secreto=True)],
            script=lambda p: PRELUDIO + exportar("GHCR_USER", p["usuario"]) + exportar("GHCR_TOKEN", p["token"]) + "sudo --preserve-env=GHCR_USER,GHCR_TOKEN ux-proyecto ghcr " + q(p["proyecto"]) + "\n",
        ),
        Op(
            "proyectos.state", "proyectos", "Estado de un rol",
            "Versión actual, anterior y contenedores (ux-deploy estado).", LECTURA,  # uxyngraphar:permitir-idioma
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " ux-deploy estado " + q(p["rol"]) + "\n",
        ),
        Op(
            "proyectos.contenedores", "proyectos", "Contenedores de un usuario",
            "podman ps -a del proyecto (o de Caddy).", LECTURA,
            campos=[Campo("usuario", "Proyecto", "usuario_podman", True)],
            parser=parsear_contenedores,
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["usuario"]) + " podman ps -a --format '{{.Names}}|{{.Status}}|{{.Image}}|{{.Ports}}'\n",
        ),
        Op(
            "proyectos.logs", "proyectos", "Registro de un contenedor",
            "Últimas líneas de podman logs.", LECTURA,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("usuario", "Proyecto", "usuario_podman", True),
                Campo("contenedor", "Contenedor", "contenedor", True),
                Campo("lineas", "Líneas", "lineas", defecto="200"),  # uxyngraphar:permitir-idioma
            ],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["usuario"]) + " podman logs --tail " + q(or_default(p["lineas"], "200")) + " " + q(p["contenedor"]) + " 2>&1\n",
        ),
        Op(
            "proyectos.reiniciar", "proyectos", "Reiniciar los contenedores de un rol",
            "podman restart de la app, solo de su base de datos, o de las dos.", CAMBIO,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("alcance", "Alcance", "select", True, opciones=["app", "base", "todo"], defecto="app")],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " sh -c " + q(
                'ids=$(podman ps -aq --filter ' + q("name=^" + p["proyecto"] + "-" + p["rol"] + ("-app$" if p["alcance"] == "app" else ("-db$" if p["alcance"] == "base" else "-")))
                + '); [ -n "$ids" ] || { echo "no hay contenedores de ese rol" >&2; exit 1; }; podman restart $ids'
            ) + "\n",
        ),
        Op(
            "proyectos.app_arrancar", "proyectos", "Arrancar la aplicación",  # uxyngraphar:permitir-idioma
            "podman start solo del contenedor de la aplicación de la parte.",  # uxyngraphar:permitir-idioma
            CAMBIO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_app(p, "podman start"),
        ),
        Op(
            "proyectos.app_detener", "proyectos", "Detener la aplicación",  # uxyngraphar:permitir-idioma
            "podman stop solo del contenedor de la aplicación de la parte. La imagen y los datos se quedan.",  # uxyngraphar:permitir-idioma
            CAMBIO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_app(p, "podman stop"),
        ),
        Op(
            "proyectos.app_recrear", "proyectos", "Recrear el contenedor de la aplicación",  # uxyngraphar:permitir-idioma
            "Vuelve a crear el contenedor de la aplicación con podman-compose. No borra la imagen ni el volumen, y no toca la base.",  # uxyngraphar:permitir-idioma
            CAMBIO, largo=True, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_recrear(p, "app"),
        ),
        Op(
            "proyectos.db_arrancar", "proyectos", "Arrancar la base de datos",
            "podman start solo del contenedor PostgreSQL de la parte.",
            CAMBIO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_db(p, "podman start"),
        ),
        Op(
            "proyectos.db_detener", "proyectos", "Detener la base de datos",
            "podman stop solo del contenedor PostgreSQL de la parte. Los datos se quedan en el volumen.",
            CAMBIO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_db(p, "podman stop"),
        ),
        Op(
            "proyectos.db_recrear", "proyectos", "Recrear el contenedor de la base",
            "Vuelve a crear el contenedor PostgreSQL con podman-compose y conserva el volumen.",
            CAMBIO, largo=True, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=_script_recrear_db,
        ),
        Op(
            "proyectos.db_vacuum", "proyectos", "Ordenar las tablas",
            "VACUUM ANALYZE de la base de la parte. Actualiza el tamaño y las filas estimadas.",  # uxyngraphar:permitir-idioma
            CAMBIO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_psql_db(p, "VACUUM ANALYZE"),
        ),
        Op(
            "proyectos.db_eliminar_contenido", "proyectos", "Eliminar el contenido de la base",
            "Borra las filas de las tablas del esquema public. Conserva las tablas y el historial de migraciones.",
            DESTRUCTIVO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL], confirma="{proyecto}/{rol}",
            script=lambda p: _script_psql_db(p, _SQL_TRUNCATE_DATA_KEEP_MIGRATIONS),
        ),
        Op(
            "proyectos.db_vaciar", "proyectos", "Vaciar la base de datos",
            "Borra el esquema public y lo vuelve a crear. Después hay que desplegar para que las migraciones creen las tablas.",  # uxyngraphar:permitir-idioma
            DESTRUCTIVO, campos=[_CAMPO_PROYECTO, _CAMPO_ROL], confirma="{proyecto}/{rol}",
            script=lambda p: _script_psql_db(p, _SQL_VACIAR),
        ),
        Op(
            "proyectos.db_borrar_disco", "proyectos", "Borrar el disco de la base",
            "Detiene PostgreSQL, borra su carpeta de datos y vuelve a crear el contenedor. La base nace vacía con la contraseña actual del entorno. Después hay que desplegar para que las migraciones creen las tablas.",  # uxyngraphar:permitir-idioma
            DESTRUCTIVO, largo=True, campos=[_CAMPO_PROYECTO, _CAMPO_ROL], confirma="{proyecto}/{rol}",
            script=_script_borrar_disco_db,
        ),
        Op(
            "proyectos.subir", "proyectos", "Subir un archivo al rol",
            "Entrega compose.yaml, .env, deploy.env o alerta.env con las mismas validaciones del CI (ux-deploy subir).",
            CAMBIO,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("tipo", "Archivo", "select", True, opciones=["compose", "env", "deploy", "alerta"]),
                    Campo("contenido", "Contenido", "contenido", True)],
            script=lambda p: _script_subir(p["proyecto"], p["rol"], p["tipo"], p["contenido"]),
        ),
        Op(
            "proyectos.deploy_env", "proyectos", "Generar y subir deploy.env",
            "Compone deploy.env del rol con valores validados y lo entrega con ux-deploy subir.", CAMBIO,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("image_repo", "Imagen (sin etiqueta)", "imagen", True, ayuda="p. ej. ghcr.io/tu-org/tu-repo"),
                    Campo("health_url", "URL de salud local", "texto_env", True, ayuda="p. ej. http://127.0.0.1:18000/health"),
                    Campo("has_db", "Tiene base de datos PostgreSQL", "bool"),
                    Campo("pg_image", "Imagen de PostgreSQL", "imagen", defecto="docker.io/library/postgres:17"),
                    Campo("migrate_cmd", "Comando de migración (opcional)", "texto_env"),  # uxyngraphar:permitir-idioma
                    Campo("age", "Claves age de los respaldos", "age", ayuda="Públicas, separadas por coma. Obligatoria si hay base de datos."),  # uxyngraphar:permitir-idioma
                    Campo("bucket", "Bucket de R2 del proyecto", "bucket"),
                    Campo("hora", "Hora del respaldo diario", "hora", defecto="03:00"),
                    Campo("zona", "Zona horaria del respaldo", "texto_env", defecto="UTC"),
                    Campo("correos", "Correos de alerta (opcional)", "emails")],
            script=lambda p: _script_subir(p["proyecto"], p["rol"], "deploy", componer_deploy_env(p)),
        ),
        Op(
            "proyectos.liberar_candado", "proyectos", "Liberar publicacion atascada",
            "Cierra procesos que sostienen el candado de publicacion del rol (.deploy.lock) para poder volver a desplegar.",
            CAMBIO,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: PRELUDIO + nl(
                "home=$(getent passwd " + q(p["proyecto"]) + " | cut -d: -f6)",
                '[ -n "$home" ] || die "proyecto sin home"',
                "rol=" + q(p["rol"]),
                'lock="$home/roles/$rol/.deploy.lock"',
                'echo "▸ Candado: $lock"',  # uxyngraphar:permitir-idioma
                'if [ ! -e "$lock" ]; then echo "Sin candado (nada que liberar)"; exit 0; fi',
                'sudo fuser -v "$lock" 2>&1 || true',
                'atascados=""',
                'for pid in $(sudo fuser "$lock" 2>/dev/null); do',
                '  c=$(sudo cat "/proc/$pid/comm" 2>/dev/null || true)',
                '  case "$c" in conmon|rootlessport|rootlessport-*|exe|catatonit|podman|pasta|pasta.avx2|slirp4netns) ;; *) atascados="$atascados $pid" ;; esac',
                "done",
                'if [ -n "$atascados" ]; then echo "Terminando publicacion atascada:$atascados"; sudo kill $atascados 2>/dev/null || true; sleep 1; fi',  # uxyngraphar:permitir-idioma
                'if sudo fuser "$lock" >/dev/null 2>&1; then echo "Lo retiene el contenedor en marcha (fd heredado): se crea un candado nuevo sin tocarlo"; sudo rm -f -- "$lock"; fi',  # uxyngraphar:permitir-idioma
                'echo "Candado liberado"',
            ),
        ),
        Op(
            "proyectos.publicar", "proyectos", "Publicar una versión",  # uxyngraphar:permitir-idioma
            "ux-deploy publicar: descarga la imagen, migra (solo con respaldo verificado), levanta y verifica; revierte solo si falla.",
            CAMBIO, largo=True,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("tag", "Etiqueta (12 hex)", "tag", True),
                    Campo("respaldo", "Respaldo verificado (si hay migración)", "respaldo_exacto")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " ux-deploy publicar " + q(p["rol"]) + " " + q(p["tag"]) + ((" " + q(p["respaldo"])) if p["respaldo"] else "") + "\n",
        ),
        Op(
            "proyectos.revertir", "proyectos", "Revertir a una versión",  # uxyngraphar:permitir-idioma
            "ux-deploy revertir: vuelve a una etiqueta publicada, SIN migraciones.", CAMBIO, largo=True,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("tag", "Etiqueta (12 hex)", "tag", True)],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " ux-deploy revertir " + q(p["rol"]) + " " + q(p["tag"]) + "\n",
        ),
    ]


# ───────────────────────────── respaldos ─────────────────────────  # uxyngraphar:permitir-idioma


_CAMPOS_AMBITO = [
    Campo("ambito", "Ámbito", "select", True, opciones=["plataforma", "proyecto"], defecto="plataforma"),  # uxyngraphar:permitir-idioma
    Campo("proyecto", "Proyecto (si el ámbito es proyecto)", "proyecto"),  # uxyngraphar:permitir-idioma
    Campo("rol", "Rol (si el ámbito es proyecto)", "rol"),  # uxyngraphar:permitir-idioma
]


def _exigir_ambito(p: dict) -> None:
    if p["ambito"] == "proyecto" and (not p["proyecto"] or not p["rol"]):
        raise ErrorOp("indica el proyecto y el rol")


def _respaldos_ops() -> list[Op]:
    lsf = "lsf -R --files-only --format sp --separator ';'"
    return [
        Op(
            "backups.config", "respaldos", "Configuración de respaldos de la plataforma",  # uxyngraphar:permitir-idioma
            "Claves age, bucket, credenciales de R2 y temporizador (E14).", LECTURA, parser=parsear_kv,
            script=lambda p: PRELUDIO + nl(
                'age="$(sudo bash -c \'. /etc/ux/plataforma.env 2>/dev/null; printf %s "$UX_AGE_RECIPIENT"\')"',
                'bucket="$(sudo bash -c \'. /etc/ux/plataforma.env 2>/dev/null; printf %s "$UX_R2_BUCKET"\')"',
                'echo "age=$age"',
                'echo "bucket=$bucket"',
                'echo "prefijo=$(sudo bash -c \'. /etc/ux/plataforma.env 2>/dev/null; printf %s "$UX_R2_PREFIJO"\')"',
                'if sudo test -f /etc/ux/rclone.conf; then echo "rclone=presente"; else echo "rclone=ausente"; fi',
                'echo "timer_habilitado=$(systemctl is-enabled ux-backup-platform.timer 2>/dev/null || echo no-instalado)"',
                'echo "timer_activo=$(systemctl is-active ux-backup-platform.timer 2>/dev/null || echo no)"',
                'echo "siguiente=$(systemctl list-timers ux-backup-platform.timer --no-legend --no-pager 2>/dev/null | awk \'{print $1" "$2" "$3}\')"',
                'echo "ultimo=$(sudo find ' + DIR_RESPALDOS_PLATAFORMA + " -maxdepth 1 -name '*.age' -printf '%f\\n' 2>/dev/null | sort | tail -n 1)\"",
            ),
        ),
        Op(
            "backups.configurar", "respaldos", "Configurar los respaldos de la plataforma",
            "Escribe /etc/ux/plataforma.env, las credenciales de R2 (si las indicas) y activa el temporizador diario.",
            CAMBIO,
            campos=[
                Campo("age", "Claves age (recuperación,verificación)", "age", True, ayuda="Solo claves PÚBLICAS age1…, separadas por coma y sin espacios."),  # uxyngraphar:permitir-idioma
                Campo("bucket", "Bucket de la plataforma", "bucket", True, defecto="backups-general-projects"),
                Campo("prefijo", "Prefijo de este VPS dentro del bucket (vacío = nombre del servidor)", "prefijo_vps", ayuda="Ordena el bucket: los respaldos quedan en diario/<prefijo>/, semanal/<prefijo>/…"),  # uxyngraphar:permitir-idioma
                Campo("cuenta", "Account ID de Cloudflare (vacío = conservar credenciales)", "cuenta_r2"),  # uxyngraphar:permitir-idioma
                Campo("clave_id", "Access Key ID", "clave_r2", secreto=True),
                Campo("clave_secreta", "Secret Access Key", "clave_r2", secreto=True),
                Campo("timer", "Activar el temporizador diario", "bool", defecto="si"),
            ],
            script=lambda p: _script_configurar_respaldos(p),
        ),
        Op(
            "backups.timer", "respaldos", "Temporizador de respaldos de la plataforma",
            "Activa o desactiva el respaldo diario automático.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("accion", "Acción", "select", True, opciones=["activar", "desactivar"])],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + (
                "sudo systemctl enable --now ux-backup-platform.timer\n"
                if p["accion"] == "activar"
                else "sudo systemctl disable --now ux-backup-platform.timer\n"
            ),
        ),
        Op(
            "backups.plataforma", "respaldos", "Respaldar la plataforma ahora",
            "ux-respaldo --plataforma: /etc/ux y certificados de Caddy, cifrado con age y copiado a R2.", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + "sudo ux-respaldo --plataforma\n",
        ),
        Op(
            "backups.rol", "respaldos", "Respaldar la base de un rol ahora",
            "ux-deploy respaldar: pg_dump cifrado con age y copiado a R2.", CAMBIO, largo=True,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL,
                    Campo("motivo", "Motivo", "motivo", True, defecto="daily")],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " ux-deploy respaldar " + q(p["rol"]) + " " + q(p["motivo"]) + "\n",
        ),
        Op(
            "backups.locales", "respaldos", "Respaldos guardados en el VPS",
            "Copias locales cifradas (la retención local es escalonada).", LECTURA,  # uxyngraphar:permitir-idioma
            campos=_CAMPOS_AMBITO, parser=parsear_respaldos_locales,
            script=lambda p: _script_respaldos_locales(p),
        ),
        Op(
            "backups.r2", "respaldos", "Respaldos guardados en R2",
            "Lista el bucket por prefijo (diario/, semanal/, mensual/, pre-deploy/).", LECTURA,
            campos=_CAMPOS_AMBITO, parser=parsear_r2,
            script=lambda p: _script_respaldos_r2(p, lsf),
        ),
        Op(
            "backups.verificar", "respaldos", "Descargar y verificar un respaldo",
            "Descarga el respaldo por SSH, comprueba su SHA-256, lo descifra EN TU EQUIPO con tu clave privada age y valida el formato. La clave privada nunca sale de tu equipo.",
            LECTURA, largo=True,
            campos=_CAMPOS_AMBITO + [
                Campo("archivo", "Respaldo (o «ultimo»)", "respaldo", True, defecto="ultimo"),  # uxyngraphar:permitir-idioma
                Campo("identidad", "Archivo de tu clave privada age", "ruta_local", True, ayuda="p. ej. recuperacion.key (contiene AGE-SECRET-KEY-1…)"),  # uxyngraphar:permitir-idioma
                Campo("destino", "Carpeta donde guardar el descifrado (opcional)", "ruta_local", ayuda="Si la indicas se guarda el respaldo SIN cifrar: úsala solo para la prueba de restauración (E14.7)."),  # uxyngraphar:permitir-idioma
            ],
            ejecutar=verificar_respaldo,
        ),
    ]


def _script_configurar_respaldos(p: dict) -> str:
    con_creds = bool(p["cuenta"] or p["clave_id"] or p["clave_secreta"])
    if con_creds and (not p["cuenta"] or not p["clave_id"] or not p["clave_secreta"]):
        raise ErrorOp("para cambiar las credenciales de R2 indica Account ID, Access Key ID y Secret Access Key")
    env = f"UX_AGE_RECIPIENT='{p['age']}'\nUX_R2_BUCKET='{p['bucket']}'\nUX_R2_PREFIJO='{p['prefijo']}'\n"
    s = PRELUDIO + nl(
        'sudo install -d -m 755 /etc/ux || die "no pude crear /etc/ux"',
        tuberia_contenido(env) + " | sudo sh -c 'umask 077; cat > /etc/ux/plataforma.env' || die \"no pude escribir plataforma.env\"",
        "sudo chown root:root /etc/ux/plataforma.env && sudo chmod 600 /etc/ux/plataforma.env",
        'echo "plataforma.env escrito"',
    )
    if con_creds:
        s += exportar("R2_ACCOUNT_ID", p["cuenta"]) + exportar("R2_ACCESS_KEY_ID", p["clave_id"]) + exportar("R2_SECRET_ACCESS_KEY", p["clave_secreta"]) + 'sudo --preserve-env=R2_ACCOUNT_ID,R2_ACCESS_KEY_ID,R2_SECRET_ACCESS_KEY ux-proyecto r2 --plataforma || die "no pude escribir las credenciales de R2"\n'
    if p["timer"] == "si":
        s += nl(
            "sudo systemctl daemon-reload",
            'sudo systemctl enable --now ux-backup-platform.timer || die "no pude activar el temporizador (¿está instalada la plataforma, E11?)"',  # uxyngraphar:permitir-idioma
            "systemctl list-timers ux-backup-platform.timer --no-pager",
        )
    return s


def _script_respaldos_locales(p: dict) -> str:
    _exigir_ambito(p)
    dir_ = DIR_RESPALDOS_PLATAFORMA
    if p["ambito"] == "proyecto":
        dir_ = f"/home/{p['proyecto']}/backups/{p['rol']}"
    return PRELUDIO + "sudo find " + q(dir_) + " -maxdepth 1 -type f -name '*.age' -printf '%f\\t%s\\t%TY-%Tm-%Td %TH:%TM\\n' | sort -r\n"


def _script_respaldos_r2(p: dict, lsf: str) -> str:
    _exigir_ambito(p)
    if p["ambito"] == "plataforma":
        return PRELUDIO + nl(
            'B="$(sudo bash -c \'. /etc/ux/plataforma.env 2>/dev/null; printf %s "$UX_R2_BUCKET"\')"',
            '[ -n "$B" ] || die "no hay bucket configurado (configura los respaldos de la plataforma)"',
            'sudo rclone --config /etc/ux/rclone.conf ' + lsf + ' "r2:$B" | grep -v \'\\.sha256$\' | sort',
        )
    interior = '. "$HOME/roles/' + p["rol"] + '/deploy.env" && [ -n "$DEPLOY_R2_BUCKET" ] && rclone --config "$HOME/.config/rclone/rclone.conf" ' + lsf + ' "r2:$DEPLOY_R2_BUCKET"'
    return PRELUDIO + "sudo ux-as " + q(p["proyecto"]) + " bash -c " + q(interior) + " | grep -v '\\.sha256' | sort\n"


_MAGIA_PGDMP = b"PGDMP"
_MAGIA_ZSTD = bytes([0x28, 0xB5, 0x2F, 0xFD])


def _identidad_age(ruta: str) -> str:
    """Busca la línea AGE-SECRET-KEY-1… en el archivo de identidad."""  # uxyngraphar:permitir-idioma
    try:
        with open(ruta, encoding="utf-8") as fh:
            contenido = fh.read()
    except OSError as exc:
        raise ErrorOp(f"no pude leer tu clave privada: {exc}") from exc
    for linea in contenido.splitlines():
        if linea.startswith("AGE-SECRET-KEY-1"):
            return linea.strip()
    raise ErrorOp("el archivo no contiene una clave privada age (AGE-SECRET-KEY-1…)")  # uxyngraphar:permitir-idioma

def _publica_age(ruta: str) -> str:
    try:
        r = subprocess.run(["age-keygen", "-y", ruta], capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ErrorOp(f"no pude derivar la clave pública: {exc}") from exc  # uxyngraphar:permitir-idioma
    if r.returncode != 0 or not r.stdout.strip().startswith("age1"):
        raise ErrorOp("no pude derivar la clave pública de esa identidad")  # uxyngraphar:permitir-idioma
    return r.stdout.strip().splitlines()[0]


def _record_restore_test(e: Entorno, name: str) -> None:
    """E14.7: records the date on the VPS so the quarterly check passes (same file as the backend)."""
    import time

    when = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    e.ses.sudo(
        "sudo install -d -m 755 /var/lib/ux && printf '%s %s\\n' "
        + q(when) + " " + q(name) + " | sudo tee /var/lib/ux/restore-tested >/dev/null\n"
    )


def verificar_respaldo(e: Entorno, p: dict, emitir: Callable[[str], None] | None) -> Resultado:
    import os

    sal: list[str] = []

    def say(f: str, *a: object) -> None:
        l = (f % a if a else f) + "\n"
        sal.append(l)
        if emitir is not None:
            emitir(l)

    def fallo(f: str, *a: object) -> Resultado:
        say("✗ " + f, *a)  # uxyngraphar:permitir-idioma
        return Resultado(codigo=1, salida="".join(sal))

    _exigir_ambito(p)
    plataforma = p["ambito"] == "plataforma"

    identidad = _identidad_age(p["identidad"])
    pub = _publica_age(p["identidad"])
    say("Clave local: %s", pub)

    nombre = p["archivo"]
    if nombre == "ultimo":
        if plataforma:
            cmd = "sudo find " + DIR_RESPALDOS_PLATAFORMA + " -maxdepth 1 -name '*.tar.age' -printf '%f\\n' | sort | tail -n 1"
        else:
            cmd = "sudo cat " + q(f"/home/{p['proyecto']}/backups/{p['rol']}/LAST_BACKUP")
        r = e.ses.sudo(PRELUDIO + cmd + "\n")
        nombre = r.stdout.strip()
        if r.codigo != 0 or not nombre:
            return fallo("todavía no hay respaldos en el VPS para este ámbito")  # uxyngraphar:permitir-idioma
    if not util.es_respaldo(nombre):
        return fallo("el nombre del respaldo no es válido: %r", nombre)  # uxyngraphar:permitir-idioma
    if plataforma and not nombre.startswith("plataforma-"):
        return fallo("ese respaldo no es de la plataforma")
    if not plataforma and not nombre.startswith(f"{p['proyecto']}-{p['rol']}-"):
        return fallo("ese respaldo no pertenece a %s/%s", p["proyecto"], p["rol"])
    say("Respaldo: %s", nombre)

    dir_proy = f"/home/{p['proyecto']}/backups/{p['rol']}"
    ruta_sha = DIR_RESPALDOS_PLATAFORMA + "/" + nombre + ".sha256"
    if not plataforma:
        ruta_sha = dir_proy + "/" + nombre + ".sha256"
    hash_remoto = ""
    r = e.ses.sudo(PRELUDIO + "sudo cat " + q(ruta_sha) + "\n")
    if r.codigo == 0:
        campos = r.stdout.split()
        if campos:
            hash_remoto = campos[0].lower()

    say("Descargando…")  # uxyngraphar:permitir-idioma
    if plataforma:
        cmd = "sudo cat " + q(DIR_RESPALDOS_PLATAFORMA + "/" + nombre) + " | base64 -w0"
    else:
        cmd = "sudo ux-as " + q(p["proyecto"]) + " ux-deploy descargar " + q(p["rol"]) + " " + q(nombre) + " | base64 -w0"
    r = e.ses.sudo(PRELUDIO + cmd + "\n", max_bytes=MAX_DESCARGA_B64)
    if r.codigo != 0:
        return fallo("el VPS no pudo entregar el respaldo: %s", util.truncar(r.stderr.strip(), 300))
    if len(r.stdout) >= MAX_DESCARGA_B64:
        return fallo("el respaldo es demasiado grande para verificarlo desde la app (usa age y rclone directamente)")
    try:
        cifrado = base64.b64decode(r.stdout.strip())
    except Exception as exc:  # noqa: BLE001
        return fallo("la descarga llegó dañada: %s", exc)  # uxyngraphar:permitir-idioma
    if not cifrado:
        return fallo("la descarga llegó dañada")  # uxyngraphar:permitir-idioma
    say("Descargado: %d bytes", len(cifrado))

    local = hashlib.sha256(cifrado).hexdigest()
    if not hash_remoto:
        say("⚠ el VPS no tiene archivo .sha256 para este respaldo; no se puede comparar la suma")  # uxyngraphar:permitir-idioma
    elif hash_remoto == local:
        say("✔ SHA-256 coincide con el publicado en el VPS")  # uxyngraphar:permitir-idioma
    else:
        return fallo("el SHA-256 no coincide (VPS %s, descarga %s)", hash_remoto, local)

    # descifrado local con el binario age (el estándar ya lo exige instalado)  # uxyngraphar:permitir-idioma
    destino_archivo = None
    ruta_destino = ""
    if p["destino"]:
        if not os.path.isdir(p["destino"]):
            return fallo("la carpeta de destino no existe")
        ruta_destino = os.path.join(p["destino"], nombre[: -len(".age")] if nombre.endswith(".age") else nombre)
        try:
            destino_archivo = open(ruta_destino, "xb")  # O_EXCL
        except OSError as exc:
            return fallo("no pude crear %s: %s", ruta_destino, exc)
        say("Guardando el descifrado en %s (SIN cifrar)", ruta_destino)
    try:
        proc = subprocess.run(
            ["age", "--decrypt", "-i", p["identidad"]],
            input=cifrado, capture_output=True, timeout=600,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        if destino_archivo:
            destino_archivo.close()
            os.remove(ruta_destino)
        return fallo("no pude ejecutar age en tu equipo: %s", exc)
    if proc.returncode != 0:
        if destino_archivo:
            destino_archivo.close()
            os.remove(ruta_destino)
        return fallo(
            "no pude descifrar con esa clave: %s (¿es la clave de recuperación o la de verificación?)",  # uxyngraphar:permitir-idioma
            util.truncar(proc.stderr.decode("utf-8", "replace").strip(), 200),
        )
    if destino_archivo:
        destino_archivo.write(proc.stdout)
        destino_archivo.close()
    say("✔ Descifrado correcto: %d bytes", len(proc.stdout))  # uxyngraphar:permitir-idioma

    if nombre.endswith(".dump.age"):
        if proc.stdout.startswith(_MAGIA_PGDMP):
            say("✔ Formato PostgreSQL (pg_dump custom) válido")  # uxyngraphar:permitir-idioma
        else:
            return fallo("el contenido descifrado no parece un pg_dump (cabecera inesperada)")
    else:
        if proc.stdout.startswith(_MAGIA_ZSTD):
            say("✔ Archivo tar comprimido con zstd válido")  # uxyngraphar:permitir-idioma
            _record_restore_test(e, nombre)  # uxyngraphar:permitir-idioma
        else:
            return fallo("el contenido descifrado no parece un tar.zst (cabecera inesperada)")
    say("")
    say("Verificación completa. Para restaurar de verdad sigue E14.7 (pg_restore en una base de prueba).")  # uxyngraphar:permitir-idioma
    return Resultado(codigo=0, salida="".join(sal))


# ───────────────────────────── alertas ─────────────────────────  # uxyngraphar:permitir-idioma


_RUTA_ALERTA_ENV = "/etc/ux/alerta.env"

_CLAVES_ALERTA = [
    ("correos", "DEPLOY_ALERT_EMAILS", False),
    ("smtp_host", "ALERT_SMTP_HOST", False),
    ("smtp_port", "ALERT_SMTP_PORT", False),
    ("smtp_user", "ALERT_SMTP_USER", False),
    ("smtp_password", "ALERT_SMTP_PASSWORD", True),
    ("smtp_from", "ALERT_SMTP_FROM", False),
    ("tg_token", "ALERT_TELEGRAM_BOT_TOKEN", True),
    ("tg_chat", "ALERT_TELEGRAM_CHAT_ID", False),
]


def _alertas_ops() -> list[Op]:
    return [
        Op(
            "alertas.leer", "alertas", "Configuración de alertas de la plataforma",  # uxyngraphar:permitir-idioma
            "Lee /etc/ux/alerta.env. Las contraseñas y tokens nunca se muestran: solo si están definidos.", LECTURA,  # uxyngraphar:permitir-idioma
            ejecutar=_alertas_leer,
        ),
        Op(
            "alertas.guardar", "alertas", "Guardar la configuración de alertas",  # uxyngraphar:permitir-idioma
            "Escribe /etc/ux/alerta.env (600, root). Los campos secretos en blanco conservan su valor actual. Cada canal es opcional.",
            CAMBIO,
            campos=[
                Campo("correos", "Correos de destino (coma)", "emails"),
                Campo("smtp_host", "Servidor SMTP", "host"),
                Campo("smtp_port", "Puerto SMTP", "puerto", defecto="587"),
                Campo("smtp_user", "Usuario SMTP", "texto_env"),
                Campo("smtp_password", "Contraseña SMTP", "secreto_env", secreto=True),  # uxyngraphar:permitir-idioma
                Campo("smtp_from", "Remitente", "email"),
                Campo("tg_token", "Token del bot de Telegram", "tg_token", secreto=True),
                Campo("tg_chat", "Chat ID de Telegram", "tg_chat"),
            ],
            ejecutar=_alertas_guardar,
        ),
        Op(
            "alertas.probar", "alertas", "Enviar una alerta de prueba",
            "ux-alerta con el mensaje indicado. Falla si ningún canal lo entrega.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[
                Campo("proyecto", "Proyecto (vacío = plataforma)", "proyecto"),  # uxyngraphar:permitir-idioma
                Campo("rol", "Rol (con proyecto)", "rol"),
                Campo("mensaje", "Mensaje", "texto", defecto="Prueba de alertas desde la app ux-infra"),
            ],
            script=lambda p: _script_alertas_probar(p),
        ),
    ]


def _alertas_leer(e: Entorno, p: dict, emitir: Callable[[str], None] | None) -> Resultado:
    r = e.ses.sudo(PRELUDIO + "sudo cat " + _RUTA_ALERTA_ENV + " 2>/dev/null; true\n")
    actual = parsear_env_comillas(r.stdout)
    datos: dict = {"existe": bool(actual)}
    lineas: list[str] = []
    for campo, clave, secreto in _CLAVES_ALERTA:
        v = actual.get(clave, "")
        if secreto:
            datos[campo + "_definida"] = bool(v)
            lineas.append(f"{clave}: {'definida' if v else 'no definida'}")
        else:
            datos[campo] = v
            lineas.append(f"{clave}: {v}")
    return Resultado(codigo=0, salida="\n".join(lineas), datos=datos)


def _alertas_guardar(e: Entorno, p: dict, emitir: Callable[[str], None] | None) -> Resultado:
    r = e.ses.sudo(PRELUDIO + "sudo cat " + _RUTA_ALERTA_ENV + " 2>/dev/null; true\n")
    actual = parsear_env_comillas(r.stdout)
    nuevo: dict[str, str] = {}
    for campo, clave, secreto in _CLAVES_ALERTA:
        v = p.get(campo, "")
        if secreto and not v:
            v = actual.get(clave, "")
        nuevo[clave] = v
    if nuevo["DEPLOY_ALERT_EMAILS"]:
        for k in ("ALERT_SMTP_HOST", "ALERT_SMTP_USER", "ALERT_SMTP_PASSWORD", "ALERT_SMTP_FROM"):
            if not nuevo[k]:
                raise ErrorOp(f"para el canal de correo falta {k}")
    if bool(nuevo["ALERT_TELEGRAM_BOT_TOKEN"]) != bool(nuevo["ALERT_TELEGRAM_CHAT_ID"]):
        raise ErrorOp("Telegram necesita el token del bot Y el chat ID")
    if not nuevo["DEPLOY_ALERT_EMAILS"] and not nuevo["ALERT_TELEGRAM_BOT_TOKEN"]:
        raise ErrorOp("configura al menos un canal (correo o Telegram)")
    if not nuevo["ALERT_SMTP_PORT"]:
        nuevo["ALERT_SMTP_PORT"] = "587"
    cuerpo = "# Alertas de la plataforma. Generado por la app ux-infra. Formato CLAVE='valor'.\n"
    for _, clave, _ in _CLAVES_ALERTA:
        cuerpo += f"{clave}='{nuevo[clave]}'\n"
    script = PRELUDIO + nl(
        'sudo install -d -m 755 /etc/ux || die "no pude crear /etc/ux"',
        tuberia_contenido(cuerpo) + f" | sudo sh -c 'umask 077; cat > {_RUTA_ALERTA_ENV}.nuevo' || die \"no pude escribir el archivo\"",
        f"sudo chown root:root {_RUTA_ALERTA_ENV}.nuevo && sudo chmod 600 {_RUTA_ALERTA_ENV}.nuevo && sudo mv -f {_RUTA_ALERTA_ENV}.nuevo {_RUTA_ALERTA_ENV} || die \"no pude instalar el archivo\"",
        'echo "alerta.env guardado (600, root)"',
    )
    rs = e.ses.sudo(script, emitir)
    return Resultado(codigo=rs.codigo, salida=salida_combinada(rs))


def _script_alertas_probar(p: dict) -> str:
    msg = or_default(p["mensaje"], "Prueba de alertas desde la app ux-infra")
    if p["proyecto"] and p["rol"]:
        cmd = "sudo ux-as " + q(p["proyecto"]) + " ux-alerta --rol " + q(p["rol"]) + " " + q(msg)
    elif p["proyecto"] or p["rol"]:
        raise ErrorOp("indica proyecto y rol, o ninguno")
    else:
        cmd = "sudo ux-alerta " + q(msg)
    return PRELUDIO + nl(
        'out="$(' + cmd + ' 2>&1)"',
        'echo "$out"',
        'if echo "$out" | grep -qiE \'no entregada|no enviada|no se pudo\'; then exit 1; fi',
        'echo "Alerta enviada: revisa tu correo o Telegram."',
    )


# ───────────────────────────── caddy ─────────────────────────  # uxyngraphar:permitir-idioma


_CADDY_DIR = "/home/ux-caddy/caddy"
_CADDY_USUARIO = "ux-caddy"


def _caddy_ops() -> list[Op]:
    return [
        Op(
            "caddy.state", "caddy", "Estado de Caddy",
            "Contenedor, validez de la configuración y sitios registrados.", LECTURA, parser=parsear_kv,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                f"if ! id {_CADDY_USUARIO} >/dev/null 2>&1; then echo \"usuario=no existe (E12)\"; exit 0; fi",
                f'echo "usuario={_CADDY_USUARIO}"',
                f"est=\"$(sudo ux-as {_CADDY_USUARIO} podman ps --filter name=caddy --format '{{{{.Status}}}}' 2>/dev/null | head -n1)\"",
                'echo "contenedor=${est:-detenido}"',
                f'val="$(sudo ux-as {_CADDY_USUARIO} podman exec caddy caddy validate --config /etc/caddy/Caddyfile 2>&1 | tail -n 1)"',
                'echo "validacion=${val:-sin respuesta}"',
                'echo "sitios=$(ls /etc/ux/caddy/sitios/*.caddy 2>/dev/null | wc -l)"',
                f"echo \"imagen=$(sudo ux-as {_CADDY_USUARIO} podman ps --filter name=caddy --format '{{{{.Image}}}}' 2>/dev/null | head -n1)\"",
            ),
        ),
        Op(
            "caddy.sitios", "caddy", "Sitios publicados",
            "Un archivo por rol en /etc/ux/caddy/sitios (los escribe ux-proyecto rol-alta; no se editan a mano).", LECTURA,
            parser=parsear_sitios,
            script=lambda p: PRELUDIO + nl(
                "for f in /etc/ux/caddy/sitios/*.caddy; do",
                '  [ -f "$f" ] || continue',
                '  echo "### $(basename "$f")"',
                '  cat "$f"',
                "done",
            ),
        ),
        Op(
            "caddy.validar", "caddy", "Validar la configuración",  # uxyngraphar:permitir-idioma
            "caddy validate dentro del contenedor.", LECTURA,
            script=lambda p: PRELUDIO + f"sudo ux-as {_CADDY_USUARIO} podman exec caddy caddy validate --config /etc/caddy/Caddyfile 2>&1\n",
        ),
        Op(
            "caddy.recargar", "caddy", "Recargar Caddy sin cortar conexiones",
            "ux-proyecto caddy-recargar: valida y aplica los sitios actuales.", CAMBIO,
            script=lambda p: PRELUDIO + "sudo ux-proyecto caddy-recargar\n",
        ),
        Op(
            "caddy.logs", "caddy", "Registro de Caddy",
            "Últimas líneas (certificados, errores, accesos).", LECTURA,  # uxyngraphar:permitir-idioma
            campos=[Campo("lineas", "Líneas", "lineas", defecto="200")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + f"sudo ux-as {_CADDY_USUARIO} podman logs --tail " + q(or_default(p["lineas"], "200")) + " caddy 2>&1\n",
        ),
        Op(
            "caddy.reiniciar", "caddy", "Recrear el contenedor de Caddy",
            "podman-compose up -d --force-recreate con el .env de Caddy. Corta las conexiones unos segundos.", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + f"sudo ux-as {_CADDY_USUARIO} sh -c " + q(f"cd {_CADDY_DIR} && set -a && . ./.env && set +a && podman-compose -p caddy up -d --force-recreate") + "\n",
        ),
        Op(
            "caddy.actualizar", "caddy", "Actualizar la imagen de Caddy",
            "podman-compose pull + up (E15.3). Antes revisa el tag fijado en compose.yaml.", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + f"sudo ux-as {_CADDY_USUARIO} sh -c " + q(f"cd {_CADDY_DIR} && set -a && . ./.env && set +a && podman-compose -p caddy pull && podman-compose -p caddy up -d") + "\n",
        ),
    ]


# ───────────────────────────── seguridad ─────────────────────────  # uxyngraphar:permitir-idioma


def _seguridad_ops() -> list[Op]:
    return [
        Op(
            "security.firewall", "seguridad", "Firewall (UFW)",
            "Debe estar activo y permitir solo SSH, 80, 443 y los puertos aprobados como abiertos (VPS → Puertos).", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + "sudo ufw status verbose\n",
        ),
        Op(
            "security.fail2ban", "seguridad", "fail2ban",
            "Cárceles activas y direcciones bloqueadas.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                "sudo fail2ban-client status",
                "echo",
                "sudo fail2ban-client status sshd",
            ),
        ),
        Op(
            "security.desbanear", "seguridad", "Desbloquear una IP",
            "Quita una IP de la cárcel sshd de fail2ban.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("ip", "Dirección IP", "ip", True)],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + "sudo fail2ban-client set sshd unbanip " + q(p["ip"]) + "\n",
        ),
        Op(
            "security.banear", "seguridad", "Bloquear una IP",
            "La añade a la cárcel sshd. No permite bloquear la IP desde la que estás conectado.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("ip", "Dirección IP", "ip", True)],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                'mia="${SSH_CLIENT%% *}"',
                '[ "$mia" != ' + q(p["ip"]) + ' ] || die "esa es tu propia IP de conexión: no se bloquea"',  # uxyngraphar:permitir-idioma
                "sudo fail2ban-client set sshd banip " + q(p["ip"]),
            ),
        ),
        Op(
            "security.ssh", "seguridad", "Configuración efectiva de SSH",  # uxyngraphar:permitir-idioma
            "sshd -T filtrado a las directivas de seguridad (E03).", LECTURA, parser=parsear_kv_espacios,
            script=lambda p: PRELUDIO + "sudo sshd -T | grep -E '^(port|permitrootlogin|passwordauthentication|pubkeyauthentication|kbdinteractiveauthentication|authenticationmethods|allowusers|allowgroups|maxauthtries|x11forwarding|logingracetime|clientaliveinterval|clientalivecountmax) '\n",
        ),
        Op(
            "security.accesos", "seguridad", "Accesos recientes",
            "Últimos inicios de sesión e intentos fallidos de SSH.", LECTURA,  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                'echo "== Últimos accesos"',  # uxyngraphar:permitir-idioma
                "last -n 15 -a 2>/dev/null | head -n 15",
                "echo",
                'echo "== Intentos fallidos recientes (SSH)"',
                "sudo journalctl -u ssh --no-pager -n 400 2>/dev/null | grep -E 'Failed|Invalid user|Disconnected from authenticating' | tail -n 25",
            ),
        ),
        Op(
            "security.imagenes", "seguridad", "Imágenes de un usuario",  # uxyngraphar:permitir-idioma
            "Imágenes presentes en producción (para escanearlas).", LECTURA, parser=parsear_imagenes,  # uxyngraphar:permitir-idioma
            campos=[Campo("usuario", "Proyecto", "usuario_podman", True)],
            script=lambda p: PRELUDIO + "sudo ux-as " + q(p["usuario"]) + " podman images --format '{{.Repository}}:{{.Tag}}|{{.Size}}|{{.CreatedSince}}'\n",
        ),
        Op(
            "security.trivy_imagen", "seguridad", "Escanear una imagen (Trivy)",
            "Exporta la imagen a un tar y la escanea (HIGH y CRITICAL con corrección). CRITICAL con fix = no desplegar.",  # uxyngraphar:permitir-idioma
            CAMBIO, largo=True,
            campos=[
                Campo("usuario", "Proyecto", "usuario_podman", True),
                Campo("imagen", "Imagen", "imagen", True),
            ],
            script=lambda p: _script_trivy_imagen(p),
        ),
        Op(
            "security.trivy_compose", "seguridad", "Auditar el compose de un rol (Trivy)",
            "trivy config sobre compose.yaml.", CAMBIO, largo=True,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: PRELUDIO + nl(
                'command -v trivy >/dev/null 2>&1 || die "Trivy no está instalado (E15.1)"',  # uxyngraphar:permitir-idioma
                "sudo trivy config --no-progress " + q(f"/home/{p['proyecto']}/roles/{p['rol']}/compose.yaml"),
            ),
        ),
        Op(
            "security.aislamiento", "seguridad", "Auditar el aislamiento de los contenedores",
            "ux-auditar: por cada contenedor de los proyectos, privilegios, modos host, capacidades efectivas, montajes, puertos frente a UX_PUERTO y red de la base; además el compose guardado, /home en 700 y los rangos subuid/subgid. Solo lee.",  # uxyngraphar:permitir-idioma
            LECTURA,
            campos=[Campo("proyecto", "Proyecto (vacío = todos)", "proyecto")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                'command -v ux-auditar >/dev/null 2>&1 || die "ux-auditar no está instalado: reejecuta la etapa E11"',  # uxyngraphar:permitir-idioma
                "sudo ux-auditar" + (" --proyecto " + q(p["proyecto"]) if p["proyecto"] else ""),
            ),
        ),
        Op(
            "security.compose_revisar", "seguridad", "Revisar el compose guardado de un rol",
            "Pasa el compose.yaml que hay en el VPS por el linter de políticas (privilegios, capacidades, volúmenes, puertos, base en red interna…): lo mismo que hará el próximo «publicar». Solo lee.",  # uxyngraphar:permitir-idioma
            LECTURA,
            campos=[_CAMPO_PROYECTO, _CAMPO_ROL],
            script=lambda p: _script_compose_revisar(p),
        ),
        Op(
            "security.imagenes_escanear", "seguridad", "Escanear las imágenes de los proyectos (Trivy)",  # uxyngraphar:permitir-idioma
            "ux-auditar --imagenes: exporta y escanea las imágenes de cada proyecto (CRITICAL con parche = falta, HIGH con parche = aviso) y audita el aislamiento de sus contenedores. Tarda.",  # uxyngraphar:permitir-idioma
            CAMBIO, largo=True,
            campos=[Campo("proyecto", "Proyecto (vacío = todos)", "proyecto")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + nl(
                'command -v trivy >/dev/null 2>&1 || die "Trivy no está instalado (E15.1)"',  # uxyngraphar:permitir-idioma
                'command -v ux-auditar >/dev/null 2>&1 || die "ux-auditar no está instalado: reejecuta la etapa E11"',  # uxyngraphar:permitir-idioma
                "sudo ux-auditar --imagenes" + (" --proyecto " + q(p["proyecto"]) if p["proyecto"] else ""),
            ),
        ),
        Op(
            "security.lynis", "seguridad", "Auditoría con Lynis",  # uxyngraphar:permitir-idioma
            "lynis audit system (trimestral, E15.4). Tarda unos minutos.", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + nl(
                'command -v lynis >/dev/null 2>&1 || die "Lynis no está instalado (E15.4: sudo apt install -y lynis)"',  # uxyngraphar:permitir-idioma
                "sudo lynis audit system --no-colors --quiet",
                'echo; echo "== Índice de hardening"; sudo grep -E \'^hardening_index=\' /var/log/lynis-report.dat',  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "security.instalar_herramientas", "seguridad", "Instalar Trivy y Lynis",
            "Trivy desde su repositorio apt oficial firmado (E15.1) y Lynis desde Debian (E15.4).", CAMBIO, largo=True,
            script=lambda p: PRELUDIO + nl(
                'sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y wget apt-transport-https gnupg lynis || die "no pude instalar dependencias"',
                "if ! command -v trivy >/dev/null 2>&1; then",
                '  wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | gpg --dearmor | sudo tee /usr/share/keyrings/trivy.gpg >/dev/null || die "no pude obtener la clave de Trivy"',
                '  echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] https://aquasecurity.github.io/trivy-repo/deb generic main" | sudo tee /etc/apt/sources.list.d/trivy.list >/dev/null',
                '  sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y && sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y trivy || die "no pude instalar Trivy"',
                "fi",
                "trivy --version | head -n 1; lynis --version",
            ),
        ),
    ] + _puertos_ops() + _firewall_ops() + _acceso_ops()


# Puertos y firewall del VPS (VPS → Puertos). Espejo de catalogo/ops.seguridad.puertos.ts y  # uxyngraphar:permitir-idioma
# catalogo/ops.seguridad.firewall.ts: generados desde la misma especificación (paridad byte a byte).  # uxyngraphar:permitir-idioma
_C_PUERTO = Campo("puerto", "Puerto", "puerto", True)
_C_PROTOCOLO = Campo("protocolo", "Protocolo", "select", True, opciones=["tcp", "udp"], defecto="tcp")
_C_MOTIVO = Campo("motivo", "Motivo", "texto", True, ayuda="Para qué es; queda anotado en /etc/ux/puertos.conf del VPS.")  # uxyngraphar:permitir-idioma
_C_ORIGEN = Campo("origen", "IP o red de origen", "cidr", True, ayuda="Una IP (203.0.113.7) o una red CIDR (203.0.113.0/24), IPv4 o IPv6.")


def _asignar(p: dict, pares: list[tuple[str, str]]) -> str:
    return "".join(v + "=" + q(p[c]) + "\n" for v, c in pares)


def _cabecera_puerto(p: dict, con_motivo: bool) -> str:
    return (PRELUDIO + "port=" + q(p["puerto"]) + "\nproto=" + q(p["protocolo"]) + "\n"
            + ("motivo=" + q(p["motivo"]) + "\n" if con_motivo else "") + _FN_UFW + _FN_DECISION_PUERTO)


_FN_UFW = nl(
    "sshp=$(sudo sshd -T 2>/dev/null | awk '$1==\"port\"{print $2; exit}')",
    "ufw_activo() { sudo ufw status 2>/dev/null | grep -q '^Status: active'; }",
    "respaldar() { local rd f; rd=/var/backups/ux-firewall/$(date +%Y%m%d-%H%M%S)-$1; while sudo test -e \"$rd\"; do rd=\"$rd.1\"; done; sudo install -d -m 700 \"$rd\" || die \"no pude crear el respaldo $rd\"; for f in /etc/ufw/user.rules /etc/ufw/user6.rules /etc/ux/puertos.conf; do if sudo test -f \"$f\"; then sudo cp -p \"$f\" \"$rd/\"; fi; done; sudo find /var/backups/ux-firewall -mindepth 1 -maxdepth 1 -type d -printf '%T@ %f\\n' 2>/dev/null | sort -n | head -n -20 | cut -d' ' -f2 | while read -r v; do sudo rm -rf \"/var/backups/ux-firewall/$v\"; done; echo \"Respaldo del firewall antes del cambio: ${rd##*/} (VPS → Puertos → Deshacer)\"; }",  # uxyngraphar:permitir-idioma
    "numeradas() { sudo ufw status numbered 2>/dev/null | awk '/^\\[/ {l=$0; n=l; sub(/^\\[ */,\"\",n); sub(/\\].*/,\"\",n); sub(/^\\[[^]]*\\] */,\"\",l); v=(l ~ /\\(v6\\)/) ? \"v6\" : \"v4\"; gsub(/ \\(v6\\)/,\"\",l); gsub(/  +/,\" \",l); print n \"\\t\" v \"\\t\" l}'; }",
)

_FN_DECISION_PUERTO = nl(
    "conf=/etc/ux/puertos.conf; k=\"$port/$proto\"",
    "case \"$port\" in \"${sshp:-22}\") die \"el puerto $port es el de SSH: se gestiona con «Cambiar el puerto SSH», «Limitar SSH» y «Restringir SSH»\" ;; esac",  # uxyngraphar:permitir-idioma
    "decision() { sudo awk -v k=\"$k\" '$1==k {print $2; exit}' \"$conf\" 2>/dev/null; }",
    "escucha() { sudo ss -Hltnu 2>/dev/null | awk -v p=\"$port\" -v t=\"$proto\" '$1==t && $5 !~ /^(127\\.|\\[::1\\]|::1)/ {n=split($5,a,\":\"); if (a[n]==p) print $5}' | paste -sd' ' -; }",
    "reglas() { numeradas | awk -F'\\t' -v k=\"$k\" -v p=\"$port\" '{split($3,f,\" \"); if ((f[1]==k || f[1]==p) && (f[2]==\"ALLOW\" || f[2]==\"LIMIT\") && f[3]!=\"OUT\") print $1 \"\\t\" $3}' | sort -rn; }",
    "quitar_reglas() { while IFS=$'\\t' read -r n l; do echo \"Retiro de UFW la regla [$n] $l\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; done < <(reglas); }",
    "resto() { if sudo test -f \"$conf\"; then sudo awk -v k=\"$k\" '$1!=k' \"$conf\"; else echo \"# Puertos aprobados desde la webapp (VPS → Puertos): puerto/protocolo decisión fecha motivo\"; fi; }",  # uxyngraphar:permitir-idioma
    "guardar() { sudo install -d -m 755 /etc/ux; sudo tee \"$conf.nuevo\" >/dev/null; sudo chmod 644 \"$conf.nuevo\"; sudo mv \"$conf.nuevo\" \"$conf\" || die \"no pude escribir $conf\"; }",
    "anotar() { { resto; printf '%s %s %s %s\\n' \"$k\" \"$1\" \"$(date +%F)\" \"$2\"; } | guardar; }",
    "estado() {",
    "  echo; echo \"== $k\"",
    "  l=$(escucha); echo \"escucha fuera de loopback: ${l:-no}\"",
    "  r=$(sudo ufw status 2>/dev/null | sed 's/ (v6)//g' | awk -v k=\"$k\" -v p=\"$port\" '($1==k || $1==p) && $3!=\"OUT\" && ($2==\"ALLOW\" || $2==\"LIMIT\" || $2==\"DENY\" || $2==\"REJECT\") {print $2}' | sort -u | paste -sd, -)",
    "  echo \"firewall: ${r:-sin regla (lo bloquea la política por defecto)}\"",  # uxyngraphar:permitir-idioma
    "  d=$(decision); echo \"decisión: ${d:-ninguna}\"",  # uxyngraphar:permitir-idioma
    "}",
)


def _puertos_ops() -> list[Op]:
    return [
        Op(
            "security.puerto_abrir", "seguridad", "Abrir un puerto en el firewall",
            "Lo permite en UFW para todo Internet (en lugar de las reglas que tuviera) y lo anota como aprobado y abierto en /etc/ux/puertos.conf: la verificación de E11 deja de marcarlo. También reabre 80 o 443 si los cerraste. El puerto SSH se gestiona aparte.", DESTRUCTIVO, confirma="ABRIR {puerto}/{protocolo}",  # uxyngraphar:permitir-idioma
            campos=[_C_PUERTO, _C_PROTOCOLO, _C_MOTIVO],
            script=lambda p: _cabecera_puerto(p, True) + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar puerto_abrir",
                "quitar_reglas",
                "sudo ufw allow \"$k\" comment 'ux-puertos' >/dev/null || die \"UFW no aceptó la regla para $k\"",  # uxyngraphar:permitir-idioma
                "anotar abierto \"$motivo\"",
                "echo \"Puerto $k abierto en el firewall y aprobado: la verificación de E11 ya no lo marca.\"",  # uxyngraphar:permitir-idioma
                "estado",
            ),
        ),
        Op(
            "security.puerto_dejar_cerrado", "seguridad", "Aprobar un puerto cerrado al exterior",
            "Acepta que el puerto escuche fuera de loopback pero lo mantiene bloqueado en UFW (retira las reglas que lo permitían) y lo anota como aprobado y cerrado: la verificación de E11 deja de marcarlo. Para detener lo que escucha, «Cerrar un puerto externo»; para 80 y 443, «Cerrar 80 o 443 (web)».", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[_C_PUERTO, _C_PROTOCOLO, _C_MOTIVO],
            script=lambda p: _cabecera_puerto(p, True) + nl(
                "case \"$port\" in 80|443) die \"80 y 443 se cierran con «Cerrar 80 o 443 (web)», que pide confirmación porque corta la web\" ;; esac",  # uxyngraphar:permitir-idioma
                "ufw_activo || die \"el firewall (UFW) no está activo: sin él ningún puerto queda cerrado al exterior (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar puerto_dejar_cerrado",
                "quitar_reglas",
                "anotar cerrado \"$motivo\"",
                "echo \"Puerto $k aprobado como cerrado: puede escuchar fuera de loopback, pero UFW lo bloquea.\"",
                "estado",
            ),
        ),
        Op(
            "security.puerto_olvidar", "seguridad", "Retirar la aprobación de un puerto",  # uxyngraphar:permitir-idioma
            "Borra la decisión de /etc/ux/puertos.conf y, si estaba abierto, retira sus reglas de UFW. Si el puerto sigue escuchando, la verificación de E11 vuelve a marcarlo. En 80 y 443 vuelve a la base de E06 (abiertos para Caddy).", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[_C_PUERTO, _C_PROTOCOLO],
            script=lambda p: _cabecera_puerto(p, False) + nl(
                "d=$(decision)",
                "[ -n \"$d\" ] || { echo \"El puerto $k no tenía decisión anotada: nada que retirar.\"; estado; exit 0; }",  # uxyngraphar:permitir-idioma
                "case \"$k\" in 80/tcp|443/tcp) base=1 ;; *) base=0 ;; esac",
                "respaldar puerto_olvidar",
                "[ \"$d\" != abierto ] || [ \"$base\" = 1 ] || quitar_reglas",
                "resto | guardar",
                "echo \"Aprobación de $k retirada (era: $d).\"",  # uxyngraphar:permitir-idioma
                "if [ \"$base\" = 1 ]; then",
                "  [ \"$d\" != cerrado ] || sudo ufw allow \"$k\" >/dev/null || die \"UFW no aceptó la regla para $k\"",  # uxyngraphar:permitir-idioma
                "  echo \"$k vuelve a la base de E06: abierto en el firewall para Caddy.\"",
                "else",
                "  [ -z \"$(escucha)\" ] || echo \"Sigue escuchando fuera de loopback: la verificación de E11 volverá a marcarlo.\"",  # uxyngraphar:permitir-idioma
                "fi",
                "estado",
            ),
        ),
        Op(
            "security.puerto_limitar", "seguridad", "Abrir un puerto con límite de conexiones",  # uxyngraphar:permitir-idioma
            "Lo abre en UFW con límite anti fuerza bruta (más de 6 conexiones en 30 s desde una misma IP se bloquean) en lugar de las reglas que tuviera, y lo anota como aprobado y abierto.", DESTRUCTIVO, confirma="LIMITAR {puerto}/{protocolo}",  # uxyngraphar:permitir-idioma
            campos=[_C_PUERTO, _C_PROTOCOLO, _C_MOTIVO],
            script=lambda p: _cabecera_puerto(p, True) + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar puerto_limitar",
                "quitar_reglas",
                "sudo ufw limit \"$k\" comment 'ux-puertos' >/dev/null || die \"UFW no aceptó el límite para $k\"",  # uxyngraphar:permitir-idioma
                "anotar abierto \"$motivo\"",
                "echo \"Puerto $k abierto con límite de conexiones (6 en 30 s por IP) y aprobado.\"",  # uxyngraphar:permitir-idioma
                "estado",
            ),
        ),
        Op(
            "security.web_cerrar", "seguridad", "Cerrar 80 o 443 (web) en el firewall",
            "Bloquea en UFW el puerto web aunque Caddy siga escuchando y lo anota como aprobado y cerrado. Cerrar 443 corta los sitios HTTPS; cerrar 80 corta la redirección a HTTPS y la renovación de certificados por HTTP. Se deshace con «Abrir un puerto» o «Retirar la aprobación».", DESTRUCTIVO, confirma="CERRAR {puerto}/tcp",  # uxyngraphar:permitir-idioma
            campos=[Campo("puerto", "Puerto web", "select", True, opciones=["80", "443"], defecto="80"), _C_MOTIVO],
            script=lambda p: _cabecera_puerto(dict(p, protocolo="tcp"), True) + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: sin él ningún puerto queda cerrado al exterior (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar web_cerrar",
                "quitar_reglas",
                "anotar cerrado \"$motivo\"",
                "echo \"Puerto $k cerrado en el firewall: Caddy sigue escuchando, pero desde fuera ya no llega.\"",
                "[ \"$port\" != 80 ] || echo \"Aviso: sin el 80, Caddy no puede renovar certificados por HTTP-01 (usa DNS-01 o reábrelo antes de que caduquen).\"",  # uxyngraphar:permitir-idioma
                "estado",
            ),
        ),
    ]


def _firewall_ops() -> list[Op]:
    return [
        Op(
            "security.puerto_permitir_origen", "seguridad", "Permitir un puerto solo desde una IP o red",
            "Abre el puerto en UFW solo para esa IP o red (CIDR) y retira las reglas que lo abrían a todo Internet. Lo anota como aprobado y abierto. Repite para añadir más orígenes.", DESTRUCTIVO, confirma="PERMITIR {puerto}/{protocolo} DESDE {origen}",  # uxyngraphar:permitir-idioma
            campos=[_C_PUERTO, _C_PROTOCOLO, _C_ORIGEN, _C_MOTIVO],
            script=lambda p: PRELUDIO + _asignar(p, [("port", "puerto"), ("proto", "protocolo"), ("origen", "origen"), ("motivo", "motivo")]) + _FN_UFW + _FN_DECISION_PUERTO + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar puerto_permitir_origen",
                "while IFS=$'\\t' read -r n l; do echo \"Retiro de UFW la regla [$n] $l (abierta a todo Internet)\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; done < <(reglas | awk -F'\\t' '$2 ~ / Anywhere/')",
                "sudo ufw allow from \"$origen\" to any port \"$port\" proto \"$proto\" comment 'ux-puertos' >/dev/null || die \"UFW no aceptó la regla para $k desde $origen\"",  # uxyngraphar:permitir-idioma
                "anotar abierto \"$motivo (solo desde orígenes permitidos)\"",  # uxyngraphar:permitir-idioma
                "echo \"Puerto $k permitido solo desde $origen.\"",
                "estado",
            ),
        ),
        Op(
            "security.puerto_quitar_origen", "seguridad", "Quitar un origen permitido de un puerto",
            "Retira de UFW las reglas que permiten el puerto desde esa IP o red. Si no queda ninguna, el puerto queda cerrado al exterior.", CAMBIO,
            campos=[_C_PUERTO, _C_PROTOCOLO, _C_ORIGEN],
            script=lambda p: PRELUDIO + _asignar(p, [("port", "puerto"), ("proto", "protocolo"), ("origen", "origen")]) + _FN_UFW + _FN_DECISION_PUERTO + nl(
                "respaldar puerto_quitar_origen",
                "m=0",
                "while IFS=$'\\t' read -r n l; do echo \"Retiro de UFW la regla [$n] $l\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; m=$((m + 1)); done < <(reglas | awk -F'\\t' -v o=\"$origen\" '{n=split($2,f,\" \"); for (i=2; i<=n; i++) if (f[i]==o) {print; break}}')",
                "[ \"$m\" -gt 0 ] || echo \"No había reglas de $k desde $origen.\"",  # uxyngraphar:permitir-idioma
                "[ -n \"$(reglas)\" ] || [ \"$(decision)\" != abierto ] || echo \"Ya no queda ninguna regla que permita $k: retira la aprobación o vuelve a abrirlo.\"",  # uxyngraphar:permitir-idioma
                "estado",
            ),
        ),
        Op(
            "security.rango_abrir", "seguridad", "Abrir un rango de puertos",
            "Permite en UFW un rango contiguo (hasta 1000 puertos, sin incluir SSH) para todo Internet y lo anota como aprobado y abierto: los puertos del rango dejan de marcarse en E11. Útil para mosh, WebRTC o FTP pasivo.", DESTRUCTIVO, confirma="ABRIR {desde}-{hasta}/{protocolo}",  # uxyngraphar:permitir-idioma
            campos=[Campo("desde", "Desde", "puerto", True), Campo("hasta", "Hasta", "puerto", True), _C_PROTOCOLO, _C_MOTIVO],
            script=lambda p: PRELUDIO + _asignar(p, [("desde", "desde"), ("hasta", "hasta"), ("proto", "protocolo"), ("motivo", "motivo")]) + nl(
                "port=\"$desde-$hasta\"",
            ) + _FN_UFW + _FN_DECISION_PUERTO + nl(
                "[ \"$desde\" -lt \"$hasta\" ] || die \"«Desde» debe ser menor que «Hasta»\"",  # uxyngraphar:permitir-idioma
                "[ $((hasta - desde)) -lt 1000 ] || die \"como máximo 1000 puertos por rango\"",  # uxyngraphar:permitir-idioma
                "[ \"${sshp:-22}\" -lt \"$desde\" ] || [ \"${sshp:-22}\" -gt \"$hasta\" ] || die \"el rango contiene el puerto SSH (${sshp:-22})\"",
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar rango_abrir",
                "sudo ufw allow \"$desde:$hasta/$proto\" comment 'ux-puertos' >/dev/null || die \"UFW no aceptó el rango $desde:$hasta/$proto\"",  # uxyngraphar:permitir-idioma
                "anotar abierto \"$motivo\"",
                "echo \"Rango $k abierto en el firewall y aprobado.\"",
                "sudo ufw status | grep -F \"$desde:$hasta/$proto\" || true",
            ),
        ),
        Op(
            "security.rango_cerrar", "seguridad", "Cerrar un rango de puertos",
            "Retira de UFW las reglas de ese rango y borra su aprobación de /etc/ux/puertos.conf.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("desde", "Desde", "puerto", True), Campo("hasta", "Hasta", "puerto", True), _C_PROTOCOLO],
            script=lambda p: PRELUDIO + _asignar(p, [("desde", "desde"), ("hasta", "hasta"), ("proto", "protocolo")]) + nl(
                "port=\"$desde-$hasta\"",
            ) + _FN_UFW + _FN_DECISION_PUERTO + nl(
                "respaldar rango_cerrar",
                "m=0",
                "while IFS=$'\\t' read -r n _ l; do echo \"Retiro de UFW la regla [$n] $l\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; m=$((m + 1)); done < <(numeradas | awk -F'\\t' -v r=\"$desde:$hasta/$proto\" '{split($3,f,\" \"); if (f[1]==r && f[3]!=\"OUT\") print}' | sort -rn)",
                "resto | guardar",
                "echo \"Rango $k cerrado: $m reglas retiradas de UFW y aprobación borrada.\"",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "security.ip_bloquear", "seguridad", "Bloquear una IP o red en el firewall",
            "Añade al principio de UFW una regla que rechaza todo el tráfico de esa IP o red (todos los puertos). No permite bloquear la IP desde la que se conecta Uxdeployar ni redes demasiado amplias.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("ip", "IP o red", "cidr", True, ayuda="Una IP (203.0.113.7) o una red CIDR (203.0.113.0/24)."), _C_MOTIVO],
            script=lambda p: PRELUDIO + _asignar(p, [("ip", "ip"), ("motivo", "motivo")]) + _FN_UFW + nl(
                "mia=\"${SSH_CLIENT%% *}\"",
                "case \"$ip\" in 0.0.0.0/0|::/0) die \"no se bloquea todo Internet: usa la política de entrada del firewall\" ;; esac",  # uxyngraphar:permitir-idioma
                "pre=\"${ip##*/}\"; [ \"$pre\" != \"$ip\" ] || pre=\"\"",
                "case \"$ip\" in *:*) [ -z \"$pre\" ] || [ \"$pre\" -ge 32 ] || die \"red IPv6 demasiado amplia (como mínimo /32)\" ;; *) [ -z \"$pre\" ] || [ \"$pre\" -ge 8 ] || die \"red IPv4 demasiado amplia (como mínimo /8)\" ;; esac",  # uxyngraphar:permitir-idioma
                "if [ -n \"$mia\" ] && { [ \"$mia\" = \"$ip\" ] || python3 -c 'import ipaddress,sys; sys.exit(0 if ipaddress.ip_address(sys.argv[1]) in ipaddress.ip_network(sys.argv[2], strict=False) else 1)' \"$mia\" \"$ip\" 2>/dev/null; }; then die \"Uxdeployar se conecta desde $mia: bloquear $ip lo dejaría sin acceso\"; fi",  # uxyngraphar:permitir-idioma
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "respaldar ip_bloquear",
                "sudo ufw prepend deny from \"$ip\" comment \"ux-bloqueo: $motivo\" >/dev/null || sudo ufw insert 1 deny from \"$ip\" comment \"ux-bloqueo: $motivo\" >/dev/null || die \"UFW no aceptó el bloqueo de $ip\"",  # uxyngraphar:permitir-idioma
                "echo \"Bloqueado $ip en todos los puertos ($motivo).\"",
                "numeradas | awk -F'\\t' '$3 ~ /ux-bloqueo/ {print \"[\" $1 \"] \" $3}'",
            ),
        ),
        Op(
            "security.ip_desbloquear", "seguridad", "Desbloquear una IP o red en el firewall",
            "Retira de UFW las reglas DENY/REJECT de esa IP o red. Para la cárcel de fail2ban, «Desbloquear una IP».", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("ip", "IP o red", "cidr", True)],
            script=lambda p: PRELUDIO + _asignar(p, [("ip", "ip")]) + _FN_UFW + nl(
                "respaldar ip_desbloquear",
                "m=0",
                "while IFS=$'\\t' read -r n _ l; do echo \"Retiro de UFW la regla [$n] $l\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; m=$((m + 1)); done < <(numeradas | awk -F'\\t' -v o=\"$ip\" '{n=split($3,f,\" \"); if (f[2]!=\"DENY\" && f[2]!=\"REJECT\") next; for (i=3; i<=n; i++) if (f[i]==o) {print; break}}' | sort -rn)",
                "if [ \"$m\" -gt 0 ]; then echo \"$ip desbloqueado ($m reglas).\"; else echo \"No había reglas que bloquearan $ip en UFW.\"; fi",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "security.regla_borrar", "seguridad", "Borrar una regla del firewall",
            "Borra de UFW la regla con ese número (el de VPS → Puertos → Firewall), también las creadas a mano. No permite borrar la última regla que deja entrar por SSH.", DESTRUCTIVO, confirma="BORRAR REGLA {numero}",  # uxyngraphar:permitir-idioma
            campos=[Campo("numero", "Número de regla", "texto", True, ayuda="El número entre corchetes de «ufw status numbered».")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + _asignar(p, [("numero", "numero")]) + _FN_UFW + nl(
                "[[ \"$numero\" =~ ^[0-9]{1,4}$ ]] || die \"el número de regla debe ser un entero (el que muestra VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "fila=$(numeradas | awk -F'\\t' -v n=\"$numero\" '$1==n')",
                "[ -n \"$fila\" ] || die \"no existe la regla [$numero] en UFW\"",
                "IFS=$'\\t' read -r _ fam l <<<\"$fila\"",
                "echo \"Regla [$numero] ($fam): $l\"",
                "permite_ssh() { awk -F'\\t' -v s=\"${sshp:-22}\" -v fam=\"$1\" '$2==fam {split($3,f,\" \"); if ((f[1]==s || f[1]==s \"/tcp\") && (f[2]==\"ALLOW\" || f[2]==\"LIMIT\") && f[3]!=\"OUT\") c++} END {print c+0}'; }",
                "if [ \"$(printf '%s\\n' \"$fila\" | permite_ssh \"$fam\")\" = 1 ] && [ \"$(numeradas | permite_ssh \"$fam\")\" -le 1 ]; then die \"es la última regla que permite SSH (${sshp:-22}) en $fam: borrarla dejaría el VPS sin acceso\"; fi",  # uxyngraphar:permitir-idioma
                "respaldar regla_borrar",
                "sudo ufw --force delete \"$numero\" >/dev/null || die \"UFW no pudo borrar la regla $numero\"",
                "echo \"Regla [$numero] borrada. Reglas que quedan (se renumeran):\"",
                "numeradas | awk -F'\\t' '{print \"[\" $1 \"] \" $3 ($2==\"v6\" ? \" (v6)\" : \"\")}'",
            ),
        ),
        Op(
            "security.firewall_registro", "seguridad", "Registro (logging) del firewall",
            "Nivel de registro de UFW en /var/log/ufw.log: off, low (bloqueos), medium o high (más detalle y más disco).", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("nivel", "Nivel", "select", True, opciones=["off", "low", "medium", "high"], defecto="low")],
            script=lambda p: PRELUDIO + _asignar(p, [("nivel", "nivel")]) + _FN_UFW + nl(
                "sudo ufw logging \"$nivel\" >/dev/null || die \"UFW no aceptó el nivel de registro $nivel\"",  # uxyngraphar:permitir-idioma
                "sudo ufw status verbose | grep -i '^Logging' || true",
            ),
        ),
        Op(
            "security.firewall_respaldar", "seguridad", "Respaldar el firewall ahora",
            "Copia las reglas de UFW y /etc/ux/puertos.conf a /var/backups/ux-firewall (se conservan los 20 últimos). Cada cambio de VPS → Puertos ya respalda solo.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[],
            script=lambda p: PRELUDIO + _asignar(p, []) + _FN_UFW + nl(
                "respaldar manual",
                "sudo find /var/backups/ux-firewall -mindepth 1 -maxdepth 1 -type d -printf '%T@ %f\\n' 2>/dev/null | sort -rn | head -n 20 | cut -d' ' -f2",
            ),
        ),
        Op(
            "security.firewall_restaurar", "seguridad", "Restaurar el firewall (deshacer)",
            "Vuelve las reglas de UFW y /etc/ux/puertos.conf a un respaldo («ultimo» = deshacer el último cambio). Antes respalda el estado actual. No restaura un respaldo que no permita entrar por SSH.", DESTRUCTIVO, confirma="RESTAURAR {respaldo}",  # uxyngraphar:permitir-idioma
            campos=[Campo("respaldo", "Respaldo", "texto", True, ayuda="«ultimo» o el nombre del respaldo (AAAAMMDD-HHMMSS-operación).", defecto="ultimo")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + _asignar(p, [("respaldo", "respaldo")]) + _FN_UFW + nl(
                "base=/var/backups/ux-firewall",
                "if [ \"$respaldo\" = ultimo ]; then r=$(sudo find \"$base\" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %f\\n' 2>/dev/null | sort -n | tail -n 1 | cut -d' ' -f2); else r=\"$respaldo\"; fi",
                "[ -n \"$r\" ] || die \"no hay respaldos del firewall todavía\"",  # uxyngraphar:permitir-idioma
                "[[ \"$r\" =~ ^[0-9]{8}-[0-9]{6}-[a-z0-9_.]+$ ]] || die \"nombre de respaldo no válido: $r\"",  # uxyngraphar:permitir-idioma
                "sudo test -f \"$base/$r/user.rules\" || die \"el respaldo $r no existe o no tiene user.rules\"",
                "sudo cat \"$base/$r/user.rules\" \"$base/$r/user6.rules\" 2>/dev/null | grep -Eq \"^### tuple ### (allow|limit) (tcp|any) ${sshp:-22} \" || die \"el respaldo $r no permite SSH (${sshp:-22}): restaurarlo dejaría el VPS sin acceso\"",  # uxyngraphar:permitir-idioma
                "respaldar firewall_restaurar",
                "for f in user.rules user6.rules; do if sudo test -f \"$base/$r/$f\"; then sudo install -m 640 -o root -g root \"$base/$r/$f\" \"/etc/ufw/$f\" || die \"no pude restaurar $f\"; fi; done",
                "if sudo test -f \"$base/$r/puertos.conf\"; then sudo install -d -m 755 /etc/ux; sudo install -m 644 -o root -g root \"$base/$r/puertos.conf\" /etc/ux/puertos.conf || die \"no pude restaurar puertos.conf\"; else echo \"# Puertos aprobados desde la webapp (VPS → Puertos): puerto/protocolo decisión fecha motivo\" | sudo tee /etc/ux/puertos.conf >/dev/null; fi",  # uxyngraphar:permitir-idioma
                "if ufw_activo; then sudo ufw reload >/dev/null || die \"UFW no pudo recargar las reglas restauradas\"; fi",
                "echo \"Firewall restaurado al respaldo $r.\"",
                "sudo ufw status verbose",
            ),
        ),
    ]


# Salvaguarda: si nadie la confirma (seguridad.salvaguarda_confirmar), el VPS deshace el cambio solo.
_FN_SALVAGUARDA = nl(
    "sg=/var/lib/ux/salvaguarda",
    "sg_pendiente() { sudo systemctl is-active --quiet ux-salvaguarda.timer; }",
    "sg_instantanea() { local f; sg_pendiente && die \"hay un cambio de acceso sin confirmar (se revierte solo en unos minutos): espera o confírmalo antes de hacer otro\"; sudo rm -rf \"$sg/previo\"; sudo install -d -m 700 \"$sg/previo\"; : | sudo tee \"$sg/previo/ausentes\" >/dev/null; for f in /etc/ufw/user.rules /etc/ufw/user6.rules /etc/ufw/ufw.conf /etc/default/ufw /etc/ux/puertos.conf /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf /etc/ssh/sshd_config.d/10-ux-puerto.conf /etc/fail2ban/jail.d/ux-sshd-puerto.local; do if sudo test -e \"$f\"; then sudo cp -p --parents \"$f\" \"$sg/previo/\"; else echo \"$f\" | sudo tee -a \"$sg/previo/ausentes\" >/dev/null; fi; done; }",  # uxyngraphar:permitir-idioma
    "reiniciar_ssh() { sudo systemctl daemon-reload; if sudo systemctl is-active --quiet ssh.socket; then sudo systemctl restart ssh.socket; else sudo systemctl restart ssh 2>/dev/null || sudo systemctl restart sshd; fi; }",
    "sg_armar() {",
    "  local min=\"$1\"",
    "  sudo tee \"$sg/revertir.sh\" >/dev/null <<'REV'",
    "#!/bin/bash",
    "# Uxdeployar: deshace el último cambio de acceso si nadie lo confirmó a tiempo.",  # uxyngraphar:permitir-idioma
    "d=/var/lib/ux/salvaguarda/previo",
    "[ -d \"$d\" ] || exit 0",
    "while read -r f; do [ -n \"$f\" ] && rm -f \"$f\"; done < \"$d/ausentes\"",
    "cp -a \"$d/etc/.\" /etc/",
    "systemctl daemon-reload",
    "if systemctl is-active --quiet ssh.socket; then systemctl restart ssh.socket; else systemctl restart ssh 2>/dev/null || systemctl restart sshd; fi",
    "if grep -q '^ENABLED=yes' /etc/ufw/ufw.conf 2>/dev/null; then ufw --force disable >/dev/null; ufw --force enable >/dev/null; else ufw --force disable >/dev/null; fi",
    "systemctl reload fail2ban 2>/dev/null || true",
    "echo \"revertido $(date -Is)\" > /var/lib/ux/salvaguarda/estado",
    "logger -t ux-salvaguarda \"cambio de acceso revertido: Uxdeployar no confirmó la reconexión a tiempo\"",  # uxyngraphar:permitir-idioma
    "REV",
    "  sudo chmod 700 \"$sg/revertir.sh\"",
    "  sudo systemctl reset-failed ux-salvaguarda.timer ux-salvaguarda.service >/dev/null 2>&1 || true",
    "  sudo systemd-run --quiet --unit=ux-salvaguarda --on-active=\"${min}min\" --timer-property=AccuracySec=5s /bin/bash \"$sg/revertir.sh\" || die \"no pude programar la reversión automática (systemd-run)\"",  # uxyngraphar:permitir-idioma
    "  echo \"armada $(date -d \"+$min min\" +%H:%M)\" | sudo tee \"$sg/estado\" >/dev/null",
    "  echo \"SALVAGUARDA: si Uxdeployar no vuelve a entrar, el VPS deshace este cambio solo a las $(date -d \"+$min min\" +%H:%M).\"",
    "}",
    "sg_deshacer_ya() { sudo systemctl stop ux-salvaguarda.timer 2>/dev/null; sudo bash \"$sg/revertir.sh\"; die \"$1: deshecho al momento\"; }",
    "reglas_ssh() { numeradas | awk -F'\\t' -v p=\"${sshp:-22}\" '{split($3,f,\" \"); if ((f[1]==p || f[1]==p \"/tcp\") && (f[2]==\"ALLOW\" || f[2]==\"LIMIT\") && f[3]==\"IN\") print $1 \"\\t\" f[4]}' | sort -rn; }",
)


def _acceso_ops() -> list[Op]:
    return [
        Op(
            "security.ssh_puerto_cambiar", "seguridad", "Cambiar el puerto SSH",
            "Con red de seguridad: SSH pasa a escuchar en el puerto viejo y en el nuevo (UFW con límite y fail2ban incluidos), Uxdeployar prueba a entrar por el nuevo y, si lo consigue, guarda el puerto nuevo y cierra el viejo. Si no puede entrar, el VPS lo deshace solo en los minutos indicados.", DESTRUCTIVO, confirma="CAMBIAR SSH A {puerto}",  # uxyngraphar:permitir-idioma
            campos=[Campo("puerto", "Puerto SSH nuevo", "puerto", True, ayuda="De 1024 a 65535, libre y sin otro uso aprobado."), Campo("minutos", "Minutos para deshacerlo si Uxdeployar no vuelve a entrar", "select", True, opciones=["2", "5", "10", "15"], defecto="5")],
            script=lambda p: PRELUDIO + _asignar(p, [("nuevo", "puerto"), ("min", "minutos")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "viejo=\"${sshp:-22}\"",
                "[ \"$nuevo\" != \"$viejo\" ] || die \"SSH ya escucha en el $nuevo\"",
                "[ \"$nuevo\" -ge 1024 ] || die \"usa un puerto de 1024 o más para SSH\"",  # uxyngraphar:permitir-idioma
                "case \"$nuevo\" in 80|443) die \"80 y 443 son de la web (Caddy)\" ;; esac",
                "[ -z \"$(sudo ss -Hltn \"( sport = :$nuevo )\" 2>/dev/null)\" ] || die \"el puerto $nuevo ya está en uso en el VPS\"",  # uxyngraphar:permitir-idioma
                "! sudo awk -v k=\"$nuevo/tcp\" '$1==k {f=1} END {exit !f}' /etc/ux/puertos.conf 2>/dev/null || die \"el puerto $nuevo/tcp está aprobado para otra cosa en VPS → Puertos: retíralo antes\"",  # uxyngraphar:permitir-idioma
                "sudo sshd -t || die \"la configuración actual de sshd ya tiene errores: corrígela antes\"",  # uxyngraphar:permitir-idioma
                "sg_instantanea",
                "respaldar ssh_puerto_cambiar",
                "otros=$(sudo grep -lsEi \"^[[:space:]]*Port[[:space:]]+$viejo[[:space:]]*$\" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf | grep -v '/10-ux-puerto\\.conf$')",
                "if [ -n \"$otros\" ]; then printf 'Port %s\\n' \"$nuevo\"; else printf 'Port %s\\nPort %s\\n' \"$viejo\" \"$nuevo\"; fi | sudo tee /etc/ssh/sshd_config.d/10-ux-puerto.conf >/dev/null",
                "sudo sshd -t || sg_deshacer_ya \"sshd rechazó la configuración nueva\"",  # uxyngraphar:permitir-idioma
                "if ufw_activo; then sudo ufw limit \"$nuevo/tcp\" comment 'ux-ssh' >/dev/null || sg_deshacer_ya \"UFW no aceptó el puerto $nuevo\"; fi",  # uxyngraphar:permitir-idioma
                "if sudo test -d /etc/fail2ban/jail.d; then printf '[sshd]\\nport = %s,%s\\n' \"$viejo\" \"$nuevo\" | sudo tee /etc/fail2ban/jail.d/ux-sshd-puerto.local >/dev/null; sudo systemctl reload fail2ban 2>/dev/null || true; fi",
                "sg_armar \"$min\"",
                "reiniciar_ssh || sg_deshacer_ya \"no pude reiniciar SSH\"",
                "sleep 2",
                "[ -n \"$(sudo ss -Hltn \"( sport = :$nuevo )\" 2>/dev/null)\" ] || sg_deshacer_ya \"sshd no quedó escuchando en el $nuevo\"",  # uxyngraphar:permitir-idioma
                "echo \"SSH escucha ahora en $viejo y $nuevo. Uxdeployar va a probar a entrar por el $nuevo; si lo consigue, cierra el $viejo.\"",
            ),
        ),
        Op(
            "security.ssh_puerto_retirar_viejo", "seguridad", "Cerrar el puerto SSH anterior",
            "Paso final de «Cambiar el puerto SSH» (lo lanza Uxdeployar tras entrar por el nuevo): SSH deja de escuchar en el puerto viejo y se retiran sus reglas de UFW y de fail2ban. Exige que SSH ya escuche en el nuevo.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("viejo", "Puerto SSH anterior", "puerto", True), Campo("nuevo", "Puerto SSH nuevo", "puerto", True)],
            script=lambda p: PRELUDIO + _asignar(p, [("viejo", "viejo"), ("nuevo", "nuevo")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "[ \"$viejo\" != \"$nuevo\" ] || die \"el puerto anterior y el nuevo son el mismo\"",
                "sudo sshd -T 2>/dev/null | awk '$1==\"port\"{print $2}' | grep -qx \"$nuevo\" || die \"SSH no escucha en el $nuevo: no cierro el $viejo\"",
                "respaldar ssh_puerto_retirar_viejo",
                "for f in /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf; do [ \"$f\" = /etc/ssh/sshd_config.d/10-ux-puerto.conf ] && continue; if sudo test -f \"$f\"; then sudo sed -i -E \"s/^([[:space:]]*Port[[:space:]]+$viejo[[:space:]]*)$/# \\1  # retirado por Uxdeployar (SSH en el $nuevo)/I\" \"$f\"; fi; done",
                "printf 'Port %s\\n' \"$nuevo\" | sudo tee /etc/ssh/sshd_config.d/10-ux-puerto.conf >/dev/null",
                "sudo sshd -t || die \"sshd rechazó la configuración: revisa /etc/ssh/sshd_config.d/10-ux-puerto.conf\"",  # uxyngraphar:permitir-idioma
                "reiniciar_ssh || die \"no pude reiniciar SSH\"",
                "if ufw_activo; then while IFS=$'\\t' read -r n _ l; do echo \"Retiro de UFW la regla [$n] $l\"; sudo ufw --force delete \"$n\" >/dev/null || die \"no pude retirar la regla $n de UFW\"; done < <(numeradas | awk -F'\\t' -v p=\"$viejo\" '{split($3,f,\" \"); if ((f[1]==p || f[1]==p \"/tcp\") && f[3]!=\"OUT\") print}' | sort -rn); fi",
                "if sudo test -f /etc/fail2ban/jail.d/ux-sshd-puerto.local; then printf '[sshd]\\nport = %s\\n' \"$nuevo\" | sudo tee /etc/fail2ban/jail.d/ux-sshd-puerto.local >/dev/null; sudo systemctl reload fail2ban 2>/dev/null || true; fi",
                "echo \"SSH queda solo en el $nuevo.\"",
                "sudo sshd -T 2>/dev/null | grep '^port '",
            ),
        ),
        Op(
            "security.ssh_limitar", "seguridad", "Limitar SSH (anti fuerza bruta)",
            "Cambia las reglas de SSH en UFW entre LIMIT (más de 6 conexiones en 30 s desde una IP se bloquean) y ALLOW (sin límite), conservando sus orígenes.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[Campo("modo", "Modo", "select", True, opciones=["limitar", "sin_limite"], defecto="limitar")],
            script=lambda p: PRELUDIO + _asignar(p, [("modo", "modo")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "if [ \"$modo\" = limitar ]; then a=limit; else a=allow; fi",
                "origenes=$(reglas_ssh | cut -f2 | sort -u)",
                "[ -n \"$origenes\" ] || die \"UFW no tiene ninguna regla que permita SSH (${sshp:-22})\"",
                "respaldar ssh_limitar",
                "for o in $origenes; do if [ \"$o\" = Anywhere ]; then sudo ufw \"$a\" \"${sshp:-22}/tcp\" comment 'ux-ssh' >/dev/null; else sudo ufw \"$a\" from \"$o\" to any port \"${sshp:-22}\" proto tcp comment 'ux-ssh' >/dev/null; fi || die \"UFW no aceptó el cambio para $o\"; done",  # uxyngraphar:permitir-idioma
                "echo \"SSH (${sshp:-22}) en modo $modo.\"",
                "sudo ufw status | grep -E \"^${sshp:-22}(/tcp)? \" || true",
            ),
        ),
        Op(
            "security.ssh_restringir", "seguridad", "Restringir SSH a ciertas IPs",
            "Con red de seguridad: SSH solo acepta conexiones desde esas IPs o redes (con límite); siempre se incluye la IP desde la que entra Uxdeployar. Vacío = volver a permitir SSH desde cualquier sitio. Si Uxdeployar no puede volver a entrar, el VPS lo deshace solo.", DESTRUCTIVO, confirma="RESTRINGIR SSH",  # uxyngraphar:permitir-idioma
            campos=[Campo("origenes", "IPs o redes permitidas", "origenes", False, ayuda="Separadas por comas (203.0.113.7, 198.51.100.0/24). Vacío = desde cualquier sitio."), Campo("minutos", "Minutos para deshacerlo si Uxdeployar no vuelve a entrar", "select", True, opciones=["2", "5", "10", "15"], defecto="5")],  # uxyngraphar:permitir-idioma
            script=lambda p: PRELUDIO + _asignar(p, [("origenes", "origenes"), ("min", "minutos")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "mia=\"${SSH_CLIENT%% *}\"",
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "lista=$(printf '%s' \"$origenes\" | tr ',' ' ')",
                "[ -z \"$lista\" ] || [ -n \"$mia\" ] || die \"no sé desde qué IP entra Uxdeployar: no restrinjo SSH a ciegas\"",  # uxyngraphar:permitir-idioma
                "sg_instantanea",
                "respaldar ssh_restringir",
                "sg_armar \"$min\"",
                "if [ -z \"$lista\" ]; then",
                "  sudo ufw limit \"${sshp:-22}/tcp\" comment 'ux-ssh' >/dev/null || sg_deshacer_ya \"UFW no aceptó la regla de SSH\"",  # uxyngraphar:permitir-idioma
                "  quitar=$(reglas_ssh | awk -F'\\t' '$2!=\"Anywhere\"')",
                "else",
                "  for o in $lista $mia; do sudo ufw limit from \"$o\" to any port \"${sshp:-22}\" proto tcp comment 'ux-ssh' >/dev/null || sg_deshacer_ya \"UFW no aceptó el origen $o\"; done",  # uxyngraphar:permitir-idioma
                "  quitar=$(reglas_ssh | awk -F'\\t' -v l=\" $lista $mia \" 'index(l, \" \" $2 \" \") == 0')",
                "fi",
                "while IFS=$'\\t' read -r n o; do [ -n \"$n\" ] || continue; echo \"Retiro de UFW la regla de SSH [$n] desde $o\"; sudo ufw --force delete \"$n\" >/dev/null || sg_deshacer_ya \"no pude retirar la regla $n\"; done <<<\"$quitar\"",
                "if [ -z \"$lista\" ]; then echo \"SSH permitido desde cualquier sitio (con límite).\"; else echo \"SSH solo desde: $lista (y $mia, desde donde entra Uxdeployar).\"; fi",  # uxyngraphar:permitir-idioma
                "reglas_ssh | cut -f2 | sort -u",
            ),
        ),
        Op(
            "security.firewall_politica", "seguridad", "Políticas por defecto del firewall",  # uxyngraphar:permitir-idioma
            "Con red de seguridad: qué hace UFW con lo que no tiene regla. Entrada: deny (recomendado), reject o allow (expone todo). Salida: allow (recomendado) o deny (deja salir solo DNS, HTTP(S) y NTP). Si Uxdeployar no puede volver a entrar, el VPS lo deshace solo.", DESTRUCTIVO, confirma="POLITICA {entrada}/{salida}",  # uxyngraphar:permitir-idioma
            campos=[Campo("entrada", "Entrada", "select", True, opciones=["deny", "reject", "allow"], defecto="deny"), Campo("salida", "Salida", "select", True, opciones=["allow", "deny"], defecto="allow"), Campo("minutos", "Minutos para deshacerlo si Uxdeployar no vuelve a entrar", "select", True, opciones=["2", "5", "10", "15"], defecto="5")],
            script=lambda p: PRELUDIO + _asignar(p, [("entrada", "entrada"), ("salida", "salida"), ("min", "minutos")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "ufw_activo || die \"el firewall (UFW) no está activo: actívalo antes (VPS → Puertos → Firewall)\"",  # uxyngraphar:permitir-idioma
                "sg_instantanea",
                "respaldar firewall_politica",
                "sg_armar \"$min\"",
                "if [ \"$salida\" = deny ]; then for r in 53 80/tcp 443/tcp 123/udp; do sudo ufw allow out \"$r\" comment 'ux-salida' >/dev/null || sg_deshacer_ya \"UFW no aceptó la salida $r\"; done; echo \"Salida denegada salvo DNS, HTTP(S) y NTP (reglas ux-salida).\"; fi",  # uxyngraphar:permitir-idioma
                "sudo ufw default \"$entrada\" incoming >/dev/null || sg_deshacer_ya \"UFW no aceptó la política de entrada\"",  # uxyngraphar:permitir-idioma
                "sudo ufw default \"$salida\" outgoing >/dev/null || sg_deshacer_ya \"UFW no aceptó la política de salida\"",  # uxyngraphar:permitir-idioma
                "[ \"$entrada\" != allow ] || echo \"Aviso: con entrada «allow» todo lo que escucha queda expuesto; la verificación de E11 lo marcará.\"",  # uxyngraphar:permitir-idioma
                "sudo ufw status verbose | grep -E '^(Default|Logging):'",
            ),
        ),
        Op(
            "security.firewall_activar", "seguridad", "Activar el firewall",
            "Con red de seguridad: asegura una regla que permita SSH y activa UFW. Si Uxdeployar no puede volver a entrar, el VPS lo desactiva solo.", CAMBIO,
            campos=[Campo("minutos", "Minutos para deshacerlo si Uxdeployar no vuelve a entrar", "select", True, opciones=["2", "5", "10", "15"], defecto="5")],
            script=lambda p: PRELUDIO + _asignar(p, [("min", "minutos")]) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "command -v ufw >/dev/null 2>&1 || die \"UFW no está instalado (etapa E06)\"",  # uxyngraphar:permitir-idioma
                "if ufw_activo; then echo \"UFW ya está activo.\"; sudo ufw status verbose; exit 0; fi",  # uxyngraphar:permitir-idioma
                "sg_instantanea",
                "respaldar firewall_activar",
                "sg_armar \"$min\"",
                "sudo ufw show added 2>/dev/null | grep -Eq \"^ufw (allow|limit) (${sshp:-22}|${sshp:-22}/tcp)( |$)\" || sudo ufw limit \"${sshp:-22}/tcp\" comment 'ux-ssh' >/dev/null || sg_deshacer_ya \"UFW no aceptó la regla de SSH\"",  # uxyngraphar:permitir-idioma
                "sudo ufw --force enable >/dev/null || sg_deshacer_ya \"UFW no se pudo activar\"",
                "sudo ufw status verbose",
            ),
        ),
        Op(
            "security.firewall_desactivar", "seguridad", "Desactivar el firewall",
            "Desactiva UFW: todo lo que escucha fuera de loopback queda expuesto a Internet y la verificación de E11 fallará. Las reglas se conservan para reactivarlo.", DESTRUCTIVO, confirma="DESACTIVAR FIREWALL",  # uxyngraphar:permitir-idioma
            campos=[],
            script=lambda p: PRELUDIO + _asignar(p, []) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "ufw_activo || { echo \"UFW ya está inactivo.\"; exit 0; }",  # uxyngraphar:permitir-idioma
                "respaldar firewall_desactivar",
                "sudo ufw --force disable >/dev/null || die \"UFW no se pudo desactivar\"",
                "echo \"UFW desactivado: todo lo que escucha fuera de loopback queda expuesto. Reactívalo con «Activar el firewall».\"",  # uxyngraphar:permitir-idioma
            ),
        ),
        Op(
            "security.salvaguarda_confirmar", "seguridad", "Confirmar un cambio de acceso",
            "Cancela la reversión automática pendiente tras un cambio de SSH o del firewall. Uxdeployar lo hace solo al volver a entrar; úsalo a mano solo si confirmaste el acceso por tu cuenta.", CAMBIO,  # uxyngraphar:permitir-idioma
            campos=[],
            script=lambda p: PRELUDIO + _asignar(p, []) + _FN_UFW + _FN_SALVAGUARDA + nl(
                "if sg_pendiente; then",
                "  sudo systemctl stop ux-salvaguarda.timer",
                "  sudo systemctl reset-failed ux-salvaguarda.service ux-salvaguarda.timer >/dev/null 2>&1 || true",
                "  echo \"confirmado $(date -Is)\" | sudo tee \"$sg/estado\" >/dev/null",
                "  echo \"Cambio de acceso confirmado: la reversión automática queda cancelada.\"",  # uxyngraphar:permitir-idioma
                "else",
                "  e=$(sudo cat \"$sg/estado\" 2>/dev/null)",
                "  echo \"No había reversión pendiente (${e:-sin historial}).\"",  # uxyngraphar:permitir-idioma
                "  [ \"${e%% *}\" != revertido ] || exit 3",
                "fi",
            ),
        ),
    ]


def _script_trivy_imagen(p: dict) -> str:
    tar = "/var/tmp/ux-scan-" + p["usuario"] + ".tar"
    return PRELUDIO + nl(
        'command -v trivy >/dev/null 2>&1 || die "Trivy no está instalado (E15.1)"',  # uxyngraphar:permitir-idioma
        "sudo rm -f " + q(tar),
        "sudo ux-as " + q(p["usuario"]) + " podman save --format docker-archive -o " + q(tar) + " " + q(p["imagen"]) + ' || die "no pude exportar la imagen"',
        "sudo trivy image --input " + q(tar) + " --severity HIGH,CRITICAL --ignore-unfixed --no-progress",
        "rc=$?",
        "sudo rm -f " + q(tar),
        "exit $rc",
    )


def _script_compose_revisar(p: dict) -> str:
    home = "/home/" + p["proyecto"]
    return PRELUDIO + nl(
        'sudo test -f /usr/local/lib/ux/ux-lint-compose.py || die "falta el linter del compose: reejecuta la etapa E11"',
        "f=" + q(home + "/roles/" + p["rol"] + "/compose.yaml"),
        'sudo test -f "$f" || die "el rol no tiene compose.yaml en el VPS: lo sube el CI con «subir compose»"',  # uxyngraphar:permitir-idioma
        "puerto=$(sudo grep '^UX_PUERTO=' " + q("/etc/ux/projects/" + p["proyecto"] + "/" + p["rol"] + ".env") + " 2>/dev/null | tr -dc 0-9)",
        'sudo python3 -I /usr/local/lib/ux/ux-lint-compose.py "$f" --rol ' + q(p["rol"]) + " --home " + q(home) + " --proyecto " + q(p["proyecto"]) + ' ${puerto:+--puerto "$puerto"}',
        "rc=$?",
        "echo",
        'if [ "$rc" -eq 0 ]; then echo "Cumple las políticas (los AVISO no bloquean salvo en modo estricto)."; else echo "INCUMPLE las políticas: el próximo «publicar» se bloqueará hasta subir un compose corregido."; fi',  # uxyngraphar:permitir-idioma
        'exit "$rc"',
    )


# ───────────────────────────── DNS (equipo local) ─────────────────────────  # uxyngraphar:permitir-idioma


def comprobar_dominios(ip_vps: str, dominios: list[str]) -> list[dict]:
    """Resuelve cada dominio y compara con la IP del VPS; si apunta, intenta el
    handshake TLS y lee el certificado. Corre en el equipo del administrador."""
    res: list[dict] = [{} for _ in dominios]
    hilos = []
    for i, d in enumerate(dominios):
        h = threading.Thread(target=lambda i=i, d=d: res.__setitem__(i, _comprobar_dominio(ip_vps, d)))
        hilos.append(h)
        h.start()
    for h in hilos:
        h.join()
    return res


def _comprobar_dominio(ip_vps: str, d: str) -> dict:
    from datetime import datetime, timezone

    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.x509.oid import NameOID

    e: dict = {"dominio": d.strip().lower(), "ips": [], "apunta": False}
    d = e["dominio"]
    if not util.es_dominio(d):
        e["error"] = "dominio no válido"  # uxyngraphar:permitir-idioma
        return e
    try:
        ips = sorted(set(info[4][0] for info in socket.getaddrinfo(d, 443, proto=socket.IPPROTO_TCP)))
    except OSError:
        e["error"] = "no resuelve (¿falta el registro DNS A?)"  # uxyngraphar:permitir-idioma
        return e
    e["ips"] = ips
    e["apunta"] = any(ip == ip_vps for ip in ips)
    if not e["apunta"]:
        return e
    try:
        contexto = ssl.create_default_context()
        contexto.minimum_version = ssl.TLSVersion.TLSv1_2
        with socket.create_connection((d, 443), timeout=6) as sock:
            with contexto.wrap_socket(sock, server_hostname=d) as tls:
                der = tls.getpeercert(binary_form=True)
                cert = x509.load_der_x509_certificate(der, default_backend())
    except Exception as exc:  # noqa: BLE001
        e["https"] = {"valido": False, "detalle": "sin HTTPS válido todavía: " + util.truncar(str(exc), 160)}  # uxyngraphar:permitir-idioma
        return e
    emisor = ""
    try:
        emisor = cert.issuer.get_attributes_for_oid(NameOID.COMMON_NAME)[0].value
    except Exception:  # noqa: BLE001
        emisor = ""
    vence = cert.not_valid_after_utc
    dias = (vence - datetime.now(timezone.utc)).days
    e["https"] = {"valido": True, "emisor": emisor, "vence": vence.strftime("%Y-%m-%d"), "dias": dias}
    return e


# ───────────────────────────── parsers ─────────────────────────  # uxyngraphar:permitir-idioma


def parsear_kv(stdout: str) -> Any:
    m: dict[str, str] = {}
    for l in stdout.split("\n"):
        l = l.rstrip("\r")
        if "=" in l:
            i = l.index("=")
            if i > 0:
                m[l[:i].strip()] = l[i + 1 :].strip()
    return m


def parsear_kv_espacios(stdout: str) -> Any:
    m: dict[str, str] = {}
    for l in stdout.split("\n"):
        l = l.strip()
        if not l:
            continue
        i = min((p for p in (l.find(" "), l.find("\t")) if p >= 0), default=-1)
        if i > 0:
            m[l[:i]] = l[i + 1 :].strip()
    return m


def parsear_listar(stdout: str) -> Any:
    filas = []
    for i, l in enumerate(stdout.split("\n")):
        c = l.split()
        if i == 0 and c and c[0] == "PROYECTO":
            continue
        if len(c) < 4:
            continue
        filas.append(
            {"proyecto": c[0], "rol": c[1], "dominio": c[2], "puerto": c[3], "version": c[4] if len(c) >= 5 else "-"}
        )
    return filas


_VER_RE = re.compile(r"^\[(OK|AVISO|FALTA)\]\s+(.*)$")


def parsear_verificar(stdout: str) -> Any:
    res = []
    for l in stdout.split("\n"):
        m = _VER_RE.match(l.rstrip("\r"))
        if m:
            res.append({"nivel": m.group(1).lower(), "texto": m.group(2)})
    return res


def parsear_contenedores(stdout: str) -> Any:
    res = []
    for l in stdout.split("\n"):
        c = l.rstrip("\r").split("|", 3)
        if len(c) < 3:
            continue
        res.append({"nombre": c[0], "estado": c[1], "imagen": c[2], "puertos": c[3] if len(c) == 4 else ""})
    return res


def parsear_imagenes(stdout: str) -> Any:
    res = []
    for l in stdout.split("\n"):
        c = l.rstrip("\r").split("|", 2)
        if len(c) < 3 or c[0].startswith("<none>"):
            continue
        res.append({"referencia": c[0], "tamano": c[1], "creada": c[2]})
    return res


_MOTIVO_RE = re.compile(r"-(daily|pre-deploy)\.(dump|tar)\.age$")


def parsear_respaldos_locales(stdout: str) -> Any:
    res = []
    for l in stdout.split("\n"):
        c = l.rstrip("\r").split("\t")
        if len(c) < 3:
            continue
        try:
            n = int(c[1])
        except ValueError:
            n = 0
        f = {"nombre": c[0], "bytes": n, "fecha": c[2], "motivo": ""}
        m = _MOTIVO_RE.search(c[0])
        if m:
            f["motivo"] = m.group(1)
        res.append(f)
    return res


def parsear_r2(stdout: str) -> Any:
    res = []
    for l in stdout.split("\n"):
        l = l.rstrip("\r")
        i = l.find(";")
        if i < 0:
            continue
        try:
            n = int(l[:i].strip())
        except ValueError:
            n = 0
        ruta = l[i + 1 :]
        o = {"prefijo": "", "nombre": ruta, "bytes": n}
        j = ruta.rfind("/")
        if j >= 0:
            o["prefijo"], o["nombre"] = ruta[:j], ruta[j + 1 :]
        res.append(o)
    return res


_DOMINIO_SITIO_RE = re.compile(r"^([A-Za-z0-9.-]+)\s*\{")
_DESTINO_RE = re.compile(r"reverse_proxy\s+(\S+)")


def parsear_sitios(stdout: str) -> Any:
    res = []
    cur: dict | None = None
    buf: list[str] = []

    def cerrar() -> None:
        nonlocal cur, buf
        if cur is not None:
            cur["texto"] = "\n".join(buf).strip()
            res.append(cur)
        cur, buf = None, []

    for l in stdout.split("\n"):
        l = l.rstrip("\r")
        if l.startswith("### "):
            cerrar()
            cur = {"archivo": l[4:].strip(), "dominio": "", "destino": "", "texto": ""}
            continue
        if cur is None:
            continue
        buf.append(l)
        m = _DOMINIO_SITIO_RE.match(l)
        if m and not cur["dominio"]:
            cur["dominio"] = m.group(1)
        m = _DESTINO_RE.search(l)
        if m and not cur["destino"]:
            cur["destino"] = m.group(1)
    cerrar()
    return res


_ENV_RE = re.compile(r"^([A-Z][A-Z0-9_]*)='([^']*)'$")


def parsear_env_comillas(texto: str) -> dict[str, str]:
    m: dict[str, str] = {}
    for l in texto.split("\n"):
        mm = _ENV_RE.match(l.rstrip("\r"))
        if mm:
            m[mm.group(1)] = mm.group(2)
    return m
