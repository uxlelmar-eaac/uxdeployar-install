set -o pipefail
die() { echo "ERROR: $*" >&2; exit 1; }
echo "▸ Limpieza de residuos de proyectos (contraste con el panel)"
ESPERADOS_RAW=''
declare -A ESP=()
ESP[ux-caddy]=1
ESP[uxdeployar]=1
for n in $ESPERADOS_RAW; do ESP["$n"]=1; done
echo "@@ESPERADOS"
printf "%s\n" $ESPERADOS_RAW
declare -A CAND=()
if sudo test -d /etc/ux/projects; then
  for d in /etc/ux/projects/*/; do
    sudo test -d "$d" || continue
    n=$(basename "$d")
    CAND["$n"]=1
  done
fi
if sudo test -d /etc/ux/caddy/sitios; then
  for f in /etc/ux/caddy/sitios/*.caddy; do
    sudo test -f "$f" || continue
    b=$(basename "$f" .caddy)
    n=${b%%-*}
    [ -n "$n" ] && CAND["$n"]=1
  done
fi
while IFS=: read -r u _ _ _ gecos home _; do
  case "$gecos" in ux-proyecto/*) CAND["$u"]=1 ;; esac
done < /etc/passwd
fallos=0
residuos=0
echo "@@RESUMEN"
for n in $(printf "%s\n" "${!CAND[@]}" | sort); do
  [ -n "${ESP[$n]:-}" ] && continue
  # Solo residuos del estándar ux-proyecto (no usuarios de apps uxa-/uxs-/uxp-).
  marca=0; getent passwd "$n" >/dev/null 2>&1 && case "$(getent passwd "$n" | cut -d: -f5)" in ux-proyecto/*) marca=1 ;; esac
  reg=0; sudo test -d /etc/ux/projects/"$n" && reg=1
  if [ "$marca" != 1 ] && [ "$reg" != 1 ]; then continue; fi
  residuos=$((residuos + 1))
  home=""; getent passwd "$n" >/dev/null 2>&1 && home=$(getent passwd "$n" | cut -d: -f6)
  home_ok=0; [ -n "$home" ] && [ -d "$home" ] && home_ok=1
  sitios=0; sudo test -d /etc/ux/caddy/sitios && sitios=$(sudo find /etc/ux/caddy/sitios -maxdepth 1 -type f -name "$n-*.caddy" 2>/dev/null | wc -l)
  archivo=0; sudo test -d /var/lib/ux/archivo && archivo=$(sudo find /var/lib/ux/archivo -maxdepth 1 -type d -name "$n-*" 2>/dev/null | wc -l)
  cont=0
  if [ "$marca" = 1 ] && command -v ux-as >/dev/null 2>&1; then
    cont=$(sudo ux-as "$n" podman ps -aq 2>/dev/null | wc -l)
    cont=${cont:-0}
  fi
  echo "@@RESIDUO $n registro=$reg usuario=$marca home=$home_ok sitios=$sitios archivo=$archivo contenedores=$cont"
  echo "▸ residuo: $n (registro=$reg usuario=$marca home=$home_ok sitios=$sitios contenedores=$cont)"
  echo "  · limpiando $n…"
  if command -v ux-proyecto >/dev/null 2>&1 && [ "$marca" = 1 ]; then
    if sudo ux-proyecto baja "$n" --confirmar "$n"; then
      echo "  ✔ baja vía ux-proyecto: $n"
      continue
    fi
    echo "  ! ux-proyecto baja falló; limpieza forzada"
  fi
  if [ "$marca" = 1 ]; then
    sudo ux-as "$n" podman stop --all --time 20 >/dev/null 2>&1 || true
    sudo loginctl disable-linger "$n" 2>/dev/null || true
    sudo loginctl terminate-user "$n" >/dev/null 2>&1 || true
    sleep 1
  fi
  for f in /etc/ux/caddy/sitios/"$n"-*.caddy; do
    sudo test -f "$f" || continue
    sudo rm -f -- "$f" && echo "  · sitio quitado: $(basename "$f")"
  done
  sudo rm -rf -- /etc/ux/projects/"$n"
  if [ "$home_ok" = 1 ]; then
    sudo install -d -m 700 -o root -g root /var/lib/ux/archivo
    dest=/var/lib/ux/archivo/"$n-$(date +%Y%m%d-%H%M%S)"
    sudo mv -- "$home" "$dest" && echo "  · home archivado en $dest"
  fi
  if getent passwd "$n" >/dev/null 2>&1; then
    if sudo userdel "$n" 2>/dev/null; then echo "  · usuario eliminado: $n"
    else echo "  ✗ no pude eliminar el usuario $n"; fallos=$((fallos + 1)); fi
  fi
  echo "  ✔ limpieza forzada de $n"
done
if command -v ux-proyecto >/dev/null 2>&1; then
  sudo ux-proyecto caddy-recargar 2>/dev/null || true
fi
echo "@@TOTAL residuos=$residuos fallos=$fallos"
if [ "$residuos" -eq 0 ]; then echo "✔ sin residuos de proyectos respecto al panel"; fi
[ "$fallos" -eq 0 ] || die "quedaron $fallos fallo(s) al limpiar residuos"
echo "@@FIN"
