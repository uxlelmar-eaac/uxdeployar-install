"""EXT-11: ``ux build`` on the operator PC → local Podman/Nixpacks → registry push.

The VPS then deploys the published digest as an IMAGEN app (ADR-007).
This module documents the command contract; the PC installer wires the CLI entry.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="ux build",
        description="Construye en el PC (Nixpacks/Podman) y publica la imagen en el registry.",
    )
    p.add_argument("ruta", nargs="?", default=".", help="Directorio del repositorio")
    p.add_argument("--tag", required=True, help="Referencia fully-qualified (registry/repo:tag)")
    p.add_argument("--platform", default="linux/amd64", help="Plataforma destino del VPS")
    args = p.parse_args(argv)

    if not shutil.which("nixpacks") and not shutil.which("podman"):
        print("Falta nixpacks o podman en el PATH del PC", file=sys.stderr)
        return 2
    # Generate Dockerfile then build+push with podman (operator must be logged in to the registry).
    out = subprocess.run(
        ["nixpacks", "build", args.ruta, "--out", ".ux-pack-out"],
        check=False,
    )
    if out.returncode != 0:
        return out.returncode
    build = subprocess.run(
        [
            "podman",
            "build",
            "--platform",
            args.platform,
            "-t",
            args.tag,
            "-f",
            ".ux-pack-out/.nixpacks/Dockerfile",
            args.ruta,
        ],
        check=False,
    )
    if build.returncode != 0:
        return build.returncode
    push = subprocess.run(["podman", "push", args.tag], check=False)
    return push.returncode


if __name__ == "__main__":
    raise SystemExit(main())
