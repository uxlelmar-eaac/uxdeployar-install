"""Gestor de trabajos largos (instalaciones, respaldos, escaneos…) y bitácora.

Espejo de ``05-vps/app/internal/jobs/jobs.go``: las tareas corren en
segundo plano, acumulan su salida (2 MiB máximo, lo más antiguo se descarta) y
la interfaz la consulta por sondeo con un desplazamiento, sin conexiones
abiertas. Solo hay **un trabajo a la vez**; los demás se rechazan con
``ErrorOcupado``.
"""

from __future__ import annotations

import secrets
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .util import truncar

MAX_SALIDA = 2 * 1024 * 1024  # 2 MiB por trabajo
MAX_ANILLO = 256 * 1024  # consola integrada

CORRIENDO = "corriendo"
EXITO = "ok"
FALLO = "error"
CANCELADO = "cancelado"


class ErrorOcupado(Exception):
    """Ya hay una tarea en curso."""


def _ahora() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _marca() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


class Trabajo:
    """Una tarea en segundo plano."""

    def __init__(self, id_: str, titulo: str, cancelar: threading.Event) -> None:
        self.id = id_
        self.titulo = titulo
        self.inicio = _ahora()
        self._cancelar = cancelar
        self._mu = threading.Lock()
        self.estado = CORRIENDO
        self.codigo = 0
        self.detalle = ""
        self._salida = bytearray()
        self._base = 0
        self.fin = ""
        self.marca = ""

    def marcar(self, m: str) -> None:
        with self._mu:
            self.marca = m

    def emitir(self, s: str) -> None:
        datos = s.encode("utf-8", errors="replace")
        with self._mu:
            self._salida.extend(datos)
            if len(self._salida) > MAX_SALIDA:
                corte = len(self._salida) - MAX_SALIDA
                del self._salida[:corte]
                self._base += corte

    def vista(self, desde: int) -> dict:
        with self._mu:
            if desde < self._base:
                desde = self._base
            fin = self._base + len(self._salida)
            if desde > fin:
                desde = fin
            trozo = bytes(self._salida[desde - self._base :]).decode("utf-8", errors="replace")
            v = {
                "id": self.id,
                "titulo": self.titulo,
                "estado": self.estado,
                "codigo": self.codigo,
                "detalle": self.detalle,
                "salida": trozo,
                "siguiente": fin,
                "inicio": self.inicio,
            }
            if self.fin:
                v["fin"] = self.fin
            if self.marca:
                v["marca"] = self.marca
        return v

    def texto(self) -> str:
        with self._mu:
            return bytes(self._salida).decode("utf-8", errors="replace")

    def _terminar(self, cancelado: bool, codigo: int, detalle: str, estado: str) -> None:
        with self._mu:
            self.fin = _ahora()
            self.codigo = codigo
            self.detalle = detalle
            self.estado = estado


# Función de un trabajo: (cancelar, emitir, trabajo) -> (codigo, detalle|None).
Funcion = Callable[[threading.Event, Callable[[str], None], "Trabajo"], tuple[int, str | None]]


class Gestor:
    """Administra los trabajos de la app (uno a la vez)."""

    def __init__(self, bitacora: "Bitacora") -> None:
        self._mu = threading.Lock()
        self._trabajos: dict[str, Trabajo] = {}
        self._orden: list[str] = []
        self._activo = ""
        self.bitacora = bitacora

    def lanzar(self, titulo: str, f: Funcion) -> Trabajo:
        with self._mu:
            if self._activo and self._activo in self._trabajos:
                t = self._trabajos[self._activo]
                with t._mu:
                    corriendo = t.estado == CORRIENDO
                if corriendo:
                    raise ErrorOcupado("ya hay una tarea en curso: espera a que termine o cancélala")
            id_ = secrets.token_hex(6)
            cancelar = threading.Event()
            t = Trabajo(id_, titulo, cancelar)
            self._trabajos[id_] = t
            self._orden.append(id_)
            self._activo = id_
            if len(self._orden) > 40:
                viejo = self._orden.pop(0)
                self._trabajos.pop(viejo, None)
        self.bitacora.registrar("trabajo", "inicio", titulo)

        def cuerpo() -> None:
            codigo, detalle = 1, "error interno"
            try:
                codigo, detalle = f(cancelar, t.emitir, t)
            except Exception as exc:  # noqa: BLE001 - nunca debe cerrar la app
                pila = traceback.format_exc()
                t.emitir(f"\nERROR INTERNO: {exc}\n{pila}\n")
                self.bitacora.registrar("trabajo", "panico", f"{titulo}: {exc}")
                codigo, detalle = 1, f"error interno: {exc}"
            if cancelar.is_set():
                t._terminar(True, codigo, "cancelado desde la interfaz", CANCELADO)
            elif detalle is not None:
                t._terminar(False, codigo, detalle, FALLO)
            elif codigo != 0:
                t._terminar(False, codigo, f"terminó con código {codigo}", FALLO)
            else:
                t._terminar(False, 0, "", EXITO)
            with t._mu:
                est, det = t.estado, t.detalle
            self.bitacora.registrar("trabajo", est, titulo + " " + det)

        threading.Thread(target=cuerpo, daemon=True).start()
        return t

    def obtener(self, id_: str) -> Trabajo | None:
        with self._mu:
            return self._trabajos.get(id_)

    def cancelar(self, id_: str) -> bool:
        t = self.obtener(id_)
        if t is None:
            return False
        t._cancelar.set()
        return True

    def recientes(self) -> list[dict]:
        with self._mu:
            ids = list(reversed(self._orden))
        res = []
        for id_ in ids:
            t = self.obtener(id_)
            if t is not None:
                v = t.vista(1 << 30)
                v["salida"] = ""
                res.append(v)
        return res

    def hay_trabajo(self) -> bool:
        with self._mu:
            t = self._trabajos.get(self._activo)
        if t is None:
            return False
        with t._mu:
            return t.estado == CORRIENDO


class Bitacora:
    """Una línea por evento en un archivo local. NUNCA recibe secretos."""

    def __init__(self, dir_: str = "") -> None:
        self._mu = threading.Lock()
        self.archivo = ""
        self._anillo = bytearray()
        self._base = 0
        if dir_:
            dir_path = Path(dir_)
            try:
                dir_path.mkdir(parents=True, exist_ok=True, mode=0o700)
            except OSError:
                return
            self._podar(dir_path, 30)
            self.archivo = str(dir_path / f"registro-{time.strftime('%Y%m%d-%H%M%S')}.log")

    def ruta(self) -> str:
        return self.archivo

    def mensaje(self, linea: str) -> None:
        with self._mu:
            self._anotar(linea)

    def _anotar(self, linea: str) -> None:
        self._anillo.extend(linea.encode("utf-8", errors="replace"))
        self._anillo.append(ord("\n"))
        if len(self._anillo) > MAX_ANILLO:
            corte = len(self._anillo) - MAX_ANILLO
            del self._anillo[:corte]
            self._base += corte

    def desde(self, desde: int) -> tuple[str, int]:
        with self._mu:
            fin = self._base + len(self._anillo)
            if desde < self._base:
                desde = self._base
            if desde > fin:
                desde = fin
            return bytes(self._anillo[desde - self._base :]).decode("utf-8", errors="replace"), fin

    def registrar(self, id_: str, estado: str, detalle: str = "") -> None:
        linea = f"{_marca()}  {id_}  {estado}  {truncar(detalle, 500)}"
        with self._mu:
            if self.archivo:
                try:
                    with open(self.archivo, "a", encoding="utf-8") as fh:
                        fh.write(linea + "\n")
                except OSError:
                    pass
            self._anotar(linea)

    @staticmethod
    def _podar(dir_path: Path, conservar: int) -> None:
        nombres = sorted(
            p.name
            for p in dir_path.iterdir()
            if p.is_file() and p.name.startswith("registro-") and p.name.endswith(".log")
        )
        for nombre in nombres[: max(0, len(nombres) - conservar)]:
            try:
                (dir_path / nombre).unlink()
            except OSError:
                pass
