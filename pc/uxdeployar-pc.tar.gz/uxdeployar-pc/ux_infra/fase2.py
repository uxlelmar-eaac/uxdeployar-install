"""Fase 2 guiada: ejecuta las etapas E00–E17 del protocolo en el VPS.

Espejo de ``05-vps/app/internal/fase2/``. Los comandos salen SIEMPRE de los
contratos (``vps/agent/stages``); la interfaz solo envía identificadores
(etapa, paso, bloque). El estado de las etapas vive en el VPS y lo gestiona
``init-vps.sh``.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import re
import socket
import tarfile
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import paramiko

from . import compartido, contratos, inventario, ops, sesion as sesion_mod, ssh as sshx, util

AGENT_DIR = "/opt/ux-infra/05-vps/agent"
INIT_VPS = AGENT_DIR + "/init-vps.sh"
# Los contratos que esta app lleva dentro (misma carpeta que usa el pack).
ETAPAS_DIR = Path(__file__).resolve().parents[3] / "vps" / "agent" / "stages"

# Catálogo declarativo de verificaciones (el mismo que leen el panel y el instalador).
CATALOGO_PATH = Path(__file__).resolve().parents[3] / "src" / "modules" / "phases" / "domain" / "catalogo" / "verificaciones.json"
# Scripts de las verificaciones con comprobación propia: los mismos archivos que lee el panel
# (`ContractsLoader.script`), sin el salto de línea final.
SCRIPTS_DIR = compartido.archivo("src/modules/phases/scripts")


def _script(nombre: str) -> str:
    texto = (SCRIPTS_DIR / f"{nombre}.sh").read_text(encoding="utf-8").replace("\r\n", "\n")
    return texto[:-1] if texto.endswith("\n") else texto


def _cargar_catalogo() -> dict:
    try:
        return json.loads(CATALOGO_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"filas": {}}


CATALOGO = _cargar_catalogo()


def fila_catalogo(etapa: str, fila: str) -> dict | None:
    return CATALOGO.get("filas", {}).get(f"{etapa}:{fila}")


# Protocolo de líneas por sujeto (gemelo de `sujetosDe` en fase2.resultado.ts).
_MARCAS = {"✔": "cumple", "✗": "no_cumple", "·": "no_aplica", "!": "advertencia", "?": "no_comprobable"}
_LINEA_SUJETO_RE = re.compile(
    r"^\s*([✔✗·!?])\s+(servidor|proyecto|rol|dominio):(\S+)\s+[—-]\s+(.*?)\s*(?:\[causa=([a-z_]+)\])?\s*$"
)


def sujetos_de(salida: str) -> list[dict]:
    out = []
    for l in salida.split("\n"):
        m = _LINEA_SUJETO_RE.match(l)
        if m:
            s = {"tipo": m.group(2), "id": m.group(3), "estado": _MARCAS[m.group(1)], "motivo": m.group(4)}
            if m.group(5):
                s["causa"] = m.group(5)
            out.append(s)
    return out


def sujetos_fallan(salida: str) -> str:
    """Motivo si algún sujeto «no cumple» (un código 0 no tapa un fallo declarado); vacío si no."""
    mal = [s for s in sujetos_de(salida) if s["estado"] == "no_cumple"]
    if not mal:
        return ""
    return "no cumple: " + " · ".join(f"{s['tipo']}:{s['id']} — {s['motivo']}" for s in mal[:3])


ESTADOS_PERMITIDOS = {"completada", "fallida", "pendiente", "bloqueada"}

DESTINOS: dict[str, tuple[str, str]] = {
    "13.1": ("proyectos", "Alta de proyecto (panel Proyectos)"),
    "13.2": ("proyectos", "Alta de rol y dominio (panel Proyectos)"),
    "13.3": ("proyectos", "Credenciales de R2 por proyecto (panel Proyectos)"),
    "13.4": ("proyectos", "Sesión en GHCR (panel Proyectos)"),
    "13.5": ("proyectos", "Verificación de proyectos (panel Proyectos)"),
}

ASISTENTES = {
    "1.2": "acceso-limpiar",
    "1.3": "acceso-llave",
    "1.4": "acceso-primer",
    "2.4": "comprobar",
    "3.4": "comprobar",
    "3.5": "totp",
    "14.1": "age",
    "14.2": "r2",
    "14.3": "r2-ciclo",
    "14.7": "restauracion",
    "15.2": "escaneo",
}

_CMD_RE = re.compile(r"`([^`]+)`")
_REINICIA_RE = re.compile(r"(^|[\s;&|])(sudo\s+)?(reboot|systemctl\s+reboot|shutdown\s+-r)\b")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_METODOS_RE = re.compile(r"attempted methods \[([^\]]*)\]")
_PUERTO_RE = re.compile(r'-p\s+("?\$\{VPS_SSH_PORT\}"?|\d+)')
_MARC_PROY_RE = re.compile(r"<(proyecto|rol|dominio-del-rol)>")


class ErrorSinRepo(Exception):
    """El protocolo todavía no está en el VPS (la app lo instala en la Fase 1)."""


# ───────────────────────────── sondas ─────────────────────────


@dataclass
class Sonda:
    usuario: str = "admin"  # admin | root | proyecto
    puerto: str = ""  # actual | nuevo | número
    remoto: str = ""
    espera: str = "ok"  # ok | rechazo | sin-password
    literal: str = ""


@dataclass
class Vars:
    ip: str = ""
    admin: str = ""
    puerto_nuevo: int = 2222
    dominio: str = ""


@dataclass
class ResultadoSonda:
    estado: str = ""
    salida: str = ""
    error: str = ""
    causa: str = ""  # solo con «red»: timeout (lo descarta un firewall) | cerrado (nada escucha) | red


CAUSA_RED = {
    "timeout": " (sin respuesta: un firewall descarta la conexión)",
    "cerrado": " (conexión rechazada: nada escucha en ese puerto)",
}


def causa_red(exc: OSError) -> str:
    if isinstance(exc, ConnectionRefusedError):
        return "cerrado"
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return "timeout"
    return "red"


ESPERA_REINTENTO = 33.0  # > ventana de 30 s de «ufw limit»; las pruebas la acortan


def probar_acceso(
    host: str,
    puerto: int,
    usuario: str,
    firmante,
    anclada,
    solo_password: bool,
    remoto: str,
    timeout: float = 12.0,
    codigo_2fa: str = "",
) -> ResultadoSonda:
    """Intenta una conexión independiente y clasifica lo que pasó (espejo de probarSSH)."""
    pidio2fa = False
    try:
        sock = socket.create_connection((host, puerto), timeout=timeout)
    except OSError as exc:
        return ResultadoSonda(estado="red", error=util.truncar(str(exc), 200), causa=causa_red(exc))
    t = paramiko.Transport(sock)
    try:
        sshx._aplicar_algoritmos(t, anclada)
        t.start_client(timeout=timeout)
        presentada = t.get_remote_server_key()
        if presentada is None or anclada is None or presentada.asbytes() != anclada.asbytes():
            return ResultadoSonda(estado="huella", error="el servidor presentó otra huella")

        def handler(_ti, _instr, preguntas):
            nonlocal pidio2fa
            if not preguntas:
                return []
            pidio2fa = True
            if codigo_2fa:
                return [codigo_2fa] * len(preguntas)
            raise paramiko.AuthenticationException("la sonda no responde al segundo factor")

        try:
            if solo_password:
                t.auth_password(usuario, "ux-sonda-no-es-una-clave")
            elif firmante is not None:
                # Llave y teclado-interactivo son ALTERNATIVAS (como en el original):
                # si la llave sola no basta (2FA), se prueba el teclado-interactivo.
                try:
                    t.auth_publickey(usuario, firmante)
                except paramiko.BadAuthenticationType:
                    pass  # el servidor no ofrece llaves
                except paramiko.AuthenticationException:
                    try:
                        t.auth_interactive(usuario, handler)
                    except (paramiko.AuthenticationException, paramiko.BadAuthenticationType):
                        pass
        except paramiko.BadAuthenticationType:
            # El servidor ni siquiera ofrece el método probado.
            if solo_password:
                return ResultadoSonda(estado="sin-password", error="Permission denied: el servidor no acepta contraseñas")
            return ResultadoSonda(estado="rechazado", error="el servidor no acepta ese método de autenticación")
        except paramiko.AuthenticationException:
            # paramiko no entrega la lista de métodos ofrecidos (OpenSSH sí): una
            # contraseña rechazada y un método ausente se ven igual. Para la
            # sonda «solo llaves» eso basta: nuestra contraseña de prueba no entró.
            if solo_password:
                return ResultadoSonda(estado="sin-password", error="Permission denied: el servidor no acepta contraseñas")
            if pidio2fa:
                return ResultadoSonda(estado="2fa", error="llave aceptada; el servidor pide además el código 2FA")
            return ResultadoSonda(estado="rechazado", error="autenticación rechazada")
        if solo_password:
            return ResultadoSonda(estado="con-password", error="el servidor aceptó una contraseña")
        if not remoto:
            return ResultadoSonda(estado="ok")
        try:
            chan = t.open_session(timeout=timeout)
            chan.exec_command(remoto)
            chan.shutdown_write()
            out = bytearray()
            while True:
                if chan.recv_ready():
                    trozo = chan.recv(65536)
                    if not trozo:
                        break
                    out.extend(trozo)
                elif chan.exit_status_ready():
                    break
                else:
                    import select

                    select.select([chan], [], [], 0.2)
            codigo = chan.recv_exit_status()
        except Exception as exc:  # noqa: BLE001
            return ResultadoSonda(estado="fallo-comando", error=util.truncar(str(exc), 200))
        salida = bytes(out).decode("utf-8", errors="replace").strip()
        if codigo != 0:
            return ResultadoSonda(estado="fallo-comando", salida=salida, error=f"código {codigo}")
        return ResultadoSonda(estado="ok", salida=salida)
    finally:
        try:
            t.close()
        except Exception:  # noqa: BLE001
            pass


def evaluar_sonda(s: Sonda, r: ResultadoSonda, desc: str) -> tuple[bool, str]:
    if s.espera == "ok":
        if r.estado == "ok":
            if s.literal and s.literal not in r.salida:
                return False, f"{desc} entró, pero la respuesta fue {util.truncar(r.salida, 120)!r} (se esperaba {s.literal!r})"
            return True, f"{desc} entra con la llave y responde {util.truncar(r.salida, 80)!r}"
        if r.estado == "2fa":
            return True, desc + " acepta la llave y pide el segundo factor (2FA activo)"
        return False, f"{desc} NO entra ({r.estado}): {r.error}{CAUSA_RED.get(r.causa, '')}"
    if s.espera == "rechazo":
        if r.estado == "rechazado":
            return True, desc + " rechazado, como se esperaba"
        if r.estado == "red" and r.causa == "timeout":
            return True, desc + " filtrado (un firewall descarta la conexión), como se esperaba"
        if r.estado == "red":
            return True, desc + " cerrado (no hay servicio SSH en ese puerto), como se esperaba"
        if r.estado == "fallo-comando":
            return True, f"{desc} no permite ese comando ({util.truncar(r.salida + ' ' + r.error, 120)}), como se esperaba"
        if r.estado == "sin-llave":
            return False, desc + ": no se pudo probar (" + r.error + ")"
        return False, f"{desc} NO fue rechazado ({r.estado})"
    if s.espera == "sin-password":
        if r.estado == "sin-password":
            return True, desc + ": " + r.error
        return False, desc + ": " + r.error
    return False, "sonda desconocida"


# ───────────────────────────── comprobaciones ─────────────────────────


@dataclass
class Comprobacion:
    tipo: str = "ninguna"  # vps | proyectos | sonda | local | ninguna
    cmd: str = ""
    local: str = ""
    sondas: list[Sonda] = field(default_factory=list)
    esperado: str = ""
    root: bool = False
    # Alcance declarado en el catálogo (servidor | proyecto | rol | dominio); vacío: se deduce del comando.
    alcance: str = ""

    def donde(self) -> str:
        if self.tipo in ("sonda", "local"):
            return "pc"
        if self.tipo == "proyectos":
            return "proyectos"
        if self.tipo == "vps":
            return "vps"
        return ""


_SCRIPT_FIREWALL_INICIAL = _script("firewall-baseline")

_SCRIPT_APT_PENDIENTES = _script("apt-pending")

_SCRIPT_PERMISOS_SSH = _script("ssh-permissions")

_SCRIPT_BAN = _script("ban")

_SCRIPT_TRAZA_SUDO = _script("sudo-trace")

_SCRIPT_CARCEL_SSH = _script("ssh-jail")

_SCRIPT_SIN_IPV6 = _script("no-ipv6")

_SCRIPT_UFWV6 = _script("ufw-no-v6")

# Script-backed checks decide with their exit code. The contract columns read
# «sin líneas» / «sin reglas (v6)», which `cumple` would pass on any failure.
_ESPERADO_SIN_IPV6 = "IPv6 apagado, o el del proveedor filtrado por UFW (lo decide el script)"
_ESPERADO_UFWV6 = "ninguna regla v6, salvo IPv6 del proveedor (lo decide el script)"

_SCRIPT_E14_TIMER = _script("e14-timer")

_SCRIPT_E14_REMOTO = _script("e14-remoto")

_SCRIPT_RCLONE_CIFRADO = _script("rclone-encrypted")

_SCRIPT_TRIVY = _script("trivy")

_SCRIPT_CALENDARIO = _script("calendar")

# Decisiones de puertos aprobadas por el humano (VPS → Puertos): «<puerto>/<proto> abierto|cerrado …».
_PUERTOS_APROBADOS = r"""apr=$(sudo awk '!/^[[:space:]]*#/ && NF>=2 {print $1, $2}' /etc/ux/puertos.conf 2>/dev/null || true)
ufw_ab=$(sudo ufw status 2>/dev/null | sed 's/ (v6)//' | awk '$2=="ALLOW"||$2=="LIMIT"{print $1}' | sort -u)
decision(){ awk -v k="$1" '$1==k {print $2; exit}' <<<"$apr"; }
"""

_SCRIPT_PUERTOS_EXTERNOS = _script("external-ports")

_SCRIPT_PLATAFORMA_PARCIAL = _script("platform-partial")

# The script decides with its exit code: the contract column names `[FALTA]`,
# and `cumple` would read it as "must not appear" even for the allowed E12–E14.
_ESPERADO_PLATAFORMA_PARCIAL = "ninguna falta propia de E11 (lo decide el script; las de E12–E14 quedan pendientes)"

_SCRIPT_CADDY_CORRE = _script("caddy-runs")

_SCRIPT_AA_ERRORES = _script("apparmor-errors")

# aa-enforce returns 0 for a missing profile, and a raw enforce count includes
# desktop profiles: check each critical profile that exists, by name.
_SCRIPT_AA_CRITICOS = _script("apparmor-critical")

_SCRIPT_AIDE = _script("aide")

_SCRIPT_REGLAS_AUDIT = _script("audit-rules")

_SCRIPT_TIMER_AIDE = _script("aide-timer")

_SCRIPT_BASE_AIDE = _script("aide-base")

_SCRIPT_SIN_SOCKET = _script("no-socket")

_SCRIPT_CADDY_ESCUCHA = _script("caddy-listens")

_SCRIPT_BD_INVISIBLE = _script("db-not-exposed")


# ───────────────────────────── cierre (E16) ─────────────────────────

_SCRIPT_CIERRE_ETAPAS = _script("closeout-stages")

_SCRIPT_CIERRE_SSH = _script("closeout-ssh")

_SCRIPT_CIERRE_PERMISOS = _script("closeout-permissions")

_SCRIPT_CIERRE_CUENTAS = _script("closeout-accounts")

_SCRIPT_CIERRE_UFW = _script("closeout-ufw")

# E12 needs 80/443 open in UFW (E06): caught here before the closeout (E16).
_SCRIPT_UFW_WEB = _script("ufw-web")

# `cumple` ignores the contract literal `<= 500M`: the cap is read from the journald config.
_SCRIPT_DRY_RUN_DESATENDIDO = _script("unattended-dry-run")

_SCRIPT_TOPE_JOURNAL = _script("journal-cap")

_SCRIPT_CIERRE_FAIL2BAN = _script("closeout-fail2ban")

_SCRIPT_CIERRE_SYSCTL = _script("closeout-sysctl")

_SCRIPT_CIERRE_SERVICIOS = _script("closeout-services")

_SCRIPT_CIERRE_PODMAN = _script("closeout-podman")

_SCRIPT_CIERRE_SEGURIDAD = _script("closeout-security")

_SCRIPT_CIERRE_RESPALDOS = _script("closeout-backups")

_SCRIPT_CIERRE_HERRAMIENTAS = _script("closeout-tools")

_SCRIPT_CIERRE_UDP = _script("closeout-udp")

# A bouncer installed before crowdsec was configured has no API key and blocks
# nothing: check both services and that a bouncer actually pulls decisions.
_SCRIPT_CROWDSEC = _script("cond-05-if-crowdsec")

# Validación ampliada de E16: cada script lista ✔/✗ por detalle y su código de salida decide
# (la columna del contrato es para leerla; sus literales no salen tal cual en la salida).
# Sin palabras que `cumple` lee como «no debe dar resultados» («falla», «sin …»).
_DETALLE = "cada detalle en ✔ (lo decide el script; un ✗ basta)"

_SOBRESCRITURAS: dict[str, Comprobacion] = {
    "00:Inventario completo": Comprobacion(tipo="local", local="inventario"),
    "00:Placeholders reemplazados": Comprobacion(
        tipo="vps",
        cmd="if [ -s inventory/inventory.yaml ]; then grep -vE '^\\s*#' inventory/inventory.yaml | grep -nE '<[^>]+>' | grep -vE '^[0-9]+:\\s*(r2_account_id|age_recipient|proveedor_dns):'; else echo 'falta inventory/inventory.yaml'; fi",
        esperado="sin resultados",
    ),
    # An empty VPS_IP means the inventory did not load: fail instead of passing.
    "00:Variables exportadas": Comprobacion(tipo="vps", cmd='test -n "$VPS_IP" && echo "$VPS_IP"', esperado="la IP real del VPS"),
    "01:Sistema al día": Comprobacion(tipo="vps", cmd=_SCRIPT_APT_PENDIENTES),
    "01:Firewall de partida": Comprobacion(tipo="vps", cmd=_SCRIPT_FIREWALL_INICIAL),
    "02:Permisos .ssh": Comprobacion(tipo="vps", cmd=_SCRIPT_PERMISOS_SSH),
    "02:Traza de sudo": Comprobacion(tipo="vps", cmd=_SCRIPT_TRAZA_SUDO),
    "02:Sesión de respaldo": Comprobacion(tipo="local", local="sesion"),
    "04:Dry-run": Comprobacion(tipo="vps", cmd=_SCRIPT_DRY_RUN_DESATENDIDO, esperado=_DETALLE),
    "04:Journal": Comprobacion(tipo="vps", cmd=_SCRIPT_TOPE_JOURNAL, esperado=_DETALLE),
    # Provider images (Vultr) ship UFW already active: a literal `Status: active` would skip 6.2.
    "06:Firewall activo": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_UFW, esperado=_DETALLE),
    "03:Puerto activo": Comprobacion(tipo="vps", cmd="sudo ss -tlnp | grep sshd", esperado="escucha en `:${VPS_SSH_PORT}`"),
    "03:*(si 2FA)*": Comprobacion(
        tipo="vps",
        cmd=_script("cond-03-if-2fa"),
        esperado="`publickey,keyboard-interactive`",
    ),
    "05:Ban real": Comprobacion(tipo="vps", cmd=_SCRIPT_BAN),
    "05:Cárcel SSH": Comprobacion(tipo="vps", cmd=_SCRIPT_CARCEL_SSH),
    "05:*(si CrowdSec)*": Comprobacion(tipo="vps", cmd=_SCRIPT_CROWDSEC, esperado=_DETALLE),
    "08:Sin IPv6": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_IPV6, esperado=_ESPERADO_SIN_IPV6),
    "08:UFW sin v6": Comprobacion(tipo="vps", cmd=_SCRIPT_UFWV6, esperado=_ESPERADO_UFWV6),
    "16:IPv6 off": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_IPV6, esperado=_ESPERADO_SIN_IPV6),
    "07:Claves aplicadas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SYSCTL),
    "09:Sin errores AA": Comprobacion(tipo="vps", cmd=_SCRIPT_AA_ERRORES),
    "09:AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_AIDE),
    "09:Reglas audit": Comprobacion(tipo="vps", cmd=_SCRIPT_REGLAS_AUDIT, esperado=_DETALLE),
    "09:Timer AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_TIMER_AIDE, esperado=_DETALLE),
    "16:Reglas audit": Comprobacion(tipo="vps", cmd=_SCRIPT_REGLAS_AUDIT, esperado=_DETALLE),
    "16:Timer AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_TIMER_AIDE, esperado=_DETALLE),
    "09:Críticos en enforce": Comprobacion(tipo="vps", cmd=_SCRIPT_AA_CRITICOS, esperado=_DETALLE),
    "12:Escucha 80/443": Comprobacion(tipo="vps", cmd=_SCRIPT_CADDY_ESCUCHA),
    "12:UFW permite 80/443": Comprobacion(tipo="vps", cmd=_SCRIPT_UFW_WEB, esperado=_DETALLE),
    "10:Sin socket": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_SOCKET, esperado="`masked`"),
    "16:Sin socket": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_SOCKET, esperado="`masked`"),
    "11:Plataforma": Comprobacion(tipo="vps", cmd=_SCRIPT_PLATAFORMA_PARCIAL, esperado=_ESPERADO_PLATAFORMA_PARCIAL),
    "12:Plataforma": Comprobacion(tipo="vps", cmd=_SCRIPT_CADDY_CORRE),
    "14:Timer": Comprobacion(tipo="vps", cmd=_SCRIPT_E14_TIMER),
    "14:Remoto": Comprobacion(tipo="vps", cmd=_SCRIPT_E14_REMOTO),
    "14:Solo cifrado": Comprobacion(tipo="vps", cmd=_SCRIPT_RCLONE_CIFRADO),
    "14:Restauración": Comprobacion(tipo="local", local="restauracion"),
    "14:Alertas": Comprobacion(tipo="vps", cmd=_script("closeout-alerts"), esperado=_DETALLE),
    "15:Trivy corre": Comprobacion(tipo="vps", cmd=_SCRIPT_TRIVY),
    "15:Calendario visible": Comprobacion(tipo="vps", cmd=_SCRIPT_CALENDARIO),
    "15:Base de AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_BASE_AIDE, esperado=_DETALLE),
    "16:Puertos": Comprobacion(tipo="vps", cmd=_SCRIPT_PUERTOS_EXTERNOS),
    "16:Sin puertos extra": Comprobacion(tipo="vps", cmd=_SCRIPT_PUERTOS_EXTERNOS),
    "16:Sin publicación": Comprobacion(tipo="local", local="http-cerrado"),
    "16:TLS de un rol": Comprobacion(tipo="local", local="tls"),
    "16:Restauración": Comprobacion(tipo="local", local="restauracion"),
    "16:BD invisible": Comprobacion(tipo="proyectos", cmd=_SCRIPT_BD_INVISIBLE),
    "16:Etapas previas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_ETAPAS, esperado=_DETALLE),
    "16:SSH efectivo": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SSH, esperado=_DETALLE),
    "16:Permisos críticos": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_PERMISOS, esperado=_DETALLE),
    "16:Cuentas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_CUENTAS, esperado=_DETALLE),
    "16:UFW detallado": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_UFW, esperado=_DETALLE),
    "16:Fail2Ban detallado": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_FAIL2BAN, esperado=_DETALLE),
    "16:Sysctl completo": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SYSCTL, esperado=_DETALLE),
    "16:Servicios y parches": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SERVICIOS, esperado=_DETALLE),
    "16:Podman y Caddy": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_PODMAN, esperado=_DETALLE),
    "16:MAC y auditoría": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SEGURIDAD, esperado=_DETALLE),
    # Explicit verdict per subject (role, project, server) instead of guessing from the contract text.
    "16:Plataforma": Comprobacion(tipo="vps", cmd=_script("closeout-platform"), esperado=_DETALLE),
    "16:Respaldo de roles": Comprobacion(tipo="vps", alcance="rol", cmd=_script("closeout-role-backups"), esperado=_DETALLE),
    "16:Alertas": Comprobacion(tipo="vps", cmd=_script("closeout-alerts"), esperado=_DETALLE),
    "16:Respaldos en R2": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_RESPALDOS, esperado=_DETALLE),
    "16:Herramientas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_HERRAMIENTAS, esperado=_DETALLE),
    "16:Sin UDP expuesto": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_UDP, esperado=_DETALLE),
}


def _sondas_de(cmd: str, esperado: str) -> list[Sonda]:
    usuario = "admin"
    if "root@" in cmd:
        usuario = "root"
    elif "<proyecto>@" in cmd:
        usuario = "proyecto"
    puerto = ""
    m = _PUERTO_RE.search(cmd)
    if m:
        puerto = "nuevo" if "VPS_SSH_PORT" in m.group(1) else m.group(1)
    remoto = ""
    i = cmd.rfind("'")
    if i > 0:
        j = cmd.rfind("'", 0, i)
        if j >= 0:
            remoto = cmd[j + 1 : i]
    elif (f := cmd.split()) and "@" not in f[-1]:
        remoto = f[-1].strip('"')
    e = esperado.lower()
    espera, literal = "ok", ""
    if "PubkeyAuthentication=no" in cmd:
        espera = "sin-password"
    elif "rechazado" in e or "denied" in e:
        espera = "rechazo"
        if not remoto:
            remoto = "echo x"
    else:
        m = re.search(r"`([^`]+)`", esperado)
        if m:
            literal = m.group(1)
    if usuario == "root" and not puerto:
        return [
            Sonda(usuario="root", puerto="22", remoto=remoto, espera=espera),
            Sonda(usuario="root", puerto="nuevo", remoto=remoto, espera=espera),
        ]
    if not puerto:
        puerto = "actual"
    return [Sonda(usuario=usuario, puerto=puerto, remoto=remoto, espera=espera, literal=literal)]


def _comprobacion_local(etapa: str, celdas: list[str]) -> str:
    if etapa != "01" or len(celdas) < 4:
        return ""
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return ""
    if "LLAVE_PRIVADA" in m.group(1) or "LLAVE_PUBLICA" in m.group(1):
        return "llaves"
    if m.group(1).startswith("ssh "):
        return "acceso"
    return ""


def _comando_de_verificacion(celdas: list[str]) -> str:
    if len(celdas) < 4:
        return ""
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return ""
    cmd = m.group(1).replace("\\|", "|")
    if "LLAVE_PRIVADA" in cmd or "LLAVE_PUBLICA" in cmd:
        return ""
    if cmd.startswith("ssh ") or ("<" in cmd and ">" in cmd and re.search(r"<[A-Za-z]", cmd)):
        return ""
    if cmd.lower().startswith("ver "):
        return ""
    return cmd


def clasificar(etapa: str, celdas: list[str]) -> Comprobacion:
    c = _clasificar_fila(etapa, celdas)
    if c.tipo == "proyectos" and not c.alcance and len(celdas) >= 4:
        f = fila_catalogo(etapa, celdas[1])
        if f and f.get("alcance"):
            c = dataclasses.replace(c, alcance=f["alcance"])
    return c


def _clasificar_fila(etapa: str, celdas: list[str]) -> Comprobacion:
    if len(celdas) < 4:
        return Comprobacion()
    esperado = celdas[3]
    clave = f"{etapa}:{celdas[1]}"
    if clave in _SOBRESCRITURAS:
        c = _SOBRESCRITURAS[clave]
        if not c.esperado:
            c.esperado = esperado
        return c
    if (l := _comprobacion_local(etapa, celdas)) != "":
        return Comprobacion(tipo="local", local=l, esperado=esperado)
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return Comprobacion(esperado=esperado)
    cmd = m.group(1).replace("\\|", "|")
    if cmd.startswith("ssh "):
        return Comprobacion(tipo="sonda", sondas=_sondas_de(cmd, esperado), esperado=esperado, root="root@" in cmd)
    if _MARC_PROY_RE.search(cmd):
        return Comprobacion(tipo="proyectos", cmd=cmd, esperado=esperado)
    if (c := _comando_de_verificacion(celdas)) != "":
        return Comprobacion(tipo="vps", cmd=c, esperado=esperado)
    return Comprobacion(esperado=esperado)


_TILDE_RE = re.compile(r"`([^`]*)`")
_NO_APLICA_RE = re.compile(r"^.*\(no aplica\).*$", re.I | re.M)
_PARENT_RE = re.compile(r"\([^()]*\)")


def _es_palabra(r: str) -> bool:
    return r == "_" or r.isalnum()


def coincide_literal(salida: str, lit: str) -> bool:
    pre, post = "", ""
    if lit and _es_palabra(lit[0]):
        pre = r"(^|[^A-Za-z0-9_])"
    if lit and _es_palabra(lit[-1]):
        post = r"($|[^A-Za-z0-9_])"
    try:
        return bool(re.search(r"(?i)" + pre + re.escape(lit) + post, salida))
    except re.error:
        return lit.lower() in salida.lower()


def cumple(esperado: str, stdout: str, stderr: str, codigo: int, cmd: str, v: Vars) -> tuple[bool, str]:
    puerto = str(v.puerto_nuevo)
    esperado = esperado.replace("${VPS_SSH_PORT}", puerto).replace("2222", puerto)
    lits: list[str] = []

    def protege(m: re.Match) -> str:
        lits.append(m.group(1))
        return f"\x00{len(lits) - 1}\x00"

    texto = _TILDE_RE.sub(protege, esperado)
    texto = _PARENT_RE.sub("", texto)
    vigentes = [l for i, l in enumerate(lits) if f"\x00{i}\x00" in texto]
    low = _TILDE_RE.sub("", esperado).lower()
    todo = stdout + "\n" + stderr
    if "list-timers" in cmd and re.search(r"(^|[^0-9])0 timers listed", todo):
        return False, "el temporizador no está programado"
    if codigo == 127:
        return False, "el comando no existe en el servidor (código 127): falta instalar algo o no está en el PATH"
    for neg in ("sin resultados", "sin líneas", "falla", "sin respuesta"):
        if neg in low:
            if codigo != 0 or not stdout.strip():
                return True, "sin resultados, como se esperaba"
            return False, "debía no dar resultados y los dio"
    if texto.strip().lower().startswith("sin ") and vigentes:
        for l in vigentes:
            if l in todo:
                return False, f"aparece «{l}» y no debería"
        return True, "no aparece «" + "», «".join(vigentes) + "»"
    if codigo != 0:
        return False, f"el comando terminó con código {codigo}"
    # Twin of fase2.cumple.ts: a check that says it does not apply passes.
    no_aplica = _NO_APLICA_RE.search(todo)
    if no_aplica:
        return True, no_aplica.group(0).strip()
    faltan = []
    for l in vigentes:
        if not l or "${" in l or any(ch in l for ch in "<>="):
            continue
        partes = [l]
        if "," in l and " " not in l and "-interactive" not in l:
            partes = l.split(",")
        for p in partes:
            if not coincide_literal(todo, p):
                faltan.append(p)
    if faltan:
        return False, "no aparece «" + "», «".join(faltan) + "» en la salida"
    return True, "resultado esperado"


# `sudo` resets the environment, so `sudo apt …` only stays non-interactive
# (no debconf or needrestart prompts) if the variables travel through `env`.
_APT_SIN_PREGUNTAS = (
    "export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a\n"
    "if ! declare -F ux_sudo_base >/dev/null; then\n"
    '  if declare -F sudo >/dev/null; then eval "ux_sudo_base () $(declare -f sudo | tail -n +2)"; else ux_sudo_base() { command sudo "$@"; }; fi\n'
    '  sudo() { case "${1:-}" in apt|apt-get) ux_sudo_base env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a "$@" ;; *) ux_sudo_base "$@" ;; esac; }\n'
    "  export -f ux_sudo_base sudo\n"
    "fi\n"
)

# The installer leaves secrets.sh as root 600: load.sh, run as the admin, cannot read it.
_SECRETOS_DE_ROOT = 'if [ -f inventory/secrets.sh ] && [ ! -r inventory/secrets.sh ]; then eval "$(sudo cat inventory/secrets.sh 2>/dev/null)" >/dev/null 2>&1 || true; fi\n'


def preludio() -> str:
    return 'export PATH="$PATH:/usr/local/sbin:/usr/sbin:/sbin"\n' + _APT_SIN_PREGUNTAS + "cd " + util.comillas(AGENT_DIR) + " && { source inventory/load.sh >/dev/null 2>&1; true; }\n" + _SECRETOS_DE_ROOT


PASOS_COMPROBACION: dict[str, list[Sonda]] = {
    "2.4": [Sonda(usuario="admin", puerto="actual", remoto="echo ok", espera="ok", literal="ok")],
    "3.4": [
        Sonda(usuario="admin", puerto="nuevo", remoto="echo ok", espera="ok", literal="ok"),
        Sonda(usuario="root", puerto="22", remoto="echo x", espera="rechazo"),
        Sonda(usuario="root", puerto="nuevo", remoto="echo x", espera="rechazo"),
    ],
}


@dataclass
class EstadoEtapa:
    etapa: str = ""
    titulo: str = ""
    estado: str = ""
    fecha: str = ""
    intentos: str = ""
    nota: str = ""

    def json(self) -> dict:
        return {
            "etapa": self.etapa,
            "titulo": self.titulo,
            "estado": self.estado,
            "fecha": self.fecha,
            "intentos": self.intentos,
            "nota": self.nota,
        }


@dataclass
class Ejecucion:
    bloque: str
    codigo: int
    salida: str
    hora: str


class Fase2:
    """Mantiene el plan cargado y el historial de ejecuciones de la sesión."""

    def __init__(self, ses: "sesion_mod.Sesion") -> None:
        self.ses = ses
        self.local: Callable[[str, Vars, Callable[[str], None] | None], tuple[bool, str, str | None]] | None = None
        self._mu = threading.Lock()
        self._proto_ok = ""
        self.plan = contratos.cargar(ETAPAS_DIR)
        self.hist: list[Ejecucion] = []
        # Las comprobaciones «de la PC» se resuelven aquí por defecto; la capa web puede sustituirlas.
        self.local = lambda tipo, v, emitir: local_por_defecto(tipo, v, emitir, self)

    # -- plan ---------------------------------------------------------------

    def vista(self) -> dict:
        etapas = []
        for e in self.plan:
            verificaciones = []
            for i, fila in enumerate(e.punto_control):
                if i == 0:
                    continue  # encabezado de la tabla
                c = clasificar(e.id, fila)
                v = {"idx": i, "celdas": fila, "ejecutable": c.tipo != "ninguna", "local": _comprobacion_local(e.id, fila)}
                if (donde := c.donde()) != "":
                    v["donde"] = donde
                verificaciones.append(v)
            etapas.append({**e.json(), "verificaciones": verificaciones})
        return {"etapas": etapas}

    # -- variables ----------------------------------------------------------

    def variables(self) -> Vars:
        p = self.ses.parametros()
        v = Vars(ip=p.host, admin=p.usuario, puerto_nuevo=2222)
        script = "{ cd " + util.comillas(AGENT_DIR) + " && . inventory/load.sh; } >/dev/null 2>&1\n" + "printf '%s\\n' \"${VPS_IP:-}\" \"${VPS_ADMIN_USER:-}\" \"${VPS_SSH_PORT:-}\" \"${DOMAIN:-}\""
        try:
            r = self.ses.plano(script)
        except Exception:  # noqa: BLE001
            r = None
        if r is not None and r.codigo == 0:
            l = r.stdout.rstrip("\n").split("\n")
            while len(l) < 4:
                l.append("")
            if (s := l[0].strip()) and "<" not in s and ">" not in s:
                v.ip = s
            if (s := l[1].strip()) and "<" not in s and ">" not in s:
                v.admin = s
            try:
                n = int(l[2].strip())
                if 0 < n < 65536:
                    v.puerto_nuevo = n
            except ValueError:
                pass
            v.dominio = l[3].strip()
        if not v.admin or v.admin == "root":
            v.admin = p.usuario if (p.usuario and p.usuario != "root") else "vpsadmin"
        return v

    def proyectos(self) -> list[tuple[str, str, str]]:
        script = """for reg in $(sudo find /etc/ux/projects -mindepth 2 -maxdepth 2 -name '*.env' 2>/dev/null | sort); do
  p=$(basename "$(dirname "$reg")"); r=$(basename "$reg" .env)
  d=$(sudo sh -c ". '$reg'; printf %s \\"\\$UX_DOMINIO\\"" 2>/dev/null)
  printf '%s|%s|%s\\n' "$p" "$r" "$d"
done"""
        r = self.ses.sudo(script)
        res: list[tuple[str, str, str]] = []
        for l in r.stdout.split("\n"):
            c = l.strip().split("|")
            if len(c) != 3 or not util.es_proyecto(c[0]) or not util.es_rol(c[1]):
                continue
            if c[2] and not util.es_dominio(c[2]):
                c[2] = ""
            res.append((c[0], c[1], c[2]))
        return res

    # -- ejecución ----------------------------------------------------------

    def ejecutar_bloque(self, etapa: str, paso: str, idx: int, emitir: Callable[[str], None] | None):
        if ASISTENTES.get(paso):
            raise ValueError("este paso lo resuelve su asistente en la interfaz, no ejecutando el bloque")
        _, p, cmd = contratos.buscar(self.plan, etapa, paso, idx)
        etiqueta = f"E{etapa} · {paso} · bloque {idx} · {p.titulo}"
        if emitir is not None:
            emitir("$ " + etiqueta + "\n\n")
        self.sincronizar_protocolo(emitir)
        r = self.ses.sudo(preludio() + cmd, emitir)
        reinicia = bool(_REINICIA_RE.search(cmd))
        self.registrar(etiqueta, r.codigo, r.stdout + "\n" + r.stderr)
        return r.codigo, reinicia

    def registrar(self, bloque: str, codigo: int, salida: str) -> None:
        with self._mu:
            self.hist.append(
                Ejecucion(bloque=bloque, codigo=codigo, salida=util.cola(salida, 60000), hora=time.strftime("%Y-%m-%d %H:%M:%S"))
            )

    def ejecutar_rollback(self, etapa: str, emitir: Callable[[str], None] | None):
        for e in self.plan:
            if e.id != etapa:
                continue
            if not e.rollback_bloques:
                raise ValueError("esta etapa no tiene un rollback ejecutable")
            self.sincronizar_protocolo(emitir)
            codigo, reinicia = 0, False
            for i, b in enumerate(e.rollback_bloques):
                if b.parametros:
                    raise ValueError("el rollback de esta etapa necesita datos tuyos: hazlo desde su panel")
                if emitir is not None:
                    emitir(f"$ E{etapa} · rollback · bloque {i + 1}\n\n")
                r = self.ses.sudo(preludio() + b.comando, emitir)
                if _REINICIA_RE.search(b.comando):
                    reinicia = True
                self.registrar(f"E{etapa} · rollback {i + 1}", r.codigo, r.stdout + "\n" + r.stderr)
                if r.codigo != 0:
                    codigo = r.codigo
                    break
            return codigo, reinicia
        raise ValueError("la etapa no existe")

    # -- estado en el VPS ---------------------------------------------------

    def estado_remoto(self) -> list[EstadoEtapa]:
        r = self.ses.plano("[ -f " + util.comillas(INIT_VPS) + " ] || exit 44; bash " + util.comillas(INIT_VPS) + " --estado-json")
        if r.codigo == 44:
            raise ErrorSinRepo("el protocolo todavía no está en el VPS (la app lo instala en la Fase 1): no hay estado de etapas guardado")
        if r.codigo != 0:
            raise ValueError("no pude leer el estado del VPS: " + util.truncar(r.stderr.strip(), 200))
        try:
            datos = json.loads(r.stdout)
        except json.JSONDecodeError as exc:
            raise ValueError("el estado devuelto por init-vps.sh no es JSON válido") from exc
        return [EstadoEtapa(**e) for e in datos]

    def marcar(self, etapa: str, estado: str, nota: str) -> None:
        if etapa not in contratos.IDS:
            raise ValueError("etapa fuera de rango")
        if estado not in ESTADOS_PERMITIDOS:
            raise ValueError("estado no permitido")
        nota = _CONTROL_RE.sub(" ", util.truncar(nota, 200)).replace("|", "·")
        cmd = f"[ -f {util.comillas(INIT_VPS)} ] || exit 44; bash {util.comillas(INIT_VPS)} --marcar {etapa} {estado} {util.comillas(nota)}"
        r = self.ses.plano(cmd)
        if r.codigo == 44:
            raise ErrorSinRepo("el protocolo todavía no está en el VPS")
        if r.codigo != 0:
            raise ValueError("no pude marcar la etapa: " + util.truncar((r.stderr + r.stdout).strip(), 200))

    def informe(self) -> str:
        info = self.ses.info()
        b = ["INFORME DE CONFIGURACIÓN UX-VPS — Fase 2", f"Generado: {time.strftime('%Y-%m-%d %H:%M:%S')}", f"Servidor: {info.host} · huella: {info.huella}", ""]
        try:
            est = self.estado_remoto()
        except Exception as exc:  # noqa: BLE001
            b.append(f"  (estado no disponible: {exc})")
        else:
            b.append("ESTADO EN EL VPS (init-vps.sh)")
            for e in est:
                linea = f"  E{e.etapa} [{e.estado}] intentos={e.intentos} {e.titulo}"
                if e.nota:
                    linea += " — " + e.nota
                b.append(linea)
        b.append("")
        b.append("EJECUCIONES DE ESTA SESIÓN")
        with self._mu:
            hist = list(self.hist)
        if not hist:
            b.append("  (ninguna)")
        for h in hist:
            b.append(f"\n== {h.hora} · {h.bloque} · código {h.codigo}\n{h.salida}")
        return "\n".join(b)

    # -- verificaciones -----------------------------------------------------

    def ejecutar_verificacion(self, etapa: str, idx: int, emitir: Callable[[str], None] | None) -> int:
        fila = None
        for e in self.plan:
            if e.id == etapa and 1 <= idx < len(e.punto_control):
                fila = e.punto_control[idx]
        if fila is None:
            raise ValueError("la verificación no existe en el contrato")
        emitir = emitir or (lambda s: None)
        c = clasificar(etapa, fila)
        v = self.variables()
        nombre = f"E{etapa} · punto de control {idx} · {fila[1]}"
        emitir("▸ " + fila[1] + " — esperado: " + fila[3].replace("`", "") + "\n\n")
        salida: list[str] = []

        def anotar(s: str) -> None:
            salida.append(s)
            emitir(s)

        ok, motivo, err = self._comprobar(c, v, anotar)
        if err is not None:
            self.registrar(nombre, 1, err + cola_salida("".join(salida)))
            raise ValueError(err)
        codigo = 0 if ok else 1
        marca = "✔" if ok else "✗"
        emitir("\n" + marca + " " + motivo + "\n")
        self.registrar(nombre, codigo, (motivo if ok else motivo + cola_salida("".join(salida))))
        return codigo

    def _comprobar(self, c: Comprobacion, v: Vars, emitir: Callable[[str], None]) -> tuple[bool, str, str | None]:
        if c.tipo == "vps":
            emitir("$ " + primera_linea(c.cmd) + "\n")
            r = self.ses.sudo(preludio() + c.cmd, emitir)
            if r.codigo == 0:
                for l in r.stdout.split("\n"):
                    if l.strip().startswith("No aplica:"):
                        return True, l.strip(), None
            ok, m = cumple(c.esperado, r.stdout, r.stderr, r.codigo, c.cmd, v)
            if ok and (mal := sujetos_fallan(r.stdout)):
                return False, mal, None
            return ok, m, None
        if c.tipo == "proyectos":
            items = self.proyectos()
            if c.alcance:
                solo_proyecto = c.alcance == "proyecto"
            else:
                solo_proyecto = "<rol>" not in c.cmd and "<dominio-del-rol>" not in c.cmd
            visto: set[str] = set()
            n, fallos = 0, 0
            for it in items:
                if solo_proyecto and it[0] in visto:
                    continue
                visto.add(it[0])
                n += 1
                cmd = sustituir(c.cmd, it)
                emitir("\n== " + it[0] + ("" if solo_proyecto else "/" + it[1]) + "\n$ " + primera_linea(cmd) + "\n")
                r = self.ses.sudo(preludio() + cmd, emitir)
                ok, m = cumple(sustituir(c.esperado, it), r.stdout, r.stderr, r.codigo, cmd, v)
                if ok and (mal := sujetos_fallan(r.stdout)):
                    ok, m = False, mal
                emitir(("  ✔ " if ok else "  ✗ ") + m + "\n")
                if not ok:
                    fallos += 1
            if n == 0:
                return True, "todavía no hay proyectos dados de alta: no aplica (se comprobará cuando los haya)", None
            if fallos > 0:
                return False, f"{fallos} de {n} no cumplen", None
            return True, f"los {n} cumplen", None
        if c.tipo == "sonda":
            return self._comprobar_sondas(c, v, emitir)
        if c.tipo == "local":
            if self.local is None:
                return False, "", "esta comprobación no está disponible"
            return self.local(c.local, v, emitir)
        return False, "", "esta verificación no tiene comprobación automática"

    def _comprobar_sondas(self, c: Comprobacion, v: Vars, emitir: Callable[[str], None]) -> tuple[bool, str, str | None]:
        fallos, n, txts = 0, 0, []
        for s in c.sondas:
            if s.usuario == "proyecto":
                items = self.proyectos()
                visto: set[str] = set()
                for it in items:
                    if it[0] in visto:
                        continue
                    visto.add(it[0])
                    r, desc = self._sondear(s, v, it[0])
                    if r.estado == "sin-llave":
                        emitir("  ⚠ " + desc + ": " + r.error + " (lo comprueba el CI)\n")
                        continue
                    n += 1
                    ok, t = evaluar_sonda(s, r, desc)
                    emitir(("  ✔ " if ok else "  ✗ ") + t + "\n")
                    if not ok:
                        fallos += 1
                continue
            n += 1
            r, desc = self._sondear(s, v, "")
            ok, t = evaluar_sonda(s, r, desc)
            emitir(("  ✔ " if ok else "  ✗ ") + t + "\n")
            txts.append(t)
            if not ok:
                fallos += 1
        if c.root:
            r = self.ses.sudo("sudo sshd -T 2>/dev/null | grep -i '^permitrootlogin'")
            linea = r.stdout.strip()
            emitir("  → configuración efectiva: " + linea + "\n")
            if linea.lower() != "permitrootlogin no":
                fallos += 1
                emitir("  ✗ sshd todavía permite el acceso de root\n")
        if n == 0:
            return True, "no hay nada que probar desde aquí todavía (lo comprueba el CI)", None
        if fallos > 0:
            return False, f"{fallos} prueba(s) de acceso no dieron el resultado esperado", None
        if len(txts) == 1:
            return True, txts[0], None
        return True, "todas las pruebas de acceso dieron el resultado esperado", None

    def _puerto_de(self, s: Sonda, v: Vars) -> int:
        if s.puerto == "actual":
            if (p := self.ses.parametros().puerto) > 0:
                return p
            return 22
        if s.puerto == "nuevo":
            return v.puerto_nuevo
        try:
            n = int(s.puerto)
        except ValueError:
            n = 0
        return n if n > 0 else 22

    def _sondear(self, s: Sonda, v: Vars, proyecto: str) -> tuple[ResultadoSonda, str]:
        r, desc = self._sondear_una(s, v, proyecto)
        debe_responder = s.espera in ("ok", "sin-password")
        # Un timeout es casi siempre un firewall que descarta, no un baneo: un solo reintento.
        for _ in range(1 if r.causa == "timeout" else 2):
            if not (debe_responder and r.estado == "red"):
                break
            self._desbanear_mi_ip()
            time.sleep(ESPERA_REINTENTO)
            r, desc = self._sondear_una(s, v, proyecto)
        if s.usuario == "root" or s.espera in ("rechazo", "sin-password"):
            self._desbanear_mi_ip()
        return r, desc

    def _desbanear_mi_ip(self) -> None:
        try:
            self.ses.sudo('ip="${SSH_CLIENT%% *}"; [ -n "$ip" ] && sudo fail2ban-client unban "$ip" >/dev/null 2>&1; true')
        except Exception:  # noqa: BLE001
            pass

    def _sondear_una(self, s: Sonda, v: Vars, proyecto: str) -> tuple[ResultadoSonda, str]:
        p = self.ses.parametros()
        puerto = self._puerto_de(s, v)
        usuario = {"root": "root", "proyecto": proyecto}.get(s.usuario, v.admin)
        desc = f"{usuario}@{p.host}:{puerto}"
        if p.anclada is None:
            return ResultadoSonda(estado="sin-llave", error="no hay una sesión con la huella del servidor anclada"), desc
        firmante = None
        if s.espera != "sin-password":
            ruta, passphrase = p.ruta_llave, p.passphrase
            if s.usuario == "proyecto":
                ruta = util.expandir_ruta("~/.ssh/ux_ci_" + proyecto)
                passphrase = ""
            if not ruta:
                return ResultadoSonda(estado="sin-llave", error="la app está conectada con contraseña: conéctate con tu llave para poder probar el acceso por llave"), desc
            if not Path(ruta).exists():
                return ResultadoSonda(estado="sin-llave", error=f"no encuentro la llave {Path(ruta).name} en este equipo"), desc
            try:
                firmante = sshx.cargar_firmante(ruta, passphrase)
            except (sshx.ErrorAuth, sshx.ErrorPassphrase) as exc:
                return ResultadoSonda(estado="sin-llave", error=util.truncar(str(exc), 200)), desc
        r = probar_acceso(p.host, puerto, usuario, firmante, p.anclada, s.espera == "sin-password", s.remoto)
        return r, desc

    def comprobar_paso(self, paso: str, emitir: Callable[[str], None] | None) -> int:
        sondas = PASOS_COMPROBACION.get(paso)
        if sondas is None:
            raise ValueError("este paso no tiene comprobación automática")
        emitir = emitir or (lambda s: None)
        v = self.variables()
        fallos = 0
        for s in sondas:
            r, desc = self._sondear(s, v, "")
            bien, txt = evaluar_sonda(s, r, desc)
            if not bien:
                fallos += 1
            emitir(("✔ " if bien else "✗ ") + txt + "\n")
        self.registrar(f"paso {paso} · comprobación de acceso", fallos, "")
        if fallos > 0:
            if paso == "3.4":
                emitir("\nNo cierres la sesión actual: la app sigue conectada por el puerto anterior. Revisa el paso 3.1–3.3 o usa «Deshacer la etapa».\n")
            return 1
        if paso == "3.4":
            p = self.ses.parametros()
            if p.puerto != v.puerto_nuevo:
                emitir(f"\nCambiando la conexión de la app al puerto {v.puerto_nuevo}…\n")
                try:
                    self.ses.reconectar(puerto=v.puerto_nuevo)
                except Exception as exc:  # noqa: BLE001
                    emitir("✗ No pude reconectar por el puerto nuevo: " + str(exc) + "\n")
                    return 1
                emitir(f"✔ La app ya trabaja por el puerto {v.puerto_nuevo}.\n")
        return 0

    def probar_acceso_2fa(self, codigo: str) -> tuple[bool, str]:
        v = self.variables()
        p = self.ses.parametros()
        if not p.ruta_llave or p.anclada is None:
            return False, "la app no está conectada con tu llave"
        try:
            firmante = sshx.cargar_firmante(p.ruta_llave, p.passphrase)
        except (sshx.ErrorAuth, sshx.ErrorPassphrase) as exc:
            return False, str(exc)
        r = probar_acceso(p.host, p.puerto, v.admin, firmante, p.anclada, False, "echo ok", 15.0, codigo)
        if r.estado == "ok" and "ok" in r.salida:
            return True, f"{v.admin}@{p.host}:{p.puerto} entra con llave + código 2FA"
        return False, f"el acceso con llave + código falló ({r.estado}): {r.error}"

    # -- protocolo ----------------------------------------------------------

    def sincronizar_protocolo(self, emitir: Callable[[str], None] | None) -> None:
        paquete, suma = empaquetar_protocolo()
        with self._mu:
            if self._proto_ok == suma:
                return
        marca = AGENT_DIR + "/.ux-protocolo-sha"
        try:
            actual = self.ses.leer(marca)
        except Exception:  # noqa: BLE001
            actual = ""
        if actual.strip() == suma:
            with self._mu:
                self._proto_ok = suma
            return
        if emitir is not None:
            emitir("Actualizando en el VPS los archivos del protocolo a la versión de esta app…\n")
        base = "/opt/ux-infra/05-vps"
        tmp = "/tmp/ux-protocolo-" + suma[:12] + ".tgz"
        self.ses.escribir(tmp, paquete)
        # The pack may belong to root (installer VPS): replace it as root with the
        # pack-sync.sh it brings, the same mechanism as the installer and the panel.
        usuario = self.ses.parametros().usuario
        admin = "" if usuario in ("", "root") else " --admin " + util.comillas(usuario)
        script = (
            "set -e\n"
            f"sudo install -d -m 755 {util.comillas(base)}\n"
            f"staging=\"$(sudo mktemp -d {util.comillas(base + '/.ux-protocolo.XXXXXX')})\"\n"
            f"trap 'sudo rm -rf \"$staging\"; rm -f {util.comillas(tmp)}' EXIT\n"
            f"sudo tar -xzf {util.comillas(tmp)} -C \"$staging\" --no-same-owner --no-same-permissions --touch\n"
            f"sudo bash \"$staging/agent/pack-sync.sh\" \"$staging/agent\" {util.comillas(AGENT_DIR)}{admin}\n"
            f"printf '%s\\n' {util.comillas(suma)} | sudo tee {util.comillas(marca)} >/dev/null\n"
        )
        r = self.ses.sudo(script)
        if r.codigo != 0:
            raise ValueError("no pude actualizar el protocolo en el VPS: " + util.truncar(r.stderr.strip(), 300))
        try:
            # La envoltura «sudo» corre como el administrador: install.sh exige root.
            # Su salida va a stderr (las últimas líneas) para que el aviso diga por qué falló.
            rr = self.ses.sudo("if [ -x /usr/local/bin/ux-project ]; then o=\"$(sudo bash " + util.comillas(AGENT_DIR + "/platform/install.sh") + " 2>&1)\" || { printf '%s\\n' \"$o\" | tail -n 5 >&2; exit 1; }; fi")
            if rr.codigo != 0 and emitir is not None:
                emitir("AVISO: no pude reinstalar las herramientas ux-* (" + util.truncar(rr.stderr.strip(), 200) + ")\n")
        except Exception:  # noqa: BLE001
            pass
        with self._mu:
            self._proto_ok = suma
        if emitir is not None:
            emitir("Protocolo del VPS actualizado.\n\n")


def empaquetar_protocolo() -> tuple[bytes, str]:
    """Tar.gz del pack agent/ (lo que la Fase 1 instala en el VPS)."""
    agente_dir = ETAPAS_DIR.parent  # 05-vps/agent
    datos = tempfile.NamedTemporaryFile(suffix=".tgz", delete=False)
    datos.close()
    try:
        with tarfile.open(datos.name, "w:gz") as tar:
            for ruta in sorted(agente_dir.rglob("*")):
                if ruta.is_file():
                    tar.add(ruta, arcname=str(Path("agent") / ruta.relative_to(agente_dir)))
        with open(datos.name, "rb") as fh:
            paquete = fh.read()
    finally:
        try:
            Path(datos.name).unlink()
        except OSError:
            pass
    return paquete, hashlib.sha256(paquete).hexdigest()


# ───────────────────────────── helpers ─────────────────────────


def sustituir(s: str, it: tuple[str, str, str]) -> str:
    return s.replace("<proyecto>", it[0]).replace("<rol>", it[1]).replace("<dominio-del-rol>", it[2])


def primera_linea(s: str) -> str:
    l = s.strip().split("\n", 1)
    return l[0] + " …" if len(l) > 1 else l[0]


def cola_salida(s: str) -> str:
    s = s.strip()
    if not s:
        return ""
    l = s.split("\n")
    if len(l) > 40:
        l = ["…", *l[-40:]]
    return "\n--- salida ---\n" + "\n".join(l)


RESTORE_RECORD = "/var/lib/ux/restore-tested"
RESTORE_MAX_DAYS = 92


CDN_RANGOS_PATH = CATALOGO_PATH.parent / "cdn-rangos.json"


def _es_ip_cloudflare(ip: str) -> bool:
    import ipaddress

    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    redes = json.loads(CDN_RANGOS_PATH.read_text(encoding="utf-8"))["cloudflare"]
    return any(a in ipaddress.ip_network(r) for r in redes)


def _origen_tls(ip: str, dominio: str) -> dict:
    """TLS del origen por IP + SNI (sin DNS ni CDN) y su código HTTP; como `DominiosSonda.origen`."""
    import http.client
    import ssl

    ctx = ssl.create_default_context()
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    try:
        with socket.create_connection((ip, 443), timeout=6) as raw:
            with ctx.wrap_socket(raw, server_hostname=dominio) as tls:
                emisor = dict(x[0] for x in tls.getpeercert().get("issuer", ()))
                c = http.client.HTTPConnection(dominio, timeout=6)
                c.sock = tls
                c.request("GET", "/", headers={"Host": dominio, "User-Agent": "uxdeployar-verificacion"})
                cod = c.getresponse().status
                return {"valido": True, "emisor": emisor.get("organizationName", ""), "http": cod}
    except ssl.SSLCertVerificationError as e:
        return {"valido": False, "detalle": str(e.verify_message or e)[:160]}
    except socket.timeout:
        return {"valido": False, "conexion": "tiempo"}
    except ConnectionRefusedError as e:
        return {"valido": False, "conexion": "rechazada", "detalle": str(e)[:160]}
    except OSError as e:
        return {"valido": False, "conexion": "error", "detalle": str(e)[:160]}


def tls_rol(ip_vps: str, dominio: str) -> tuple[str, str]:
    """(estado, motivo) de un dominio, con las mismas reglas que `veredictoTls` (fase2.tls.ts)."""
    try:
        ips = sorted({i[4][0] for i in socket.getaddrinfo(dominio, 443, socket.AF_INET, proto=socket.IPPROTO_TCP)})
    except OSError:
        return "no_cumple", f"{dominio}: no resuelve (¿falta el registro DNS A?)"
    cdn = ip_vps not in ips and bool(ips) and all(_es_ip_cloudflare(i) for i in ips)
    if ip_vps not in ips and not cdn:
        return "advertencia", f"{dominio}: el DNS aún no apunta a este VPS ({', '.join(ips[:3])}): TLS sin comprobar"
    o = _origen_tls(ip_vps, dominio)
    if o.get("conexion") == "tiempo":
        return "no_comprobable", f"{dominio}: el 443 del VPS no respondió a tiempo"
    if o.get("conexion"):
        return "no_cumple", f"{dominio}: Caddy no atiende el 443 del VPS: {o.get('detalle', '')}"
    if not o["valido"]:
        return "no_cumple", f"{dominio}: certificado inválido en el origen: {o.get('detalle', '')}"
    avisos = []
    if "zerossl" in o.get("emisor", "").lower():
        avisos.append("emitido por ZeroSSL: Let's Encrypt no pudo emitirlo")
    if o.get("http", 0) >= 500:
        avisos.append(f"el origen responde HTTP {o['http']}: ¿el rol está caído?")
    if avisos:
        return "advertencia", f"{dominio}: " + " · ".join(avisos)
    via = " (detrás de Cloudflare)" if cdn else ""
    return "cumple", f"{dominio}: certificado válido de {o.get('emisor') or '?'} · HTTP {o.get('http')}{via}"


def _resumen_tls(sujetos: list[tuple[str, tuple[str, str]]]) -> tuple[bool, str, None]:
    malos = [f"{i} ({m})" for i, (e, m) in sujetos if e in ("no_cumple", "no_comprobable")]
    avisos = [f"{i} ({m})" for i, (e, m) in sujetos if e == "advertencia"]
    con = sum(1 for _, (e, _) in sujetos if e != "no_aplica")
    t = f"comprobados {con} de {len(sujetos)} rol(es)"
    if malos:
        t += " · no cumple: " + ", ".join(malos[:5])
    if avisos:
        t += " · aviso: " + ", ".join(avisos[:5])
    return not malos, t, None


def restore_check(f2: "Fase2") -> tuple[bool, str, str | None]:
    """E14.7 / E16: a restore test recorded less than a quarter ago (same rule as the backend)."""
    try:
        out = f2.ses.sudo(f"sudo cat {RESTORE_RECORD} 2>/dev/null || true").stdout
    except Exception:  # noqa: BLE001
        out = ""
    import calendar

    first = (out.strip().split() or [""])[0]
    try:
        when = calendar.timegm(time.strptime(first[:19], "%Y-%m-%dT%H:%M:%S"))
    except ValueError:
        return False, "no hay ninguna prueba de restauración registrada (E14.7)", None
    days = int((time.time() - when) // 86400)
    if days <= RESTORE_MAX_DAYS:
        return True, f"restauración probada hace {days} día(s)", None
    return False, f"la última prueba de restauración tiene {days} días (máx. {RESTORE_MAX_DAYS})", None


def local_por_defecto(tipo: str, v: Vars, emitir: Callable[[str], None] | None, f2: "Fase2") -> tuple[bool, str, str | None]:
    """Comprobaciones que se hacen en la PC del operador (las que no necesitan panel)."""
    if tipo == "sesion":
        info = f2.ses.info()
        if info.conectada and info.sudo_listo:
            return True, "conectado y con sudo validado (la sesión de respaldo)", None
        return False, "no hay una sesión de respaldo (conectada y con sudo)", None
    if tipo == "inventario":
        try:
            texto = f2.ses.leer("/opt/ux-infra/05-vps/agent/inventory/inventory.yaml")
        except Exception as exc:  # noqa: BLE001
            return False, f"no pude leer el inventario del VPS: {exc}", None
        falta = inventario.faltantes(texto)
        if falta:
            return False, "inventario incompleto: " + "; ".join(falta[:5]), None
        return True, "inventario completo", None
    if tipo in ("llaves", "acceso"):
        info = f2.ses.info()
        if info.conectada:
            return True, "acceso con llave activo (esta sesión)", None
        return False, "conéctate con tu llave para comprobar el acceso", None
    if tipo == "http-cerrado":
        try:
            with socket.create_connection((v.ip, 18000), timeout=3):
                return False, "algo escucha en el 18000 (¿un rol publicado fuera del estándar?)", None
        except OSError:
            return True, "nada publicado en el 18000, como se esperaba", None
    if tipo == "tls":
        items = f2.proyectos()
        if not items:
            return True, "sin roles publicados: no aplica", None
        if not any(d for _, _, d in items):
            return False, "hay roles sin dominio registrado", None
        sujetos = [(f"{p}/{r}", tls_rol(v.ip, d) if d else ("no_aplica", "sin dominio registrado")) for p, r, d in items]
        return _resumen_tls(sujetos)
    if tipo == "restauracion":
        return restore_check(f2)
    return False, "", f"comprobación local desconocida: {tipo}"
