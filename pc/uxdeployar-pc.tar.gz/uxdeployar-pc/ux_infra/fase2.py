"""Fase 2 guiada: ejecuta las etapas E00–E17 del protocolo en el VPS.

Espejo de ``05-vps/app/internal/fase2/``. Los comandos salen SIEMPRE de los
contratos (``vps/agent/stages``); la interfaz solo envía identificadores
(etapa, paso, bloque). El estado de las etapas vive en el VPS y lo gestiona
``init-vps.sh``.
"""

from __future__ import annotations

import hashlib
import json
import re
import socket
import tarfile
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import paramiko

from . import contratos, inventario, ops, sesion as sesion_mod, ssh as sshx, util

AGENT_DIR = "/opt/ux-infra/05-vps/agent"
INIT_VPS = AGENT_DIR + "/init-vps.sh"
# Los contratos que esta app lleva dentro (misma carpeta que usa el pack).
ETAPAS_DIR = Path(__file__).resolve().parents[3] / "vps" / "agent" / "stages"

ESTADOS_PERMITIDOS = {"completada", "fallida", "pendiente", "bloqueada"}

DESTINOS: dict[str, tuple[str, str]] = {
    "13.1": ("proyectos", "Alta de proyecto (panel Proyectos)"),
    "13.2": ("proyectos", "Alta de rol y dominio (panel Proyectos)"),
    "13.3": ("proyectos", "Credenciales de R2 por proyecto (panel Proyectos)"),
    "13.4": ("proyectos", "Sesión en GHCR (panel Proyectos)"),
    "13.5": ("proyectos", "Verificación de proyectos (panel Proyectos)"),
}

ASISTENTES = {
    "1.2": "acceso-limpiar",
    "1.3": "acceso-llave",
    "1.4": "acceso-primer",
    "2.4": "comprobar",
    "3.4": "comprobar",
    "3.5": "totp",
    "14.1": "age",
    "14.2": "r2",
    "14.3": "r2-ciclo",
    "14.7": "restauracion",
    "15.2": "escaneo",
}

_CMD_RE = re.compile(r"`([^`]+)`")
_REINICIA_RE = re.compile(r"(^|[\s;&|])(sudo\s+)?(reboot|systemctl\s+reboot|shutdown\s+-r)\b")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_METODOS_RE = re.compile(r"attempted methods \[([^\]]*)\]")
_PUERTO_RE = re.compile(r'-p\s+("?\$\{VPS_SSH_PORT\}"?|\d+)')
_MARC_PROY_RE = re.compile(r"<(proyecto|rol|dominio-del-rol)>")


class ErrorSinRepo(Exception):
    """El protocolo todavía no está en el VPS (la app lo instala en la Fase 1)."""


# ───────────────────────────── sondas ─────────────────────────


@dataclass
class Sonda:
    usuario: str = "admin"  # admin | root | proyecto
    puerto: str = ""  # actual | nuevo | número
    remoto: str = ""
    espera: str = "ok"  # ok | rechazo | sin-password
    literal: str = ""


@dataclass
class Vars:
    ip: str = ""
    admin: str = ""
    puerto_nuevo: int = 2222
    dominio: str = ""


@dataclass
class ResultadoSonda:
    estado: str = ""
    salida: str = ""
    error: str = ""


ESPERA_REINTENTO = 33.0  # > ventana de 30 s de «ufw limit»; las pruebas la acortan


def probar_acceso(
    host: str,
    puerto: int,
    usuario: str,
    firmante,
    anclada,
    solo_password: bool,
    remoto: str,
    timeout: float = 12.0,
    codigo_2fa: str = "",
) -> ResultadoSonda:
    """Intenta una conexión independiente y clasifica lo que pasó (espejo de probarSSH)."""
    pidio2fa = False
    try:
        sock = socket.create_connection((host, puerto), timeout=timeout)
    except OSError as exc:
        return ResultadoSonda(estado="red", error=util.truncar(str(exc), 200))
    t = paramiko.Transport(sock)
    try:
        sshx._aplicar_algoritmos(t, anclada)
        t.start_client(timeout=timeout)
        presentada = t.get_remote_server_key()
        if presentada is None or anclada is None or presentada.asbytes() != anclada.asbytes():
            return ResultadoSonda(estado="huella", error="el servidor presentó otra huella")

        def handler(_ti, _instr, preguntas):
            nonlocal pidio2fa
            if not preguntas:
                return []
            pidio2fa = True
            if codigo_2fa:
                return [codigo_2fa] * len(preguntas)
            raise paramiko.AuthenticationException("la sonda no responde al segundo factor")

        try:
            if solo_password:
                t.auth_password(usuario, "ux-sonda-no-es-una-clave")
            elif firmante is not None:
                # Llave y teclado-interactivo son ALTERNATIVAS (como en el original):
                # si la llave sola no basta (2FA), se prueba el teclado-interactivo.
                try:
                    t.auth_publickey(usuario, firmante)
                except paramiko.BadAuthenticationType:
                    pass  # el servidor no ofrece llaves
                except paramiko.AuthenticationException:
                    try:
                        t.auth_interactive(usuario, handler)
                    except (paramiko.AuthenticationException, paramiko.BadAuthenticationType):
                        pass
        except paramiko.BadAuthenticationType:
            # El servidor ni siquiera ofrece el método probado.
            if solo_password:
                return ResultadoSonda(estado="sin-password", error="Permission denied: el servidor no acepta contraseñas")
            return ResultadoSonda(estado="rechazado", error="el servidor no acepta ese método de autenticación")
        except paramiko.AuthenticationException:
            # paramiko no entrega la lista de métodos ofrecidos (OpenSSH sí): una
            # contraseña rechazada y un método ausente se ven igual. Para la
            # sonda «solo llaves» eso basta: nuestra contraseña de prueba no entró.
            if solo_password:
                return ResultadoSonda(estado="sin-password", error="Permission denied: el servidor no acepta contraseñas")
            if pidio2fa:
                return ResultadoSonda(estado="2fa", error="llave aceptada; el servidor pide además el código 2FA")
            return ResultadoSonda(estado="rechazado", error="autenticación rechazada")
        if solo_password:
            return ResultadoSonda(estado="con-password", error="el servidor aceptó una contraseña")
        if not remoto:
            return ResultadoSonda(estado="ok")
        try:
            chan = t.open_session(timeout=timeout)
            chan.exec_command(remoto)
            chan.shutdown_write()
            out = bytearray()
            while True:
                if chan.recv_ready():
                    trozo = chan.recv(65536)
                    if not trozo:
                        break
                    out.extend(trozo)
                elif chan.exit_status_ready():
                    break
                else:
                    import select

                    select.select([chan], [], [], 0.2)
            codigo = chan.recv_exit_status()
        except Exception as exc:  # noqa: BLE001
            return ResultadoSonda(estado="fallo-comando", error=util.truncar(str(exc), 200))
        salida = bytes(out).decode("utf-8", errors="replace").strip()
        if codigo != 0:
            return ResultadoSonda(estado="fallo-comando", salida=salida, error=f"código {codigo}")
        return ResultadoSonda(estado="ok", salida=salida)
    finally:
        try:
            t.close()
        except Exception:  # noqa: BLE001
            pass


def evaluar_sonda(s: Sonda, r: ResultadoSonda, desc: str) -> tuple[bool, str]:
    if s.espera == "ok":
        if r.estado == "ok":
            if s.literal and s.literal not in r.salida:
                return False, f"{desc} entró, pero la respuesta fue {util.truncar(r.salida, 120)!r} (se esperaba {s.literal!r})"
            return True, f"{desc} entra con la llave y responde {util.truncar(r.salida, 80)!r}"
        if r.estado == "2fa":
            return True, desc + " acepta la llave y pide el segundo factor (2FA activo)"
        return False, f"{desc} NO entra ({r.estado}): {r.error}"
    if s.espera == "rechazo":
        if r.estado == "rechazado":
            return True, desc + " rechazado, como se esperaba"
        if r.estado == "red":
            return True, desc + " cerrado (no hay servicio SSH en ese puerto), como se esperaba"
        if r.estado == "fallo-comando":
            return True, f"{desc} no permite ese comando ({util.truncar(r.salida + ' ' + r.error, 120)}), como se esperaba"
        if r.estado == "sin-llave":
            return False, desc + ": no se pudo probar (" + r.error + ")"
        return False, f"{desc} NO fue rechazado ({r.estado})"
    if s.espera == "sin-password":
        if r.estado == "sin-password":
            return True, desc + ": " + r.error
        return False, desc + ": " + r.error
    return False, "sonda desconocida"


# ───────────────────────────── comprobaciones ─────────────────────────


@dataclass
class Comprobacion:
    tipo: str = "ninguna"  # vps | proyectos | sonda | local | ninguna
    cmd: str = ""
    local: str = ""
    sondas: list[Sonda] = field(default_factory=list)
    esperado: str = ""
    root: bool = False

    def donde(self) -> str:
        if self.tipo in ("sonda", "local"):
            return "pc"
        if self.tipo == "proyectos":
            return "proyectos"
        if self.tipo == "vps":
            return "vps"
        return ""


_SCRIPT_APT_PENDIENTES = """sudo apt-get update -qq >/dev/null 2>&1 || { echo "apt update falló"; exit 1; }
held=$(apt-mark showhold 2>/dev/null)
n=0
for p in $(apt list --upgradable 2>/dev/null | grep 'upgradable from' | cut -d/ -f1); do
  printf '%s\\n' "$held" | grep -qx "$p" && echo "Retenido con hold (no cuenta): $p" || n=$((n+1))
done
echo "Paquetes pendientes de actualizar: $n"
[ "$n" -eq 0 ]"""

_SCRIPT_PERMISOS_SSH = """d="$HOME/.ssh"; a="$d/authorized_keys"
pd=$(stat -c %a "$d" 2>/dev/null); pa=$(stat -c %a "$a" 2>/dev/null)
echo ".ssh: ${pd:-no existe} · authorized_keys: ${pa:-no existe}"
[ "$pd" = 700 ] && [ "$pa" = 600 ]"""

_SCRIPT_BAN = """ip=203.0.113.254   # IP de documentación (RFC 5737): nunca es la tuya
sudo fail2ban-client status sshd >/dev/null 2>&1 || { echo "La cárcel sshd no está activa"; exit 1; }
sudo fail2ban-client set sshd banip "$ip" >/dev/null
if sudo fail2ban-client status sshd | grep -q "$ip"; then echo "Prueba: la IP $ip aparece en «Banned IP list»"; r=0; else echo "La IP de prueba no aparece en la lista de baneadas"; r=1; fi
sudo fail2ban-client set sshd unbanip "$ip" >/dev/null 2>&1
echo "IP de prueba desbloqueada"
exit $r"""

_SCRIPT_TRAZA_SUDO = """if sudo test -f /var/log/sudo.log; then sudo tail -n 20 /var/log/sudo.log; exit 0; fi
echo "La traza de sudo está en el journal (sudo-rs no escribe /var/log/sudo.log)"
sudo journalctl -q --no-pager -n 20 _COMM=sudo"""

_SCRIPT_CARCEL_SSH = """sudo fail2ban-client status sshd || { echo "La cárcel sshd no está activa"; exit 1; }
p=$(sudo grep -E '^[[:space:]]*port[[:space:]]*=' /etc/fail2ban/jail.local 2>/dev/null | head -1 | sed -E 's/.*=[[:space:]]*//')
echo "Puerto que vigila la cárcel: ${p:-sin definir} (SSH usa ${VPS_SSH_PORT:-2222})"
m=$(sudo fail2ban-client get sshd maxretry 2>/dev/null)
echo "Intentos permitidos (cargados): ${m:-?} (jail.local pide 3)"
[ "$p" = "${VPS_SSH_PORT:-2222}" ] && [ "$m" = 3 ]"""

_SCRIPT_SIN_IPV6 = """marca="$(cat /etc/ux/ipv6-proveedor 2>/dev/null || echo ninguna)"
vivo="$(ip -6 addr show scope global 2>/dev/null | grep inet6 || true)"
echo "Decisión guardada en 8.0: $marca · IPv6 global activo: $([ -n "$vivo" ] && echo sí || echo no)"
if [ "$marca" = si ] || [ -n "$vivo" ]; then
  echo "$vivo"
  echo "UFW: $(grep '^IPV6=' /etc/default/ufw 2>/dev/null || echo 'IPV6 sin definir') · $(sudo ufw status | head -1)"
  if grep -q '^IPV6=yes' /etc/default/ufw && sudo ufw status | grep -q 'Status: active'; then
    echo "No aplica: tu proveedor usa IPv6 en la red; queda activo y filtrado por el firewall (UFW con IPv6)"; exit 0
  fi
  echo "IPv6 activo y SIN filtrar por UFW: repite el paso 8.0 y el 8.2 (E08)"; exit 1
fi
l=$(ip a | grep inet6 || true)
[ -z "$l" ] && echo "Sin direcciones IPv6" || { echo "$l"; exit 1; }"""

_SCRIPT_UFWV6 = """if [ "$(cat /etc/ux/ipv6-proveedor 2>/dev/null)" = si ] || [ -n "$(ip -6 addr show scope global 2>/dev/null | grep inet6)" ]; then
  echo "No aplica: IPv6 del proveedor; las reglas (v6) son las que lo protegen"; exit 0
fi
s=$(sudo ufw status verbose); echo "$s"
! echo "$s" | grep -q '(v6)'"""

# Script-backed checks decide with their exit code. The contract columns read
# «sin líneas» / «sin reglas (v6)», which `cumple` would pass on any failure.
_ESPERADO_SIN_IPV6 = "IPv6 apagado, o el del proveedor filtrado por UFW (lo decide el script)"
_ESPERADO_UFWV6 = "ninguna regla v6, salvo IPv6 del proveedor (lo decide el script)"

_SCRIPT_RCLONE_CIFRADO = r"""B="$(sudo bash -c '. /etc/ux/plataforma.env 2>/dev/null; printf %s "$UX_R2_BUCKET"')"
[ -n "$B" ] || { echo "Los respaldos de la plataforma no están configurados (E14.4)"; exit 1; }
f=$(sudo rclone --config /etc/ux/rclone.conf lsf -R "r2:$B" 2>/dev/null | grep '\.age$' | sort | tail -1)
[ -n "$f" ] || { echo "Todavía no hay respaldos en r2:$B"; exit 1; }
echo "Último respaldo: $f"
cab=$(sudo rclone --config /etc/ux/rclone.conf cat "r2:$B/$f" 2>/dev/null | head -c 21)
echo "Empieza con: $cab"
case "$cab" in age-encryption.org*) exit 0 ;; *) exit 1 ;; esac"""

_SCRIPT_TRIVY = """command -v trivy >/dev/null 2>&1 || { echo "Trivy no está instalado (paso 15.1)"; exit 1; }
img=$(sudo ux-as ux-caddy podman images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -v '<none>' | head -1)
if [ -z "$img" ]; then echo "Aún no hay imágenes que escanear; Trivy responde:"; sudo trivy --version; exit $?; fi
tar=/var/tmp/ux-scan-verificacion.tar; sudo rm -f "$tar"
echo "Escaneando $img…"
sudo ux-as ux-caddy podman save --format docker-archive -o "$tar" "$img" || exit 1
sudo trivy image --input "$tar" --severity HIGH,CRITICAL --scanners vuln --no-progress; rc=$?
sudo rm -f "$tar"; exit $rc"""

_SCRIPT_CALENDARIO = """faltan=0
for t in apt-daily-upgrade.timer ux-backup-platform.timer aide-check.timer; do
  if systemctl list-timers --all "$t" 2>/dev/null | grep -q "$t"; then echo "✔ $t programado"
  elif [ "$t" = ux-backup-platform.timer ] && [ "$(systemctl is-enabled "$t" 2>/dev/null)" != enabled ]; then echo "· $t se activa al configurar los respaldos (E14, en el panel)"
  else echo "✗ $t no está programado"; faltan=$((faltan+1)); fi
done
echo "Mensual (actualización consciente) y trimestral (restauración, Lynis): se lanzan desde la app (Sistema, Respaldos, Seguridad)."
[ "$faltan" -eq 0 ]"""

# Decisiones de puertos aprobadas por el humano (VPS → Puertos): «<puerto>/<proto> abierto|cerrado …».
_PUERTOS_APROBADOS = r"""apr=$(sudo awk '!/^[[:space:]]*#/ && NF>=2 {print $1, $2}' /etc/ux/puertos.conf 2>/dev/null || true)
ufw_ab=$(sudo ufw status 2>/dev/null | sed 's/ (v6)//' | awk '$2=="ALLOW"||$2=="LIMIT"{print $1}' | sort -u)
decision(){ awk -v k="$1" '$1==k {print $2; exit}' <<<"$apr"; }
"""

_SCRIPT_PUERTOS_EXTERNOS = r"""p="${VPS_SSH_PORT:-2222}"
ext=$(sudo ss -Htln | awk '{print $4}' | grep -vE '^(127\.|\[::1\]|::1)' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
echo "Puertos a la escucha fuera de loopback: $(echo $ext)"
""" + _PUERTOS_APROBADOS + r"""otros=""; mal=""
for x in $ext; do
  case "$x" in "$p"|80|443) continue ;; esac
  d=$(decision "$x/tcp")
  if [ "$d" = cerrado ] && grep -qxE "$x(/tcp)?" <<<"$ufw_ab"; then mal="$mal $x"
  elif [ -n "$d" ]; then echo "Aprobado en VPS → Puertos: $x/tcp ($d)"
  else otros="$otros $x"; fi
done
[ -z "$mal" ] || echo "✗ aprobados como cerrados, pero UFW los permite:$mal (VPS → Puertos)"
[ -z "$otros" ] || echo "✗ puertos de más sin aprobar:$otros (apruébalos o ciérralos en VPS → Puertos)"
[ -z "$mal$otros" ]"""

_SCRIPT_PLATAFORMA_PARCIAL = r"""out=$(sudo ux-proyecto verificar 2>&1)
echo "$out" | sed -E '/\[FALTA\].*E1[234]/s/\[FALTA\]/[PENDIENTE]/'
f=$(echo "$out" | grep '\[FALTA\]' | grep -vE 'E1[234]')
[ -z "$f" ] || { echo; echo "Faltas que no dependen de las etapas 12–14:"; echo "$f"; exit 1; }
echo 'Nada propio de E11 por resolver; lo marcado [PENDIENTE] llega con las etapas 12–14.'"""

# The script decides with its exit code: the contract column names `[FALTA]`,
# and `cumple` would read it as "must not appear" even for the allowed E12–E14.
_ESPERADO_PLATAFORMA_PARCIAL = "ninguna falta propia de E11 (lo decide el script; las de E12–E14 quedan pendientes)"

_SCRIPT_CADDY_CORRE = r"""sudo ux-proyecto verificar 2>&1 | grep -E 'Caddy' ; sudo ux-proyecto verificar 2>&1 | grep -q '\[OK\].*Caddy en ejecución'"""

_SCRIPT_AA_ERRORES = """l=$(sudo journalctl -k -b 2>/dev/null | grep -i apparmor | grep -iE 'error|fail' || true)
[ -z "$l" ] && echo "Sin errores de AppArmor en este arranque" || { echo "$l" | tail -20; exit 1; }"""

# aa-enforce returns 0 for a missing profile, and a raw enforce count includes
# desktop profiles: check each critical profile that exists, by name.
_SCRIPT_AA_CRITICOS = r"""s=$(sudo aa-status 2>/dev/null) || { echo "AppArmor no responde (aa-status falló)"; exit 1; }
echo "$s" | grep -E 'profiles are (loaded|in (enforce|complain) mode)'
enf=$(echo "$s" | awk '/profiles are in enforce mode/{e=1;next} /profiles are in|processes have/{e=0} e{print $1}')
f=0
for p in usr.sbin.sshd; do
  if [ ! -f "/etc/apparmor.d/$p" ]; then echo "ℹ $p: Debian no trae este perfil, no cuenta"; continue; fi
  n="/${p//.//}"
  if grep -qx "$n" <<<"$enf"; then echo "✔ $n en enforce"; else echo "✗ $n existe pero no está en enforce (paso 9.3)"; f=1; fi
done
for k in apparmor-profiles apparmor-profiles-extra; do
  if dpkg -s "$k" 2>/dev/null | grep -q '^Status: install ok installed'; then echo "✗ $k instalado: solo trae perfiles de escritorio (paso 9.1 lo quita)"; f=1; fi
done
exit $f"""

_SCRIPT_AIDE = """command -v aide >/dev/null 2>&1 || { echo "AIDE no está instalado (paso 9.7)"; exit 1; }
sudo test -s /var/lib/aide/aide.db || { echo "AIDE configurado; la base de referencia la genera E15 (paso 15.6)"; exit 0; }
cfg=/etc/aide/aide.conf; [ -f "$cfg" ] || cfg=/etc/aide.conf
sudo aide --config "$cfg" --check --limit '^/etc/' >/tmp/ux-aide.$$ 2>&1; rc=$?
tail -25 /tmp/ux-aide.$$; rm -f /tmp/ux-aide.$$
if [ "$rc" -ge 14 ]; then echo "AIDE no puede verificar (código $rc)"; sudo ls -l /var/lib/aide; exit 1; fi
if [ "$rc" -eq 0 ]; then echo "AIDE funciona: /etc coincide con la base (código 0)"
else echo "AIDE funciona y detectó diferencias con la base (código $rc = $( [ $((rc & 1)) -ne 0 ] && printf 'nuevos ')$( [ $((rc & 2)) -ne 0 ] && printf 'borrados ')$( [ $((rc & 4)) -ne 0 ] && printf 'cambiados')); antes de E15 es esperable, el paso 15.6 renueva la base"; fi"""

_SCRIPT_REGLAS_AUDIT = r"""r=$(sudo auditctl -l 2>/dev/null) || { echo "✗ auditctl no responde (paso 9.6)"; exit 1; }
f=0
for w in /etc/passwd /etc/shadow /etc/sudoers /etc/sudoers.d /etc/ssh/sshd_config /etc/ssh/sshd_config.d; do
  if grep -qE -e "^-w $w -p [rwxa]*" -e "(path|dir)=$w( |$)" <<<"$r"; then echo "✔ vigilado: $w"; else echo "✗ falta la regla de auditoría sobre $w (paso 9.6)"; f=1; fi
done
exit $f"""

_SCRIPT_TIMER_AIDE = r"""systemctl list-timers aide-check.timer --no-pager 2>/dev/null | grep aide-check.timer || { echo "✗ aide-check.timer no está programado (paso 9.7)"; exit 1; }
echo "✔ aide-check.timer programado"
d=$(systemctl is-enabled dailyaidecheck.timer 2>/dev/null)
case "$d" in
  ""|masked|disabled|not-found) echo "✔ dailyaidecheck.timer de Debian fuera de servicio (${d:-no instalado}): un solo chequeo de AIDE" ;;
  *) echo "✗ dailyaidecheck.timer de Debian sigue activo ($d): AIDE correría dos veces (paso 9.7 lo enmascara)"; exit 1 ;;
esac"""

_SCRIPT_BASE_AIDE = r"""sudo test -s /var/lib/aide/aide.db || { echo "✗ falta la base de AIDE /var/lib/aide/aide.db (paso 15.6)"; exit 1; }
f=0
for p in trivy lynis; do
  l=/var/lib/dpkg/info/$p.list
  [ -e "$l" ] || { echo "ℹ $p no está instalado todavía"; continue; }
  if sudo test /var/lib/aide/aide.db -nt "$l"; then echo "✔ base de AIDE posterior a la instalación de $p"; else echo "✗ la base de AIDE es anterior a la instalación de $p (paso 15.6 la renueva)"; f=1; fi
done
exit $f"""

_SCRIPT_SIN_SOCKET = """e=$(systemctl --global is-enabled podman.socket 2>&1 || true); echo "$e"
[ "$e" = "masked" ]"""

_SCRIPT_CADDY_ESCUCHA = r"""ss=$(sudo ss -Htln)
echo "$ss" | grep -E ':(80|443)\s' || true
echo "$ss" | grep -qE ':80\s' || { echo "Nada escucha en el 80"; exit 1; }
if ls /etc/ux/caddy/sitios/*.caddy >/dev/null 2>&1; then
  echo "$ss" | grep -qE ':443\s' || { echo "Hay sitios publicados pero nada escucha en el 443"; exit 1; }
else
  echo "Sin sitios publicados: el 443 se abrirá con el primero."
fi"""

_SCRIPT_BD_INVISIBLE = """c="<proyecto>-<rol>-db"
if ! sudo ux-as <proyecto> podman container exists "$c" 2>/dev/null; then echo "$c: el rol no tiene base de datos (no aplica)"; exit 0; fi
sudo ux-as <proyecto> podman inspect "$c" --format '{{json .NetworkSettings.Networks}}'
pub=$(sudo ux-as <proyecto> podman port "$c" 2>/dev/null)
[ -z "$pub" ] || { echo "Publica puertos: $pub"; exit 1; }"""


def _condicional(prueba: str, motivo: str, cmd: str) -> str:
    return "if ! " + prueba + "; then echo " + util.comillas("No aplica: " + motivo) + "; exit 0; fi\n" + cmd


# ───────────────────────────── cierre (E16) ─────────────────────────

_CIERRE_AYUDAS = """f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
"""

_SCRIPT_CIERRE_ETAPAS = """j=$(bash init-vps.sh --estado-json 2>/dev/null) || { echo "✗ no pude leer el estado de las etapas"; exit 1; }
echo "$j" | python3 -c '
import json,sys
malas=[]
for e in json.load(sys.stdin):
    n=e["etapa"].replace("E","")
    if n in ("00","13","16","17"): continue   # E00 es contexto; E13 es operación diaria; E16 es esta; E17 es consulta
    if e["estado"] not in ("completada","probada"): malas.append(e["etapa"]+" ("+e["estado"]+")")
    else: print("✔ "+e["etapa"]+" "+e["estado"])
if malas:
    print("✗ etapas sin completar: "+", ".join(malas)); sys.exit(1)
'"""

_SCRIPT_CIERRE_SSH = _CIERRE_AYUDAS + """t=$(sudo sshd -T 2>/dev/null) || { echo "✗ sshd -T falló"; exit 1; }
v(){ echo "$t" | awk -v k="$1" '$1==k{ $1=""; sub(/^ /,""); print; exit }'; }
chk(){ g="$(v "$1")"; if [ "$g" = "$2" ]; then ok "$1 = $2"; else ko "$1 = ${g:-?} (esperado $2)"; fi; }
chk port "${VPS_SSH_PORT:-2222}"; chk permitrootlogin no; chk passwordauthentication no; chk permitemptypasswords no
chk pubkeyauthentication yes; chk x11forwarding no; chk maxauthtries 3; chk maxsessions 2; chk logingracetime 20
if [ -f /etc/ssh/sshd_config.d/00-vps-mfa.conf ]; then chk kbdinteractiveauthentication yes; else chk kbdinteractiveauthentication no; fi
echo "$t" | grep -q '^allowgroups ' && ok "AllowGroups definido: $(v allowgroups)" || ko "falta AllowGroups"
c="$(v ciphers)"
case "$c" in *chacha20-poly1305*) ok "cifrados modernos" ;; *) ko "cifrados sin endurecer: $c" ;; esac
case "$c" in *cbc*|*3des*|*arcfour*) ko "cifrados débiles permitidos: $c" ;; *) ok "sin cifrados débiles" ;; esac
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_PERMISOS = _CIERRE_AYUDAS + """perm "$HOME/.ssh" 700
perm "$HOME/.ssh/authorized_keys" "600 400"
for k in /etc/ssh/ssh_host_*_key; do [ -e "$k" ] && perm "$k" 600; done
perm /etc/shadow "640 600 000"; perm /etc/sudoers 440
for s in /etc/sudoers.d/*; do [ -e "$s" ] && perm "$s" "440 400"; done
# El CI del proyecto debe leer <p>/<r>.env; 750 root:root rompe el deploy.
# /etc/ux también: sin poder atravesarlo, el CI no llega a projects/.
if [ -d /etc/ux ]; then
  sudo chmod 755 /etc/ux
  perm /etc/ux "755"
fi
if [ -d /etc/ux/projects ]; then
  sudo chmod 755 /etc/ux/projects
  perm /etc/ux/projects "755"
fi
[ -f /etc/ux/plataforma.env ] && perm /etc/ux/plataforma.env 600
[ -f /etc/ux/rclone.conf ] && perm /etc/ux/rclone.conf 600
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_CUENTAS = _CIERRE_AYUDAS + """u0=$(awk -F: '$3==0{print $1}' /etc/passwd | tr '\\n' ' ')
[ "$u0" = "root " ] && ok "solo root tiene UID 0" || ko "cuentas con UID 0: $u0"
vac=$(sudo awk -F: '$2==""{print $1}' /etc/shadow | tr '\\n' ' ')
[ -z "$vac" ] && ok "ninguna cuenta con contraseña vacía" || ko "contraseña vacía en: $vac"
a="${VPS_ADMIN_USER:-$(id -un)}"
id -nG "$a" | tr ' ' '\\n' | grep -qx sudo && ok "$a pertenece al grupo sudo" || ko "$a no está en el grupo sudo"
echo "→ root: $(sudo passwd -S root 2>/dev/null | awk '{print $2}') (el acceso SSH de root ya está cerrado en la fila 1)"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_UFW = _CIERRE_AYUDAS + """p="${VPS_SSH_PORT:-2222}"
s=$(sudo ufw status verbose 2>&1)
echo "$s" | grep -q 'Status: active' && ok "UFW activo" || ko "UFW inactivo"
echo "$s" | grep -q 'Default: deny (incoming), allow (outgoing)' && ok "política: denegar entrante, permitir saliente" || ko "política por defecto distinta: $(echo "$s" | grep '^Default')"
echo "$s" | grep -Eq "^$p/tcp +LIMIT" && ok "SSH ($p) con límite de intentos" || ko "el puerto $p no tiene regla LIMIT"
echo "$s" | grep -Eq '^80/tcp +ALLOW' && ok "80/tcp abierto" || ko "falta 80/tcp"
echo "$s" | grep -Eq '^443/tcp +ALLOW' && ok "443/tcp abierto" || ko "falta 443/tcp"
abiertos=$(sudo awk '!/^[[:space:]]*#/ && $2=="abierto" {print $1}' /etc/ux/puertos.conf 2>/dev/null | sed -E 's#/(tcp|udp)##' | sort -u)
otros=""
for x in $(echo "$s" | awk '/ALLOW|LIMIT/{print $1}' | sed -E 's#/(tcp|udp)##' | sort -u); do
  case "$x" in "$p"|80|443) continue ;; esac
  if grep -qx "$x" <<<"$abiertos"; then ok "regla de $x: aprobado como abierto en VPS → Puertos"; else otros="$otros $x"; fi
done
[ -z "$otros" ] && ok "sin reglas de más" || ko "reglas de más (puertos sin aprobar como abiertos):$otros"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_FAIL2BAN = _CIERRE_AYUDAS + """unidad fail2ban
chk(){ g=$(sudo fail2ban-client get sshd "$1" 2>/dev/null); if [ "$g" = "$2" ]; then ok "sshd $1 = $2"; else ko "sshd $1 = ${g:-?} (esperado $2)"; fi; }
chk maxretry 3; chk bantime 86400; chk findtime 600
sudo fail2ban-client status sshd >/dev/null 2>&1 && ok "cárcel sshd activa" || ko "cárcel sshd inactiva"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_SYSCTL = _CIERRE_AYUDAS + """pasada(){
  f=0
  while read -r k e; do
    [ -z "$k" ] && continue
    if ! sudo test -e "/proc/sys/${k//.//}"; then ok "$k no existe en este kernel (nada que endurecer)"; continue; fi
    if ! g=$(sudo sysctl -n "$k" 2>/dev/null); then ko "$k existe pero no se pudo leer"; continue; fi
    case "|$e|" in *"|$g|"*) ok "$k = $g" ;; *) ko "$k = ${g:-?} (esperado $e)" ;; esac
  done <<'LISTA'
net.ipv4.conf.all.rp_filter 1
net.ipv4.conf.default.rp_filter 1
net.ipv4.tcp_syncookies 1
net.ipv4.icmp_echo_ignore_broadcasts 1
net.ipv4.icmp_ignore_bogus_error_responses 1
net.ipv4.conf.all.accept_redirects 0
net.ipv4.conf.default.accept_redirects 0
net.ipv4.conf.all.secure_redirects 0
net.ipv4.conf.all.send_redirects 0
net.ipv4.conf.default.send_redirects 0
net.ipv4.conf.all.accept_source_route 0
net.ipv4.conf.default.accept_source_route 0
net.ipv4.conf.all.log_martians 1
net.ipv4.conf.default.log_martians 1
net.ipv4.ip_unprivileged_port_start 80
kernel.kptr_restrict 2
kernel.dmesg_restrict 1
kernel.yama.ptrace_scope 2
kernel.sysrq 0
kernel.unprivileged_bpf_disabled 1|2
net.core.bpf_jit_harden 2
dev.tty.ldisc_autoload 0
fs.suid_dumpable 0
fs.protected_hardlinks 1
fs.protected_symlinks 1
fs.protected_fifos 2
fs.protected_regular 2
kernel.randomize_va_space 2
LISTA
}
ufw_pisa(){
  u=$(. /etc/default/ufw 2>/dev/null; echo "${IPT_SYSCTL:-}")
  { [ -n "$u" ] && [ -f "$u" ]; } || return 0
  while read -r k v; do
    l=$(grep -E "^[[:space:]]*${k//.//}[[:space:]]*=" "$u" | tail -n 1)
    [ -n "$l" ] || continue
    uv=$(printf '%s' "${l#*=}" | tr -d '[:space:]')
    [ "$uv" = "$v" ] || ko "UFW pone $k = $uv en cada arranque ($u): repite E07, su paso 7.1 lo comenta"
  done < <(sed -nE 's/^[[:space:]]*([a-z0-9_.]+)[[:space:]]*=[[:space:]]*([0-9]+)[[:space:]]*$/\\1 \\2/p' /etc/sysctl.d/zz-ux-hardening.conf)
}
pasada
if [ ! -f /etc/sysctl.d/zz-ux-hardening.conf ]; then
  ko "E07 todavía no se aplicó: falta /etc/sysctl.d/zz-ux-hardening.conf"
elif [ "$f" -ne 0 ]; then
  echo "⚠ Diagnóstico: la clave cambió después de E07 ⚠"
  echo "Fuentes persistentes que mencionan log_martians:"
  fu=$(grep -rns "log_martians" /etc/sysctl.conf /etc/sysctl.d /run/sysctl.d /usr/lib/sysctl.d /etc/ufw/sysctl.conf)
  if [ -n "$fu" ]; then echo "$fu" | sed 's/^/  /'; else echo "  (ninguna)"; fi
  echo "Valores en vivo por interfaz:"; sysctl -a 2>/dev/null | grep "log_martians" | sed 's/^/  /'
  ls -l /etc/sysctl.d/zz-ux-hardening.conf 2>&1 | sed 's/^/  /'
  journalctl -b -u systemd-sysctl --no-pager 2>/dev/null | tail -3 | sed 's/^/  /'
  echo "⚠ Reaplicando la configuración persistente (sysctl --system) ⚠"
  sudo sysctl -q --system >/dev/null 2>&1 || true
  pasada
  [ "$f" -eq 0 ] && echo "✔ El valor en vivo se había desviado de la configuración persistente; ya quedó corregido. Revisa el diagnóstico de arriba para ver qué lo cambió."
fi
[ -f /etc/sysctl.d/zz-ux-hardening.conf ] && ufw_pisa
[ "$f" -eq 0 ] || echo "⚠ Repite la etapa E07 («Ejecutar esta etapa») y vuelve a validar: su paso 7.1 reaplica y comprueba estas claves."
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_SERVICIOS = _CIERRE_AYUDAS + """x=$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}')
otros=$(echo "$x" | grep -v '^cloud-init' | grep -v '^$' || true); ci=$(echo "$x" | grep '^cloud-init' || true)
if [ -z "$otros" ]; then ok "ninguna unidad systemd fallida (aparte de cloud-init)"; else
  ko "unidades fallidas: $(echo $otros)"
  for u in $otros; do echo "--- $u"; sudo journalctl -u "$u" -n 8 --no-pager 2>&1 | tail -8; done
fi
if [ -n "$ci" ]; then
  echo "ℹ cloud-init con fallos ($(echo $ci)): solo afecta al aprovisionamiento inicial del proveedor"
  sudo cloud-init status --long 2>&1 | head -10
  for u in $ci; do echo "--- $u"; sudo journalctl -u "$u" -n 12 --no-pager 2>&1 | tail -12; done
fi
if [ -f /var/run/reboot-required ]; then ko "el sistema pide reiniciar: $(cat /var/run/reboot-required.pkgs 2>/dev/null | tr '\\n' ' ')"; else ok "sin reinicio pendiente"; fi
nuevo=$(ls -1 /boot/vmlinuz-* 2>/dev/null | sed 's#.*/vmlinuz-##' | sort -V | tail -1)
if [ -n "$nuevo" ] && [ "$(uname -r)" != "$nuevo" ]; then ko "arrancado con el kernel $(uname -r) pero hay uno más nuevo instalado ($nuevo): reinicia"; else ok "kernel en uso al día ($(uname -r))"; fi
a=/etc/apt/apt.conf.d/20auto-upgrades
grep -q 'Update-Package-Lists "1"' "$a" 2>/dev/null && grep -q 'Unattended-Upgrade "1"' "$a" 2>/dev/null && ok "actualizaciones automáticas activadas" || ko "20auto-upgrades no activa las actualizaciones"
systemctl is-enabled apt-daily-upgrade.timer >/dev/null 2>&1 && ok "apt-daily-upgrade.timer habilitado" || ko "apt-daily-upgrade.timer deshabilitado"
sec(){ apt list --upgradable 2>/dev/null | grep -c -- '-security' || true; }
if [ "$(sec)" -gt 0 ] && command -v unattended-upgrade >/dev/null 2>&1; then
  echo "ℹ $(sec) actualización(es) de seguridad pendientes: las instalo ahora con unattended-upgrade (lo mismo que hace su temporizador diario)" # uxyngraphar:permitir-idioma
  sudo timeout 900 unattended-upgrade >/dev/null 2>&1 || true
fi
n=$(apt list --upgradable 2>/dev/null | grep -c 'upgradable from' || true); s=$(sec)
if [ "${s:-0}" -gt 0 ]; then ko "$s actualización(es) de seguridad sin instalar" # uxyngraphar:permitir-idioma
elif [ "${n:-0}" -gt 0 ]; then ok "sin actualizaciones de seguridad pendientes (ℹ $n paquete(s) normales: se instalan con apt upgrade cuando decidas)" # uxyngraphar:permitir-idioma
else ok "sin paquetes pendientes de actualizar"; fi
[ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" = yes ] && ok "hora sincronizada ($(timedatectl show -p Timezone --value 2>/dev/null))" || ko "la hora no está sincronizada"
us=$(df --output=pcent / | tail -1 | tr -dc 0-9); ui=$(df --output=ipcent / | tail -1 | tr -dc 0-9)
[ "${us:-100}" -lt 85 ] && ok "disco al ${us}%" || ko "disco al ${us}%"
[ "${ui:-100}" -lt 85 ] && ok "inodos al ${ui}%" || ko "inodos al ${ui}%"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_PODMAN = _CIERRE_AYUDAS + """r=$(sudo ux-as ux-caddy podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null)
[ "$r" = true ] && ok "Podman de ux-caddy corre rootless" || ko "Podman de ux-caddy no es rootless ($r)"
n=$(sudo podman ps -aq 2>/dev/null | wc -l)
[ "$n" -eq 0 ] && ok "root no tiene contenedores" || ko "root tiene $n contenedor(es): todo debe correr rootless"
l=$(loginctl show-user ux-caddy -p Linger --value 2>/dev/null)
[ "$l" = yes ] && ok "ux-caddy con linger (sobrevive a los reinicios)" || ko "ux-caddy sin linger ($l)"
st=$(sudo ux-as ux-caddy podman ps --filter name=caddy --format '{{.Names}} {{.Status}}' 2>/dev/null)
echo "$st" | grep -q 'Up' && ok "Caddy en ejecución: $st" || ko "Caddy no está corriendo ($st)"
insp=$(sudo ux-as ux-caddy podman inspect caddy --format '{{.HostConfig.RestartPolicy.Name}}|{{.HostConfig.ReadonlyRootfs}}|{{.HostConfig.SecurityOpt}}|{{.HostConfig.CapDrop}}' 2>/dev/null)
case "$insp" in *unless-stopped*|*always*) ok "Caddy se reinicia solo" ;; *) ko "Caddy sin política de reinicio ($insp)" ;; esac
case "$insp" in *'|true|'*) ok "sistema de archivos de Caddy en solo lectura" ;; *) ko "Caddy no es read_only ($insp)" ;; esac
case "$insp" in *no-new-privileges*) ok "no-new-privileges activo" ;; *) ko "falta no-new-privileges" ;; esac
ce=$(sudo ux-as ux-caddy podman exec caddy sh -c 'grep CapEff /proc/1/status' 2>/dev/null | awk '{print $2}')
case "$ce" in 0000000000000400|0000000000000000) ok "capacidades efectivas mínimas ($ce)" ;; *) ko "Caddy conserva capacidades de más (CapEff=${ce:-?}; permitido solo 0000000000000400)" ;; esac
c=$(curl -s -m 5 -o /dev/null -w '%{http_code}' http://127.0.0.1:80/ 2>/dev/null)
case "$c" in 2??|3??|4??) ok "Caddy responde en 127.0.0.1:80 (HTTP $c)" ;; *) ko "Caddy no responde en el 80 (HTTP ${c:-000})" ;; esac
if command -v ux-auditar >/dev/null 2>&1; then
  aud=$(sudo ux-auditar 2>&1)
  while IFS= read -r l; do ko "proyectos: ${l#*] }"; done < <(printf '%s\\n' "$aud" | grep -F '[FALTA]')
  printf '%s\\n' "$aud" | grep -qF '[FALTA]' || ok "contenedores de los proyectos: $(printf '%s\\n' "$aud" | tail -n 1)"
else
  ko "falta ux-auditar (etapa E11): no se auditan los contenedores de los proyectos"
fi
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_SEGURIDAD = _CIERRE_AYUDAS + """sudo aa-status --enabled 2>/dev/null && ok "AppArmor habilitado" || ko "AppArmor deshabilitado"
sudo cat /sys/kernel/security/lsm 2>/dev/null | grep -qw apparmor && ok "AppArmor entre los módulos de seguridad del kernel" || ko "AppArmor no está entre los módulos de seguridad del kernel (/sys/kernel/security/lsm)"
e=$(sudo aa-status 2>/dev/null | awk '/profiles are in enforce mode/{print $1; exit}')
[ "${e:-0}" -gt 0 ] && ok "$e perfiles en modo enforce" || ko "ningún perfil en enforce"
unidad auditd
r=$(sudo auditctl -l 2>/dev/null | grep -vc 'No rules')
[ "${r:-0}" -gt 0 ] && ok "$r regla(s) de auditoría cargadas" || ko "auditd sin reglas"
en=$(sudo auditctl -s 2>/dev/null | awk '/^enabled/{print $2}')
case "$en" in 1|2) ok "auditoría habilitada (enabled=$en)" ;; *) ko "auditoría deshabilitada (enabled=${en:-?})" ;; esac
sudo test -s /var/lib/aide/aide.db && ok "base de datos de AIDE presente" || ko "falta /var/lib/aide/aide.db"
unidad aide-check.timer timer
systemctl is-enabled --quiet dailyaidecheck.timer 2>/dev/null && ko "dailyaidecheck.timer de Debian activo: AIDE correría dos veces (paso 9.7)" || ok "un solo timer de AIDE (aide-check.timer)"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_RESPALDOS = _CIERRE_AYUDAS + """unidad ux-backup-platform.timer timer
x=$(sudo bash -c '. /etc/ux/plataforma.env 2>/dev/null; printf "%s|%s|%s" "$UX_R2_BUCKET" "${UX_R2_PREFIJO:-}" "$UX_AGE_RECIPIENT"')
B=${x%%|*}; r=${x#*|}; P=${r%%|*}; A=${r#*|}
[ -n "$B" ] && ok "bucket configurado: $B" || { ko "sin bucket en /etc/ux/plataforma.env"; echo "✗ sin configuración de respaldos"; exit 1; }
case "$A" in age1*) ok "clave pública age configurada" ;; *) ko "UX_AGE_RECIPIENT inválido" ;; esac
if [ -z "$P" ]; then P=$(hostname -s | tr 'A-Z' 'a-z' | tr -c 'a-z0-9\\n' '-' | sed 's/-*$//'); fi
ok "prefijo del VPS en el bucket: $P"
l=$(sudo rclone --config /etc/ux/rclone.conf lsf --max-age 48h "r2:$B/diario/$P/" 2>/dev/null)
echo "$l" | grep -q '\\.tar\\.age$' && ok "respaldo cifrado de las últimas 48 h en diario/$P/" || ko "ningún respaldo .age en diario/$P/ en las últimas 48 h"
echo "$l" | grep -q '\\.sha256$' && ok "con su suma .sha256" || ko "falta la suma .sha256"
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_HERRAMIENTAS = _CIERRE_AYUDAS + """for c in age rclone zstd trivy lynis aide auditctl ufw fail2ban-client podman msmtp curl ux-proyecto ux-respaldo ux-deploy ux-alerta ux-as; do
  command -v "$c" >/dev/null 2>&1 && ok "$c instalado" || ko "falta $c"
done
i=$(sudo grep -s '^hardening_index=' /var/log/lynis-report.dat | tail -1 | cut -d= -f2)
if [ -z "$i" ]; then ko "no hay informe de Lynis (paso 15.4)"; elif [ "$i" -ge 70 ]; then ok "índice de hardening de Lynis: $i"; else ko "índice de hardening de Lynis bajo: $i (mínimo 70)"; fi
[ "$f" -eq 0 ]"""

_SCRIPT_CIERRE_UDP = _CIERRE_AYUDAS + r"""u=$(sudo ss -Hulnp 2>/dev/null | awk '{print $4}' | grep -vE '^(127\.|\[?::1\]?:)' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un | grep -vxE '68|546' || true)
""" + _PUERTOS_APROBADOS + r"""# Cliente UDP (QUIC de cloudflared, DNS…): rango efímero, número nuevo en cada reinicio; no expuesto si UFW deniega la entrada.
read -r ea eb < /proc/sys/net/ipv4/ip_local_port_range 2>/dev/null || { ea=32768; eb=60999; }
ent=$(sudo ufw status verbose 2>/dev/null | grep -cE '^Default: (deny|reject) \(incoming\)')
permite(){ awk -v p="$1" '{split($1,a,"/"); if (a[2]!="" && a[2]!="udp") next; n=split(a[1],r,":"); if ((n==1 && r[1]==p) || (n==2 && p+0>=r[1]+0 && p+0<=r[2]+0)) f=1} END{exit !f}' <<<"$ufw_ab"; }
prog(){ sudo ss -Hulnp "( sport = :$1 )" 2>/dev/null | grep -o '(("[^"]*"' | head -n 1 | cut -d'"' -f2; }
pend=""
for x in $u; do
  d=$(decision "$x/udp")
  if [ "$d" = cerrado ] && grep -qxE "$x(/udp)?" <<<"$ufw_ab"; then ko "UDP $x aprobado como cerrado, pero UFW lo permite (VPS → Puertos)"
  elif [ -n "$d" ]; then ok "UDP $x aprobado en VPS → Puertos ($d)"
  elif [ "${ent:-0}" -gt 0 ] && [ "$x" -ge "$ea" ] && [ "$x" -le "$eb" ] && ! permite "$x"; then ok "UDP $x efímero de un cliente ($(prog "$x")): UFW no lo permite, no está expuesto"
  else pend="$pend $x"; fi
done
[ -z "$pend" ] && ok "ningún puerto UDP expuesto sin aprobar (salvo el cliente DHCP)" || { ko "puertos UDP a la escucha fuera de loopback sin aprobar:$pend (apruébalos o ciérralos en VPS → Puertos)"; sudo ss -ulnp 2>/dev/null | grep -vE '127\.|::1'; }
[ "$f" -eq 0 ]"""

# A bouncer installed before crowdsec was configured has no API key and blocks
# nothing: check both services and that a bouncer actually pulls decisions.
_SCRIPT_CROWDSEC = _condicional("command -v cscli >/dev/null 2>&1", "CrowdSec no está instalado (es opcional)", """f=0
for u in crowdsec crowdsec-firewall-bouncer; do
  if systemctl is-active --quiet "$u"; then echo "✔ $u activo"; else echo "✗ $u no está activo"; f=1; fi
done
j=$(sudo cscli bouncers list -o json 2>/dev/null) || { echo "✗ cscli no responde"; exit 1; }
printf '%s' "$j" | python3 -c '
import json, sys
vivos = 0
for b in json.load(sys.stdin) or []:
    lp = b.get("last_pull") or ""
    rev = bool(b.get("revoked"))
    vivo = bool(lp) and not lp.startswith("0001") and not rev
    vivos += vivo
    print(("✔" if vivo else "✗") + " bouncer " + str(b.get("name", "?")) + " · último contacto: " + (lp if vivo else "nunca") + (" · revocado" if rev else ""))
if not vivos:
    print("✗ ningún bouncer en contacto con CrowdSec: no se bloquea ninguna IP (repite E05, paso 5.5)")
sys.exit(0 if vivos else 1)
' || f=1
exit $f""")

# Validación ampliada de E16: cada script lista ✔/✗ por detalle y su código de salida decide
# (la columna del contrato es para leerla; sus literales no salen tal cual en la salida).
# Sin palabras que `cumple` lee como «no debe dar resultados» («falla», «sin …»).
_DETALLE = "cada detalle en ✔ (lo decide el script; un ✗ basta)"

_SOBRESCRITURAS: dict[str, Comprobacion] = {
    "00:Inventario completo": Comprobacion(tipo="local", local="inventario"),
    "00:Placeholders reemplazados": Comprobacion(
        tipo="vps",
        cmd="if [ -s inventory/inventory.yaml ]; then grep -vE '^\\s*#' inventory/inventory.yaml | grep -nE '<[^>]+>' | grep -vE '^[0-9]+:\\s*(r2_account_id|age_recipient|proveedor_dns):'; else echo 'falta inventory/inventory.yaml'; fi",
        esperado="sin resultados",
    ),
    # An empty VPS_IP means the inventory did not load: fail instead of passing.
    "00:Variables exportadas": Comprobacion(tipo="vps", cmd='test -n "$VPS_IP" && echo "$VPS_IP"', esperado="la IP real del VPS"),  # uxyngraphar:permitir-idioma
    "01:Sistema al día": Comprobacion(tipo="vps", cmd=_SCRIPT_APT_PENDIENTES),
    "02:Permisos .ssh": Comprobacion(tipo="vps", cmd=_SCRIPT_PERMISOS_SSH),
    "02:Traza de sudo": Comprobacion(tipo="vps", cmd=_SCRIPT_TRAZA_SUDO),
    "02:Sesión de respaldo": Comprobacion(tipo="local", local="sesion"),
    "03:Puerto activo": Comprobacion(tipo="vps", cmd="sudo ss -tlnp | grep sshd", esperado="escucha en `:${VPS_SSH_PORT}`"),
    "03:*(si 2FA)*": Comprobacion(
        tipo="vps",
        cmd=_condicional("[ -f /etc/ssh/sshd_config.d/00-vps-mfa.conf ]", "el 2FA no está activado", "sudo sshd -T | grep authenticationmethods"),
        esperado="`publickey,keyboard-interactive`",
    ),
    "05:Ban real": Comprobacion(tipo="vps", cmd=_SCRIPT_BAN),
    "05:Cárcel SSH": Comprobacion(tipo="vps", cmd=_SCRIPT_CARCEL_SSH),
    "05:*(si CrowdSec)*": Comprobacion(tipo="vps", cmd=_SCRIPT_CROWDSEC, esperado=_DETALLE),
    "08:Sin IPv6": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_IPV6, esperado=_ESPERADO_SIN_IPV6),
    "08:UFW sin v6": Comprobacion(tipo="vps", cmd=_SCRIPT_UFWV6, esperado=_ESPERADO_UFWV6),
    "16:IPv6 off": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_IPV6, esperado=_ESPERADO_SIN_IPV6),
    "07:Claves aplicadas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SYSCTL),
    "09:Sin errores AA": Comprobacion(tipo="vps", cmd=_SCRIPT_AA_ERRORES),
    "09:AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_AIDE),
    "09:Reglas audit": Comprobacion(tipo="vps", cmd=_SCRIPT_REGLAS_AUDIT, esperado=_DETALLE),
    "09:Timer AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_TIMER_AIDE, esperado=_DETALLE),
    "16:Reglas audit": Comprobacion(tipo="vps", cmd=_SCRIPT_REGLAS_AUDIT, esperado=_DETALLE),
    "16:Timer AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_TIMER_AIDE, esperado=_DETALLE),
    "09:Críticos en enforce": Comprobacion(tipo="vps", cmd=_SCRIPT_AA_CRITICOS, esperado=_DETALLE),
    "12:Escucha 80/443": Comprobacion(tipo="vps", cmd=_SCRIPT_CADDY_ESCUCHA),
    "10:Sin socket": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_SOCKET, esperado="`masked`"),
    "16:Sin socket": Comprobacion(tipo="vps", cmd=_SCRIPT_SIN_SOCKET, esperado="`masked`"),
    "11:Plataforma": Comprobacion(tipo="vps", cmd=_SCRIPT_PLATAFORMA_PARCIAL, esperado=_ESPERADO_PLATAFORMA_PARCIAL),
    "12:Plataforma": Comprobacion(tipo="vps", cmd=_SCRIPT_CADDY_CORRE),
    "14:Solo cifrado": Comprobacion(tipo="vps", cmd=_SCRIPT_RCLONE_CIFRADO),
    "14:Restauración": Comprobacion(tipo="local", local="restauracion"),
    "15:Trivy corre": Comprobacion(tipo="vps", cmd=_SCRIPT_TRIVY),
    "15:Calendario visible": Comprobacion(tipo="vps", cmd=_SCRIPT_CALENDARIO),
    "15:Base de AIDE": Comprobacion(tipo="vps", cmd=_SCRIPT_BASE_AIDE, esperado=_DETALLE),
    "16:Puertos": Comprobacion(tipo="vps", cmd=_SCRIPT_PUERTOS_EXTERNOS),
    "16:Sin puertos extra": Comprobacion(tipo="vps", cmd=_SCRIPT_PUERTOS_EXTERNOS),
    "16:Sin publicación": Comprobacion(tipo="local", local="http-cerrado"),
    "16:TLS de un rol": Comprobacion(tipo="local", local="tls"),
    "16:Restauración": Comprobacion(tipo="local", local="restauracion"),
    "16:BD invisible": Comprobacion(tipo="proyectos", cmd=_SCRIPT_BD_INVISIBLE),
    "16:Etapas previas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_ETAPAS, esperado=_DETALLE),
    "16:SSH efectivo": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SSH, esperado=_DETALLE),
    "16:Permisos críticos": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_PERMISOS, esperado=_DETALLE),
    "16:Cuentas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_CUENTAS, esperado=_DETALLE),
    "16:UFW detallado": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_UFW, esperado=_DETALLE),
    "16:Fail2Ban detallado": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_FAIL2BAN, esperado=_DETALLE),
    "16:Sysctl completo": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SYSCTL, esperado=_DETALLE),
    "16:Servicios y parches": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SERVICIOS, esperado=_DETALLE),
    "16:Podman y Caddy": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_PODMAN, esperado=_DETALLE),
    "16:MAC y auditoría": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_SEGURIDAD, esperado=_DETALLE),
    "16:Respaldos en R2": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_RESPALDOS, esperado=_DETALLE),
    "16:Herramientas": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_HERRAMIENTAS, esperado=_DETALLE),
    "16:Sin UDP expuesto": Comprobacion(tipo="vps", cmd=_SCRIPT_CIERRE_UDP, esperado=_DETALLE),
}


def _sondas_de(cmd: str, esperado: str) -> list[Sonda]:
    usuario = "admin"
    if "root@" in cmd:
        usuario = "root"
    elif "<proyecto>@" in cmd:
        usuario = "proyecto"
    puerto = ""
    m = _PUERTO_RE.search(cmd)
    if m:
        puerto = "nuevo" if "VPS_SSH_PORT" in m.group(1) else m.group(1)
    remoto = ""
    i = cmd.rfind("'")
    if i > 0:
        j = cmd.rfind("'", 0, i)
        if j >= 0:
            remoto = cmd[j + 1 : i]
    elif (f := cmd.split()) and "@" not in f[-1]:
        remoto = f[-1].strip('"')
    e = esperado.lower()
    espera, literal = "ok", ""
    if "PubkeyAuthentication=no" in cmd:
        espera = "sin-password"
    elif "rechazado" in e or "denied" in e:
        espera = "rechazo"
        if not remoto:
            remoto = "echo x"
    else:
        m = re.search(r"`([^`]+)`", esperado)
        if m:
            literal = m.group(1)
    if usuario == "root" and not puerto:
        return [
            Sonda(usuario="root", puerto="22", remoto=remoto, espera=espera),
            Sonda(usuario="root", puerto="nuevo", remoto=remoto, espera=espera),
        ]
    if not puerto:
        puerto = "actual"
    return [Sonda(usuario=usuario, puerto=puerto, remoto=remoto, espera=espera, literal=literal)]


def _comprobacion_local(etapa: str, celdas: list[str]) -> str:
    if etapa != "01" or len(celdas) < 4:
        return ""
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return ""
    if "LLAVE_PRIVADA" in m.group(1) or "LLAVE_PUBLICA" in m.group(1):
        return "llaves"
    if m.group(1).startswith("ssh "):
        return "acceso"
    return ""


def _comando_de_verificacion(celdas: list[str]) -> str:
    if len(celdas) < 4:
        return ""
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return ""
    cmd = m.group(1).replace("\\|", "|")
    if "LLAVE_PRIVADA" in cmd or "LLAVE_PUBLICA" in cmd:
        return ""
    if cmd.startswith("ssh ") or ("<" in cmd and ">" in cmd and re.search(r"<[A-Za-z]", cmd)):
        return ""
    if cmd.lower().startswith("ver "):
        return ""
    return cmd


def clasificar(etapa: str, celdas: list[str]) -> Comprobacion:
    if len(celdas) < 4:
        return Comprobacion()
    esperado = celdas[3]
    clave = f"{etapa}:{celdas[1]}"
    if clave in _SOBRESCRITURAS:
        c = _SOBRESCRITURAS[clave]
        if not c.esperado:
            c.esperado = esperado
        return c
    if (l := _comprobacion_local(etapa, celdas)) != "":
        return Comprobacion(tipo="local", local=l, esperado=esperado)
    m = _CMD_RE.search(celdas[2])
    if m is None:
        return Comprobacion(esperado=esperado)
    cmd = m.group(1).replace("\\|", "|")
    if cmd.startswith("ssh "):
        return Comprobacion(tipo="sonda", sondas=_sondas_de(cmd, esperado), esperado=esperado, root="root@" in cmd)
    if _MARC_PROY_RE.search(cmd):
        return Comprobacion(tipo="proyectos", cmd=cmd, esperado=esperado)
    if (c := _comando_de_verificacion(celdas)) != "":
        return Comprobacion(tipo="vps", cmd=c, esperado=esperado)
    return Comprobacion(esperado=esperado)


_TILDE_RE = re.compile(r"`([^`]*)`")
_NO_APLICA_RE = re.compile(r"^.*\(no aplica\).*$", re.I | re.M)
_PARENT_RE = re.compile(r"\([^()]*\)")


def _es_palabra(r: str) -> bool:
    return r == "_" or r.isalnum()


def coincide_literal(salida: str, lit: str) -> bool:
    pre, post = "", ""
    if lit and _es_palabra(lit[0]):
        pre = r"(^|[^A-Za-z0-9_])"
    if lit and _es_palabra(lit[-1]):
        post = r"($|[^A-Za-z0-9_])"
    try:
        return bool(re.search(r"(?i)" + pre + re.escape(lit) + post, salida))
    except re.error:
        return lit.lower() in salida.lower()


def cumple(esperado: str, stdout: str, stderr: str, codigo: int, cmd: str, v: Vars) -> tuple[bool, str]:
    puerto = str(v.puerto_nuevo)
    esperado = esperado.replace("${VPS_SSH_PORT}", puerto).replace("2222", puerto)
    lits: list[str] = []

    def protege(m: re.Match) -> str:
        lits.append(m.group(1))
        return f"\x00{len(lits) - 1}\x00"

    texto = _TILDE_RE.sub(protege, esperado)
    texto = _PARENT_RE.sub("", texto)
    vigentes = [l for i, l in enumerate(lits) if f"\x00{i}\x00" in texto]
    low = _TILDE_RE.sub("", esperado).lower()
    todo = stdout + "\n" + stderr
    if "list-timers" in cmd and "0 timers listed" in todo:
        return False, "el temporizador no está programado"
    if codigo == 127:
        return False, "el comando no existe en el servidor (código 127): falta instalar algo o no está en el PATH"
    for neg in ("sin resultados", "sin líneas", "falla", "sin respuesta"):
        if neg in low:
            if codigo != 0 or not stdout.strip():
                return True, "sin resultados, como se esperaba"
            return False, "debía no dar resultados y los dio"
    if texto.strip().lower().startswith("sin ") and vigentes:
        for l in vigentes:
            if l in todo:
                return False, f"aparece «{l}» y no debería"
        return True, "no aparece «" + "», «".join(vigentes) + "»"
    if codigo != 0:
        return False, f"el comando terminó con código {codigo}"
    # Twin of fase2.cumple.ts: a check that says it does not apply passes.
    no_aplica = _NO_APLICA_RE.search(todo)
    if no_aplica:
        return True, no_aplica.group(0).strip()
    faltan = []
    for l in vigentes:
        if not l or "${" in l or any(ch in l for ch in "<>="):
            continue
        partes = [l]
        if "," in l and " " not in l and "-interactive" not in l:
            partes = l.split(",")
        for p in partes:
            if not coincide_literal(todo, p):
                faltan.append(p)
    if faltan:
        return False, "no aparece «" + "», «".join(faltan) + "» en la salida"
    return True, "resultado esperado"


# `sudo` resets the environment, so `sudo apt …` only stays non-interactive
# (no debconf or needrestart prompts) if the variables travel through `env`.
_APT_SIN_PREGUNTAS = (
    "export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a\n"
    "if ! declare -F ux_sudo_base >/dev/null; then\n"
    '  if declare -F sudo >/dev/null; then eval "ux_sudo_base () $(declare -f sudo | tail -n +2)"; else ux_sudo_base() { command sudo "$@"; }; fi\n'
    '  sudo() { case "${1:-}" in apt|apt-get) ux_sudo_base env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a "$@" ;; *) ux_sudo_base "$@" ;; esac; }\n'
    "  export -f ux_sudo_base sudo\n"
    "fi\n"
)


def preludio() -> str:
    return 'export PATH="$PATH:/usr/local/sbin:/usr/sbin:/sbin"\n' + _APT_SIN_PREGUNTAS + "cd " + util.comillas(AGENT_DIR) + " && { source inventory/load.sh >/dev/null 2>&1; true; }\n"


PASOS_COMPROBACION: dict[str, list[Sonda]] = {
    "2.4": [Sonda(usuario="admin", puerto="actual", remoto="echo ok", espera="ok", literal="ok")],
    "3.4": [
        Sonda(usuario="admin", puerto="nuevo", remoto="echo ok", espera="ok", literal="ok"),
        Sonda(usuario="root", puerto="22", remoto="echo x", espera="rechazo"),
        Sonda(usuario="root", puerto="nuevo", remoto="echo x", espera="rechazo"),
        Sonda(usuario="admin", puerto="22", remoto="echo x", espera="rechazo"),
    ],
}


@dataclass
class EstadoEtapa:
    etapa: str = ""
    titulo: str = ""
    estado: str = ""
    fecha: str = ""
    intentos: str = ""
    nota: str = ""

    def json(self) -> dict:
        return {
            "etapa": self.etapa,
            "titulo": self.titulo,
            "estado": self.estado,
            "fecha": self.fecha,
            "intentos": self.intentos,
            "nota": self.nota,
        }


@dataclass
class Ejecucion:
    bloque: str
    codigo: int
    salida: str
    hora: str


class Fase2:
    """Mantiene el plan cargado y el historial de ejecuciones de la sesión."""

    def __init__(self, ses: "sesion_mod.Sesion") -> None:
        self.ses = ses
        self.local: Callable[[str, Vars, Callable[[str], None] | None], tuple[bool, str, str | None]] | None = None
        self._mu = threading.Lock()
        self._proto_ok = ""
        self.plan = contratos.cargar(ETAPAS_DIR)
        self.hist: list[Ejecucion] = []
        # Las comprobaciones «de la PC» se resuelven aquí por defecto; la capa web puede sustituirlas.
        self.local = lambda tipo, v, emitir: local_por_defecto(tipo, v, emitir, self)

    # -- plan ---------------------------------------------------------------

    def vista(self) -> dict:
        etapas = []
        for e in self.plan:
            verificaciones = []
            for i, fila in enumerate(e.punto_control):
                if i == 0:
                    continue  # encabezado de la tabla
                c = clasificar(e.id, fila)
                v = {"idx": i, "celdas": fila, "ejecutable": c.tipo != "ninguna", "local": _comprobacion_local(e.id, fila)}
                if (donde := c.donde()) != "":
                    v["donde"] = donde
                verificaciones.append(v)
            etapas.append({**e.json(), "verificaciones": verificaciones})
        return {"etapas": etapas}

    # -- variables ----------------------------------------------------------

    def variables(self) -> Vars:
        p = self.ses.parametros()
        v = Vars(ip=p.host, admin=p.usuario, puerto_nuevo=2222)
        script = "{ cd " + util.comillas(AGENT_DIR) + " && . inventory/load.sh; } >/dev/null 2>&1\n" + "printf '%s\\n' \"${VPS_IP:-}\" \"${VPS_ADMIN_USER:-}\" \"${VPS_SSH_PORT:-}\" \"${DOMAIN:-}\""
        try:
            r = self.ses.plano(script)
        except Exception:  # noqa: BLE001
            r = None
        if r is not None and r.codigo == 0:
            l = r.stdout.rstrip("\n").split("\n")
            while len(l) < 4:
                l.append("")
            if (s := l[0].strip()) and "<" not in s and ">" not in s:
                v.ip = s
            if (s := l[1].strip()) and "<" not in s and ">" not in s:
                v.admin = s
            try:
                n = int(l[2].strip())
                if 0 < n < 65536:
                    v.puerto_nuevo = n
            except ValueError:
                pass
            v.dominio = l[3].strip()
        if not v.admin or v.admin == "root":
            v.admin = p.usuario if (p.usuario and p.usuario != "root") else "vpsadmin"
        return v

    def proyectos(self) -> list[tuple[str, str, str]]:
        script = """for reg in $(sudo find /etc/ux/projects -mindepth 2 -maxdepth 2 -name '*.env' 2>/dev/null | sort); do
  p=$(basename "$(dirname "$reg")"); r=$(basename "$reg" .env)
  d=$(sudo sh -c ". '$reg'; printf %s \\"\\$UX_DOMINIO\\"" 2>/dev/null)
  printf '%s|%s|%s\\n' "$p" "$r" "$d"
done"""
        r = self.ses.sudo(script)
        res: list[tuple[str, str, str]] = []
        for l in r.stdout.split("\n"):
            c = l.strip().split("|")
            if len(c) != 3 or not util.es_proyecto(c[0]) or not util.es_rol(c[1]):
                continue
            if c[2] and not util.es_dominio(c[2]):
                c[2] = ""
            res.append((c[0], c[1], c[2]))
        return res

    # -- ejecución ----------------------------------------------------------

    def ejecutar_bloque(self, etapa: str, paso: str, idx: int, emitir: Callable[[str], None] | None):
        if ASISTENTES.get(paso):
            raise ValueError("este paso lo resuelve su asistente en la interfaz, no ejecutando el bloque")
        _, p, cmd = contratos.buscar(self.plan, etapa, paso, idx)
        etiqueta = f"E{etapa} · {paso} · bloque {idx} · {p.titulo}"
        if emitir is not None:
            emitir("$ " + etiqueta + "\n\n")
        self.sincronizar_protocolo(emitir)
        r = self.ses.sudo(preludio() + cmd, emitir)
        reinicia = bool(_REINICIA_RE.search(cmd))
        self.registrar(etiqueta, r.codigo, r.stdout + "\n" + r.stderr)
        return r.codigo, reinicia

    def registrar(self, bloque: str, codigo: int, salida: str) -> None:
        with self._mu:
            self.hist.append(
                Ejecucion(bloque=bloque, codigo=codigo, salida=util.cola(salida, 60000), hora=time.strftime("%Y-%m-%d %H:%M:%S"))
            )

    def ejecutar_rollback(self, etapa: str, emitir: Callable[[str], None] | None):
        for e in self.plan:
            if e.id != etapa:
                continue
            if not e.rollback_bloques:
                raise ValueError("esta etapa no tiene un rollback ejecutable")
            self.sincronizar_protocolo(emitir)
            codigo, reinicia = 0, False
            for i, b in enumerate(e.rollback_bloques):
                if b.parametros:
                    raise ValueError("el rollback de esta etapa necesita datos tuyos: hazlo desde su panel")
                if emitir is not None:
                    emitir(f"$ E{etapa} · rollback · bloque {i + 1}\n\n")
                r = self.ses.sudo(preludio() + b.comando, emitir)
                if _REINICIA_RE.search(b.comando):
                    reinicia = True
                self.registrar(f"E{etapa} · rollback {i + 1}", r.codigo, r.stdout + "\n" + r.stderr)
                if r.codigo != 0:
                    codigo = r.codigo
                    break
            return codigo, reinicia
        raise ValueError("la etapa no existe")

    # -- estado en el VPS ---------------------------------------------------

    def estado_remoto(self) -> list[EstadoEtapa]:
        r = self.ses.plano("[ -f " + util.comillas(INIT_VPS) + " ] || exit 44; bash " + util.comillas(INIT_VPS) + " --estado-json")
        if r.codigo == 44:
            raise ErrorSinRepo("el protocolo todavía no está en el VPS (la app lo instala en la Fase 1): no hay estado de etapas guardado")
        if r.codigo != 0:
            raise ValueError("no pude leer el estado del VPS: " + util.truncar(r.stderr.strip(), 200))
        try:
            datos = json.loads(r.stdout)
        except json.JSONDecodeError as exc:
            raise ValueError("el estado devuelto por init-vps.sh no es JSON válido") from exc
        return [EstadoEtapa(**e) for e in datos]

    def marcar(self, etapa: str, estado: str, nota: str) -> None:
        if etapa not in contratos.IDS:
            raise ValueError("etapa fuera de rango")
        if estado not in ESTADOS_PERMITIDOS:
            raise ValueError("estado no permitido")
        nota = _CONTROL_RE.sub(" ", util.truncar(nota, 200)).replace("|", "·")
        cmd = f"[ -f {util.comillas(INIT_VPS)} ] || exit 44; bash {util.comillas(INIT_VPS)} --marcar {etapa} {estado} {util.comillas(nota)}"
        r = self.ses.plano(cmd)
        if r.codigo == 44:
            raise ErrorSinRepo("el protocolo todavía no está en el VPS")
        if r.codigo != 0:
            raise ValueError("no pude marcar la etapa: " + util.truncar((r.stderr + r.stdout).strip(), 200))

    def informe(self) -> str:
        info = self.ses.info()
        b = ["INFORME DE CONFIGURACIÓN UX-VPS — Fase 2", f"Generado: {time.strftime('%Y-%m-%d %H:%M:%S')}", f"Servidor: {info.host} · huella: {info.huella}", ""]
        try:
            est = self.estado_remoto()
        except Exception as exc:  # noqa: BLE001
            b.append(f"  (estado no disponible: {exc})")
        else:
            b.append("ESTADO EN EL VPS (init-vps.sh)")
            for e in est:
                linea = f"  E{e.etapa} [{e.estado}] intentos={e.intentos} {e.titulo}"
                if e.nota:
                    linea += " — " + e.nota
                b.append(linea)
        b.append("")
        b.append("EJECUCIONES DE ESTA SESIÓN")
        with self._mu:
            hist = list(self.hist)
        if not hist:
            b.append("  (ninguna)")
        for h in hist:
            b.append(f"\n== {h.hora} · {h.bloque} · código {h.codigo}\n{h.salida}")
        return "\n".join(b)

    # -- verificaciones -----------------------------------------------------

    def ejecutar_verificacion(self, etapa: str, idx: int, emitir: Callable[[str], None] | None) -> int:
        fila = None
        for e in self.plan:
            if e.id == etapa and 1 <= idx < len(e.punto_control):
                fila = e.punto_control[idx]
        if fila is None:
            raise ValueError("la verificación no existe en el contrato")
        emitir = emitir or (lambda s: None)
        c = clasificar(etapa, fila)
        v = self.variables()
        nombre = f"E{etapa} · punto de control {idx} · {fila[1]}"
        emitir("▸ " + fila[1] + " — esperado: " + fila[3].replace("`", "") + "\n\n")
        salida: list[str] = []

        def anotar(s: str) -> None:
            salida.append(s)
            emitir(s)

        ok, motivo, err = self._comprobar(c, v, anotar)
        if err is not None:
            self.registrar(nombre, 1, err + cola_salida("".join(salida)))
            raise ValueError(err)
        codigo = 0 if ok else 1
        marca = "✔" if ok else "✗"
        emitir("\n" + marca + " " + motivo + "\n")
        self.registrar(nombre, codigo, (motivo if ok else motivo + cola_salida("".join(salida))))
        return codigo

    def _comprobar(self, c: Comprobacion, v: Vars, emitir: Callable[[str], None]) -> tuple[bool, str, str | None]:
        if c.tipo == "vps":
            emitir("$ " + primera_linea(c.cmd) + "\n")
            r = self.ses.sudo(preludio() + c.cmd, emitir)
            if r.codigo == 0:
                for l in r.stdout.split("\n"):
                    if l.strip().startswith("No aplica:"):
                        return True, l.strip(), None
            ok, m = cumple(c.esperado, r.stdout, r.stderr, r.codigo, c.cmd, v)
            return ok, m, None
        if c.tipo == "proyectos":
            items = self.proyectos()
            solo_proyecto = "<rol>" not in c.cmd and "<dominio-del-rol>" not in c.cmd
            visto: set[str] = set()
            n, fallos = 0, 0
            for it in items:
                if solo_proyecto and it[0] in visto:
                    continue
                visto.add(it[0])
                n += 1
                cmd = sustituir(c.cmd, it)
                emitir("\n== " + it[0] + ("" if solo_proyecto else "/" + it[1]) + "\n$ " + primera_linea(cmd) + "\n")
                r = self.ses.sudo(preludio() + cmd, emitir)
                ok, m = cumple(sustituir(c.esperado, it), r.stdout, r.stderr, r.codigo, cmd, v)
                emitir(("  ✔ " if ok else "  ✗ ") + m + "\n")
                if not ok:
                    fallos += 1
            if n == 0:
                return True, "todavía no hay proyectos dados de alta: no aplica (se comprobará cuando los haya)", None
            if fallos > 0:
                return False, f"{fallos} de {n} no cumplen", None
            return True, f"los {n} cumplen", None
        if c.tipo == "sonda":
            return self._comprobar_sondas(c, v, emitir)
        if c.tipo == "local":
            if self.local is None:
                return False, "", "esta comprobación no está disponible"
            return self.local(c.local, v, emitir)
        return False, "", "esta verificación no tiene comprobación automática"

    def _comprobar_sondas(self, c: Comprobacion, v: Vars, emitir: Callable[[str], None]) -> tuple[bool, str, str | None]:
        fallos, n, txts = 0, 0, []
        for s in c.sondas:
            if s.usuario == "proyecto":
                items = self.proyectos()
                visto: set[str] = set()
                for it in items:
                    if it[0] in visto:
                        continue
                    visto.add(it[0])
                    r, desc = self._sondear(s, v, it[0])
                    if r.estado == "sin-llave":
                        emitir("  ⚠ " + desc + ": " + r.error + " (lo comprueba el CI)\n")
                        continue
                    n += 1
                    ok, t = evaluar_sonda(s, r, desc)
                    emitir(("  ✔ " if ok else "  ✗ ") + t + "\n")
                    if not ok:
                        fallos += 1
                continue
            n += 1
            r, desc = self._sondear(s, v, "")
            ok, t = evaluar_sonda(s, r, desc)
            emitir(("  ✔ " if ok else "  ✗ ") + t + "\n")
            txts.append(t)
            if not ok:
                fallos += 1
        if c.root:
            r = self.ses.sudo("sudo sshd -T 2>/dev/null | grep -i '^permitrootlogin'")
            linea = r.stdout.strip()
            emitir("  → configuración efectiva: " + linea + "\n")
            if linea.lower() != "permitrootlogin no":
                fallos += 1
                emitir("  ✗ sshd todavía permite el acceso de root\n")
        if n == 0:
            return True, "no hay nada que probar desde aquí todavía (lo comprueba el CI)", None
        if fallos > 0:
            return False, f"{fallos} prueba(s) de acceso no dieron el resultado esperado", None
        if len(txts) == 1:
            return True, txts[0], None
        return True, "todas las pruebas de acceso dieron el resultado esperado", None

    def _puerto_de(self, s: Sonda, v: Vars) -> int:
        if s.puerto == "actual":
            if (p := self.ses.parametros().puerto) > 0:
                return p
            return 22
        if s.puerto == "nuevo":
            return v.puerto_nuevo
        try:
            n = int(s.puerto)
        except ValueError:
            n = 0
        return n if n > 0 else 22

    def _sondear(self, s: Sonda, v: Vars, proyecto: str) -> tuple[ResultadoSonda, str]:
        r, desc = self._sondear_una(s, v, proyecto)
        debe_responder = s.espera in ("ok", "sin-password")
        for _ in range(2):
            if not (debe_responder and r.estado == "red"):
                break
            self._desbanear_mi_ip()
            time.sleep(ESPERA_REINTENTO)
            r, desc = self._sondear_una(s, v, proyecto)
        if s.usuario == "root" or s.espera in ("rechazo", "sin-password"):
            self._desbanear_mi_ip()
        return r, desc

    def _desbanear_mi_ip(self) -> None:
        try:
            self.ses.sudo('ip="${SSH_CLIENT%% *}"; [ -n "$ip" ] && sudo fail2ban-client unban "$ip" >/dev/null 2>&1; true')
        except Exception:  # noqa: BLE001
            pass

    def _sondear_una(self, s: Sonda, v: Vars, proyecto: str) -> tuple[ResultadoSonda, str]:
        p = self.ses.parametros()
        puerto = self._puerto_de(s, v)
        usuario = {"root": "root", "proyecto": proyecto}.get(s.usuario, v.admin)
        desc = f"{usuario}@{p.host}:{puerto}"
        if p.anclada is None:
            return ResultadoSonda(estado="sin-llave", error="no hay una sesión con la huella del servidor anclada"), desc
        firmante = None
        if s.espera != "sin-password":
            ruta, passphrase = p.ruta_llave, p.passphrase
            if s.usuario == "proyecto":
                ruta = util.expandir_ruta("~/.ssh/ux_ci_" + proyecto)
                passphrase = ""
            if not ruta:
                return ResultadoSonda(estado="sin-llave", error="la app está conectada con contraseña: conéctate con tu llave para poder probar el acceso por llave"), desc
            if not Path(ruta).exists():
                return ResultadoSonda(estado="sin-llave", error=f"no encuentro la llave {Path(ruta).name} en este equipo"), desc
            try:
                firmante = sshx.cargar_firmante(ruta, passphrase)
            except (sshx.ErrorAuth, sshx.ErrorPassphrase) as exc:
                return ResultadoSonda(estado="sin-llave", error=util.truncar(str(exc), 200)), desc
        r = probar_acceso(p.host, puerto, usuario, firmante, p.anclada, s.espera == "sin-password", s.remoto)
        return r, desc

    def comprobar_paso(self, paso: str, emitir: Callable[[str], None] | None) -> int:
        sondas = PASOS_COMPROBACION.get(paso)
        if sondas is None:
            raise ValueError("este paso no tiene comprobación automática")
        emitir = emitir or (lambda s: None)
        v = self.variables()
        fallos = 0
        for s in sondas:
            r, desc = self._sondear(s, v, "")
            bien, txt = evaluar_sonda(s, r, desc)
            if not bien:
                fallos += 1
            emitir(("✔ " if bien else "✗ ") + txt + "\n")
        self.registrar(f"paso {paso} · comprobación de acceso", fallos, "")
        if fallos > 0:
            if paso == "3.4":
                emitir("\nNo cierres la sesión actual: la app sigue conectada por el puerto anterior. Revisa el paso 3.1–3.3 o usa «Deshacer la etapa».\n")
            return 1
        if paso == "3.4":
            p = self.ses.parametros()
            if p.puerto != v.puerto_nuevo:
                emitir(f"\nCambiando la conexión de la app al puerto {v.puerto_nuevo}…\n")
                try:
                    self.ses.reconectar(puerto=v.puerto_nuevo)
                except Exception as exc:  # noqa: BLE001
                    emitir("✗ No pude reconectar por el puerto nuevo: " + str(exc) + "\n")
                    return 1
                emitir(f"✔ La app ya trabaja por el puerto {v.puerto_nuevo}.\n")
        return 0

    def probar_acceso_2fa(self, codigo: str) -> tuple[bool, str]:
        v = self.variables()
        p = self.ses.parametros()
        if not p.ruta_llave or p.anclada is None:
            return False, "la app no está conectada con tu llave"
        try:
            firmante = sshx.cargar_firmante(p.ruta_llave, p.passphrase)
        except (sshx.ErrorAuth, sshx.ErrorPassphrase) as exc:
            return False, str(exc)
        r = probar_acceso(p.host, p.puerto, v.admin, firmante, p.anclada, False, "echo ok", 15.0, codigo)
        if r.estado == "ok" and "ok" in r.salida:
            return True, f"{v.admin}@{p.host}:{p.puerto} entra con llave + código 2FA"
        return False, f"el acceso con llave + código falló ({r.estado}): {r.error}"

    # -- protocolo ----------------------------------------------------------

    def sincronizar_protocolo(self, emitir: Callable[[str], None] | None) -> None:
        paquete, suma = empaquetar_protocolo()
        with self._mu:
            if self._proto_ok == suma:
                return
        marca = AGENT_DIR + "/.ux-protocolo-sha"
        try:
            actual = self.ses.leer(marca)
        except Exception:  # noqa: BLE001
            actual = ""
        if actual.strip() == suma:
            with self._mu:
                self._proto_ok = suma
            return
        if emitir is not None:
            emitir("Actualizando en el VPS los archivos del protocolo a la versión de esta app…\n")
        base = "/opt/ux-infra/05-vps"
        tmp = "/tmp/ux-protocolo-" + suma[:12] + ".tgz"
        self.ses.escribir(tmp, paquete)
        script = (
            f"set -e\ntar -xzf {util.comillas(tmp)} -C {util.comillas(base)} --no-same-owner --no-same-permissions --touch\n"
            f"rm -f {util.comillas(tmp)}\n"
            f"find {util.comillas(base)}/agent -type d -exec chmod 755 {{}} +\n"
            f"find {util.comillas(base)}/agent -type f \\( -name '*.sh' -o -name '*.py' -o -path '*/platform/bin/*' \\) -exec chmod 755 {{}} +\n"
            f"printf '%s\\n' {util.comillas(suma)} > {util.comillas(marca)}"
        )
        r = self.ses.plano(script)
        if r.codigo != 0:
            raise ValueError("no pude actualizar el protocolo en el VPS: " + util.truncar(r.stderr.strip(), 300))
        try:
            # La envoltura «sudo» corre como el administrador: install.sh exige root.
            # Su salida va a stderr (las últimas líneas) para que el aviso diga por qué falló.
            rr = self.ses.sudo("if [ -x /usr/local/bin/ux-project ]; then o=\"$(sudo bash " + util.comillas(AGENT_DIR + "/platform/install.sh") + " 2>&1)\" || { printf '%s\\n' \"$o\" | tail -n 5 >&2; exit 1; }; fi")
            if rr.codigo != 0 and emitir is not None:
                emitir("AVISO: no pude reinstalar las herramientas ux-* (" + util.truncar(rr.stderr.strip(), 200) + ")\n")
        except Exception:  # noqa: BLE001
            pass
        with self._mu:
            self._proto_ok = suma
        if emitir is not None:
            emitir("Protocolo del VPS actualizado.\n\n")


def empaquetar_protocolo() -> tuple[bytes, str]:
    """Tar.gz del pack agent/ (lo que la Fase 1 instala en el VPS)."""
    agente_dir = ETAPAS_DIR.parent  # 05-vps/agent
    datos = tempfile.NamedTemporaryFile(suffix=".tgz", delete=False)
    datos.close()
    try:
        with tarfile.open(datos.name, "w:gz") as tar:
            for ruta in sorted(agente_dir.rglob("*")):
                if ruta.is_file():
                    tar.add(ruta, arcname=str(Path("agent") / ruta.relative_to(agente_dir)))
        with open(datos.name, "rb") as fh:
            paquete = fh.read()
    finally:
        try:
            Path(datos.name).unlink()
        except OSError:
            pass
    return paquete, hashlib.sha256(paquete).hexdigest()


# ───────────────────────────── helpers ─────────────────────────


def sustituir(s: str, it: tuple[str, str, str]) -> str:
    return s.replace("<proyecto>", it[0]).replace("<rol>", it[1]).replace("<dominio-del-rol>", it[2])


def primera_linea(s: str) -> str:
    l = s.strip().split("\n", 1)
    return l[0] + " …" if len(l) > 1 else l[0]


def cola_salida(s: str) -> str:
    s = s.strip()
    if not s:
        return ""
    l = s.split("\n")
    if len(l) > 40:
        l = ["…", *l[-40:]]
    return "\n--- salida ---\n" + "\n".join(l)


RESTORE_RECORD = "/var/lib/ux/restore-tested"
RESTORE_MAX_DAYS = 92


def restore_check(f2: "Fase2") -> tuple[bool, str, str | None]:
    """E14.7 / E16: a restore test recorded less than a quarter ago (same rule as the backend)."""
    try:
        out = f2.ses.sudo(f"sudo cat {RESTORE_RECORD} 2>/dev/null || true").stdout
    except Exception:  # noqa: BLE001
        out = ""
    import calendar

    first = (out.strip().split() or [""])[0]
    try:
        when = calendar.timegm(time.strptime(first[:19], "%Y-%m-%dT%H:%M:%S"))
    except ValueError:
        return False, "no hay ninguna prueba de restauración registrada (E14.7)", None  # uxyngraphar:permitir-idioma
    days = int((time.time() - when) // 86400)
    if days <= RESTORE_MAX_DAYS:
        return True, f"restauración probada hace {days} día(s)", None  # uxyngraphar:permitir-idioma
    return False, f"la última prueba de restauración tiene {days} días (máx. {RESTORE_MAX_DAYS})", None  # uxyngraphar:permitir-idioma


def local_por_defecto(tipo: str, v: Vars, emitir: Callable[[str], None] | None, f2: "Fase2") -> tuple[bool, str, str | None]:
    """Comprobaciones que se hacen en la PC del operador (las que no necesitan panel)."""
    if tipo == "sesion":
        info = f2.ses.info()
        if info.conectada and info.sudo_listo:
            return True, "conectado y con sudo validado (la sesión de respaldo)", None
        return False, "no hay una sesión de respaldo (conectada y con sudo)", None
    if tipo == "inventario":
        try:
            texto = f2.ses.leer("/opt/ux-infra/05-vps/agent/inventory/inventory.yaml")
        except Exception as exc:  # noqa: BLE001
            return False, f"no pude leer el inventario del VPS: {exc}", None
        falta = inventario.faltantes(texto)
        if falta:
            return False, "inventario incompleto: " + "; ".join(falta[:5]), None
        return True, "inventario completo", None
    if tipo in ("llaves", "acceso"):
        info = f2.ses.info()
        if info.conectada:
            return True, "acceso con llave activo (esta sesión)", None
        return False, "conéctate con tu llave para comprobar el acceso", None
    if tipo == "http-cerrado":
        try:
            with socket.create_connection((v.ip, 18000), timeout=3):
                return False, "algo escucha en el 18000 (¿un rol publicado fuera del estándar?)", None
        except OSError:
            return True, "nada publicado en el 18000, como se esperaba", None
    if tipo == "tls":
        items = f2.proyectos()
        if not items:
            return True, "sin roles publicados: no aplica", None
        dominios = [d for _, _, d in items if d]
        if not dominios:
            return False, "hay roles sin dominio registrado", None
        res = ops.comprobar_dominios(v.ip, dominios)
        malos = [r["dominio"] for r in res if r.get("apunta") and r.get("https", {}).get("valido") is False]
        if malos:
            return False, "TLS inválido en: " + ", ".join(malos[:5]), None
        return True, "TLS verificado en " + str(len(dominios)) + " dominio(s)", None
    if tipo == "restauracion":
        return restore_check(f2)
    return False, "", f"comprobación local desconocida: {tipo}"
