"""Sesión compartida de la app: conexión, validación de sudo y ejecución.

Espejo de ``05-vps/app/internal/sesion/sesion.go``. Una sola conexión SSH para
toda la app; la contraseña de sudo vive solo en memoria; la reconexión
automática respeta una pausa mínima (``PAUSA_RECONEXION``) para no activar el
límite de conexiones del firewall del VPS.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from . import ssh as sshx
from . import util

# Mínimo entre dos reaperturas automáticas fallidas (> la ventana de 30 s de
# «ufw limit» y el hitcount de fail2ban). Igual que PausaReconexion del original.
PAUSA_RECONEXION = 45.0


class ErrorSinSesion(Exception):
    """No hay una sesión conectada con el VPS."""


@dataclass
class Parametros:
    host: str = ""
    puerto: int = 22
    usuario: str = ""
    ruta_llave: str = ""
    passphrase: str = ""
    password: str = ""
    totp: str = ""
    password_sudo: str = ""
    anclada: "object | None" = None  # paramiko.PKey anclada


@dataclass
class Info:
    """Lo que la interfaz puede ver de la sesión (sin secretos)."""

    conectada: bool = False
    viva: bool = False
    host: str = ""
    puerto: int = 0
    usuario: str = ""
    huella: str = ""
    ruta_llave: str = ""
    sudo_listo: bool = False
    metodo: str = "llave"
    es_root: bool = False
    desde: str = ""

    def json(self) -> dict:
        d = {
            "conectada": self.conectada,
            "viva": self.viva,
            "host": self.host,
            "puerto": self.puerto,
            "usuario": self.usuario,
            "huella": self.huella,
            "ruta_llave": self.ruta_llave,
            "sudo_listo": self.sudo_listo,
            "metodo": self.metodo,
            "es_root": self.es_root,
        }
        if self.desde:
            d["desde"] = self.desde
        return d


# First stdin line = password; remainder = script. Exported `sudo` uses -S so
# the password never appears in argv and no askpass file / executable tmpfs is
# required (CI often mounts /run and /dev/shm noexec).
# The password only validates the timestamp (`sudo -S -v`); the command runs
# with `sudo -n` and keeps the caller's stdin, so `sudo tee FILE <<EOF` and
# `... | sudo X` get their own input instead of the password line. Without
# timestamp caching it falls back to the old pipe. Mirrors remote/domain/shell.ts.
ENVOLTURA_SUDO = r"""IFS= read -r UX_PW || exit 97
sudo() {
  command sudo -n true 2>/dev/null ||
    printf '%s\n' "$UX_PW" | command sudo -S -p '' -v 2>/dev/null
  if command sudo -n true 2>/dev/null; then
    command sudo -n "$@"
  else
    printf '%s\n' "$UX_PW" | command sudo -S -p '' "$@"
  fi
}
export -f sudo
UX_S="$(cat)"
[ -n "$UX_S" ] || exit 99
exec </dev/null
eval "$UX_S"
UX_RC=$?
unset UX_PW
exit "$UX_RC"
"""

# Para root no hay sudo ni contraseña; un VPS recién creado puede no tener sudo
# instalado, así que `sudo` se define como función que ejecuta el comando
# directamente (con -u cambia de usuario con runuser).
ENVOLTURA_ROOT = r"""sudo() {
  local u=""
  while [ $# -gt 0 ]; do
    case "$1" in
      -u) u="$2"; shift 2 ;;
      --) shift; break ;;
      -*) shift ;;
      *) break ;;
    esac
  done
  while [ $# -gt 0 ]; do
    case "$1" in [A-Za-z_]*=*) export "$1"; shift ;; *) break ;; esac
  done
  if [ -n "$u" ]; then runuser -u "$u" -- "$@"; else "$@"; fi
}
export -f sudo
UX_S="$(cat)"
exec </dev/null
eval "$UX_S"
"""

ENVOLTURA_PLANA = r"""UX_S="$(cat)"
exec </dev/null
eval "$UX_S"
"""


class Sesion:
    """La conexión compartida de toda la app."""

    def __init__(self) -> None:
        self._mu = threading.RLock()
        self._reabrir = threading.Lock()
        self._cli: "sshx.Cliente | None" = None
        self._p = Parametros()
        self._sudo_ok = False
        self._desde: datetime | None = None
        self._fallo_hasta = 0.0
        self._fallo_msg = ""
        self._freno = True  # freno de reconexión automática (las pruebas lo desactivan)

    # -- conexión -----------------------------------------------------------

    def conectar(self, p: Parametros) -> None:
        cli = sshx.Cliente.dial(
            sshx.Config(
                host=p.host,
                puerto=p.puerto,
                usuario=p.usuario,
                contrasena=p.password,
                ruta_llave=p.ruta_llave,
                passphrase=p.passphrase,
                totp=p.totp,
                anclada=p.anclada,
            )
        )
        try:
            self.adoptar(cli, p)
            if p.password_sudo or p.usuario == "root":
                try:
                    self.validar_sudo()
                except Exception:
                    self.desconectar()
                    raise
        except Exception:
            cli.cerrar()
            raise

    def adoptar(self, cli: "sshx.Cliente", p: Parametros) -> None:
        with self._mu:
            viejo = self._cli
            self._cli, self._p, self._sudo_ok, self._desde = cli, p, False, datetime.now(timezone.utc)
        if viejo is not None:
            viejo.cerrar()

    def reconectar(self, puerto: int = 0, totp: str = "") -> None:
        with self._mu:
            p = self._p
        if not p.host:
            raise ValueError("no hay una sesión previa que reconectar")
        if puerto > 0:
            p.puerto = puerto
        p.totp = totp
        self.conectar(p)

    def desconectar(self) -> None:
        with self._mu:
            cli = self._cli
            self._cli, self._p, self._sudo_ok = None, Parametros(), False
        if cli is not None:
            cli.cerrar()

    def info(self) -> Info:
        with self._mu:
            p = self._p
            i = Info(
                host=p.host,
                puerto=p.puerto,
                usuario=p.usuario,
                ruta_llave=p.ruta_llave,
                sudo_listo=self._sudo_ok,
                es_root=p.usuario == "root",
                metodo="password" if (not p.ruta_llave and p.password) else "llave",
            )
            if self._cli is not None:
                i.conectada, i.viva = True, self._cli.vivo()
                if self._desde:
                    i.desde = self._desde.astimezone().isoformat(timespec="seconds")
            if p.anclada is not None:
                i.huella = sshx.huella(p.anclada)
        return i

    def parametros(self) -> Parametros:
        with self._mu:
            return self._p

    def actualizar_puerto(self, puerto: int) -> None:
        with self._mu:
            self._p.puerto = puerto

    # -- uso ----------------------------------------------------------------

    def validar_sudo(self) -> None:
        """Comprueba la contraseña de sudo una vez, para fallar rápido."""
        if self._es_root():
            r = self.plano("id -u")
            if r.codigo != 0 or r.stdout.strip() != "0":
                raise ValueError(
                    "la sesión como root no tiene privilegios de administrador (id -u no devolvió 0)"
                )
        else:
            r = self.sudo("sudo whoami")
            if r.codigo != 0 or r.stdout.strip() != "root":
                raise ValueError(
                    "sudo no devolvió 'root': verifica la contraseña de sudo del usuario administrador"
                )
        with self._mu:
            self._sudo_ok = True

    def sudo(
        self,
        script: str,
        salida: Callable[[str], None] | None = None,
        max_bytes: int = 0,
    ) -> sshx.Resultado:
        cli, pw = self._cliente()
        if self._es_root():
            return cli.ejecutar(
                "bash -c " + _comillas(ENVOLTURA_ROOT), stdin=script, salida=salida, max_bytes=max_bytes or 512 * 1024
            )
        if not pw:
            raise ValueError(
                "falta la contraseña de sudo del usuario administrador (reconecta e indícala)"
            )
        return cli.ejecutar(
            "bash -c " + _comillas(ENVOLTURA_SUDO),
            stdin=pw + "\n" + script,
            salida=salida,
            max_bytes=max_bytes or 512 * 1024,
        )

    def plano(self, script: str, salida: Callable[[str], None] | None = None) -> sshx.Resultado:
        cli, _ = self._cliente()
        return cli.ejecutar(
            "bash -c " + _comillas(ENVOLTURA_PLANA), stdin=script, salida=salida
        )

    def leer(self, ruta: str) -> str:
        """Devuelve el contenido de un archivo remoto legible por el administrador."""
        cli, _ = self._cliente()
        r = cli.ejecutar("cat -- " + _comillas(ruta))
        if r.codigo != 0:
            raise ValueError("no pude leer " + ruta + ": " + util.truncar(r.stderr.strip(), 200))
        return r.stdout

    def escribir(self, ruta: str, datos: str | bytes) -> None:
        """Guarda un archivo remoto (por stdin, permisos restrictivos) como el administrador."""
        cli, _ = self._cliente()
        cli.escribir_archivo(ruta, "600", datos)

    # -- internos -----------------------------------------------------------

    def _es_root(self) -> bool:
        with self._mu:
            return self._p.usuario == "root"

    def _cliente(self) -> tuple["sshx.Cliente", str]:
        with self._mu:
            cli, p = self._cli, self._p
        if cli is None:
            raise ErrorSinSesion("no hay una sesión conectada con el VPS: conéctate primero")
        if cli.vivo():
            return cli, p.password_sudo
        # La conexión se cayó: un intento automático de reabrirla con los mismos
        # datos. Con un TOTP de un solo uso no es posible: se pide reconectar a mano.
        if p.totp:
            raise ValueError(
                "la conexión con el VPS se cerró (¿reinicio o corte de red?): usa «Reconectar»"
            )
        with self._reabrir:
            with self._mu:
                if self._cli is not None and self._cli is not cli and self._cli.vivo():
                    return self._cli, self._p.password_sudo
                if self._freno and time.time() < self._fallo_hasta:
                    msg = self._fallo_msg
                else:
                    msg = ""
            if msg:
                raise ValueError(msg)
            try:
                self.conectar(p)
            except Exception as exc:
                msg = (
                    f"la conexión con el VPS se cerró y no pude reabrirla ({exc}): "
                    f"revisa que el servidor esté encendido; la app no reintenta sola "
                    f"durante {int(PAUSA_RECONEXION)} s para no activar el límite de "
                    f"conexiones del firewall. Usa «Reconectar»"
                )
                with self._mu:
                    if self._freno:
                        self._fallo_hasta = time.time() + PAUSA_RECONEXION
                        self._fallo_msg = msg
                raise ValueError(msg) from exc
            with self._mu:
                return self._cli, self._p.password_sudo


def _comillas(s: str) -> str:
    """Escapa un valor para usarlo como UN argumento POSIX (comillas simples)."""
    return "'" + s.replace("'", "'\"'\"'") + "'"
