"""Inventario (``inventory.yaml``): esquema, validación, edición línea a línea
y generación inicial. Espejo de ``05-vps/app/internal/inventario/inventario.go``.

Sin librerías YAML: el inventario tiene una forma simple (secciones y claves de
un nivel) y se edita línea a línea para respetar los comentarios del
administrador.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from . import util

_HOST = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$")
_CHAT = re.compile(r"^-?[0-9]{1,20}$")
_RUTA = re.compile(r"^[^\"'#<>|\r\n]+$")
_PROVEEDOR = re.compile(r"^[A-Za-z0-9 ._-]{0,60}$")
_SECCION = re.compile(r"^([A-Za-z0-9_.-]+):\s*(#.*)?$")
_CLAVE = re.compile(r"^(\s+)([A-Za-z0-9_.-]+):(\s*)(.*)$")


@dataclass
class Campo:
    seccion: str
    clave: str
    etiqueta: str
    ayuda: str
    tipo: str  # texto | numero | solo-lectura
    requerido: bool
    ejemplo: str = ""
    variable: str = ""

    def json(self) -> dict:
        d = {
            "seccion": self.seccion,
            "clave": self.clave,
            "etiqueta": self.etiqueta,
            "ayuda": self.ayuda,
            "tipo": self.tipo,
            "requerido": self.requerido,
        }
        if self.ejemplo:
            d["ejemplo"] = self.ejemplo
        if self.variable:
            d["variable"] = self.variable
        return d


ESQUEMA: list[Campo] = [
    Campo("vps", "ip_publica", "IP pública del VPS", "La IP real de tu servidor.", "texto", True, "203.0.113.10", "VPS_IP"),
    Campo("vps", "huella_ssh", "Huella SSH del servidor", "SHA256:… La app la rellena al verificar la huella.", "texto", False, "SHA256:…", "VPS_SSH_FINGERPRINT"),
    Campo("vps", "proveedor", "Proveedor", "Hetzner, DigitalOcean, OVH, Vultr…", "texto", False, "hetzner", ""),
    Campo("vps", "os", "Sistema operativo", "El estándar exige Debian 13 (trixie) o Ubuntu 26.04 LTS.", "solo-lectura", False, "Debian 13 (trixie) o Ubuntu 26.04 LTS", ""),
    Campo("vps", "zona_horaria", "Zona horaria", "Formato IANA, p. ej. America/Mexico_City.", "texto", False, "UTC", "VPS_TIMEZONE"),
    Campo("vps", "puerto_ssh", "Puerto SSH (futuro, E03)", "Entre 1024 y 65535. Se aplica al endurecer SSH.", "numero", False, "2222", "VPS_SSH_PORT"),
    Campo("vps", "usuario_admin", "Usuario administrador", "Con sudo; es quien opera el servidor.", "texto", False, "vpsadmin", "VPS_ADMIN_USER"),
    Campo("acceso", "llave_privada", "Llave privada (local)", "Ruta en TU computadora; nunca sale de ella.", "texto", False, "~/.ssh/id_ed25519", "LLAVE_PRIVADA"),
    Campo("acceso", "llave_publica", "Llave pública (local)", "Ruta de la .pub en tu computadora.", "texto", False, "~/.ssh/id_ed25519.pub", "LLAVE_PUBLICA"),
    Campo("dominio", "base", "Dominio base", "Tu dominio real; los proyectos cuelgan de él.", "texto", True, "tudominio.com", "DOMAIN"),
    Campo("dominio", "proveedor_dns", "Proveedor de DNS", "Cloudflare, Route53… (el DNS se gestiona a mano).", "texto", False, "cloudflare", ""),
    Campo("tls", "email_acme", "Email para Let's Encrypt", "Recibe avisos de certificados.", "texto", True, "admin@tudominio.com", "ACME_EMAIL"),
    Campo("backup", "r2_account_id", "Account ID de Cloudflare (R2)", "32 caracteres hexadecimales. La app lo rellena sola en la E14.", "texto", False, "", "R2_ACCOUNT_ID"),
    Campo("backup", "age_recipient", "Claves públicas age (respaldos)", "Dos claves age1… separadas por coma, sin espacios: recuperación y verificación del CI. La app las crea sola en la E14.", "texto", False, "age1…,age1…", "AGE_RECIPIENT"),
    Campo("backup", "bucket_plataforma", "Bucket de la plataforma", "Respaldos de /etc/ux y certificados de Caddy.", "texto", False, "backups-general-projects", "R2_BUCKET"),
    Campo("backup", "prefijo_vps", "Prefijo de este VPS en el bucket", "Ordena el bucket: diario/<prefijo>/… Vacío = nombre del servidor.", "texto", False, "", "R2_PREFIJO"),
    Campo("alertas", "correos", "Correos que reciben alertas", "Separados por coma; vacío = sin correo.", "texto", False, "admin@tudominio.com", "ALERTA_CORREOS"),
    Campo("alertas", "smtp_host", "Servidor SMTP", "Host del correo saliente.", "texto", False, "smtp.tudominio.com", "ALERTA_SMTP_HOST"),
    Campo("alertas", "smtp_usuario", "Usuario SMTP", "", "texto", False, "alertas@tudominio.com", "ALERTA_SMTP_USER"),
    Campo("alertas", "smtp_from", "Remitente (From)", "", "texto", False, "alertas@tudominio.com", "ALERTA_SMTP_FROM"),
    Campo("alertas", "telegram_chat_id", "Chat ID de Telegram", "Vacío = sin Telegram.", "texto", False, "", "ALERTA_TELEGRAM_CHAT"),
]


def campo_de(seccion: str, clave: str) -> Campo | None:
    for c in ESQUEMA:
        if c.seccion == seccion and c.clave == clave:
            return c
    return None


def validar(seccion: str, clave: str, valor: str) -> None:
    """Comprueba el valor de un campo. Vacío es válido salvo en requeridos."""
    valor = valor.strip()
    if any(ch in valor for ch in '#"\r\n'):
        raise ValueError("no puede contener #, comillas dobles ni saltos de línea")
    c = campo_de(seccion, clave)
    req = bool(c and c.requerido)
    if not valor:
        if req:
            raise ValueError("es obligatorio")
        return
    if "<" in valor or ">" in valor:
        raise ValueError("tiene un marcador <…> sin reemplazar")
    k = f"{seccion}.{clave}"
    if k == "vps.ip_publica":
        util.validar_host(valor)
    elif k == "vps.huella_ssh":
        util.normalizar_huella(valor)
    elif k == "vps.puerto_ssh":
        p = util.validar_puerto(valor)
        if p < 1024:
            raise ValueError("debe estar entre 1024 y 65535")
    elif k == "vps.usuario_admin":
        util.validar_usuario(valor)
    elif k == "vps.zona_horaria":
        if not util.es_zona_horaria(valor):
            raise ValueError("zona horaria no válida (p. ej. America/Mexico_City)")
    elif k in ("vps.proveedor", "dominio.proveedor_dns"):
        if not _PROVEEDOR.match(valor):
            raise ValueError("solo letras, números, espacios, punto, guion y guion bajo")
    elif k == "dominio.base":
        if not util.es_dominio(valor):
            raise ValueError("dominio no válido (p. ej. midominio.com)")
    elif k == "tls.email_acme":
        util.validar_email(valor)
    elif k == "backup.r2_account_id":
        if not util.es_account_r2(valor):
            raise ValueError("debe ser el Account ID de Cloudflare (32 caracteres hexadecimales)")
    elif k == "backup.age_recipient":
        if not util.es_age_recipients(valor):
            raise ValueError("deben ser claves age1… (una o varias separadas por coma, sin espacios)")
    elif k == "backup.prefijo_vps":
        if not util.es_prefijo_vps(valor):
            raise ValueError("prefijo no válido (minúsculas, dígitos y guiones, hasta 40)")
    elif k == "backup.bucket_plataforma":
        if not util.es_bucket(valor):
            raise ValueError("nombre de bucket no válido (minúsculas, números y guiones)")
    elif k == "alertas.correos":
        for e in valor.split(","):
            util.validar_email(e.strip())
    elif k == "alertas.smtp_host":
        if not _HOST.match(valor):
            raise ValueError("host SMTP no válido")
    elif k in ("alertas.smtp_usuario", "alertas.smtp_from"):
        if any(ch in valor for ch in " '`$\\;|&"):
            raise ValueError("contiene caracteres no permitidos")
    elif k == "alertas.telegram_chat_id":
        if not _CHAT.match(valor):
            raise ValueError("debe ser un número (puede empezar con -)")
    elif k in ("acceso.llave_privada", "acceso.llave_publica"):
        if not _RUTA.match(valor):
            raise ValueError("ruta no válida")


# ───────────────────── lectura y edición línea a línea ─────────────────────


def _separar_valor(resto: str) -> tuple[str, str]:
    """Separa ``"valor"   # comentario`` en (valor sin comillas, resto original)."""
    idx = resto.find("#")
    cuerpo = resto
    sufijo = ""
    if idx >= 0:
        cuerpo, sufijo = resto[:idx], resto[idx:]
    cuerpo = cuerpo.strip().strip("\"'")
    return cuerpo, sufijo


def parsear(texto: str) -> dict[str, dict[str, str]]:
    res: dict[str, dict[str, str]] = {}
    actual = ""
    for l in texto.replace("\r\n", "\n").split("\n"):
        sin = l.strip()
        if not sin or sin.startswith("#"):
            continue
        if not l.startswith((" ", "\t")):
            m = _SECCION.match(l)
            if m:
                actual = m.group(1)
                res.setdefault(actual, {})
            continue
        if not actual:
            continue
        m = _CLAVE.match(l)
        if m:
            v, _ = _separar_valor(m.group(4))
            res[actual][m.group(2)] = v
    return res


def _renderizar(c: Campo, valor: str) -> str:
    if c.tipo == "numero":
        return valor
    return '"' + valor.replace("\\", "\\\\").replace('"', '\\"') + '"'


def aplicar(texto: str, cambios: dict[str, str]) -> str:
    """Cambia valores (``seccion.clave`` → valor) conservando comentarios y orden."""
    nl = "\r\n" if "\r\n" in texto else "\n"
    lineas = texto.replace("\r\n", "\n").split("\n")
    tipo_de: dict[str, Campo] = {}
    for c in ESQUEMA:
        tipo_de[f"{c.seccion}.{c.clave}"] = c
    pendientes: dict[str, str] = {}
    for k, v in cambios.items():
        c = tipo_de.get(k)
        if c is None:
            raise ValueError(f"campo desconocido: {k}")
        if c.tipo == "solo-lectura":
            continue
        validar(c.seccion, c.clave, v)
        pendientes[k] = v.strip()
    seccion = ""
    ultima_de: dict[str, int] = {}
    for i, l in enumerate(lineas):
        sin = l.strip()
        if not sin or sin.startswith("#"):
            continue
        if not l.startswith((" ", "\t")):
            m = _SECCION.match(l)
            if m:
                seccion = m.group(1)
                ultima_de.setdefault(seccion, i)
            continue
        m = _CLAVE.match(l)
        if not m or not seccion:
            continue
        ultima_de[seccion] = i
        k = f"{seccion}.{m.group(2)}"
        if k in pendientes:
            nuevo = pendientes[k]
            _, com = _separar_valor(m.group(4))
            c = tipo_de[k]
            val = _renderizar(c, nuevo)
            if com:
                val += "   " + com
            lineas[i] = m.group(1) + m.group(2) + ":" + m.group(3) + val
            if m.group(3) == "":
                lineas[i] = m.group(1) + m.group(2) + ": " + val
            del pendientes[k]
    if pendientes:
        for k in sorted(pendientes):
            c = tipo_de[k]
            linea = "  " + c.clave + ": " + _renderizar(c, pendientes[k])
            idx = ultima_de.get(c.seccion)
            if idx is not None:
                lineas.insert(idx + 1, linea)
                for s, j in list(ultima_de.items()):
                    if j >= idx + 1:
                        ultima_de[s] = j + 1
                ultima_de[c.seccion] = idx + 1
            else:
                lineas.extend(["", c.seccion + ":", linea])
                ultima_de[c.seccion] = len(lineas) - 1
    return nl.join(lineas)


def faltantes(texto: str) -> list[str]:
    """Replica la exigencia de init-vps.sh: REQUERIDO sin valor o con marcadores."""
    vals = parsear(texto)
    falta: list[str] = []
    req = {
        "vps.ip_publica": "VPS_IP",
        "vps.huella_ssh": "VPS_SSH_FINGERPRINT",
        "dominio.base": "DOMAIN",
        "tls.email_acme": "ACME_EMAIL",
    }
    for k in sorted(req):
        seccion, _, clave = k.partition(".")
        v = vals.get(seccion, {}).get(clave, "")
        if not v or v.startswith("$") or "REEMPLAZA" in v:
            falta.append(k)
    for l in texto.split("\n"):
        sin = l.strip()
        if sin.startswith("#"):
            continue
        if re.match(r"^(r2_account_id|age_recipient|proveedor_dns):", sin):
            continue
        if re.search(r"<[^>]+>", l):
            falta.append("marcadores <…> sin reemplazar: " + sin)
            break
    return falta


# ───────────────────── generación inicial (Fase 1) ─────────────────────


@dataclass
class Datos:
    ip: str = ""
    huella: str = ""
    proveedor: str = ""
    zona_horaria: str = ""
    puerto_ssh_futuro: int = 0
    usuario_admin: str = ""
    ruta_llave: str = ""
    ruta_llave_publica: str = ""
    dominio: str = ""
    email_acme: str = ""


def _yaml_texto(v: str) -> str:
    return v.replace("\\", "\\\\").replace('"', '\\"')


def _def(v: str, d: str) -> str:
    return d if not v.strip() else v


# ───────────────────── secretos (secrets.sh) ─────────────────────


@dataclass
class Secreto:
    nombre: str
    etiqueta: str
    grupo: str
    ayuda: str = ""

    def json(self) -> dict:
        return {"nombre": self.nombre, "etiqueta": self.etiqueta, "grupo": self.grupo, "ayuda": self.ayuda}


SECRETOS_CONOCIDOS: list[Secreto] = [
    Secreto("SSH_KEY_PASSPHRASE", "Passphrase de tu llave SSH", "Acceso SSH", "Solo si tu llave la tiene."),
    Secreto("VPS_ADMIN_PASSWORD", "Contraseña de sudo del usuario administrador", "Acceso SSH", "La que definiste en la Fase 1."),
    Secreto("R2_ACCESS_KEY_ID", "R2 · Access Key ID de la plataforma", "Respaldos (Cloudflare R2)", "Token Object Read & Write restringido al bucket."),
    Secreto("R2_SECRET_ACCESS_KEY", "R2 · Secret Access Key de la plataforma", "Respaldos (Cloudflare R2)", ""),
    Secreto("ALERTA_SMTP_PASSWORD", "Contraseña SMTP", "Alertas", "Solo si usas correo."),
    Secreto("ALERTA_TELEGRAM_TOKEN", "Token del bot de Telegram", "Alertas", "Te lo da @BotFather; solo si usas Telegram."),
    Secreto("GHCR_USER", "GHCR · usuario de GitHub", "Registro de imágenes (GHCR)", ""),
    Secreto("GHCR_TOKEN", "GHCR · token de solo lectura de paquetes", "Registro de imágenes (GHCR)", "Permiso read:packages únicamente."),
]

_NOMBRE_SECRETO = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")
_LINEA_EXPORT = re.compile(r"^\s*(?:export\s+)?([A-Z][A-Z0-9_]*)=(.*)$")


def validar_secreto(nombre: str, valor: str) -> None:
    if not _NOMBRE_SECRETO.match(nombre):
        raise ValueError("nombre de secreto no válido")
    if "\r" in valor or "\n" in valor or "\x00" in valor:
        raise ValueError("no puede contener saltos de línea")
    if len(valor) > 512:
        raise ValueError("es demasiado largo")
    if nombre == "VPS_ADMIN_PASSWORD" and valor:
        util.validar_password_sudo(valor)
    if nombre in ("R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY") and valor and not util.es_alfanumerico(valor):
        raise ValueError("las claves de R2 solo pueden contener letras y dígitos")


def _desentrecomillar(v: str) -> str:
    v = v.strip()
    if len(v) >= 2 and v.startswith('"'):
        i = v.rfind('"')
        if i > 0:
            inner = v[1:i]
            return inner.replace('\\"', '"').replace("\\\\", "\\").replace("\\$", "$").replace("\\`", "`")
    if len(v) >= 2 and v.startswith("'"):
        v = v.replace("'\"'\"'", "\x00").strip("'")
        return v.replace("\x00", "'")
    if "#" in v:
        v = v[: v.index("#")].strip()
    return v


def parsear_secretos(texto: str) -> dict[str, str]:
    """Lee ``secrets.sh`` (``export NOMBRE="valor"``)."""
    res: dict[str, str] = {}
    for l in texto.replace("\r\n", "\n").split("\n"):
        if l.strip().startswith("#"):
            continue
        m = _LINEA_EXPORT.match(l)
        if m:
            res[m.group(1)] = _desentrecomillar(m.group(2))
    return res


def generar_secretos(valores: dict[str, str]) -> str:
    """Escribe ``secrets.sh`` con el formato del ejemplo."""
    b: list[str] = []
    b.append("# Secretos del pack de agentes — NUNCA versionar este archivo.")
    b.append("# Generado por la app UX-VPS. Permisos 600. Alternativa más segura: SOPS + age.")
    b.append("")
    conocidos = {s.nombre for s in SECRETOS_CONOCIDOS}
    grupo = ""
    for s in SECRETOS_CONOCIDOS:
        if s.grupo != grupo:
            if grupo:
                b.append("")
            b.append("# ─── " + s.grupo + " ───")
            grupo = s.grupo
        b.append(f"export {s.nombre}={util.comillas(valores.get(s.nombre, ''))}")
    otros = sorted(k for k in valores if k not in conocidos)
    if otros:
        b.append("")
        b.append("# ─── Otros ───")
        for k in otros:
            b.append(f"export {k}={util.comillas(valores[k])}")
    return "\n".join(b) + "\n"


# ───────────────────── generación inicial (Fase 1) ─────────────────────


def generar(d: Datos) -> str:
    dominio = _def(d.dominio, "tudominio.com")
    email = _def(d.email_acme, "admin@tudominio.com")
    puerto = d.puerto_ssh_futuro or 2222
    b: list[str] = []

    def w(s: str) -> None:
        b.append(s)

    w("# Inventario del VPS — generado por la app UX-VPS (Fase 1).")
    w("# Los REQUERIDO que faltan se completan antes de la Fase 2 (ver inventory.example.yaml).")
    w("")
    w("version: 2")
    w("")
    w("# ─── VPS ──────────────────────────────────────────────────────────────")
    w("vps:")
    w(f'  ip_publica: "{_yaml_texto(d.ip)}"')
    w(f'  huella_ssh: "{_yaml_texto(d.huella)}"')
    w(f'  proveedor: "{_yaml_texto(_def(d.proveedor, "vps"))}"')
    w('  os: "Debian 13 (trixie) o Ubuntu 26.04 LTS"')
    w(f'  zona_horaria: "{_yaml_texto(_def(d.zona_horaria, "UTC"))}"')
    w(f"  puerto_ssh: {puerto}")
    w(f'  usuario_admin: "{_yaml_texto(_def(d.usuario_admin, "vpsadmin"))}"')
    w("")
    w("# ─── Acceso (equipo LOCAL del administrador) ──────────────────────────────")
    w("acceso:")
    w(f'  llave_privada: "{_yaml_texto(_def(d.ruta_llave, "~/.ssh/id_ed25519"))}"')
    w(f'  llave_publica: "{_yaml_texto(_def(d.ruta_llave_publica, "~/.ssh/id_ed25519.pub"))}"')
    w('  passphrase_llave: "${SSH_KEY_PASSPHRASE}"')
    w('  password_sudo: "${VPS_ADMIN_PASSWORD}"')
    w("")
    w("# ─── Dominio y DNS ────────────────────────────────────────────────────")
    w("dominio:")
    w(f'  base: "{_yaml_texto(dominio)}"')
    w('  proveedor_dns: "<cloudflare|route53|...>"')
    w("")
    w("# ─── TLS / ACME ───────────────────────────────────────────────────────")
    w("tls:")
    w(f'  email_acme: "{_yaml_texto(email)}"')
    w("")
    w("# ─── Respaldos (Cloudflare R2) ────────────────────────────────────────")
    w("backup:")
    w('  r2_account_id: "<REEMPLAZA_CON_TU_ACCOUNT_ID>"')
    w('  age_recipient: "<age1…_RECUPERACION,age1…_VERIFICACION>"')
    w('  bucket_plataforma: "backups-general-projects"')
    w('  prefijo_vps: ""')
    w('  r2_access_key_id: "${R2_ACCESS_KEY_ID}"')
    w('  r2_secret_access_key: "${R2_SECRET_ACCESS_KEY}"')
    w("")
    w("# ─── Alertas (correo y/o Telegram) ────────────────────────────────────")
    w("alertas:")
    w(f'  correos: "{_yaml_texto(email)}"')
    w('  smtp_host: ""')
    w('  smtp_usuario: ""')
    w('  smtp_from: ""')
    w('  smtp_password: "${ALERTA_SMTP_PASSWORD}"')
    w('  telegram_bot_token: "${ALERTA_TELEGRAM_TOKEN}"')
    w('  telegram_chat_id: ""')
    w("")
    w("# ─── Registro de imágenes (GHCR) ──────────────────────────────────────")
    w("ghcr:")
    w('  usuario: "${GHCR_USER}"')
    w('  token: "${GHCR_TOKEN}"')
    return "\n".join(b)
