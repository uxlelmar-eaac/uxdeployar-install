"""ux-infra — app única en Python (lado proyecto y lado servidor).

Una sola aplicación para preparar un repositorio según el estándar de despliegue
y para configurar y operar el VPS. Sustituye a ``ux-prep`` (Python) y a la app
UX-VPS (Go), que se conserva en ``vps/`` solo mientras dura el port.
"""

__version__ = "0.1.0"
