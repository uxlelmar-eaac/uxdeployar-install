"""Convierte ``agent/stages/NN-*.md`` en un plan estructurado.

Espejo de ``05-vps/app/internal/contratos/contratos.go``: los comandos viven
SOLO en este plan (lado servidor de la app); la interfaz los referencia por
identificador (etapa, paso, bloque) y nunca los envía.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

IDS = [f"{i:02d}" for i in range(18)]

_FRONT = re.compile(r"^(id|etapa|titulo|estado|origen|depende_de):\s*(.*)$")
_PASO = re.compile(r"^###\s+(\d+\.\d+[a-z]?)\s+(.*)$")
_MARCADOR = re.compile(r"<[A-Za-zÁÉÍÓÚáéíóúñÑ][A-Za-zÁÉÍÓÚáéíóúñÑ0-9_ .-]*>")

_CLASES = ["AUTO", "HUMANO", "ENTORNO", "INFO"]


@dataclass
class Bloque:
    comando: str
    tipo: str = "normal"  # normal | rollback
    tamano: int = 0
    parametros: bool = False

    def json(self) -> dict:
        return {"comando": self.comando, "tipo": self.tipo, "tamano": self.tamano, "parametros": self.parametros}


@dataclass
class Paso:
    num: str
    titulo: str
    clase: str = "AUTO"  # AUTO | HUMANO | MIXTO | ENTORNO | INFO
    ubicacion: str = ""
    texto: list[str] = field(default_factory=list)
    bloques: list[Bloque] = field(default_factory=list)

    def json(self) -> dict:
        return {
            "num": self.num,
            "titulo": self.titulo,
            "clase": self.clase,
            "ubicacion": self.ubicacion,
            "texto": self.texto,
            "bloques": [b.json() for b in self.bloques],
        }


@dataclass
class Seccion:
    titulo: str
    lineas: list[str] = field(default_factory=list)

    def json(self) -> dict:
        return {"titulo": self.titulo, "lineas": self.lineas}


@dataclass
class Etapa:
    id: str = ""
    titulo: str = ""
    estado: str = ""
    origen: str = ""
    precondiciones: list[str] = field(default_factory=list)
    secciones: list[Seccion] = field(default_factory=list)
    pasos: list[Paso] = field(default_factory=list)
    punto_control: list[list[str]] = field(default_factory=list)
    rollback: list[str] = field(default_factory=list)
    rollback_bloques: list[Bloque] = field(default_factory=list)

    def json(self) -> dict:
        return {
            "id": self.id,
            "titulo": self.titulo,
            "estado": self.estado,
            "origen": self.origen,
            "precondiciones": self.precondiciones,
            "secciones": [s.json() for s in self.secciones],
            "pasos": [p.json() for p in self.pasos],
            "punto_control": self.punto_control,
            "rollback": self.rollback,
            "rollback_bloques": [b.json() for b in self.rollback_bloques],
        }


def clase_de(texto: str) -> str:
    presentes = [c for c in _CLASES if f"[{c}]" in texto]
    if not presentes:
        return "AUTO"
    if "HUMANO" in presentes and "AUTO" in presentes:
        return "MIXTO"
    return presentes[0]


def ubicacion_de(texto: str) -> str:
    if "[VPS]" in texto:
        return "VPS"
    if "[LOCAL]" in texto:
        return "LOCAL"
    return ""


def parsear(texto: str) -> Etapa:
    plan = Etapa()
    campos: dict[str, str] = {}
    lineas = texto.replace("\r\n", "\n").split("\n")
    seccion = ""
    seccion_titulo = ""
    paso: Paso | None = None
    en_bloque = False
    sangria = ""
    bloque: list[str] = []
    nota = ""
    en_front = False
    front_visto = False
    especiales = {"pasos", "steps", "punto de control", "precondiciones", "entradas", "registro"}
    indice: dict[str, int] = {}

    for linea in lineas:
        if linea.strip() == "---":
            if not en_front and not front_visto:
                en_front, front_visto = True, True
                continue
            en_front = False
            continue
        if en_front:
            m = _FRONT.match(linea)
            if m:
                campos[m.group(1).strip()] = m.group(2).strip().strip('"')
            continue
        if linea.startswith("## "):
            seccion_titulo = linea[3:].strip()
            seccion = seccion_titulo.lower()
            if seccion_titulo not in indice:
                indice[seccion_titulo] = len(plan.secciones)
                plan.secciones.append(Seccion(titulo=seccion_titulo))
            paso, en_bloque = None, False
            continue
        if linea.strip().startswith("```"):
            if en_bloque:
                if seccion.startswith("rollback"):
                    cmd = "\n".join(bloque).strip()
                    plan.rollback_bloques.append(
                        Bloque(comando=cmd, tipo="rollback", tamano=len(cmd), parametros=bool(_MARCADOR.search(cmd)))
                    )
                elif paso is not None:
                    cmd = "\n".join(bloque).strip()
                    tipo = "rollback" if "rollback" in nota.lower() else "normal"
                    paso.bloques.append(
                        Bloque(comando=cmd, tipo=tipo, tamano=len(cmd), parametros=bool(_MARCADOR.search(cmd)))
                    )
                bloque, en_bloque, nota = [], False, ""
            else:
                en_bloque = (seccion in ("pasos", "steps") and paso is not None) or seccion.startswith("rollback")
                sangria = linea[: len(linea) - len(linea.lstrip(" \t"))]
            continue
        if en_bloque:
            bloque.append(linea[len(sangria):] if linea.startswith(sangria) else linea)
            continue
        es_verif = seccion.startswith("verificaciones")
        if seccion_titulo and seccion not in especiales and not seccion.startswith("rollback") and not es_verif:
            if linea.strip():
                plan.secciones[indice[seccion_titulo]].lineas.append(linea)
        if seccion in ("pasos", "steps"):
            m = _PASO.match(linea)
            if m:
                plan.pasos.append(Paso(num=m.group(1), titulo=m.group(2).strip(), clase=clase_de(m.group(2)), ubicacion=ubicacion_de(m.group(2))))
                paso = plan.pasos[-1]
                nota = ""
                continue
            if paso is not None and linea.strip():
                paso.texto.append(linea)
                if "**" in linea and "rollback" in linea.lower():
                    nota = linea
                elif not linea.strip().startswith("-"):
                    nota = ""
        elif (seccion == "punto de control" or es_verif) and linea.strip().startswith("|"):
            marca = "\x00BARRA\x00"
            cruda = linea.strip().replace("\\|", marca)
            celdas = [c.strip().replace(marca, "\\|") for c in cruda.strip("|").split("|")]
            todo_guiones = all(c.startswith("-") for c in celdas)
            if celdas and not todo_guiones and not (celdas[0] == "#" and plan.punto_control):
                plan.punto_control.append(celdas)
        elif seccion.startswith("rollback") and linea.strip():
            plan.rollback.append(linea.strip())
        elif seccion == "precondiciones" and linea.strip():
            plan.precondiciones.append(linea.strip())

    plan.id = campos.get("etapa") or campos.get("id", "")
    plan.titulo = campos.get("titulo", "")
    plan.estado = campos.get("estado", "")
    plan.origen = campos.get("origen", "")
    return plan


def cargar(dir_etapas: str | Path) -> list[Etapa]:
    """Lee y ordena los 18 contratos desde la carpeta ``etapas/``."""
    dir_ = Path(dir_etapas)
    res: list[Etapa] = []
    for n in IDS:
        coinc = sorted(dir_.glob(f"{n}-*.md"))
        if not coinc:
            raise FileNotFoundError(f"falta el contrato {n}-*.md")
        e = parsear(coinc[0].read_text(encoding="utf-8"))
        if not e.id:
            e.id = n
        res.append(e)
    return res


def buscar(plan: list[Etapa], etapa: str, paso: str, idx: int) -> tuple[Etapa, Paso, str]:
    """Busca un bloque ejecutable por identificador y valida que se pueda correr."""
    for e in plan:
        if e.id != etapa:
            continue
        for p in e.pasos:
            if p.num != paso:
                continue
            if p.clase == "HUMANO":
                raise ValueError("este paso es [HUMANO]: lo resuelve su asistente o panel en la app")
            if p.clase not in ("AUTO", "MIXTO", "ENTORNO", "INFO"):
                raise ValueError("clase de paso desconocida")
            if p.ubicacion == "LOCAL":
                raise ValueError("este paso se hace en tu computadora ([LOCAL]), no en el VPS")
            if idx < 0 or idx >= len(p.bloques):
                raise ValueError("el bloque no existe en el contrato")
            b = p.bloques[idx]
            if b.tipo == "rollback":
                raise ValueError("este bloque es un rollback: no se ejecuta desde la guía (revisa el contrato)")
            if b.parametros:
                raise ValueError("este bloque lleva marcadores <así> que se completan con datos tuyos: usa el panel correspondiente de la app")
            return e, p, b.comando
    raise ValueError("el paso no existe en el contrato")
