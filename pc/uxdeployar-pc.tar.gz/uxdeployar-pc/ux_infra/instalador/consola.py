"""Diálogo en la terminal: preguntas con validación, secretos ocultos y confirmaciones.

Las funciones de entrada y salida se inyectan para poder probar el flujo sin terminal.
"""

from __future__ import annotations

import getpass
import sys
from typing import Callable

Validador = Callable[[str], str]


def _escribir(texto: str) -> None:
    print(texto, flush=True)


def _salida_en_vivo(texto: str) -> None:
    sys.stdout.write(texto)
    sys.stdout.flush()


class Consola:
    def __init__(
        self,
        entrada: Callable[[str], str] = input,
        salida: Callable[[str], None] = _escribir,
        secreto: Callable[[str], str] = getpass.getpass,
        en_vivo: Callable[[str], None] = _salida_en_vivo,
    ) -> None:
        self._entrada = entrada
        self._salida = salida
        self._secreto = secreto
        self.en_vivo = en_vivo

    # -- salida -------------------------------------------------------------

    def titulo(self, texto: str) -> None:
        self._salida(f"\n══ {texto}")

    def info(self, texto: str) -> None:
        self._salida(f"   {texto}")

    def ok(self, texto: str) -> None:
        self._salida(f"✔  {texto}")

    def aviso(self, texto: str) -> None:
        self._salida(f"!  {texto}")

    def error(self, texto: str) -> None:
        self._salida(f"✖  {texto}")

    # -- entrada ------------------------------------------------------------

    def preguntar(self, texto: str, defecto: str = "", validar: Validador | None = None) -> str:
        """Repite la pregunta hasta que la respuesta pase ``validar`` (que la normaliza)."""
        sufijo = f" [{defecto}]" if defecto else ""
        while True:
            respuesta = self._entrada(f"?  {texto}{sufijo}: ").strip() or defecto
            if not respuesta:
                self.error("hace falta una respuesta")
                continue
            if validar is None:
                return respuesta
            try:
                return validar(respuesta)
            except ValueError as exc:
                self.error(str(exc))

    def secreto(self, texto: str, validar: Validador | None = None) -> str:
        """Lee sin eco; el valor no se imprime nunca."""
        while True:
            valor = self._secreto(f"?  {texto}: ").strip()
            if not valor:
                self.error("hace falta un valor")
                continue
            if validar is None:
                return valor
            try:
                return validar(valor)
            except ValueError as exc:
                self.error(str(exc))

    def confirmar(self, texto: str, defecto: bool = True) -> bool:
        marca = "S/n" if defecto else "s/N"
        while True:
            try:
                r = self._entrada(f"?  {texto} [{marca}]: ").strip().lower()
            except EOFError:  # sin terminal (p. ej. --yes en un script): nunca se asume un sí
                self._salida("")
                return False
            if not r:
                return defecto
            if r in ("s", "si", "sí", "y", "yes"):
                return True
            if r in ("n", "no"):
                return False
            self.error("responde s o n")

    def elegir(self, texto: str, opciones: list[tuple[str, str]], defecto: str) -> str:
        """``opciones`` = [(clave, descripción)]; devuelve la clave elegida."""
        self._salida(f"?  {texto}")
        for i, (clave, descripcion) in enumerate(opciones, start=1):
            marca = " (por defecto)" if clave == defecto else ""
            self._salida(f"     {i}. {descripcion}{marca}")
        claves = [c for c, _ in opciones]
        while True:
            r = self._entrada("   número: ").strip()
            if not r:
                return defecto
            if r.isdigit() and 1 <= int(r) <= len(opciones):
                return claves[int(r) - 1]
            if r in claves:
                return r
            self.error(f"elige un número entre 1 y {len(opciones)}")

    def pausa(self, texto: str) -> None:
        self._entrada(f"?  {texto} (Intro para seguir) ")
