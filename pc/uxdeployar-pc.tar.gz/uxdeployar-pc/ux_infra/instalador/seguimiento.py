"""Lanza ``install.sh`` en el VPS y sigue la instalación hasta el final.

La instalación corre como servicio en el VPS y sobrevive a los cortes; aquí solo
se mira. Cuando la sesión se corta (reinicios de E01/E08/E09, cierre del puerto 22
en E03) se espera 33–45 s, porque ``ufw limit`` y fail2ban castigan las ráfagas, y
se reconecta: primero al administrador por el puerto nuevo con la llave, si no a
root por el 22.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Callable

from .. import ssh, util
from . import ErrorInstalador
from .conexion import Destino, conectar
from .consola import Consola

ARCHIVO_ESTADO = "/var/lib/ux/instalador/estado"
RUTA_INSTALL = "/root/uxdeployar-install.sh"
RUTA_LLAVE_ADMIN = "/root/uxdeployar-admin.pub"
RUTA_RAIZ_ACME = "/root/uxdeployar-acme-raiz.pem"
SEGUIR = "uxdeployar logs --hasta-terminar"
PAUSA_S = (33.0, 45.0)
MAX_RECONEXIONES = 45


@dataclass
class Opciones:
    panel: str
    api: str
    correo: str
    puerto_ssh: int = 2222
    usuario_admin: str = "vpsadmin"
    version: str = ""
    token: str = ""
    release_url: str = ""
    release_repo: str = ""
    acme_ca: str = ""
    raiz_acme_pem: str = ""
    ip_publica: str = ""
    registro: str = ""


def argumentos_install(op: Opciones) -> list[str]:
    args = [
        "--panel-domain", op.panel,
        "--api-domain", op.api,
        "--acme-email", op.correo,
        "--ssh-port", str(op.puerto_ssh),
        "--admin-user", op.usuario_admin,
        "--ssh-key", RUTA_LLAVE_ADMIN,
    ]  # fmt: skip
    if op.version:
        args += ["--version", op.version]
    if op.token:
        args += ["--token-file", "-"]
    if op.ip_publica:
        args += ["--public-ip", op.ip_publica]
    if op.release_url:
        args += ["--release-url", op.release_url]
    if op.release_repo:
        args += ["--release-repo", op.release_repo]
    if op.registro:
        args += ["--registry", op.registro]
    if op.acme_ca:
        args += ["--acme-ca", op.acme_ca]
    if op.raiz_acme_pem:
        args += ["--acme-ca-root", RUTA_RAIZ_ACME]
    return args + ["--yes"]


def leer_estado(cli: ssh.Cliente) -> str:
    """Primera palabra del estado de la instalación: en-curso, completada, fallida o sin-instalar."""
    r = cli.ejecutar(f"cat {ARCHIVO_ESTADO} 2>/dev/null || echo sin-instalar")
    return (r.stdout.split() or ["sin-instalar"])[0]


def lanzar(cli: ssh.Cliente, consola: Consola, install_sh: str, llave_publica: str, op: Opciones) -> bool:
    """Sube lo necesario y ejecuta install.sh siguiendo su salida.

    Devuelve True si la sesión siguió hasta el final y False si se cortó. Un fallo
    antes de arrancar el servicio (DNS, sistema, release) lanza ``ErrorInstalador``.
    """
    cli.escribir_archivo(RUTA_INSTALL, "700", install_sh)
    cli.escribir_archivo(RUTA_LLAVE_ADMIN, "644", llave_publica.strip() + "\n")
    if op.raiz_acme_pem:
        cli.escribir_archivo(RUTA_RAIZ_ACME, "644", op.raiz_acme_pem)
    comando = "bash " + RUTA_INSTALL + " " + " ".join(util.comillas(a) for a in argumentos_install(op))
    try:
        r = cli.ejecutar(comando, stdin=(op.token + "\n") if op.token else None, salida=consola.en_vivo)
        estado = leer_estado(cli) if r.codigo != 0 else ""
    except ssh.ErrorRed:
        return False
    if estado == "sin-instalar":
        detalle = (r.stderr.strip().splitlines() or ["install.sh falló"])[-1]
        raise ErrorInstalador(detalle)
    return True


class Reconectador:
    """Vuelve a entrar al VPS tras un corte, sin ráfagas que active fail2ban."""

    def __init__(
        self,
        admin: Destino,
        root: Destino,
        *,
        abrir: Callable[[Destino], ssh.Cliente] = conectar,
        dormir: Callable[[float], None] = time.sleep,
        pausa: Callable[[], float] = lambda: random.uniform(*PAUSA_S),
        max_intentos: int = MAX_RECONEXIONES,
    ) -> None:
        self.admin = admin
        self.root = root
        self._abrir = abrir
        self._dormir = dormir
        self._pausa = pausa
        self._max = max_intentos

    def abrir(self, consola: Consola) -> tuple[ssh.Cliente, bool]:
        """Devuelve (cliente, es_root)."""
        for _ in range(self._max):
            self._dormir(self._pausa())
            for destino in (self.admin, self.root):
                try:
                    cli = self._abrir(destino)
                except ssh.ErrorHuellaAnclada as exc:
                    raise ErrorInstalador(f"{exc}: no continúo") from exc
                except (ssh.ErrorRed, ssh.ErrorAuth):
                    continue
                consola.ok(f"reconectado como {destino.usuario} (puerto {destino.puerto})")
                return cli, destino is self.root
            consola.info("el VPS aún no responde; sigo esperando…")
        raise ErrorInstalador(
            "no pude volver a conectar con el VPS. La instalación sigue sola en el servidor: "
            "vuelve a ejecutar este programa más tarde para ver cómo acabó."
        )


def seguir(
    consola: Consola, reconectador: Reconectador, cli: ssh.Cliente | None, es_root: bool = True
) -> tuple[str, ssh.Cliente, bool]:
    """Sigue el registro hasta que la instalación termina; devuelve (estado, cliente, es_root)."""
    while True:
        if cli is None:
            consola.aviso("se cortó la conexión (normal: el VPS se reinicia o cambia el puerto SSH)")
            cli, es_root = reconectador.abrir(consola)
        try:
            estado = leer_estado(cli)
            if estado not in ("completada", "fallida"):
                cli.ejecutar(SEGUIR, salida=consola.en_vivo)
                estado = leer_estado(cli)
            if estado in ("completada", "fallida"):
                return estado, cli, es_root
        except ssh.ErrorRed:
            cli.cerrar()
            cli = None


def reanudar(cli: ssh.Cliente, consola: Consola, es_root: bool, sudo: str) -> None:
    """``uxdeployar resume`` sigue el registro él mismo; si se corta, lo retoma ``seguir``."""
    try:
        if es_root:
            cli.ejecutar("uxdeployar resume", salida=consola.en_vivo)
        else:
            cli.ejecutar_sudo("uxdeployar resume", sudo, salida=consola.en_vivo)
    except ssh.ErrorRed:
        pass
