"""Prueba desde el PC que los puertos que necesita la instalación llegan al VPS.

Abre escuchas temporales en el VPS (python3, sin instalar nada más) y se conecta a
cada una desde aquí. Así se detecta antes de instalar un firewall del proveedor
que bloquea 80/443 (Let's Encrypt) o el puerto SSH nuevo (tras E03 el 22 se cierra).
"""

from __future__ import annotations

import socket
import threading
from typing import Callable

from .. import ssh
from . import ErrorInstalador

ESPERA_LISTO_S = 30.0
TIMEOUT_CONEXION_S = 6.0

PREPARAR_PYTHON = (
    "command -v python3 >/dev/null || "
    "{ DEBIAN_FRONTEND=noninteractive apt-get update -qq && "
    "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 >/dev/null; }"
)

# Escucha en los puertos de argv; responde «ux» a cada conexión y termina cuando
# todos recibieron una o a los 60 s. Imprime OCUPADO <p> si alguno ya está en uso.
SCRIPT_ESCUCHA = r"""
import select, socket, sys, time
puertos = [int(p) for p in sys.argv[1:]]
abiertos = {}
for p in puertos:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("0.0.0.0", p))
    except OSError:
        print("OCUPADO", p, flush=True)
        continue
    s.listen(4)
    abiertos[s] = p
print("LISTO", flush=True)
pendientes = set(abiertos.values())
fin = time.time() + 60
while pendientes and time.time() < fin:
    listos, _, _ = select.select(list(abiertos), [], [], 1)
    for s in listos:
        c, _ = s.accept()
        c.sendall(b"ux\n")
        c.close()
        pendientes.discard(abiertos[s])
"""

Conector = Callable[[tuple[str, int], float], socket.socket]


def _responde(host: str, puerto: int, conectar: Conector) -> bool:
    try:
        with conectar((host, puerto), TIMEOUT_CONEXION_S) as s:
            s.settimeout(TIMEOUT_CONEXION_S)
            return s.recv(8).startswith(b"ux")
    except OSError:
        return False


def probar(
    cli: ssh.Cliente,
    host: str,
    puertos: list[int],
    conectar: Conector = socket.create_connection,
) -> list[int]:
    """Devuelve los puertos que no llegan desde aquí (vacío = todo bien)."""
    r = cli.ejecutar(f"bash -c '{PREPARAR_PYTHON}'")
    if r.codigo != 0:
        raise ErrorInstalador("no pude preparar python3 en el VPS para probar los puertos")

    salida: list[str] = []
    listo = threading.Event()

    def recibir(texto: str) -> None:
        salida.append(texto)
        if "LISTO" in "".join(salida):
            listo.set()

    hilo = threading.Thread(
        target=lambda: cli.ejecutar(
            "python3 - " + " ".join(str(p) for p in puertos), stdin=SCRIPT_ESCUCHA, salida=recibir
        ),
        daemon=True,
    )
    hilo.start()
    if not listo.wait(ESPERA_LISTO_S):
        raise ErrorInstalador("las escuchas de prueba no arrancaron en el VPS")
    ocupados = [int(l.split()[1]) for l in "".join(salida).splitlines() if l.startswith("OCUPADO")]
    if ocupados:
        raise ErrorInstalador(
            "puertos ya en uso por otro servicio en el VPS: "
            + ", ".join(map(str, ocupados))
            + ". La instalación necesita un VPS recién instalado."
        )
    fallidos = [p for p in puertos if not _responde(host, p, conectar)]
    if not fallidos:
        hilo.join(timeout=10)
    return fallidos


def explicar_bloqueo(fallidos: list[int]) -> str:
    lista = ", ".join(f"TCP {p}" for p in fallidos)
    return (
        f"No llegan desde aquí: {lista}. Ábrelos de entrada en el firewall de tu proveedor "
        "(Hetzner: Firewalls; OVH: Edge Network Firewall; AWS: Security groups; "
        "DigitalOcean: Cloud Firewalls; Oracle: Security lists) y vuelve a probar."
    )
