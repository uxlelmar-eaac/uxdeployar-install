"""Consultas DNS por UDP directas a un servidor (biblioteca estándar).

Preguntar a los NS autoritativos de la zona dice si el registro ya existe sin
pasar por ninguna caché, y sin dejar en 1.1.1.1 u 8.8.8.8 un «no existe»
guardado que retrasaría la propagación. Solo A, AAAA y NS, que es lo que usa
el instalador.
"""

from __future__ import annotations

import ipaddress
import os
import socket
import struct
from typing import Callable

TIPOS = {"A": 1, "NS": 2, "AAAA": 28}

# (paquete, ip, timeout) → respuesta; inyectable para probar sin red.
Transporte = Callable[[bytes, str, float], bytes]


def _udp(paquete: bytes, ip: str, timeout: float) -> bytes:
    familia = socket.AF_INET6 if ":" in ip else socket.AF_INET
    with socket.socket(familia, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        s.sendto(paquete, (ip, 53))
        return s.recv(4096)


def _nombre_a_bytes(nombre: str) -> bytes:
    salida = b""
    for etiqueta in nombre.rstrip(".").split("."):
        datos = etiqueta.encode("idna")
        salida += bytes([len(datos)]) + datos
    return salida + b"\x00"


def construir_consulta(nombre: str, tipo: str, ident: int) -> bytes:
    # Sin recursión (RD=0): al autoritativo solo se le pregunta por su zona.
    cabecera = struct.pack(">HHHHHH", ident, 0x0000, 1, 0, 0, 0)
    return cabecera + _nombre_a_bytes(nombre) + struct.pack(">HH", TIPOS[tipo], 1)


def _leer_nombre(datos: bytes, pos: int) -> tuple[str, int]:
    etiquetas: list[str] = []
    fin = -1
    saltos = 0
    while True:
        largo = datos[pos]
        if largo & 0xC0 == 0xC0:
            if fin < 0:
                fin = pos + 2
            pos = ((largo & 0x3F) << 8) | datos[pos + 1]
            saltos += 1
            if saltos > 32:
                raise ValueError("compresión en bucle")
            continue
        if largo == 0:
            return ".".join(etiquetas).lower(), (fin if fin >= 0 else pos + 1)
        etiquetas.append(datos[pos + 1 : pos + 1 + largo].decode("ascii", "replace"))
        pos += 1 + largo


def interpretar_respuesta(datos: bytes, tipo: str, ident: int) -> list[str]:
    """Respuestas de ``tipo`` en la sección de respuesta; error si el paquete no es el esperado."""
    rid, banderas, qd, an, _ns, _ar = struct.unpack(">HHHHHH", datos[:12])
    if rid != ident or not banderas & 0x8000:
        raise ValueError("respuesta DNS que no corresponde a la consulta")
    rcode = banderas & 0x000F
    if rcode == 3:  # NXDOMAIN: el nombre no existe todavía
        return []
    if rcode != 0:
        raise ValueError(f"el servidor DNS respondió con error {rcode}")
    pos = 12
    for _ in range(qd):
        _, pos = _leer_nombre(datos, pos)
        pos += 4
    codigo = TIPOS[tipo]
    salida: set[str] = set()
    for _ in range(an):
        _, pos = _leer_nombre(datos, pos)
        rtipo, _clase, _ttl, largo = struct.unpack(">HHIH", datos[pos : pos + 10])
        pos += 10
        rdata = datos[pos : pos + largo]
        if rtipo == codigo == 1 and largo == 4:
            salida.add(str(ipaddress.IPv4Address(rdata)))
        elif rtipo == codigo == 28 and largo == 16:
            salida.add(str(ipaddress.IPv6Address(rdata)))
        elif rtipo == codigo == 2:
            salida.add(_leer_nombre(datos, pos)[0])
        pos += largo
    return sorted(salida)


def consultar(
    nombre: str, tipo: str, ip: str, *, timeout: float = 3.0, transporte: Transporte = _udp
) -> list[str] | None:
    """Respuestas (vacío = no existe aún); ``None`` si el servidor no contestó."""
    ident = struct.unpack(">H", os.urandom(2))[0]
    try:
        datos = transporte(construir_consulta(nombre, tipo, ident), ip, timeout)
        return interpretar_respuesta(datos, tipo, ident)
    except (OSError, ValueError, IndexError, struct.error):
        return None


def ip_de(servidor: str, resolver: Callable[[str], str] = socket.gethostbyname) -> str:
    """IPv4 de un NS por su nombre (con el resolvedor del sistema); vacío si no se puede."""
    try:
        return resolver(servidor)
    except OSError:
        return ""
