"""DNS del panel y la API: registro de proveedores y espera hasta que resuelvan.

Cada proveedor es un módulo con una clase ``Proveedor`` que sabe ``detectar``
(por los NS de la zona) y ``aplicar`` los registros; ``pendientes`` es común (DoH).
Añadir otro proveedor es un archivo más y una entrada en ``PROVEEDORES``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Protocol

from ..consola import Consola
from . import doh


@dataclass(frozen=True)
class Registro:
    tipo: str  # "A" o "AAAA"
    nombre: str
    contenido: str


class Proveedor(Protocol):
    clave: str
    descripcion: str

    def detectar(self, servidores_ns: list[str]) -> bool: ...

    def aplicar(self, consola: Consola, registros: list[Registro]) -> None: ...


def registros_para(dominios: list[str], ipv4: str, ipv6: str = "") -> list[Registro]:
    registros = [Registro("A", d, ipv4) for d in dominios]
    if ipv6:
        registros += [Registro("AAAA", d, ipv6) for d in dominios]
    return registros


def pendientes(registros: list[Registro], http: doh.Http = doh._http_json) -> list[Registro]:
    return [r for r in registros if not doh.resuelve_en_todos(r.nombre, r.tipo, r.contenido, http)]


def proveedores() -> dict[str, Proveedor]:
    from . import cloudflare, manual

    return {p.clave: p for p in (cloudflare.Proveedor(), manual.Proveedor())}


def elegir(consola: Consola, dominio: str, forzado: str = "", http: doh.Http = doh._http_json) -> Proveedor:
    """El indicado con ``--dns``, el detectado por los NS, o el que elija la persona."""
    todos = proveedores()
    if forzado:
        return todos[forzado]
    ns = doh.servidores_de_nombres(dominio, http)
    for p in todos.values():
        if p.clave != "manual" and p.detectar(ns):
            consola.ok(f"la zona de {dominio} está en {p.descripcion} ({', '.join(ns[:2])})")
            return p
    if ns:
        consola.info(f"servidores de nombres de {dominio}: {', '.join(ns)}")
    clave = consola.elegir(
        "¿Dónde gestionas el DNS de ese dominio?",
        [(p.clave, p.descripcion) for p in todos.values()],
        "manual",
    )
    return todos[clave]


def esperar(
    consola: Consola,
    registros: list[Registro],
    *,
    limite_s: float = 1800,
    intervalo_s: float = 15,
    http: doh.Http = doh._http_json,
    dormir: Callable[[float], None] = time.sleep,
    reloj: Callable[[], float] = time.monotonic,
) -> None:
    """Sondea 1.1.1.1 y 8.8.8.8 hasta que todos los registros resuelven."""
    fin = reloj() + limite_s
    while True:
        faltan = pendientes(registros, http)
        if not faltan:
            consola.ok("el DNS ya resuelve en 1.1.1.1 y 8.8.8.8")
            return
        if reloj() >= fin:
            lista = ", ".join(f"{r.nombre} {r.tipo} → {r.contenido}" for r in faltan)
            raise TimeoutError(f"el DNS no propagó a tiempo: {lista}")
        consola.info("esperando a que propague: " + ", ".join(r.nombre for r in faltan))
        dormir(intervalo_s)
