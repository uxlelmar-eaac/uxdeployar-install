"""DNS del panel y la API: registro de proveedores y espera hasta que resuelvan.

Cada proveedor es un módulo con una clase ``Proveedor`` que sabe ``detectar``
(por los NS de la zona) y ``aplicar`` los registros. La espera pregunta a los NS
autoritativos de la zona (``directo``): no tienen caché, así que en cuanto
responden con el VPS se avanza; 1.1.1.1 y 8.8.8.8 (DoH) solo informan. Añadir
otro proveedor es un archivo más y una entrada en ``PROVEEDORES``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Protocol

from ..consola import Consola
from . import directo, doh

URL_VACIAR_GOOGLE = "https://dns.google/cache"
URL_VACIAR_CLOUDFLARE = "https://one.one.one.one/purge-cache/"


@dataclass(frozen=True)
class Registro:
    tipo: str  # "A" o "AAAA"
    nombre: str
    contenido: str


class Proveedor(Protocol):
    clave: str
    descripcion: str

    def detectar(self, servidores_ns: list[str]) -> bool: ...

    def aplicar(self, consola: Consola, registros: list[Registro]) -> None: ...


# (nombre del NS, su IP)
Autoritativo = tuple[str, str]


def registros_para(dominios: list[str], ipv4: str, ipv6: str = "") -> list[Registro]:
    registros = [Registro("A", d, ipv4) for d in dominios]
    if ipv6:
        registros += [Registro("AAAA", d, ipv6) for d in dominios]
    return registros


def pendientes(registros: list[Registro], http: doh.Http = doh._http_json) -> list[Registro]:
    return [r for r in registros if not doh.resuelve_en_todos(r.nombre, r.tipo, r.contenido, http)]


def autoritativos(
    dominio: str, http: doh.Http = doh._http_json, ip_de: Callable[[str], str] = directo.ip_de
) -> list[Autoritativo]:
    """NS de la zona de ``dominio`` con su IP (los que no se resuelven se omiten)."""
    return [(ns, ip) for ns in doh.servidores_de_nombres(dominio, http) if (ip := ip_de(ns))]


def faltan_en_autoritativos(
    registros: list[Registro], servidores: list[Autoritativo], transporte: directo.Transporte = directo._udp
) -> list[tuple[Registro, str]] | None:
    """(registro, NS) que aún no responden con el valor esperado; ``None`` si ningún NS contestó."""
    faltan: list[tuple[Registro, str]] = []
    alguno = False
    for r in registros:
        for nombre, ip in servidores:
            respuesta = directo.consultar(r.nombre, r.tipo, ip, transporte=transporte)
            if respuesta is None:
                faltan.append((r, nombre))
                continue
            alguno = True
            if respuesta != [r.contenido.lower()]:
                faltan.append((r, nombre))
    return faltan if alguno else None


def proveedores() -> dict[str, Proveedor]:
    from . import cloudflare, manual

    return {p.clave: p for p in (cloudflare.Proveedor(), manual.Proveedor())}


def elegir(consola: Consola, dominio: str, forzado: str = "", http: doh.Http = doh._http_json) -> Proveedor:
    """El indicado con ``--dns``, el detectado por los NS, o el que elija la persona."""
    todos = proveedores()
    if forzado:
        return todos[forzado]
    ns = doh.servidores_de_nombres(dominio, http)
    for p in todos.values():
        if p.clave != "manual" and p.detectar(ns):
            consola.ok(f"la zona de {dominio} está en {p.descripcion} ({', '.join(ns[:2])})")
            return p
    if ns:
        consola.info(f"servidores de nombres de {dominio}: {', '.join(ns)}")
    clave = consola.elegir(
        "¿Dónde gestionas el DNS de ese dominio?",
        [(p.clave, p.descripcion) for p in todos.values()],
        "manual",
    )
    return todos[clave]


def _informar_publicos(consola: Consola, registros: list[Registro], http: doh.Http) -> None:
    """Solo informa: un resolvedor público atrasado es su caché y se pone al día solo."""
    for r in registros:
        esperado = [r.contenido.lower()]
        atrasados = [n for n, url in doh.RESOLVEDORES.items() if doh.resolver(r.nombre, r.tipo, url, http) != esperado]
        if atrasados:
            consola.aviso(
                f"{', '.join(atrasados)} aún no ve {r.nombre} {r.tipo} (es su caché; se pondrá al día solo). "
                f"Para acelerarlo, vacíala escribiendo {r.nombre}: Google {URL_VACIAR_GOOGLE} · "
                f"Cloudflare {URL_VACIAR_CLOUDFLARE}"
            )


def _reloj_texto(segundos: float) -> str:
    s = int(segundos)
    return f"{s // 60:02d}:{s % 60:02d}"


def esperar(
    consola: Consola,
    registros: list[Registro],
    *,
    servidores: list[Autoritativo] | None = None,
    limite_s: float = 1800,
    intervalo_s: float = 15,
    http: doh.Http = doh._http_json,
    transporte: directo.Transporte = directo._udp,
    dormir: Callable[[float], None] = time.sleep,
    reloj: Callable[[], float] = time.monotonic,
) -> None:
    """Espera a que los NS autoritativos respondan con el VPS (o, sin ellos, 1.1.1.1 y 8.8.8.8)."""
    inicio = reloj()
    fin = inicio + limite_s
    en_linea = False
    while True:
        directos = faltan_en_autoritativos(registros, servidores, transporte) if servidores else None
        if directos is None:
            faltan = [(r, "1.1.1.1 y 8.8.8.8") for r in pendientes(registros, http)]
        else:
            faltan = directos
        if not faltan:
            if en_linea:
                consola.en_vivo("\n")
            if directos is None:
                consola.ok("el DNS ya resuelve en 1.1.1.1 y 8.8.8.8")
            else:
                consola.ok("los servidores de nombres de la zona ya responden con este VPS")
                _informar_publicos(consola, registros, http)
            return
        if reloj() >= fin:
            if en_linea:
                consola.en_vivo("\n")
            lista = ", ".join(f"{r.nombre} {r.tipo} → {r.contenido} ({donde})" for r, donde in faltan)
            raise TimeoutError(f"el DNS no propagó a tiempo: {lista}")
        r, donde = faltan[0]
        consola.en_vivo(
            f"\r   esperando {r.nombre} {r.tipo} en {donde} · {_reloj_texto(reloj() - inicio)}"
            f"{f' (+{len(faltan) - 1} más)' if len(faltan) > 1 else ''}   "
        )
        en_linea = True
        dormir(intervalo_s)
