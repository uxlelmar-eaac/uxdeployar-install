"""Proveedor manual: muestra la tabla exacta de registros para crearlos a mano."""

from __future__ import annotations

from ..consola import Consola


class Proveedor:
    clave = "manual"
    descripcion = "Otro proveedor (te muestro los registros y los creas tú)"

    def detectar(self, servidores_ns: list[str]) -> bool:
        return False

    def aplicar(self, consola: Consola, registros) -> None:
        consola.info("Crea estos registros en el panel DNS de tu proveedor (sin proxy ni CDN):")
        consola.info(f"{'Tipo':<6}{'Nombre':<40}Valor")
        for r in registros:
            consola.info(f"{r.tipo:<6}{r.nombre:<40}{r.contenido}")
        consola.info("Si ya existen con otro valor, cámbialos. Borra los AAAA de esos nombres si no usas IPv6.")
        consola.pausa("Cuando los hayas guardado")
