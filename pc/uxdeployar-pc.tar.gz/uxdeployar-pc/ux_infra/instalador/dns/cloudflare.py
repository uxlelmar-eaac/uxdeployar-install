"""Proveedor Cloudflare: crea los registros por la API con un token solo de DNS.

El token se pide oculto, se comprueba con ``/user/tokens/verify`` y con la zona
del dominio, y vive solo en memoria. Un AAAA que apunte a otro sitio rompe
Let's Encrypt (prefiere IPv6), así que se avisa y se ofrece borrarlo.
"""

from __future__ import annotations

import json
import urllib.parse
import webbrowser
from typing import Callable

from ... import cloudflare as cf
from .. import ErrorInstalador
from ..consola import Consola

_PERMISOS = [{"key": "zone", "type": "read"}, {"key": "dns", "type": "edit"}]

# Plantilla de token de usuario prellenada (Zone:Read + DNS:Edit, todas las zonas).
URL_TOKENS = "https://dash.cloudflare.com/profile/api-tokens?" + urllib.parse.urlencode(
    {
        "permissionGroupKeys": json.dumps(_PERMISOS, separators=(",", ":")),
        "accountId": "*",
        "zoneId": "all",
        "name": "uxdeployar-dns",
    }
)

CANCELAR = ("cancelar", "salir")


class Proveedor:
    clave = "cloudflare"
    descripcion = "Cloudflare (creo los registros por ti con un token)"

    def __init__(
        self,
        cliente: Callable[[str], cf.Cliente] = cf.Cliente,
        abrir: Callable[[str], object] = webbrowser.open,
    ) -> None:
        self._cliente = cliente
        self._abrir = abrir

    def detectar(self, servidores_ns: list[str]) -> bool:
        return bool(servidores_ns) and all(n.endswith(".ns.cloudflare.com") for n in servidores_ns)

    def _pedir_cliente(self, consola: Consola, dominio: str) -> cf.Cliente:
        consola.info("Crea un token de Cloudflare con esta plantilla (ya trae los permisos «Zone: Read» y «DNS: Edit»):")
        consola.info(URL_TOKENS)
        consola.info("  En «Zone Resources» deja «All zones» o elige la zona de tu dominio → «Continue» → «Create Token».")
        if consola.confirmar("¿Abro la página en el navegador?"):
            self._abrir(URL_TOKENS)
        while True:
            token = consola.secreto("Token de Cloudflare (no se muestra; escribe «cancelar» para salir)")
            if token.lower() in CANCELAR:
                raise ErrorInstalador("cancelado: no se creó ningún registro DNS")
            cliente = self._cliente(token)
            try:
                cliente.verificar_token_dns()
            except cf.Error as exc:
                consola.error(str(exc))
                continue
            try:
                cliente.zona(dominio)
                return cliente
            except cf.Error:
                consola.error(
                    f"el token es válido pero no ve la zona de {dominio}: al crearlo, en «Zone Resources» "
                    "elige «All zones» o esa zona, y comprueba que tenga «Zone: Read» y «DNS: Edit»."
                )

    def aplicar(self, consola: Consola, registros) -> None:
        cliente = self._pedir_cliente(consola, registros[0].nombre)
        try:
            self._crear(consola, cliente, registros)
        except cf.Error as exc:
            raise ErrorInstalador(f"no se pudo crear el registro DNS. {exc}") from None

    def _crear(self, consola: Consola, cliente: cf.Cliente, registros) -> None:
        tipos_por_nombre: dict[str, set[str]] = {}
        for r in registros:
            tipos_por_nombre.setdefault(r.nombre, set()).add(r.tipo)
            estado = cliente.registro(r.tipo, r.nombre, r.contenido)
            consola.ok(f"{r.tipo} {r.nombre} → {r.contenido}: {estado}")
        for nombre, tipos in tipos_por_nombre.items():
            if "AAAA" in tipos:
                continue
            for viejo in cliente.registros("AAAA", nombre):
                consola.aviso(
                    f"{nombre} tiene un AAAA ({viejo.get('content')}) que no es de este VPS: "
                    "Let's Encrypt lo usaría y fallaría."
                )
                if consola.confirmar("¿Lo borro?"):
                    cliente.borrar_registro(nombre, viejo["id"])
                    consola.ok(f"AAAA de {nombre} borrado")
