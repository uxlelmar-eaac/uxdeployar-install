"""Proveedor Cloudflare: crea los registros por la API con un token solo de DNS.

El token se pide oculto, se comprueba con ``/user/tokens/verify`` y vive solo en
memoria. Un AAAA que apunte a otro sitio rompe Let's Encrypt (prefiere IPv6), así
que se avisa y se ofrece borrarlo.
"""

from __future__ import annotations

from typing import Callable

from ... import cloudflare as cf
from ..consola import Consola

URL_TOKENS = "https://dash.cloudflare.com/profile/api-tokens"


class Proveedor:
    clave = "cloudflare"
    descripcion = "Cloudflare (creo los registros por ti con un token)"

    def __init__(self, cliente: Callable[[str], cf.Cliente] = cf.Cliente) -> None:
        self._cliente = cliente

    def detectar(self, servidores_ns: list[str]) -> bool:
        return bool(servidores_ns) and all(n.endswith(".ns.cloudflare.com") for n in servidores_ns)

    def _pedir_cliente(self, consola: Consola) -> cf.Cliente:
        consola.info(f"Crea un token en {URL_TOKENS}")
        consola.info("  «Create Token» → plantilla «Edit zone DNS» → Zone Resources: tu dominio → «Create».")
        while True:
            cliente = self._cliente(consola.secreto("Token de Cloudflare (no se muestra)"))
            try:
                cliente.verificar_token_dns()
                return cliente
            except cf.Error as exc:
                consola.error(str(exc))

    def aplicar(self, consola: Consola, registros) -> None:
        cliente = self._pedir_cliente(consola)
        tipos_por_nombre: dict[str, set[str]] = {}
        for r in registros:
            tipos_por_nombre.setdefault(r.nombre, set()).add(r.tipo)
            estado = cliente.registro(r.tipo, r.nombre, r.contenido)
            consola.ok(f"{r.tipo} {r.nombre} → {r.contenido}: {estado}")
        for nombre, tipos in tipos_por_nombre.items():
            if "AAAA" in tipos:
                continue
            for viejo in cliente.registros("AAAA", nombre):
                consola.aviso(
                    f"{nombre} tiene un AAAA ({viejo.get('content')}) que no es de este VPS: "
                    "Let's Encrypt lo usaría y fallaría."
                )
                if consola.confirmar("¿Lo borro?"):
                    cliente.borrar_registro(nombre, viejo["id"])
                    consola.ok(f"AAAA de {nombre} borrado")
