"""Consultas DNS por HTTPS (DoH, formato JSON) contra 1.1.1.1 y 8.8.8.8.

No depende del resolvedor del PC (caché, VPN, DNS de la oficina): mira lo que ve
Internet, que es lo que verá Let's Encrypt.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Callable

RESOLVEDORES = {
    "1.1.1.1": "https://cloudflare-dns.com/dns-query",
    "8.8.8.8": "https://dns.google/resolve",
}
TIPOS = {"A": 1, "NS": 2, "AAAA": 28}

Http = Callable[[str], dict]


def _http_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"Accept": "application/dns-json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read(1 << 20))


def resolver(nombre: str, tipo: str, url_base: str, http: Http = _http_json) -> list[str]:
    """Respuestas de ese tipo (sin barras finales); vacío si no hay o si el resolvedor falla."""
    consulta = urllib.parse.urlencode({"name": nombre, "type": tipo})
    try:
        datos = http(f"{url_base}?{consulta}")
    except (OSError, ValueError):
        return []
    codigo = TIPOS[tipo]
    return sorted(
        {r.get("data", "").rstrip(".").lower() for r in datos.get("Answer", []) if r.get("type") == codigo}
    )


def resuelve_en_todos(nombre: str, tipo: str, esperado: str, http: Http = _http_json) -> bool:
    """El nombre devuelve exactamente ``esperado`` en los dos resolvedores."""
    return all(resolver(nombre, tipo, url, http) == [esperado.lower()] for url in RESOLVEDORES.values())


def servidores_de_nombres(dominio: str, http: Http = _http_json) -> list[str]:
    """NS de la zona que contiene ``dominio``, empezando por su zona padre.

    No se pregunta por el nombre completo: aún no existe, y un «no existe» en la
    caché de 1.1.1.1 retrasaría la propagación cuando se cree.
    """
    partes = dominio.rstrip(".").lower().split(".")
    url = RESOLVEDORES["1.1.1.1"]
    for i in range(1 if len(partes) > 2 else 0, len(partes) - 1):
        ns = resolver(".".join(partes[i:]), "NS", url, http)
        if ns:
            return ns
    return []
