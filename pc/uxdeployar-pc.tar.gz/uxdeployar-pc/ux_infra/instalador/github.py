"""GitHub: ¿hace falta token para descargar el release?, validación del token e ``install.sh``.

El token va solo en la cabecera ``Authorization`` de las peticiones a la API de
GitHub; nunca en la URL ni en argumentos.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

from . import ErrorInstalador

API = "https://api.github.com"
REPO_RELEASES = "uxlelmar-eaac/uxdeployar-backend"
URL_INSTALL_SH = "https://raw.githubusercontent.com/uxlelmar-eaac/uxdeployar-install/main/install.sh"
TOKEN = re.compile(r"^[A-Za-z0-9_]{20,255}$")


@dataclass
class Respuesta:
    estado: int
    cuerpo: bytes
    cabeceras: dict[str, str]


def _http(url: str, token: str = "") -> Respuesta:
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "uxdeployar-pc"})
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return Respuesta(resp.status, resp.read(4 << 20), {k.lower(): v for k, v in resp.headers.items()})
    except urllib.error.HTTPError as exc:
        return Respuesta(exc.code, exc.read(1 << 16), {k.lower(): v for k, v in exc.headers.items()})
    except OSError as exc:
        raise ErrorInstalador(f"no pude contactar con GitHub: {exc}") from exc


def release_publico(repo: str = REPO_RELEASES, http=_http) -> bool:
    """True si el último release se lee sin token; 401/403/404 significan privado."""
    r = http(f"{API}/repos/{repo}/releases/latest")
    if r.estado == 200:
        return True
    if r.estado in (401, 403, 404):
        return False
    raise ErrorInstalador(f"GitHub respondió {r.estado} al leer los releases de {repo}")


def url_crear_token(host: str) -> str:
    consulta = urllib.parse.urlencode({"scopes": "repo,read:packages", "description": f"uxdeployar-{host}"})
    return f"https://github.com/settings/tokens/new?{consulta}"


def validar_token(token: str, repo: str = REPO_RELEASES, http=_http) -> str:
    """Comprueba que el token lee los releases (y, si es clásico, que tiene repo y read:packages)."""
    token = token.strip()
    if not TOKEN.match(token):
        raise ValueError("el token solo tiene letras, dígitos y guion bajo (ghp_… o github_pat_…)")
    r = http(f"{API}/repos/{repo}/releases/latest", token)
    if r.estado == 401:
        raise ValueError("GitHub no acepta ese token (caducado o mal copiado)")
    if r.estado in (403, 404):
        raise ValueError(f"el token no ve los releases de {repo}: dale acceso a ese repositorio")
    if r.estado != 200:
        raise ValueError(f"GitHub respondió {r.estado} al probar el token")
    alcances = r.cabeceras.get("x-oauth-scopes")
    if alcances is not None:
        presentes = {a.strip() for a in alcances.split(",")}
        faltan = {"repo", "read:packages"} - presentes - ({"read:packages"} if "write:packages" in presentes else set())
        if faltan:
            raise ValueError("al token le faltan permisos: " + ", ".join(sorted(faltan)))
    return token


def ultima_version(repo: str = REPO_RELEASES, token: str = "", http=_http) -> str:
    r = http(f"{API}/repos/{repo}/releases/latest", token)
    if r.estado != 200:
        return ""
    try:
        return str(json.loads(r.cuerpo).get("tag_name", ""))
    except ValueError:
        return ""


def descargar_install_sh(url: str = URL_INSTALL_SH, http=_http) -> str:
    r = http(url)
    texto = r.cuerpo.decode("utf-8", errors="replace")
    if r.estado != 200 or not texto.startswith("#!"):
        raise ErrorInstalador(f"no pude descargar install.sh de {url} (HTTP {r.estado})")
    return texto
