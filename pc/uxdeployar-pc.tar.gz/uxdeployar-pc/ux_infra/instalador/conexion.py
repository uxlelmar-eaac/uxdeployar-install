"""Conexión con el VPS: huella confirmada en el primer uso, sistema soportado y llave.

La huella se confirma una vez (o se compara con ``--huella``) y queda anclada: todas
las reconexiones posteriores, también al usuario administrador por el puerto
nuevo, exigen la misma clave de host.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

from .. import keys, ssh, util
from ..fase1 import detectar_sistema
from . import ErrorInstalador
from .consola import Consola

SISTEMAS_SOPORTADOS = {("debian", "13"), ("ubuntu", "26.04")}
LLAVE_PERSONAL = "id_ed25519"


@dataclass
class Destino:
    host: str
    puerto: int = 22
    usuario: str = "root"
    contrasena: str = ""
    ruta_llave: str = ""
    passphrase: str = ""
    anclada: object | None = None

    def config(self, timeout: float = 20.0) -> ssh.Config:
        return ssh.Config(
            host=self.host,
            puerto=self.puerto,
            usuario=self.usuario,
            contrasena=self.contrasena,
            ruta_llave=self.ruta_llave,
            passphrase=self.passphrase,
            anclada=self.anclada,
            timeout=timeout,
        )

    def con(self, **cambios) -> "Destino":
        return replace(self, **cambios)


def anclar_huella(consola: Consola, host: str, puerto: int, esperada: str = ""):
    """Lee la clave del host sin autenticar y la ancla tras confirmarla."""
    clave = ssh.escanear_clave_host(host, puerto)
    obtenida = ssh.huella(clave)
    if esperada:
        if util.normalizar_huella(esperada) != obtenida:
            raise ErrorInstalador(
                f"la huella del servidor ({obtenida}) no coincide con la indicada ({esperada}): "
                "no continúo (podría ser otro servidor)"
            )
        consola.ok(f"huella verificada: {obtenida}")
        return clave
    consola.info(f"Huella del servidor ({clave.get_name()}): {obtenida}")
    consola.info("Compárala con la que muestra tu proveedor (consola web o correo de alta).")
    if not consola.confirmar("¿Coincide?", defecto=False):
        raise ErrorInstalador("huella no confirmada: no continúo")
    return clave


def conectar(destino: Destino) -> ssh.Cliente:
    return ssh.Cliente.dial(destino.config())


def comprobar_sistema(cli: ssh.Cliente) -> str:
    ident, version, nombre = detectar_sistema(cli)
    if (ident, version) not in SISTEMAS_SOPORTADOS:
        raise ErrorInstalador(
            f"sistema no soportado: {nombre or ident + ' ' + version} "
            "(hace falta Debian 13 o Ubuntu 26.04 recién instalado)"
        )
    return nombre or f"{ident} {version}"


def dir_ssh() -> Path:
    return Path.home() / ".ssh"


def elegir_llave(consola: Consola, host: str, carpeta: Path | None = None) -> tuple[str, str, str]:
    """Devuelve (ruta privada, línea pública, passphrase): la ed25519 personal o una nueva."""
    carpeta = carpeta or dir_ssh()
    personal = carpeta / LLAVE_PERSONAL
    if personal.exists() and (carpeta / f"{LLAVE_PERSONAL}.pub").exists():
        if consola.confirmar(f"¿Uso tu llave {personal} para entrar al VPS?"):
            passphrase = passphrase_de(consola, str(personal))
            return str(personal), keys.leer_publica(str(personal) + ".pub"), passphrase
    ruta = carpeta / f"uxdeployar_{_nombre_archivo(host)}"
    if ruta.exists():
        consola.ok(f"uso la llave que ya generé para este VPS: {ruta}")
        return str(ruta), keys.leer_publica(str(ruta) + ".pub"), passphrase_de(consola, str(ruta))
    par = keys.generar_ssh(str(ruta), comentario=f"uxdeployar {host}")
    consola.ok(f"llave nueva: {par.ruta_privada} ({par.huella})")
    return par.ruta_privada, par.publica, ""


def llaves_conocidas(host: str, carpeta: Path | None = None) -> list[str]:
    """Llaves con las que este PC pudo instalar ``host`` antes: la generada para él y la personal."""
    carpeta = carpeta or dir_ssh()
    candidatas = (carpeta / f"uxdeployar_{_nombre_archivo(host)}", carpeta / LLAVE_PERSONAL)
    return [str(r) for r in candidatas if r.exists()]


def passphrase_de(consola: Consola, ruta: str) -> str:
    try:
        ssh.cargar_firmante(ruta)
        return ""
    except ssh.ErrorPassphrase:
        pass
    while True:
        frase = consola.secreto(f"Passphrase de {ruta}")
        try:
            ssh.cargar_firmante(ruta, frase)
            return frase
        except ssh.ErrorAuth as exc:
            consola.error(str(exc))


def _nombre_archivo(host: str) -> str:
    return "".join(c if c.isalnum() or c in "-." else "_" for c in host)


SCRIPT_LLAVE = (
    "umask 077; install -d -m 700 /root/.ssh; touch /root/.ssh/authorized_keys; "
    "read -r linea; grep -qxF \"$linea\" /root/.ssh/authorized_keys || "
    "printf '%s\\n' \"$linea\" >> /root/.ssh/authorized_keys; chmod 600 /root/.ssh/authorized_keys"
)


def instalar_llave(cli: ssh.Cliente, publica: str) -> None:
    """Añade la llave pública a las de root (idempotente; viaja por stdin)."""
    r = cli.ejecutar(f"bash -c {util.comillas(SCRIPT_LLAVE)}", stdin=publica.strip() + "\n")
    if r.codigo != 0:
        raise ErrorInstalador(f"no pude instalar la llave en root: {util.truncar(r.stderr.strip(), 300)}")
