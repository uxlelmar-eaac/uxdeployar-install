"""``ux-infra instalar``: de un VPS recién creado a uxdeployar funcionando, todo desde el PC.

Pasos: conexión (huella confirmada) → llave → datos → DNS → puertos → token de
GitHub → resumen → install.sh → seguimiento con reconexión → credenciales y acceso.
"""

from __future__ import annotations

import argparse
import socket
from pathlib import Path

from .. import ssh, util
from . import ErrorInstalador, dns, final, github, puertos, seguimiento
from .conexion import (
    Destino, anclar_huella, comprobar_sistema, conectar, elegir_llave, instalar_llave, llaves_conocidas, passphrase_de,
)
from .consola import Consola

ESPERA_SONDEO_S = 5.0


def _dominio(valor: str) -> str:
    d = valor.strip().lower().rstrip(".")
    if not util.es_dominio(d) or "." not in d:
        raise ValueError(f"dominio inválido: {valor} (p. ej. panel.ejemplo.com)")
    return d


def _correo(valor: str) -> str:
    return util.validar_email(valor.strip())


def _api_por_defecto(panel: str) -> str:
    partes = panel.split(".")
    return "api." + (".".join(partes[1:]) if len(partes) > 2 else panel)


def _ipv4_de(host: str) -> str:
    return host if util.es_ip(host) else socket.gethostbyname(host)


def _conectar_root(consola: Consola, args: argparse.Namespace, host: str, clave) -> tuple[ssh.Cliente, Destino]:
    destino = Destino(host, args.puerto_root, "root", anclada=clave, ruta_llave=util.expandir_ruta(args.llave or ""))
    while True:
        if not destino.ruta_llave and not destino.contrasena:
            destino = destino.con(contrasena=consola.secreto("Contraseña de root del VPS (no se muestra)"))
        try:
            return conectar(destino), destino
        except ssh.ErrorAuth as exc:
            consola.error(str(exc))
            destino = destino.con(contrasena="", ruta_llave="")


def _ipv6_publica(cli: ssh.Cliente) -> str:
    r = cli.ejecutar(
        "ip -6 route get 2606:4700:4700::1111 2>/dev/null | "
        "awk '{for (i = 1; i < NF; i++) if ($i == \"src\") {print $(i + 1); exit}}'"
    )
    ip = r.stdout.strip()
    return ip if ip and not ip.lower().startswith(("fe80", "fc", "fd")) else ""


def _paso_dns(consola: Consola, args, cli: ssh.Cliente, op: seguimiento.Opciones, ipv4: str) -> None:
    consola.titulo("DNS")
    if args.dns == "ninguno":
        consola.info("sin DNS (--dns ninguno): los dominios ya resuelven por otra vía")
        return
    ipv6 = _ipv6_publica(cli)
    if ipv6 and not consola.confirmar(f"El VPS tiene IPv6 ({ipv6}). ¿Publico también registros AAAA?", False):
        ipv6 = ""
    registros = dns.registros_para([op.panel, op.api], ipv4, ipv6)
    # Solo los NS autoritativos: preguntar a 1.1.1.1 por un nombre que aún no existe
    # deja un «no existe» en su caché y retrasa la propagación cuando se crea.
    servidores = dns.autoritativos(op.panel)
    if servidores and dns.faltan_en_autoritativos(registros, servidores) == []:
        consola.ok("los registros ya apuntan a este VPS")
        return
    proveedor = dns.elegir(consola, op.panel, args.dns or "")
    proveedor.aplicar(consola, registros)
    dns.esperar(consola, registros, servidores=servidores)


def _paso_puertos(consola: Consola, cli: ssh.Cliente, host: str, puerto_ssh: int) -> None:
    consola.titulo("Puertos")
    while True:
        fallidos = puertos.probar(cli, host, [80, 443, puerto_ssh])
        if not fallidos:
            consola.ok(f"80, 443 y {puerto_ssh} llegan al VPS desde aquí")
            return
        consola.aviso(puertos.explicar_bloqueo(fallidos))
        if not consola.confirmar("¿Pruebo de nuevo?"):
            raise ErrorInstalador("faltan puertos abiertos en el firewall del proveedor")


def _paso_token(consola: Consola, args, host: str) -> str:
    consola.titulo("Token de GitHub")
    if args.release_url:
        consola.info("los releases salen de un espejo propio: no hace falta token")
        return ""
    if github.release_publico(args.release_repo):
        consola.ok("los releases son públicos: no hace falta token")
        return ""
    url = github.url_crear_token(host)
    consola.info("Los releases son privados. Crea un token clásico con «repo» y «read:packages»:")
    consola.info(url)
    if not args.no_abrir:
        final.abrir_panel(url)
    return consola.secreto("Token de GitHub (no se muestra)", lambda t: github.validar_token(t, args.release_repo))


def _resumen(consola: Consola, host: str, sistema: str, op: seguimiento.Opciones) -> None:
    consola.titulo("Resumen")
    consola.info(f"VPS        {host} ({sistema})")
    consola.info(f"Panel      https://{op.panel}    API https://{op.api}")
    consola.info(f"Correo     {op.correo}")
    consola.info(f"SSH final  {op.usuario_admin}@{host} -p {op.puerto_ssh} (solo llave; el 22 se cierra)")
    consola.info(f"Versión    {op.version or 'la última'}")
    consola.info("El VPS se endurece (no se deshace) y se reinicia dos o tres veces; tarda unos minutos.")


def _hasta_el_final(consola: Consola, reconectador, cli, es_root: bool = True):
    """Sigue la instalación y ofrece reintentar si falla; devuelve (cli, es_root) o None si el usuario lo deja."""
    estado, cli, es_root = seguimiento.seguir(consola, reconectador, cli, es_root)
    while estado == "fallida":
        consola.error("la instalación se detuvo; el motivo está en las últimas líneas del registro")
        if not consola.confirmar("¿Reintento desde donde se quedó?"):
            consola.info("cuando lo corrijas, vuelve a ejecutar este programa: retoma la instalación")
            return None
        sudo = "" if es_root else final.sudo_de(final.leer_credenciales(cli, es_root))
        seguimiento.reanudar(cli, consola, es_root, sudo)
        estado, cli, es_root = seguimiento.seguir(consola, reconectador, cli if cli.vivo() else None, es_root)
    return cli, es_root


def _retomar(consola: Consola, args, host: str) -> int | None:
    """Si el VPS ya tiene una instalación hecha desde este PC (el puerto SSH final responde y una llave
    conocida entra como administrador), la sigue y la termina. None = no hay nada que retomar."""
    llaves = llaves_conocidas(host)
    if not llaves:
        return None
    try:
        ssh.escanear_clave_host(host, args.puerto_ssh, timeout=ESPERA_SONDEO_S)
    except ssh.ErrorRed:
        return None
    consola.info(f"el puerto {args.puerto_ssh} ya responde: compruebo si hay una instalación de uxdeployar")
    clave = anclar_huella(consola, host, args.puerto_ssh, args.huella or "")
    for ruta in llaves:
        admin = Destino(host, args.puerto_ssh, seguimiento.Opciones.usuario_admin, ruta_llave=ruta, anclada=clave)
        admin = admin.con(passphrase=passphrase_de(consola, ruta))
        try:
            cli = conectar(admin)
        except ssh.ErrorAuth:
            continue
        break
    else:
        return None
    if seguimiento.leer_estado(cli) == "sin-instalar":
        cli.cerrar()
        return None

    consola.titulo("Instalación ya iniciada")
    consola.info("este VPS ya tiene uxdeployar o lo está instalando: sigo desde donde va")
    root = Destino(host, args.puerto_root, "root", ruta_llave=admin.ruta_llave, passphrase=admin.passphrase, anclada=clave)
    seguido = _hasta_el_final(consola, seguimiento.Reconectador(admin, root), cli, es_root=False)
    if seguido is None:
        return 1
    cli, es_root = seguido
    try:
        credenciales = final.leer_credenciales(cli, es_root)
    except ErrorInstalador:
        consola.ok("uxdeployar ya está instalado y sus credenciales ya se trajeron a tu PC")
        cli.cerrar()
        return 0
    panel = final.url_panel(credenciales).removeprefix("https://").strip("/") or host
    op = seguimiento.Opciones(panel=panel, api="", correo="", puerto_ssh=args.puerto_ssh)
    _terminar(consola, args, host, clave, admin.ruta_llave, op, cli, es_root, credenciales)
    cli.cerrar()
    return 0


def _terminar(
    consola: Consola, args, host: str, clave, ruta_llave: str, op, cli, es_root: bool, credenciales: str = "",
) -> None:
    consola.titulo("Listo")
    credenciales = credenciales or final.leer_credenciales(cli, es_root)
    ruta = Path(final.guardar_credenciales(op.panel, credenciales)).resolve()
    final.borrar_copia(cli, es_root, op.usuario_admin)
    consola.ok(f"credenciales guardadas en {ruta} (y borradas del VPS); pásalas a tu gestor de contraseñas")
    final.anadir_known_hosts(host, op.puerto_ssh, clave)
    alias = f"uxdeployar-{op.panel.split('.')[0]}"
    if final.anadir_ssh_config(alias, host, op.puerto_ssh, op.usuario_admin, ruta_llave):
        consola.ok(f"acceso SSH: ssh {alias}")
    url = final.url_panel(credenciales) or f"https://{op.panel}"
    consola.ok(f"panel: {url}")
    consola.info(f"  entra con tu correo y la «Contraseña inicial» que está en {ruta}")
    if not args.no_abrir:
        final.abrir_panel(url)


def ejecutar(args: argparse.Namespace, consola: Consola | None = None) -> int:
    consola = consola or Consola()
    consola.titulo("Conexión")
    host = util.validar_host(args.host) if args.host else consola.preguntar("IP del VPS", validar=util.validar_host)
    retomado = _retomar(consola, args, host)
    if retomado is not None:
        return retomado
    clave = anclar_huella(consola, host, args.puerto_root, args.huella or "")
    cli, root = _conectar_root(consola, args, host, clave)
    sistema = comprobar_sistema(cli)
    consola.ok(f"conectado como root a {sistema}")

    consola.titulo("Llave SSH")
    ruta_llave, publica, frase = elegir_llave(consola, host, elegida=root.ruta_llave)
    instalar_llave(cli, publica)
    root = root.con(ruta_llave=ruta_llave, passphrase=frase, contrasena="")
    cli.cerrar()
    cli = conectar(root)
    consola.ok("la llave entra como root")

    consola.titulo("Datos")
    panel = _dominio(args.panel) if args.panel else consola.preguntar("Dominio del panel", validar=_dominio)
    api = _dominio(args.api) if args.api else consola.preguntar("Dominio de la API", _api_por_defecto(panel), _dominio)
    if api == panel:
        raise ErrorInstalador("el panel y la API necesitan dominios distintos")
    correo = _correo(args.correo) if args.correo else consola.preguntar("Tu correo (Let's Encrypt y acceso al panel)", validar=_correo)
    op = seguimiento.Opciones(
        panel=panel,
        api=api,
        correo=correo,
        puerto_ssh=args.puerto_ssh,
        version=args.version_uxdeployar or "",
        release_url=args.release_url or "",
        release_repo=args.release_repo,
        acme_ca=args.acme_ca or "",
        raiz_acme_pem=Path(args.acme_ca_root).read_text(encoding="utf-8") if args.acme_ca_root else "",
        ip_publica=args.ip_publica or _ipv4_de(host),
        registro=args.registry or "",
    )

    _paso_dns(consola, args, cli, op, op.ip_publica)
    _paso_puertos(consola, cli, host, op.puerto_ssh)
    op.token = _paso_token(consola, args, host)
    _resumen(consola, host, sistema, op)
    if not args.yes and not consola.confirmar("¿Instalo uxdeployar en este VPS?", defecto=False):
        consola.info("cancelado: no se cambió nada en el VPS")
        return 1

    consola.titulo("Instalación")
    install_sh = (
        Path(args.install_sh).read_text(encoding="utf-8") if args.install_sh else github.descargar_install_sh()
    )
    siguio = seguimiento.lanzar(cli, consola, install_sh, publica, op)
    admin = Destino(host, op.puerto_ssh, op.usuario_admin, ruta_llave=ruta_llave, passphrase=frase, anclada=clave)
    seguido = _hasta_el_final(consola, seguimiento.Reconectador(admin, root), cli if siguio else None)
    if seguido is None:
        return 1
    cli, es_root = seguido
    _terminar(consola, args, host, clave, ruta_llave, op, cli, es_root)
    cli.cerrar()
    return 0
