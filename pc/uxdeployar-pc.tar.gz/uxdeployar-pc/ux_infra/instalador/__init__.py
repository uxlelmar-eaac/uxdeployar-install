"""Instalación guiada de uxdeployar desde el PC (``ux-infra instalar``).

El programa del PC hace todo lo que antes había que hacer a mano en el VPS:
conexión con la huella confirmada, llave, DNS, puertos, token de GitHub,
lanzamiento de ``install.sh`` y seguimiento con reconexión hasta el final.
"""


class ErrorInstalador(Exception):
    """Un paso no puede continuar; el mensaje explica qué hacer."""
