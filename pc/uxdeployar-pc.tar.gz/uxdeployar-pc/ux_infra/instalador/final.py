"""Cierre: credenciales guardadas en el PC, acceso SSH configurado y panel abierto."""

from __future__ import annotations

import os
import re
from pathlib import Path

from .. import acceso, navegador, ssh
from . import ErrorInstalador

COPIA = "uxdeployar-credenciales.txt"
CREDENCIALES_ROOT = "/etc/ux/uxdeployar/credentials"
_SUDO = re.compile(r"^\s*sudo\s+(\S+)", re.MULTILINE)
_PANEL = re.compile(r"^Panel\s+(https://\S+)", re.MULTILINE)


def leer_credenciales(cli: ssh.Cliente, es_root: bool) -> str:
    """El administrador lee su copia (sin sudo); root, el original."""
    ruta = CREDENCIALES_ROOT if es_root else f"~/{COPIA}"
    r = cli.ejecutar(f"cat {ruta}")
    if r.codigo != 0 or not r.stdout.strip():
        raise ErrorInstalador("no encuentro las credenciales de la instalación en el VPS")
    return r.stdout


def sudo_de(credenciales: str) -> str:
    m = _SUDO.search(credenciales)
    return m.group(1) if m else ""


def url_panel(credenciales: str) -> str:
    m = _PANEL.search(credenciales)
    return m.group(1) if m else ""


def carpeta_config(panel: str, entorno: dict[str, str] | None = None) -> Path:
    entorno = os.environ if entorno is None else entorno
    if os.name == "nt" and entorno.get("APPDATA"):
        base = Path(entorno["APPDATA"])
    else:
        base = Path(entorno.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return base / "uxdeployar" / panel


def guardar_credenciales(panel: str, credenciales: str, carpeta: Path | None = None) -> Path:
    carpeta = carpeta or carpeta_config(panel)
    carpeta.mkdir(parents=True, exist_ok=True, mode=0o700)
    ruta = carpeta / "credenciales.txt"
    fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(credenciales)
    os.chmod(ruta, 0o600)
    return ruta


def borrar_copia(cli: ssh.Cliente, es_root: bool, usuario_admin: str) -> None:
    """La copia del administrador solo sirve para traerla al PC: se borra al tenerla."""
    if es_root:
        cli.ejecutar(f"rm -f \"$(getent passwd {usuario_admin} | cut -d: -f6)/{COPIA}\"")
    else:
        cli.ejecutar(f"rm -f ~/{COPIA}")


def anadir_ssh_config(
    alias: str, host: str, puerto: int, usuario: str, ruta_llave: str, ruta: Path | None = None
) -> bool:
    """Añade ``Host <alias>`` a ~/.ssh/config si no estaba. Devuelve True si escribió."""
    ruta = ruta or Path.home() / ".ssh" / "config"
    actual = ruta.read_text(encoding="utf-8") if ruta.exists() else ""
    if re.search(rf"^Host\s+{re.escape(alias)}\s*$", actual, re.MULTILINE):
        return False
    bloque = (
        f"\nHost {alias}\n  HostName {host}\n  Port {puerto}\n  User {usuario}\n"
        f"  IdentityFile {ruta_llave}\n  IdentitiesOnly yes\n"
    )
    ruta.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with open(ruta, "a", encoding="utf-8") as fh:
        fh.write(bloque if actual.endswith("\n") or not actual else "\n" + bloque)
    os.chmod(ruta, 0o600)
    return True


def anadir_known_hosts(host: str, puerto: int, clave) -> bool:
    return acceso.anadir(acceso.ruta_known_hosts(), host, puerto, clave)


def abrir_panel(url: str, abrir=navegador.abrir) -> None:
    abrir(url)
