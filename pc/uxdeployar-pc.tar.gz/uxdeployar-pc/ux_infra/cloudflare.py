"""Automatiza lo que el protocolo pedía hacer a mano en el panel de Cloudflare:
registros DNS (E12.4), buckets de R2 con su token restringido (E14.2) y las
reglas de ciclo de vida y bloqueo (E14.3).

Espejo de ``05-vps/app/internal/cloudflare/cloudflare.go``. El token vive solo
en memoria mientras la app está abierta.
"""

from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request

BASE_API = "https://api.cloudflare.com/client/v4"


class Error(Exception):
    def __init__(self, msg: str, estado: int = 0, codigos: list[int] | None = None) -> None:
        super().__init__("Cloudflare: " + msg)
        self.estado = estado
        self.codigos = codigos or []
        self.msg = msg


class Cliente:
    def __init__(self, token: str) -> None:
        self.token = token.strip()
        self.base = BASE_API

    def llamar(self, metodo: str, ruta: str, cuerpo: dict | None = None, *, esperar_result: bool = True):
        datos_bytes = None
        if cuerpo is not None:
            datos_bytes = json.dumps(cuerpo).encode("utf-8")
        req = urllib.request.Request(self.base + ruta, data=datos_bytes, method=metodo)
        req.add_header("Authorization", "Bearer " + self.token)
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                crudo = resp.read(8 << 20)
                estado = resp.status
        except urllib.error.HTTPError as exc:
            crudo = exc.read(8 << 20)
            estado = exc.code
        except OSError as exc:
            raise Error(f"no pude contactar con la API de Cloudflare: {exc}") from exc
        try:
            r = json.loads(crudo)
        except json.JSONDecodeError:
            raise Error(f"respuesta inesperada (HTTP {estado})", estado)
        if not r.get("success"):
            msgs = [x.get("message", "") for x in r.get("errors", [])]
            msg = "; ".join(m for m in msgs if m) or f"HTTP {estado}"
            if estado in (401, 403):
                msg += " (al token le falta un permiso)"
            raise Error(msg, estado, [x.get("code", 0) for x in r.get("errors", [])])
        if not esperar_result:
            return None
        return r.get("result")

    # -- cuenta -------------------------------------------------------------

    def verificar(self) -> list[dict]:
        if not self.token:
            raise Error("falta el token de Cloudflare")
        cuentas = self.llamar("GET", "/accounts?per_page=50") or []
        if not cuentas:
            raise Error("el token no tiene acceso a ninguna cuenta (necesita permisos de cuenta: R2 y tokens de API)")
        return cuentas

    # -- DNS ----------------------------------------------------------------

    def zona(self, dominio: str) -> tuple[str, str]:
        partes = dominio.rstrip(".").lower().split(".")
        for i in range(len(partes) - 1):
            nombre = ".".join(partes[i:])
            zs = self.llamar("GET", "/zones?name=" + urllib.parse.quote(nombre)) or []
            if zs:
                return zs[0]["id"], zs[0]["name"]
        raise Error(f"el dominio {dominio} no está en ninguna zona de tu cuenta de Cloudflare")

    def verificar_token_dns(self) -> None:
        """Comprueba un token de usuario (p. ej. la plantilla «Edit zone DNS»), que no ve cuentas."""
        if not self.token:
            raise Error("falta el token de Cloudflare")
        r = self.llamar("GET", "/user/tokens/verify") or {}
        if r.get("status") != "active":
            raise Error(f"el token no está activo ({r.get('status', 'desconocido')})")

    def registros(self, tipo: str, dominio: str) -> list[dict]:
        zid, _ = self.zona(dominio)
        return self.llamar("GET", f"/zones/{zid}/dns_records?type={tipo}&name=" + urllib.parse.quote(dominio)) or []

    def registro(self, tipo: str, dominio: str, contenido: str) -> str:
        """Crea o corrige un registro A o AAAA sin proxy. Devuelve 'creado', 'actualizado' o 'sin cambios'."""
        zid, _ = self.zona(dominio)
        existentes = self.registros(tipo, dominio)
        nuevo = {"type": tipo, "name": dominio, "content": contenido, "ttl": 1, "proxied": False, "comment": "UX-VPS"}
        if existentes:
            r = existentes[0]
            if r.get("content") == contenido and not r.get("proxied"):
                return "sin cambios"
            self.llamar("PUT", f"/zones/{zid}/dns_records/{r['id']}", nuevo, esperar_result=False)
            return "actualizado"
        self.llamar("POST", f"/zones/{zid}/dns_records", nuevo, esperar_result=False)
        return "creado"

    def registro_a(self, dominio: str, ip: str) -> str:
        return self.registro("A", dominio, ip)

    def borrar_registro(self, dominio: str, id_registro: str) -> None:
        zid, _ = self.zona(dominio)
        self.llamar("DELETE", f"/zones/{zid}/dns_records/{id_registro}", esperar_result=False)

    # -- R2 -----------------------------------------------------------------

    RETENCIONES = [("diario/", 14), ("semanal/", 56), ("mensual/", 365), ("pre-deploy/", 30)]

    def bucket(self, cuenta: str, nombre: str) -> bool:
        """Crea el bucket si no existe. Devuelve True si lo creó."""
        lista = self.llamar("GET", f"/accounts/{cuenta}/r2/buckets?per_page=1000") or {}
        for b in lista.get("buckets", []):
            if b.get("name") == nombre:
                return False
        self.llamar("POST", f"/accounts/{cuenta}/r2/buckets", {"name": nombre}, esperar_result=False)
        return True

    def ciclo_de_vida(self, cuenta: str, bucket: str, dias_bloqueo: int) -> None:
        reglas = []
        for prefijo, dias in self.RETENCIONES:
            reglas.append(
                {
                    "id": "ux-" + prefijo.rstrip("/"),
                    "enabled": True,
                    "conditions": {"prefix": prefijo},
                    "deleteObjectsTransition": {"condition": {"type": "Age", "maxAge": dias * 86400}},
                }
            )
        try:
            self.llamar("PUT", f"/accounts/{cuenta}/r2/buckets/{bucket}/lifecycle", {"rules": reglas}, esperar_result=False)
        except Error as exc:
            raise Error(f"ciclo de vida: {exc.msg}", exc.estado) from exc
        if dias_bloqueo <= 0:
            return
        bloqueos = []
        for p in ("diario/", "pre-deploy/"):
            bloqueos.append(
                {
                    "id": "ux-bloqueo-" + p.rstrip("/"),
                    "enabled": True,
                    "prefix": p,
                    "condition": {"type": "Age", "maxAgeSeconds": dias_bloqueo * 86400},
                }
            )
        try:
            self.llamar("PUT", f"/accounts/{cuenta}/r2/buckets/{bucket}/lock", {"rules": bloqueos}, esperar_result=False)
        except Error as exc:
            raise Error(f"bloqueo: {exc.msg}", exc.estado) from exc

    def token_r2(self, cuenta: str, bucket: str) -> tuple[str, str]:
        """Crea un token de API restringido a ese bucket y deriva sus credenciales S3."""
        grupos = []
        ruta = f"/accounts/{cuenta}/tokens"
        try:
            grupos = self.llamar("GET", ruta + "/permission_groups") or []
        except Error:
            ruta = "/user/tokens"
            grupos = self.llamar("GET", ruta + "/permission_groups") or []
        id_permiso = next((g["id"] for g in grupos if g.get("name") == "Workers R2 Storage Bucket Item Write"), "")
        if not id_permiso:
            raise Error("Cloudflare no ofreció el permiso «Workers R2 Storage Bucket Item Write»")
        cuerpo = {
            "name": "ux-vps " + bucket,
            "policies": [
                {
                    "effect": "allow",
                    "permission_groups": [{"id": id_permiso}],
                    "resources": {f"com.cloudflare.edge.r2.bucket.{cuenta}_default_{bucket}": "*"},
                }
            ],
        }
        tok = self.llamar("POST", ruta, cuerpo) or {}
        if not tok.get("id") or not tok.get("value"):
            raise Error("Cloudflare no devolvió el token creado")
        secreta = hashlib.sha256(tok["value"].encode("utf-8")).hexdigest()
        return tok["id"], secreta
