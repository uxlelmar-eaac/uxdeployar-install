"""Servidor HTTP local de la app (solo 127.0.0.1) con la misma protección que
el original: clave de acceso aleatoria por arranque (cookie HttpOnly +
SameSite=Strict), validación de Host y Origin (anti DNS rebinding y CSRF),
cabecera obligatoria ``X-UX-Peticion`` y CSP estricta.

Espejo de ``05-vps/app/internal/web/server.go`` + ``api_conexion.go``. La
interfaz nunca envía comandos: solo identificadores y parámetros validados; los
comandos salen de los contratos o del catálogo de operaciones.
"""

from __future__ import annotations

import hmac
import json
import mimetypes
import os
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import __version__, acceso, keys, navegador, cloudflare, fase1, fase2, inventario, ops, perfiles, qr, sesion, ssh, totp as totp_mod, jobs, util

COOKIE_PREFIJO = "uxinfra-"
MAX_CUERPO = 4 << 20
RUTA_INVENTARIO = "/opt/ux-infra/05-vps/agent/inventory/inventory.yaml"
DIR_INVENTARIO = "/opt/ux-infra/05-vps/agent/inventario"
RUTA_SECRETOS_VPS = DIR_INVENTARIO + "/secrets.sh"
UI_DIR = Path(__file__).resolve().parent.parent / "ui"

CSP = (
    "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
)

CAB_SEGURIDAD = (
    ("Cache-Control", "no-store"),
    ("X-Content-Type-Options", "nosniff"),
    ("Referrer-Policy", "no-referrer"),
    ("X-Frame-Options", "DENY"),
    ("Cross-Origin-Opener-Policy", "same-origin"),
    ("Cross-Origin-Resource-Policy", "same-origin"),
    ("Content-Security-Policy", CSP),
)

_TIPOS = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".woff2": "font/woff2",
    ".json": "application/json; charset=utf-8",
}


class _YaRespondido(Exception):
    """La petición ya tiene respuesta: el despachador no debe volver a responder."""


class Bitacora(jobs.Bitacora):
    """Compatibilidad: la bitácora vive en ``ux_infra.trabajos`` (como el original)."""

    def lineas(self, maximo: int = 300) -> list[str]:
        try:
            todas = Path(self.ruta()).read_text(encoding="utf-8").rstrip("\n").split("\n")
        except OSError:
            return []
        return todas[-maximo:] if len(todas) > maximo else todas

    def consola_desde(self, desde: int) -> tuple[str, int]:
        return self.desde(desde)


class Servidor:
    """La aplicación web local."""

    def __init__(
        self,
        puerto: int = 0,
        dir_config: str = "",
        version: str = "",
        abrir_navegador: bool = True,
    ) -> None:
        self.opt_puerto = puerto
        self.dir_config = dir_config or str(perfiles.dir_config())
        self.version = version or __version__
        self.abrir_navegador = abrir_navegador
        self.token = secrets.token_hex(24)
        self.puerto = 0
        self.hosts: set[str] = set()
        self.ses = sesion.Sesion()
        self.perf = perfiles.Almacen(self.dir_config)
        self.bit = Bitacora(self.dir_config)
        self.gestor = jobs.Gestor(self.bit)
        self.cat = ops.Catalogo()
        self.env = ops.Entorno(self.ses)
        self.f2 = fase2.Fase2(self.ses)
        self.f2.local = lambda tipo, v, emitir: fase2.local_por_defecto(tipo, v, emitir, self.f2)
        self._f1: dict = {
            "pasos": [{"id": p["id"], "nombre": p["nombre"], "estado": "pendiente"} for p in fase1.PASOS],
            "trabajo": "",
            "informe": None,
            "esperando": "",
        }
        self._cf: "cloudflare.Cliente | None" = None
        self._totp: dict = {"secreto": "", "respaldo": [], "cuenta": "", "activo": False}
        self._http: "ThreadingHTTPServer | None" = None
        self._mutacion = threading.Lock()  # una sola operación que cambia el servidor a la vez

    # -- arranque -----------------------------------------------------------

    def fijar_puerto(self, p: int) -> None:
        self.puerto = p
        self.hosts = {f"127.0.0.1:{p}", f"localhost:{p}"}

    def url(self) -> str:
        return f"http://127.0.0.1:{self.puerto}/?t={self.token}"

    def cookie_nombre(self) -> str:
        return f"{COOKIE_PREFIJO}{self.puerto}"

    def manejador(self):
        srv = self

        class M(BaseHTTPRequestHandler):
            server_version = "ux-infra"

            def log_message(self, *args: object) -> None:
                pass  # la bitácora propia sustituye al registro de acceso

            def do_GET(self) -> None:
                srv._servir(self, "GET")

            def do_POST(self) -> None:
                srv._servir(self, "POST")

            def do_PUT(self) -> None:
                srv._servir(self, "PUT")

            def do_DELETE(self) -> None:
                srv._servir(self, "DELETE")

        return M

    def ejecutar(self) -> int:
        httpd = ThreadingHTTPServer(("127.0.0.1", self.opt_puerto), self.manejador())
        self.fijar_puerto(httpd.server_address[1])
        self._http = httpd
        direccion = self.url()
        print()
        print("  ux-infra — interfaz local lista.")
        print("  Abre esta dirección en tu navegador (la clave de acceso va incluida):")
        print("  " + direccion)
        print()
        print("  Para terminar: botón «Salir» de la interfaz, o Ctrl+C aquí.")
        self.bit.registrar("app", "inicio", f"interfaz local en 127.0.0.1:{self.puerto}")
        if self.abrir_navegador:
            navegador.abrir(direccion)
        try:
            httpd.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            pass
        self.bit.registrar("app", "fin", "interfaz cerrada")
        httpd.server_close()
        return 0

    # -- protección ---------------------------------------------------------

    def _encabezar(self, h: BaseHTTPRequestHandler, codigo: int, extra: tuple) -> None:
        h.send_response(codigo)
        for nombre, valor in CAB_SEGURIDAD + tuple(extra):
            h.send_header(nombre, valor)
        h.end_headers()

    def _drenar(self, h: BaseHTTPRequestHandler) -> None:
        """Lee (y descarta) el cuerpo pendiente.

        En Windows, cerrar un socket con datos recibidos SIN leer envía RST, que
        puede destruir la respuesta que se acaba de escribir (el cliente ve
        ``ConnectionAbortedError`` aunque el servidor respondió). Todo rechazo
        temprano debe drenar antes de responder.
        """
        try:
            largo = int(h.headers.get("Content-Length", "0") or 0)
        except ValueError:
            return
        restante = min(largo, MAX_CUERPO)
        try:
            while restante > 0:
                trozo = h.rfile.read(min(restante, 65536))
                if not trozo:
                    return
                restante -= len(trozo)
        except OSError:
            pass

    def _rechazo_json(self, h: BaseHTTPRequestHandler, codigo: int, objeto: dict) -> None:
        self._drenar(h)
        self._json(h, codigo, objeto)

    def _rechazo_texto(self, h: BaseHTTPRequestHandler, codigo: int, texto: str) -> None:
        self._drenar(h)
        self._texto(h, codigo, texto)

    def _servir(self, h: BaseHTTPRequestHandler, metodo: str) -> None:
        # 1) Host: evita DNS rebinding.
        if h.headers.get("Host", "").lower() not in self.hosts:
            self._rechazo_texto(h, 403, "host no permitido")
            return
        # 2) Clave de acceso: primera visita por ?t=, después cookie.
        if metodo == "GET":
            t = parse_qs(urlparse(h.path).query).get("t", [""])[0]
            if t and hmac.compare_digest(t, self.token):
                h.send_response(303)
                h.send_header("Location", self._sin_token(h.path))
                h.send_header(
                    "Set-Cookie",
                    f"{self.cookie_nombre()}={self.token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=604800",
                )
                h.send_header("Content-Length", "0")
                h.end_headers()
                return
        if not hmac.compare_digest(self._leer_cookie(h), self.token):
            if h.path.startswith("/api/"):
                self._rechazo_json(h, 401, {"error": "no autorizado: abre la dirección completa que mostró la app"})
            else:
                self._rechazo_texto(
                    h,
                    401,
                    "Acceso no autorizado.\nAbre ux-infra otra vez: te lleva a la interfaz con su clave de acceso.",
                )
            return
        # 3) Métodos que cambian estado: Origin propio + cabecera personalizada + JSON.
        if metodo not in ("GET", "HEAD"):
            origen = h.headers.get("Origin", "")
            if origen and urlparse(origen).netloc.lower() not in self.hosts:
                self._rechazo_json(h, 403, {"error": "origen no permitido"})
                return
            if h.headers.get("X-UX-Peticion") != "1":
                self._rechazo_json(h, 403, {"error": "falta la cabecera de la aplicación"})
                return
            if (
                int(h.headers.get("Content-Length", "0") or 0) != 0
                and not h.headers.get("Content-Type", "").startswith("application/json")
            ):
                self._rechazo_json(h, 415, {"error": "se espera JSON"})
                return
        # 4) Despacho.
        ruta = urlparse(h.path).path
        if metodo == "GET" and not ruta.startswith("/api/"):
            self._estatico(h, ruta)
            return
        manejador = _RUTAS.get((metodo, ruta))
        args: tuple = ()
        if manejador is None:
            for patron, fn in _RUTAS_RE.get(metodo, ()):
                m = patron.match(ruta)
                if m:
                    manejador, args = fn, m.groups()
                    break
        if manejador is None:
            if ruta.startswith("/api/"):
                self._rechazo_json(
                    h,
                    501,
                    {
                        "error": (
                            "Este panel no está disponible en esta versión de la app. "
                            "Usa la CLI mientras tanto (python ux-infra.py revisar <host>)."
                        )
                    },
                )
            else:
                self._rechazo_texto(h, 404, "no encontrado")
            return
        try:
            manejador(self, h, *args)
        except _YaRespondido:
            return
        except (ValueError, ssh.ErrorRed, ssh.ErrorAuth, ssh.ErrorPassphrase) as exc:
            self._json(h, 400, {"error": str(exc), "codigo": "otro"})
        except Exception as exc:  # noqa: BLE001
            self.bit.registrar("web", "error", str(exc)[:200])
            self._json(h, 500, {"error": "error interno", "codigo": "otro"})

    def _leer_cookie(self, h: BaseHTTPRequestHandler) -> str:
        nombre = self.cookie_nombre()
        for par in h.headers.get("Cookie", "").split(";"):
            clave, _, valor = par.strip().partition("=")
            if clave == nombre:
                return valor
        return ""

    @staticmethod
    def _sin_token(ruta: str) -> str:
        u = urlparse(ruta)
        consulta = parse_qs(u.query)
        consulta.pop("t", None)
        destino = u.path
        if consulta:
            destino += "?" + "&".join(f"{k}={v[0]}" for k, v in consulta.items())
        return destino

    # -- respuestas ---------------------------------------------------------

    def _json(self, h: BaseHTTPRequestHandler, codigo: int, objeto: dict) -> None:
        datos = json.dumps(objeto, ensure_ascii=False).encode("utf-8")
        self._encabezar(
            h,
            codigo,
            (("Content-Type", "application/json; charset=utf-8"), ("Content-Length", str(len(datos)))),
        )
        h.wfile.write(datos)

    def _texto(self, h: BaseHTTPRequestHandler, codigo: int, texto: str) -> None:
        datos = (texto + "\n").encode("utf-8")
        self._encabezar(
            h,
            codigo,
            (("Content-Type", "text/plain; charset=utf-8"), ("Content-Length", str(len(datos)))),
        )
        h.wfile.write(datos)

    def _leer(self, h: BaseHTTPRequestHandler) -> dict:
        """Decodifica el cuerpo JSON (tope de tamaño). Si falla, responde y lanza _YaRespondido."""
        try:
            largo = int(h.headers.get("Content-Length", "0") or 0)
        except ValueError:
            self._rechazo_json(h, 400, {"error": "petición no válida"})
            raise _YaRespondido from None
        if largo > MAX_CUERPO:
            self._rechazo_json(h, 400, {"error": "petición demasiado grande"})
            raise _YaRespondido
        if largo == 0:
            return {}
        try:
            datos = json.loads(h.rfile.read(largo).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            self._json(h, 400, {"error": "petición no válida: " + util.truncar(str(exc), 200)})
            raise _YaRespondido from exc
        if not isinstance(datos, dict):
            self._json(h, 400, {"error": "petición no válida: se esperaba un objeto"})
            raise _YaRespondido
        return datos

    def _estatico(self, h: BaseHTTPRequestHandler, ruta: str) -> None:
        relativo = "index.html" if ruta in ("/", "") else ruta.lstrip("/")
        destino = (UI_DIR / relativo).resolve()
        raiz = UI_DIR.resolve()
        if raiz != destino and raiz not in destino.parents:
            self._texto(h, 403, "prohibido")
            return
        if not destino.is_file():
            self._texto(h, 404, "no encontrado")
            return
        datos = destino.read_bytes()
        tipo = _TIPOS.get(destino.suffix.lower()) or mimetypes.guess_type(str(destino))[0] or "application/octet-stream"
        self._encabezar(h, 200, (("Content-Type", tipo), ("Content-Length", str(len(datos)))))
        h.wfile.write(datos)

    # -- endpoints ----------------------------------------------------------

    def _h_estado(self, h: BaseHTTPRequestHandler) -> None:
        activo: dict = {}
        for t in self.gestor.recientes():
            if t["estado"] == "corriendo":
                activo = {"id": t["id"], "titulo": t["titulo"]}
                break
        self._json(
            h,
            200,
            {
                "version": self.version,
                "so": util.sistema_operativo(),
                "sesion": self.ses.info().json(),
                "activo": activo,
                "bitacora": self.bit.ruta(),
                "dir": self.dir_config,
                "servidor": "127.0.0.1",
                "inventario": RUTA_INVENTARIO,
            },
        )

    def _h_perfiles(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"perfiles": [p.json() for p in self.perf.listar()]})

    def _h_perfil_eliminar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        self.perf.eliminar(str(req.get("host", "")))
        self._json(h, 200, {"ok": True})

    def _h_llaves(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"llaves": [k.json() for k in keys.listar_locales()]})

    def _h_llave_generar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        try:
            par = keys.generar_ssh(
                str(req.get("ruta", "")),
                comentario=str(req.get("comentario", "")),
                passphrase=str(req.get("passphrase", "")),
                sobrescribir=bool(req.get("sobrescribir", False)),
            )
        except keys.ErrorExiste:
            self._json(
                h,
                409,
                {
                    "error": "ya existe una llave en esa ruta: no la sobrescribo sin tu confirmación",
                    "codigo": "existe",
                },
            )
            return
        self.bit.registrar("llave", "generada", par.ruta_publica + " " + par.huella)
        self._json(
            h,
            200,
            {
                "ruta_privada": par.ruta_privada,
                "ruta_publica": par.ruta_publica,
                "publica": par.publica,
                "huella": par.huella,
            },
        )

    def _h_huella(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        host = util.validar_host(str(req.get("host", "")))
        puerto = util.validar_puerto(req.get("puerto", 22))
        try:
            clave = ssh.escanear_clave_host(host, puerto)
        except ssh.ErrorRed as exc:
            self._json(
                h,
                502,
                {
                    "error": "no pude contactar con el servidor: " + util.truncar(str(exc), 200),
                    "codigo": "red",
                },
            )
            return
        huella_ = ssh.huella(clave)
        resp: dict = {"huella": huella_, "tipo": clave.get_name(), "host": host}
        perfil, ok = self.perf.buscar(host)
        if ok and perfil.huella:
            resp["perfil_huella"] = perfil.huella
            resp["coincide_perfil"] = perfil.huella == huella_
        self._json(h, 200, resp)

    def _h_conectar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        host = util.validar_host(str(req.get("host", "")))
        puerto = util.validar_puerto(req.get("puerto", 22))
        usuario = util.validar_usuario(str(req.get("usuario", "")))
        metodo = str(req.get("metodo", "") or "llave")
        ruta = ""
        if metodo == "password":
            if not req.get("password"):
                self._json(
                    h,
                    400,
                    {"error": "escribe la contraseña de acceso del usuario (la de root que te dio tu proveedor)"},
                )
                return
        elif metodo == "llave":
            ruta = util.expandir_ruta(str(req.get("ruta_llave", "")))
            if not ruta:
                self._json(
                    h,
                    400,
                    {"error": "falta la ruta de tu llave privada (puedes crearla en «Llaves SSH de esta computadora»)"},
                )
                return
            if not os.path.exists(ruta):
                self._json(
                    h,
                    400,
                    {"error": "no encuentro la llave privada indicada (puedes crearla en «Llaves SSH de esta computadora»)"},
                )
                return
        else:
            self._json(h, 400, {"error": "método de acceso no válido"})
            return
        if usuario != "root" and not req.get("password_sudo"):
            self._json(
                h,
                400,
                {"error": "indica la contraseña de sudo del usuario: la necesitan las operaciones del servidor"},
            )
            return
        esperada = util.normalizar_huella(str(req.get("huella", "")))
        perfil, ok = self.perf.buscar(host)
        if ok and perfil.huella:
            if not esperada:
                esperada = perfil.huella
            elif esperada != perfil.huella:
                self._json(
                    h,
                    409,
                    {
                        "error": (
                            f"la huella indicada no coincide con la guardada para este servidor "
                            f"({perfil.huella}). Si cambiaste de VPS, elimina el perfil antes de continuar."
                        ),
                        "codigo": "huella",
                    },
                )
                return
        try:
            clave = ssh.escanear_clave_host(host, puerto)
        except ssh.ErrorRed as exc:
            self._json(
                h,
                502,
                {"error": "no pude contactar con el servidor: " + util.truncar(str(exc), 200), "codigo": "red"},
            )
            return
        actual = ssh.huella(clave)
        if not esperada and req.get("confiar_primera"):
            esperada = actual
            self.bit.registrar("conexion", "huella-aceptada-primera-vez", host + " " + actual)
        if not esperada:
            self._json(
                h,
                409,
                {
                    "error": "verifica primero la huella del servidor contra la consola de tu proveedor",
                    "codigo": "confirmar_huella",
                    "huella": actual,
                    "tipo": clave.get_name(),
                },
            )
            return
        if actual != esperada:
            self._json(
                h,
                409,
                {
                    "error": (
                        f"la huella del servidor ({actual}) NO coincide con la esperada ({esperada}). "
                        "No continúes: puede ser otro servidor."
                    ),
                    "codigo": "huella",
                },
            )
            return
        p = sesion.Parametros(
            host=host,
            puerto=puerto,
            usuario=usuario,
            ruta_llave=ruta,
            passphrase=str(req.get("passphrase", "")),
            password=str(req.get("password", "")),
            totp=str(req.get("totp", "")),
            password_sudo=str(req.get("password_sudo", "")),
            anclada=clave,
        )
        with self._mutacion:
            try:
                self.ses.conectar(p)
            except (ssh.ErrorHuellaAnclada, ssh.ErrorAuth, ssh.ErrorPassphrase, ssh.ErrorRed, ValueError) as exc:
                self.bit.registrar("conexion", "error", host + " " + str(exc))
                self._mapa_error(h, exc)
                return
        self.bit.registrar("conexion", "ok", f"{usuario}@{host} ({metodo}) huella {actual}")
        if req.get("guardar"):
            self.perf.guardar(
                perfiles.Perfil(
                    nombre=str(req.get("nombre", "")),
                    host=host,
                    puerto=puerto,
                    usuario=usuario,
                    ruta_llave=ruta,
                    metodo=metodo,
                    huella=actual,
                )
            )
        self._json(h, 200, {"sesion": self.ses.info().json()})

    def _h_reconectar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        puerto = int(req.get("puerto") or 0)
        if puerto:
            puerto = util.validar_puerto(puerto)
        with self._mutacion:
            try:
                self.ses.reconectar(puerto=puerto, totp=str(req.get("totp", "")))
            except (ssh.ErrorHuellaAnclada, ssh.ErrorAuth, ssh.ErrorPassphrase, ssh.ErrorRed, ValueError) as exc:
                self.bit.registrar("conexion", "error-reconexion", str(exc))
                self._mapa_error(h, exc)
                return
        self.bit.registrar("conexion", "reconectada", "")
        self._json(h, 200, {"sesion": self.ses.info().json()})

    def _h_desconectar(self, h: BaseHTTPRequestHandler) -> None:
        with self._mutacion:
            self.ses.desconectar()
        self.bit.registrar("conexion", "cerrada", "")
        self._json(h, 200, {"sesion": self.ses.info().json()})

    def _h_salir(self, h: BaseHTTPRequestHandler) -> None:
        self._leer(h)
        self._json(h, 200, {"ok": True})
        self.bit.registrar("app", "cerrar", "esta copia")

        def _cerrar() -> None:
            time.sleep(0.2)
            if self._http is not None:
                self._http.shutdown()

        threading.Thread(target=_cerrar, daemon=True).start()

    def _h_version_nueva(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"nueva": "", "archivo": "", "actual": self.version})

    def _h_bitacora(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"ruta": self.bit.ruta(), "lineas": self.bit.lineas()})

    def _h_consola(self, h: BaseHTTPRequestHandler) -> None:
        try:
            desde = int(parse_qs(urlparse(h.path).query).get("desde", ["0"])[0])
        except ValueError:
            desde = 0
        salida, siguiente = self.bit.consola_desde(desde)
        self._json(h, 200, {"salida": salida or None, "siguiente": siguiente})

    def _h_latido(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"ok": True})

    # -- operaciones y trabajos ---------------------------------------------

    def _h_catalogo(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"operaciones": [o.json() for o in self.cat.lista()]})

    def _h_op_ejecutar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        o = self.cat.buscar(str(req.get("id", "")))
        if o is None:
            self._json(h, 404, {"error": "operación desconocida"})
            return
        params = {str(k): str(v) for k, v in (req.get("params") or {}).items()}
        if req.get("confirmar"):
            params["confirmar"] = str(req["confirmar"])
        try:
            p = o.validar(params)
        except ops.ErrorOp as exc:
            self._json(h, 422, {"error": str(exc), "codigo": "validacion"})
            return
        resumen = _resumen_op(o, p)
        if o.riesgo == ops.LECTURA and not o.largo:
            try:
                res = o.correr(self.env, p, None)
            except sesion.ErrorSinSesion as exc:
                self._json(h, 409, {"error": str(exc), "codigo": "sin_sesion"})
                return
            except ops.ErrorOp as exc:
                self._json(h, 422, {"error": str(exc), "codigo": "validacion"})
                return
            except (ssh.ErrorRed, ssh.ErrorAuth, ValueError) as exc:
                self._json(h, 502, {"error": str(exc), "codigo": "ssh"})
                return
            self._json(h, 200, {"resultado": res.json()})
            return
        titulo = o.titulo + " — " + resumen.replace(o.id, "", 1).strip()

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            try:
                res = o.correr(self.env, p, emitir)
            except (ops.ErrorOp, sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth, ValueError) as exc:
                return 1, str(exc)
            if o.reinicia and res.codigo == 0:
                t.marcar("reinicia")
            return res.codigo, None

        try:
            t = self.gestor.lanzar(titulo, cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_trabajos(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"trabajos": self.gestor.recientes()})

    def _h_trabajo(self, h: BaseHTTPRequestHandler, id_: str) -> None:
        t = self.gestor.obtener(id_)
        if t is None:
            self._json(h, 404, {"error": "trabajo desconocido"})
            return
        try:
            desde = int(parse_qs(urlparse(h.path).query).get("desde", ["0"])[0])
        except ValueError:
            desde = 0
        self._json(h, 200, t.vista(desde))

    def _h_trabajo_cancelar(self, h: BaseHTTPRequestHandler, id_: str) -> None:
        if not self.gestor.cancelar(id_):
            self._json(h, 404, {"error": "trabajo desconocido"})
            return
        self._json(h, 200, {"ok": True})

    # -- fase 2 -------------------------------------------------------------

    def _h_f2_plan(self, h: BaseHTTPRequestHandler) -> None:
        destinos = {k: {"panel": v[0], "texto": v[1]} for k, v in fase2.DESTINOS.items()}
        self._json(h, 200, {"plan": self.f2.vista(), "destinos": destinos, "asistentes": fase2.ASISTENTES})

    def _h_f2_estado(self, h: BaseHTTPRequestHandler) -> None:
        try:
            est = self.f2.estado_remoto()
        except fase2.ErrorSinRepo:
            self._json(h, 200, {"etapas": [], "sin_repo": True})
            return
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._json(h, 502, {"error": str(exc), "codigo": "estado"})
            return
        self._json(h, 200, {"etapas": [e.json() for e in est]})

    def _h_f2_bloque(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        etapa, paso = str(req.get("etapa", "")), str(req.get("paso", ""))
        idx = int(req.get("idx", 0) or 0)
        if (destino := fase2.DESTINOS.get(paso)) is not None:
            self._json(h, 409, {"error": destino[1], "codigo": "destino", "panel": destino[0]})
            return
        if fase2.ASISTENTES.get(paso):
            self._json(h, 409, {"error": "este paso se hace con su asistente en la propia etapa", "codigo": "asistente"})
            return
        titulo = f"E{etapa} · paso {paso} · bloque {idx}"

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            try:
                codigo, reinicia = self.f2.ejecutar_bloque(etapa, paso, idx, emitir)
            except (ValueError, sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth) as exc:
                return 1, str(exc)
            if reinicia:
                t.marcar("reinicia")
                emitir("\nEl servidor se está reiniciando. Espera ~1 minuto y usa «Reconectar».\n")
            return codigo, None

        try:
            t = self.gestor.lanzar(titulo, cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_f2_verificacion(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        etapa, idx = str(req.get("etapa", "")), int(req.get("idx", 0) or 0)
        titulo = f"E{etapa} · punto de control {idx}"

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            try:
                codigo = self.f2.ejecutar_verificacion(etapa, idx, emitir)
            except (ValueError, sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth) as exc:
                return 1, str(exc)
            return codigo, None

        try:
            t = self.gestor.lanzar(titulo, cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_f2_comprobar_paso(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        paso = str(req.get("paso", ""))

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            try:
                codigo = self.f2.comprobar_paso(paso, emitir)
            except (ValueError, sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth) as exc:
                return 1, str(exc)
            return codigo, None

        try:
            t = self.gestor.lanzar(f"Paso {paso} · comprobar el acceso", cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_f2_marcar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        try:
            self.f2.marcar(str(req.get("etapa", "")), str(req.get("estado", "")), str(req.get("nota", "")))
        except fase2.ErrorSinRepo as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "sin_repo"})
            return
        except ValueError as exc:
            self._json(h, 400, {"error": str(exc)})
            return
        self.bit.registrar("etapa", str(req.get("estado", "")), "E" + str(req.get("etapa", "")))
        self._json(h, 200, {"ok": True})

    def _h_f2_informe(self, h: BaseHTTPRequestHandler) -> None:
        texto = self.f2.informe().encode("utf-8")
        self._encabezar(
            h,
            200,
            (
                ("Content-Type", "text/plain; charset=utf-8"),
                ("Content-Disposition", 'attachment; filename="informe-ux-vps.txt"'),
                ("Content-Length", str(len(texto))),
            ),
        )
        h.wfile.write(texto)

    def _h_preparacion(self, h: BaseHTTPRequestHandler) -> None:
        if not self.ses.info().conectada:
            self._json(h, 409, {"error": "conéctate primero", "codigo": "sin_sesion"})
            return
        script = """. /etc/os-release 2>/dev/null
echo "usuario=$(id -un)"
echo "os=${PRETTY_NAME:-desconocido}"
if command -v sudo >/dev/null 2>&1; then echo sudo=si; else echo sudo=no; fi
if [ -f "__INIT__" ]; then echo repo=si; else echo repo=no; fi
if [ -f "__INIT__" ]; then echo init_vps=si; else echo init_vps=no; fi
if [ -f "__INV__" ]; then echo inventario=si; else echo inventario=no; fi
if command -v ux-proyecto >/dev/null 2>&1 || [ -x /usr/local/bin/ux-project ]; then echo plataforma=si; else echo plataforma=no; fi
if id ux-caddy >/dev/null 2>&1; then echo caddy=si; else echo caddy=no; fi
""".replace("__INIT__", fase2.INIT_VPS).replace("__INV__", RUTA_INVENTARIO)
        try:
            res = self.ses.plano(script)
        except (sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth) as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ssh"})
            return
        m = ops.parsear_kv(res.stdout)
        info = self.ses.info()
        self._json(
            h,
            200,
            {
                "usuario": m.get("usuario", ""),
                "os": m.get("os", ""),
                "es_root": info.es_root,
                "sudo": m.get("sudo") == "si",
                "repo": m.get("repo") == "si",
                "init_vps": m.get("init_vps") == "si",
                "inventario": m.get("inventario") == "si",
                "plataforma": m.get("plataforma") == "si",
                "caddy": m.get("caddy") == "si",
                "debian13": any(s in m.get("os", "") for s in ("Debian GNU/Linux 13", "Ubuntu 26.04")),
            },
        )

    # -- fase 1 -------------------------------------------------------------

    def _h_f1_estado(self, h: BaseHTTPRequestHandler) -> None:
        anterior = None
        try:
            datos = Path(self.dir_config, "avance-fase1.json").read_text(encoding="utf-8")
            anterior = json.loads(datos)
        except (OSError, json.JSONDecodeError):
            pass
        self._json(
            h,
            200,
            {
                "pasos": self._f1["pasos"],
                "trabajo": self._f1["trabajo"],
                "informe": self._f1["informe"],
                "esperando": self._f1["esperando"],
                "repo": fase1.REPO_DIR,
                "anterior": anterior,
            },
        )

    def _h_f1_validar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        cfg = fase1.Config(**{k: req.get(k, fase1.Config.__dataclass_fields__[k].default) for k in fase1.Config.__dataclass_fields__})
        errores = cfg.validar(lambda r: os.path.exists(util.expandir_ruta(r)))
        self._json(h, 200, {"errores": errores or []})

    def _h_f1_ejecutar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        cfg = fase1.Config(**{k: req.get(k, fase1.Config.__dataclass_fields__[k].default) for k in fase1.Config.__dataclass_fields__})
        pf, ok = self.perf.buscar(cfg.host)
        if ok and pf.huella and not cfg.huella_esperada:
            cfg.huella_esperada = pf.huella
        cfg.ruta_llave = util.expandir_ruta(cfg.ruta_llave)
        cfg.ruta_llave_publica = util.expandir_ruta(cfg.ruta_llave_publica)
        errores = cfg.validar(lambda r: os.path.exists(util.expandir_ruta(r)))
        if errores:
            self._json(h, 422, {"error": "revisa los datos del formulario", "errores": errores})
            return
        self._f1["pasos"] = [{"id": p["id"], "nombre": p["nombre"], "estado": "pendiente"} for p in fase1.PASOS]
        self._f1["informe"] = None
        titulo = "Fase 1 · preparación inicial de " + cfg.host
        srv = self

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            prep = fase1.Preparador(cfg=cfg, salida=emitir)

            def avance(id_: str, estado: str, detalle: str = "") -> None:
                for p in srv._f1["pasos"]:
                    if p["id"] == id_:
                        p["estado"], p["detalle"] = estado, detalle
                if id_ == "_global":
                    return
                emitir(f"[{estado}] {id_} {util.truncar(detalle, 200)}\n")

            prep.avance = avance
            inf = prep.ejecutar()
            srv._f1["informe"] = inf.json()
            if not inf.ok:
                return 1, None
            admin = prep.admin_entrega()
            if admin is None:
                return 1, "la preparación terminó sin la conexión del administrador"
            srv.ses.adoptar(
                admin,
                sesion.Parametros(
                    host=cfg.host,
                    puerto=cfg.puerto,
                    usuario=cfg.usuario_admin,
                    ruta_llave=cfg.ruta_llave,
                    passphrase=cfg.passphrase,
                    password_sudo=cfg.password_sudo,
                    anclada=prep.clave,
                ),
            )
            try:
                srv.ses.validar_sudo()
            except ValueError as exc:
                emitir("AVISO: la sesión quedó abierta pero sudo no validó: " + str(exc) + "\n")
            srv.perf.guardar(
                perfiles.Perfil(
                    nombre=cfg.host,
                    host=cfg.host,
                    puerto=cfg.puerto,
                    usuario=cfg.usuario_admin,
                    ruta_llave=cfg.ruta_llave,
                    huella=prep.huella,
                    proveedor=cfg.proveedor,
                )
            )
            emitir("\nSesión de " + cfg.usuario_admin + " lista. Continúa en «Fase 2».\n")
            return 0, None

        try:
            t = self.gestor.lanzar(titulo, cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._f1["trabajo"] = t.id
        self._json(h, 202, {"trabajo": t.id})

    # -- inventario y secretos ---------------------------------------------

    def _leer_remoto(self, ruta: str) -> tuple[str, bool]:
        script = "if [ -f '" + ruta + "' ]; then cat -- '" + ruta + "'; else echo __UX_NO_EXISTE__; fi"
        r = self.ses.plano(script)
        if r.codigo != 0:
            raise ValueError("no pude leer " + ruta + ": " + util.truncar(r.stderr.strip(), 200))
        if r.stdout.strip() == "__UX_NO_EXISTE__":
            return "", False
        return r.stdout, True

    def _dir_existe(self, ruta: str) -> bool:
        return self.ses.plano("[ -d '" + ruta + "' ]").codigo == 0

    def _vista_inventario(self, texto: str) -> dict:
        return {
            "existe": True,
            "ruta": RUTA_INVENTARIO,
            "esquema": [c.json() for c in inventario.ESQUEMA],
            "valores": inventario.parsear(texto),
            "faltantes": inventario.faltantes(texto),
        }

    def _h_inventario(self, h: BaseHTTPRequestHandler) -> None:
        try:
            texto, existe = self._leer_remoto(RUTA_INVENTARIO)
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        if not existe:
            sin_repo = not self._dir_existe(DIR_INVENTARIO)
            self._json(
                h,
                200,
                {"existe": False, "sin_repo": sin_repo, "ruta": RUTA_INVENTARIO, "esquema": [c.json() for c in inventario.ESQUEMA]},
            )
            return
        self._json(h, 200, self._vista_inventario(texto))

    def _h_inventario_guardar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        try:
            texto, existe = self._leer_remoto(RUTA_INVENTARIO)
            if not existe:
                self._json(h, 409, {"error": "todavía no existe inventory.yaml en el VPS: créalo primero", "codigo": "sin_inventario"})
                return
            nuevo = inventario.aplicar(texto, {str(k): str(v) for k, v in (req.get("cambios") or {}).items()})
        except ValueError as exc:
            self._json(h, 422, {"error": str(exc), "codigo": "validacion"})
            return
        except (sesion.ErrorSinSesion, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        try:
            self.ses.escribir(RUTA_INVENTARIO, nuevo)
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        claves_ = sorted((req.get("cambios") or {}).keys())
        self.bit.registrar("inventario", "guardado", ",".join(claves_))
        self._json(h, 200, self._vista_inventario(nuevo))

    def _h_inventario_crear(self, h: BaseHTTPRequestHandler) -> None:
        info = self.ses.info()
        if not info.conectada:
            self._json(h, 409, {"error": "conéctate primero", "codigo": "sin_sesion"})
            return
        try:
            _, existe = self._leer_remoto(RUTA_INVENTARIO)
            if existe:
                self._json(h, 409, {"error": "ya existe inventory.yaml: no se pisa", "codigo": "existe"})
                return
            if not self._dir_existe(DIR_INVENTARIO):
                self._json(h, 409, {"error": "el protocolo todavía no está en el VPS: la app lo instala en la «Fase 1 · Preparar el VPS». Después podrás editar el inventario aquí", "codigo": "sin_repo"})
                return
            texto = inventario.generar(inventario.Datos(ip=info.host, huella=info.huella, usuario_admin=info.usuario, ruta_llave=info.ruta_llave))
            self.ses.escribir(RUTA_INVENTARIO, texto)
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        self.bit.registrar("inventario", "creado", RUTA_INVENTARIO)
        self._json(h, 200, self._vista_inventario(texto))

    def _h_secretos(self, h: BaseHTTPRequestHandler) -> None:
        try:
            texto, existe = self._leer_remoto(RUTA_SECRETOS_VPS)
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        vals = inventario.parsear_secretos(texto)
        res = []
        conocido = set()
        for sc in inventario.SECRETOS_CONOCIDOS:
            conocido.add(sc.nombre)
            res.append({**sc.json(), "definido": vals.get(sc.nombre, "") != "", "conocido": True})
        for k in sorted(k for k in vals if k not in conocido):
            res.append({"nombre": k, "etiqueta": k, "grupo": "Otros", "ayuda": "", "definido": vals.get(k, "") != "", "conocido": False})
        sin_repo = False
        if not existe:
            sin_repo = not self._dir_existe(DIR_INVENTARIO)
        self._json(h, 200, {"existe": existe, "sin_repo": sin_repo, "ruta": RUTA_SECRETOS_VPS, "secretos": res})

    def _h_secretos_guardar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        try:
            for n, v in (req.get("valores") or {}).items():
                inventario.validar_secreto(str(n), str(v))
            for n in req.get("borrar") or []:
                inventario.validar_secreto(str(n), "")
            texto, _ = self._leer_remoto(RUTA_SECRETOS_VPS)
            if not self._dir_existe(DIR_INVENTARIO):
                self._json(h, 409, {"error": "el protocolo todavía no está en el VPS: la app lo instala en la «Fase 1 · Preparar el VPS»", "codigo": "sin_repo"})
                return
        except ValueError as exc:
            self._json(h, 422, {"error": str(exc), "codigo": "validacion"})
            return
        except (sesion.ErrorSinSesion, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        vals = inventario.parsear_secretos(texto)
        cambiados = []
        for n, v in (req.get("valores") or {}).items():
            if v:
                vals[str(n)] = str(v)
                cambiados.append(str(n))
        for n in req.get("borrar") or []:
            vals.pop(str(n), None)
            cambiados.append("-" + str(n))
        try:
            self.ses.escribir(RUTA_SECRETOS_VPS, inventario.generar_secretos(vals))
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        cambiados.sort()
        self.bit.registrar("secretos", "guardado", ",".join(cambiados))  # solo nombres, nunca valores
        self._json(h, 200, {"ok": True})

    # -- age (claves locales) ----------------------------------------------

    def _age_dir(self) -> Path:
        dir_ = Path(self.dir_config) / "age"
        dir_.mkdir(parents=True, exist_ok=True, mode=0o700)
        return dir_

    def _age_generar_local(self, nombre: str) -> tuple[str, str]:
        import subprocess

        try:
            r = subprocess.run(["age-keygen"], capture_output=True, text=True, timeout=15)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ValueError(f"no pude ejecutar age-keygen: {exc}") from exc
        if r.returncode != 0:
            raise ValueError("age-keygen falló")
        lineas = r.stdout.strip().splitlines()
        publica = next(
            (l.split(": ", 1)[1].strip() for l in lineas if l.startswith("# public key:")), ""
        )
        secreta = lineas[-1]
        ruta = self._age_dir() / (nombre + ".key")
        if ruta.exists():
            raise FileExistsError(str(ruta))
        fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(f"# created: {time.strftime('%Y-%m-%dT%H:%M:%S%z')}\n# public key: {publica}\n{secreta}\n")
        os.chmod(ruta, 0o600)
        return str(ruta), publica

    def _h_age_generar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        nombre = str(req.get("nombre", ""))
        if not acceso.es_nombre_llave(nombre):
            self._json(h, 400, {"error": "nombre no válido (letras, dígitos, punto, guion; hasta 60)"})
            return
        try:
            ruta, publica = self._age_generar_local(nombre)
        except FileExistsError as exc:
            self._json(h, 409, {"error": "ya existe una clave con ese nombre: no la sobrescribo", "codigo": "existe", "ruta": str(exc)})
            return
        except ValueError as exc:
            self._json(h, 500, {"error": str(exc)})
            return
        self.bit.registrar("age", "generada", publica + " en " + ruta)
        self._json(h, 200, {"ruta": ruta, "publica": publica})

    def _h_age_publica(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        ruta = util.expandir_ruta(str(req.get("ruta", "")))
        try:
            ops._identidad_age(ruta)
        except Exception:  # noqa: BLE001
            self._json(h, 400, {"error": "el archivo no contiene una clave age"})
            return
        try:
            publica = ops._publica_age(ruta)
        except Exception:  # noqa: BLE001
            self._json(h, 400, {"error": "clave age no válida"})
            return
        self._json(h, 200, {"publica": publica})

    def _h_age_estado(self, h: BaseHTTPRequestHandler) -> None:
        import subprocess

        claves_ = []
        dir_ = self._age_dir()
        for ruta in sorted(dir_.glob("*.key")):
            publica = ""
            try:
                r = subprocess.run(["age-keygen", "-y", str(ruta)], capture_output=True, text=True, timeout=15)
                if r.returncode == 0:
                    publica = r.stdout.strip().splitlines()[0]
            except (OSError, subprocess.TimeoutExpired):
                pass
            claves_.append({"nombre": ruta.stem, "ruta": str(ruta), "publica": publica})
        self._json(h, 200, {"claves": claves_})

    def _h_age_descargar(self, h: BaseHTTPRequestHandler) -> None:
        nombre = parse_qs(urlparse(h.path).query).get("nombre", [""])[0]
        if not acceso.es_nombre_llave(nombre):
            self._json(h, 400, {"error": "nombre no válido"})
            return
        ruta = self._age_dir() / (nombre + ".key")
        if not ruta.is_file():
            self._json(h, 404, {"error": "no existe esa clave"})
            return
        datos = ruta.read_bytes()
        self._encabezar(
            h,
            200,
            (
                ("Content-Type", "text/plain; charset=utf-8"),
                ("Content-Disposition", f'attachment; filename="{nombre}.key"'),
                ("Content-Length", str(len(datos))),
            ),
        )
        h.wfile.write(datos)

    # -- dominios -----------------------------------------------------------

    def _h_dominios(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        dominios = [str(d) for d in (req.get("dominios") or [])]
        if not 1 <= len(dominios) <= 50:
            self._json(h, 400, {"error": "indica entre 1 y 50 dominios"})
            return
        info = self.ses.info()
        if not info.host:
            self._json(h, 409, {"error": "conéctate primero para saber la IP del VPS", "codigo": "sin_sesion"})
            return
        ip = info.host
        if not util.es_ip(ip):
            try:
                import socket as socket_mod

                ip = sorted({a[4][0] for a in socket_mod.getaddrinfo(ip, None)})[0]
            except OSError:
                self._json(h, 502, {"error": "no pude resolver la dirección del VPS"})
                return
        self._json(h, 200, {"ip": ip, "dominios": ops.comprobar_dominios(ip, dominios)})

    # -- cloudflare ---------------------------------------------------------

    def _h_cf_token(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        token = str(req.get("token", ""))
        if not token:
            self._json(h, 400, {"error": "falta el token de Cloudflare"})
            return
        try:
            cliente = cloudflare.Cliente(token)
            cuentas = cliente.verificar()
        except cloudflare.Error as exc:
            self._json(h, 400, {"error": str(exc)[len("Cloudflare: ") :], "codigo": "token"})
            return
        self._cf = cliente
        self.bit.registrar("cloudflare", "token-verificado", f"{len(cuentas)} cuenta(s)")
        self._json(h, 200, {"cuentas": cuentas})

    def _h_cf_estado(self, h: BaseHTTPRequestHandler) -> None:
        cuentas = []
        if self._cf is not None:
            try:
                cuentas = self._cf.verificar()
            except cloudflare.Error:
                cuentas = []
        self._json(h, 200, {"token": self._cf is not None, "cuentas": cuentas})

    def _h_cf_olvidar(self, h: BaseHTTPRequestHandler) -> None:
        self._cf = None
        self._json(h, 200, {"ok": True})

    def _h_cf_dns(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        dominios = [str(d) for d in (req.get("dominios") or [])]
        if not dominios:
            self._json(h, 400, {"error": "indica al menos un dominio"})
            return
        info = self.ses.info()
        if not info.host:
            self._json(h, 409, {"error": "conéctate primero", "codigo": "sin_sesion"})
            return
        ip = str(req.get("ip") or info.host)
        cf = self._cf

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            if cf is None:
                return 1, "pega primero el token de Cloudflare en el panel"
            for d in dominios:
                try:
                    estado = cf.registro_a(d, ip)
                    emitir(f"{d}: {estado}\n")
                except cloudflare.Error as exc:
                    return 1, f"{d}: {exc.msg}"
            emitir("Registros DNS listos (solo DNS, sin proxy: Caddy pide los certificados).\n")
            return 0, None

        try:
            t = self.gestor.lanzar("Cloudflare · registros DNS", cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_cf_r2(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        cuenta = str(req.get("cuenta", ""))
        bucket = str(req.get("bucket", ""))
        proyecto = str(req.get("proyecto", ""))
        dias_bloqueo = int(req.get("dias_bloqueo", 0) or 0)
        cf = self._cf
        env = self.env

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            if cf is None:
                return 1, "pega primero el token de Cloudflare en el panel"
            try:
                if cf.bucket(cuenta, bucket):
                    emitir(f"Bucket {bucket} creado\n")
                else:
                    emitir(f"Bucket {bucket} ya existía\n")
                cf.ciclo_de_vida(cuenta, bucket, dias_bloqueo)
                emitir("Ciclo de vida aplicado (diario 14 d, semanal 56, mensual 365, pre-deploy 30)\n")
                clave_id, clave_secreta = cf.token_r2(cuenta, bucket)
                emitir("Token de R2 creado y restringido al bucket\n")
            except cloudflare.Error as exc:
                return 1, exc.msg
            # Las credenciales se escriben en el VPS (nunca en la interfaz).
            op = self.cat.buscar("proyectos.r2")
            if op is None:
                return 1, "catálogo sin la operación de R2"
            p = {
                "proyecto": proyecto,
                "cuenta": cuenta,
                "clave_id": clave_id,
                "clave_secreta": clave_secreta,
            }
            try:
                res = op.correr(env, p, emitir)
            except (sesion.ErrorSinSesion, ops.ErrorOp, ssh.ErrorRed, ValueError) as exc:
                return 1, str(exc)
            if res.codigo != 0:
                return res.codigo, None
            emitir("Credenciales de R2 instaladas en el VPS.\n")
            return 0, None

        try:
            t = self.gestor.lanzar("Cloudflare · bucket y token de R2", cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    # -- totp (2FA) ---------------------------------------------------------

    def _h_totp_estado(self, h: BaseHTTPRequestHandler) -> None:
        self._json(h, 200, {"activo": bool(self._totp["activo"]), "cuenta": self._totp["cuenta"] or ""})

    def _h_totp_preparar(self, h: BaseHTTPRequestHandler) -> None:
        info = self.ses.info()
        if not info.conectada:
            self._json(h, 409, {"error": "conéctate primero", "codigo": "sin_sesion"})
            return
        secreto = totp_mod.nuevo_secreto()
        respaldo = totp_mod.codigos_respaldo(5)
        cuenta = f"{info.usuario}@{info.host}"
        svg = qr.codificar(totp_mod.uri("UX-VPS", cuenta, secreto)).svg()
        self._totp = {"secreto": secreto, "respaldo": respaldo, "cuenta": cuenta, "activo": False}
        self._json(h, 200, {"qr_svg": svg, "respaldo": respaldo, "cuenta": cuenta})

    def _h_totp_activar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        codigo = str(req.get("codigo", "")).strip()
        if not self._totp["secreto"]:
            self._json(h, 409, {"error": "prepara primero el 2FA", "codigo": "sin_preparar"})
            return
        if not totp_mod.verificar(self._totp["secreto"], codigo):
            self._json(h, 422, {"error": "el código no coincide con el de tu app de autenticación", "codigo": "codigo"})
            return
        info = self.ses.info()
        destino = "/root/.google_authenticator" if info.es_root else f"/home/{info.usuario}/.google_authenticator"
        contenido = totp_mod.archivo_google_authenticator(self._totp["secreto"], self._totp["respaldo"])
        try:
            self.ses.escribir(destino, contenido)
        except (sesion.ErrorSinSesion, ValueError, ssh.ErrorRed) as exc:
            self._mapa_ops(h, exc)
            return
        self._totp["activo"] = True
        self.bit.registrar("totp", "activado", info.usuario + "@" + info.host)
        self._json(h, 200, {"ok": True})

    def _h_totp_desactivar(self, h: BaseHTTPRequestHandler) -> None:
        info = self.ses.info()
        if info.conectada:
            destino = "/root/.google_authenticator" if info.es_root else f"/home/{info.usuario}/.google_authenticator"
            try:
                self.ses.plano("rm -f " + util.comillas(destino) + " 2>/dev/null; true")
            except (sesion.ErrorSinSesion, ssh.ErrorRed):
                pass
        self._totp["activo"] = False
        self._totp["secreto"] = ""
        self._json(h, 200, {"ok": True})

    # -- acceso (E01 en la PC) ---------------------------------------------

    def _h_acceso_contexto(self, h: BaseHTTPRequestHandler) -> None:
        info = self.ses.info()
        ruta = acceso.ruta_known_hosts()
        entradas = []
        if info.host:
            entradas = [e.json() for e in acceso.buscar(ruta, info.host, info.puerto)]
        self._json(h, 200, {"known_hosts": ruta, "entradas": entradas, "host": info.host, "puerto": info.puerto})

    def _h_acceso_llave(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        self._json(h, 200, acceso.inspeccionar_llave(str(req.get("ruta", ""))).json())

    def _h_acceso_revisar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        host = util.validar_host(str(req.get("host", "")))
        puerto = util.validar_puerto(req.get("puerto", 22))
        try:
            clave = ssh.escanear_clave_host(host, puerto)
        except ssh.ErrorRed as exc:
            self._json(h, 502, {"error": str(exc), "codigo": "red"})
            return
        huella_ = ssh.huella(clave)
        ruta = acceso.ruta_known_hosts()
        en_known_hosts = [e.json() for e in acceso.buscar(ruta, host, puerto)]
        resp: dict = {
            "huella": huella_,
            "tipo": clave.get_name(),
            "host": host,
            "puerto": puerto,
            "en_known_hosts": en_known_hosts,
            "coincide_known_hosts": any(e["huella"] == huella_ for e in en_known_hosts),
        }
        perfil, ok = self.perf.buscar(host)
        if ok and perfil.huella:
            resp["perfil_huella"] = perfil.huella
            resp["coincide_perfil"] = perfil.huella == huella_
        self._json(h, 200, resp)

    def _h_acceso_probar(self, h: BaseHTTPRequestHandler) -> None:
        srv = self

        def cuerpo(cancelar, emitir, t) -> tuple[int, str | None]:
            try:
                codigo = srv.f2.comprobar_paso("2.4", emitir)
            except (ValueError, sesion.ErrorSinSesion, ssh.ErrorRed, ssh.ErrorAuth) as exc:
                return 1, str(exc)
            return codigo, None

        try:
            t = self.gestor.lanzar("Paso 2.4 · comprobar el acceso desde tu PC", cuerpo)
        except jobs.ErrorOcupado as exc:
            self._json(h, 409, {"error": str(exc), "codigo": "ocupado"})
            return
        self._json(h, 202, {"trabajo": t.id})

    def _h_acceso_limpiar(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        host = util.validar_host(str(req.get("host", "")))
        puerto = util.validar_puerto(req.get("puerto", 22))
        conservar = str(req.get("conservar", "") or "")
        quitadas, copia = acceso.quitar(acceso.ruta_known_hosts(), host, puerto, conservar)
        self._json(h, 200, {"quitadas": quitadas, "copia": copia})

    def _h_acceso_instalar_llave(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        host = util.validar_host(str(req.get("host", "")))
        puerto = util.validar_puerto(req.get("puerto", 22))
        try:
            clave = ssh.escanear_clave_host(host, puerto)
        except ssh.ErrorRed as exc:
            self._json(h, 502, {"error": str(exc), "codigo": "red"})
            return
        anadida = acceso.anadir(acceso.ruta_known_hosts(), host, puerto, clave)
        self._json(h, 200, {"anadida": anadida, "huella": ssh.huella(clave)})

    def _h_acceso_regenerar_publica(self, h: BaseHTTPRequestHandler) -> None:
        req = self._leer(h)
        try:
            linea = keys.regenerar_publica(str(req.get("ruta", "")), str(req.get("passphrase", "")))
        except (keys.ErrorPassphrase, ValueError) as exc:
            self._json(h, 400, {"error": str(exc)})
            return
        self._json(h, 200, {"publica": linea})

    def _mapa_ops(self, h: BaseHTTPRequestHandler, exc: Exception) -> None:
        if isinstance(exc, sesion.ErrorSinSesion):
            self._json(h, 409, {"error": str(exc), "codigo": "sin_sesion"})
        elif isinstance(exc, (ssh.ErrorRed, ssh.ErrorAuth)):
            self._json(h, 502, {"error": str(exc), "codigo": "ssh"})
        else:
            self._json(h, 400, {"error": str(exc), "codigo": "otro"})

    def _mapa_error(self, h: BaseHTTPRequestHandler, exc: Exception) -> None:
        if isinstance(exc, ssh.ErrorPassphrase):
            self._json(h, 401, {"error": str(exc), "codigo": "passphrase"})
        elif isinstance(exc, ssh.ErrorAuth):
            self._json(h, 401, {"error": str(exc), "codigo": "auth"})
        elif isinstance(exc, ssh.ErrorHuellaAnclada):
            self._json(h, 409, {"error": str(exc), "codigo": "huella"})
        elif isinstance(exc, ssh.ErrorRed):
            self._json(h, 502, {"error": str(exc), "codigo": "red"})
        else:
            self._json(h, 400, {"error": str(exc), "codigo": "otro"})


def _resumen_op(o: "ops.Op", p: dict) -> str:
    """Describe una operación para la bitácora SIN valores secretos ni contenidos."""
    partes = []
    for c in o.campos:
        v = p.get(c.nombre, "")
        if not v:
            continue
        if c.secreto:
            partes.append(c.nombre + "=••••••")
        elif c.tipo == "llave_ci":
            partes.append(c.nombre + "=(llave pública)")
        elif c.tipo == "contenido":
            partes.append(c.nombre + f"=({len(v)} bytes)")
        else:
            partes.append(c.nombre + "=" + util.truncar(v, 60))
    partes.sort()
    return o.id + " " + " ".join(partes)


_RUTAS: dict[tuple[str, str], object] = {
    ("GET", "/api/estado"): Servidor._h_estado,
    ("GET", "/api/perfiles"): Servidor._h_perfiles,
    ("POST", "/api/perfiles/eliminar"): Servidor._h_perfil_eliminar,
    ("GET", "/api/llaves"): Servidor._h_llaves,
    ("POST", "/api/llaves/generar"): Servidor._h_llave_generar,
    ("POST", "/api/huella"): Servidor._h_huella,
    ("POST", "/api/conectar"): Servidor._h_conectar,
    ("POST", "/api/reconectar"): Servidor._h_reconectar,
    ("POST", "/api/desconectar"): Servidor._h_desconectar,
    ("POST", "/api/salir"): Servidor._h_salir,
    ("GET", "/api/version/nueva"): Servidor._h_version_nueva,
    ("GET", "/api/bitacora"): Servidor._h_bitacora,
    ("GET", "/api/consola"): Servidor._h_consola,
    ("GET", "/api/latido"): Servidor._h_latido,
    ("POST", "/api/pestana/latido"): Servidor._h_latido,
    ("POST", "/api/pestana/cierre"): Servidor._h_latido,
    ("GET", "/api/ops/catalogo"): Servidor._h_catalogo,
    ("POST", "/api/ops/ejecutar"): Servidor._h_op_ejecutar,
    ("GET", "/api/jobs"): Servidor._h_trabajos,
    ("GET", "/api/fase2/plan"): Servidor._h_f2_plan,
    ("GET", "/api/fase2/estado"): Servidor._h_f2_estado,
    ("POST", "/api/fase2/bloque"): Servidor._h_f2_bloque,
    ("POST", "/api/fase2/verificacion"): Servidor._h_f2_verificacion,
    ("POST", "/api/fase2/comprobar-paso"): Servidor._h_f2_comprobar_paso,
    ("POST", "/api/fase2/marcar"): Servidor._h_f2_marcar,
    ("GET", "/api/fase2/informe"): Servidor._h_f2_informe,
    ("GET", "/api/preparacion"): Servidor._h_preparacion,
    ("GET", "/api/fase1/estado"): Servidor._h_f1_estado,
    ("POST", "/api/fase1/validar"): Servidor._h_f1_validar,
    ("POST", "/api/fase1/ejecutar"): Servidor._h_f1_ejecutar,
    ("GET", "/api/inventario"): Servidor._h_inventario,
    ("POST", "/api/inventario/guardar"): Servidor._h_inventario_guardar,
    ("POST", "/api/inventario/crear"): Servidor._h_inventario_crear,
    ("GET", "/api/secretos"): Servidor._h_secretos,
    ("POST", "/api/secretos/guardar"): Servidor._h_secretos_guardar,
    ("POST", "/api/age/generar"): Servidor._h_age_generar,
    ("POST", "/api/age/publica"): Servidor._h_age_publica,
    ("GET", "/api/age/estado"): Servidor._h_age_estado,
    ("GET", "/api/age/descargar"): Servidor._h_age_descargar,
    ("POST", "/api/dominios/comprobar"): Servidor._h_dominios,
    ("POST", "/api/cloudflare/token"): Servidor._h_cf_token,
    ("GET", "/api/cloudflare/estado"): Servidor._h_cf_estado,
    ("POST", "/api/cloudflare/olvidar"): Servidor._h_cf_olvidar,
    ("POST", "/api/cloudflare/dns"): Servidor._h_cf_dns,
    ("POST", "/api/cloudflare/r2"): Servidor._h_cf_r2,
    ("GET", "/api/totp/estado"): Servidor._h_totp_estado,
    ("POST", "/api/totp/preparar"): Servidor._h_totp_preparar,
    ("POST", "/api/totp/activar"): Servidor._h_totp_activar,
    ("POST", "/api/totp/desactivar"): Servidor._h_totp_desactivar,
    ("GET", "/api/acceso/contexto"): Servidor._h_acceso_contexto,
    ("POST", "/api/acceso/llave"): Servidor._h_acceso_llave,
    ("POST", "/api/acceso/revisar"): Servidor._h_acceso_revisar,
    ("POST", "/api/acceso/probar"): Servidor._h_acceso_probar,
    ("POST", "/api/acceso/comprobar"): Servidor._h_acceso_probar,
    ("POST", "/api/acceso/limpiar"): Servidor._h_acceso_limpiar,
    ("POST", "/api/acceso/instalar-llave"): Servidor._h_acceso_instalar_llave,
    ("POST", "/api/acceso/regenerar-publica"): Servidor._h_acceso_regenerar_publica,
}

_RUTAS_RE: dict[str, list[tuple[object, object]]] = {
    "GET": [
        (re.compile(r"^/api/jobs/([a-f0-9]{12})$"), Servidor._h_trabajo),
    ],
    "POST": [
        (re.compile(r"^/api/jobs/([a-f0-9]{12})/cancelar$"), Servidor._h_trabajo_cancelar),
    ],
}
