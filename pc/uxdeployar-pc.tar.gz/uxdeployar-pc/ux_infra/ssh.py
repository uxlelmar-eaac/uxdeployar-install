"""Transporte SSH de la app: cliente con **paramiko**, huella del host **anclada**,
autenticación por llave / contraseña / segundo factor TOTP y ejecución de comandos
con salida en tiempo real.

Espejo de ``05-vps/app/internal/sshx/sshx.go``. Decisiones de fidelidad:

* La clave del host se **ancla** (comparación byte a byte) y, si cambia, se
  detiene: nunca se continúa contra un servidor distinto.
* ``escanear_clave_host`` lee la clave **sin autenticar**: no envía ningún secreto.
* Los secretos viajan por **stdin**, nunca como argumento de línea de comandos.
* Como máximo ``MAX_SESIONES`` sesiones a la vez (el ``sshd`` endurecido usa
  ``MaxSessions 2`` y rechaza la tercera).

El objeto :class:`Cliente` no contiene lógica de negocio: solo ejecuta comandos
fijos que le entrega la capa de operaciones.
"""

from __future__ import annotations

import base64
import codecs
import hashlib
import socket
import threading
import time
from dataclasses import dataclass, field
from typing import Callable

try:  # pragma: no cover - la ausencia de paramiko se explica en el lanzador
    import paramiko
except ImportError as exc:  # noqa: BLE001
    raise ImportError(
        "Falta la dependencia 'paramiko'. Instálala con:\n"
        "    python -m pip install -r tools/ux-infra/requisitos.txt\n"
        "o usa el lanzador ux-infra.py, que crea el entorno por ti."
    ) from exc

__all__ = [
    "ErrorRed",
    "ErrorAuth",
    "ErrorPassphrase",
    "ErrorHuellaAnclada",
    "ErrorCancelado",
    "MAX_SESIONES",
    "huella",
    "escanear_clave_host",
    "cargar_firmante",
    "Config",
    "Resultado",
    "Cliente",
]

# Coincide con «MaxSessions 2» de la etapa E03 del manual.
MAX_SESIONES = 2
_TIMEOUT = 15.0
_TOPE_SALIDA = 512 * 1024

# Algoritmos modernos. El sshd endurecido del estándar (E03) solo ofrece
# curve25519-sha256 / sntrup761x25519-sha512@openssh.com, chacha20-poly1305 y
# aes256-gcm, y MACs *-etm. No se incluye nada obsoleto (CBC, 3DES, SHA-1).
KEX_PREFERIDOS = (
    "curve25519-sha256",
    "curve25519-sha256@libssh.org",
    "ecdh-sha2-nistp256",
    "ecdh-sha2-nistp384",
    "ecdh-sha2-nistp521",
    "diffie-hellman-group-exchange-sha256",
    "diffie-hellman-group16-sha512",
    "diffie-hellman-group14-sha256",
)
CIFRADOS_PREFERIDOS = (
    "aes256-gcm@openssh.com",
    "aes128-gcm@openssh.com",
    "aes256-ctr",
    "aes192-ctr",
    "aes128-ctr",
)
MACS_PREFERIDOS = (
    "hmac-sha2-512-etm@openssh.com",
    "hmac-sha2-256-etm@openssh.com",
    "hmac-sha2-512",
    "hmac-sha2-256",
)

_REGISTROS = {
    "kex": "_kex_info",
    "ciphers": "_cipher_info",
    "digests": "_mac_info",
    "key_types": "_key_info",
}


def _registrar_kex_estandar() -> None:
    """Registra el nombre estándar ``curve25519-sha256`` (RFC 8731).

    paramiko solo registra el nombre del borrador (``curve25519-sha256@libssh.org``),
    que es **el mismo algoritmo**; el ``sshd`` endurecido del estándar (etapa E03)
    anuncia el nombre estándar y, como SSH compara los nombres literalmente, sin
    este alias no habría ningún KEX en común. Se le asigna la misma implementación:
    no se agrega ni se debilita ningún algoritmo.
    """
    info = paramiko.Transport._kex_info
    if "curve25519-sha256" in info:
        return
    clase = info.get("curve25519-sha256@libssh.org")
    if clase is not None:
        info["curve25519-sha256"] = clase


def _aplicar_algoritmos(transporte: "paramiko.Transport", anclada=None) -> None:
    """Fija la lista de algoritmos (solo los modernos) antes del intercambio de claves."""
    _registrar_kex_estandar()
    opciones = transporte.get_security_options()

    def asignar(atributo: str, deseados: tuple[str, ...]) -> None:
        registro = getattr(paramiko.Transport, _REGISTROS[atributo])
        disponibles = [n for n in deseados if n in registro]
        if disponibles:
            setattr(opciones, atributo, tuple(disponibles))

    asignar("kex", KEX_PREFERIDOS)
    asignar("ciphers", CIFRADOS_PREFERIDOS)
    asignar("digests", MACS_PREFERIDOS)
    if anclada is not None:
        # Solo el tipo de la clave anclada, igual que el original (algoritmosPara).
        tipo = anclada.get_name()
        if tipo == "ssh-rsa":
            asignar("key_types", ("rsa-sha2-512", "rsa-sha2-256"))
        elif tipo:
            asignar("key_types", (tipo,))


class ErrorRed(Exception):
    """No se pudo conectar (red, transporte caído)."""


class ErrorAuth(Exception):
    """No se pudo autenticar, o la credencial no sirve."""


class ErrorPassphrase(Exception):
    """La llave privada pide passphrase."""


class ErrorCancelado(Exception):
    """Cancelado desde la interfaz."""


class ErrorHuellaAnclada(Exception):
    """La huella del servidor no coincide con la anclada (posible MITM)."""

    def __init__(self, obtenida: str, esperada: str) -> None:
        self.obtenida = obtenida
        self.esperada = esperada
        super().__init__(
            f"la huella del servidor ({obtenida}) NO coincide con la anclada ({esperada})"
        )


def huella(clave: "paramiko.PKey") -> str:
    """Huella SHA-256 en el formato de ``ssh-keygen -lf`` (``SHA256:…``, sin relleno)."""
    resumen = hashlib.sha256(clave.asbytes()).digest()
    return "SHA256:" + base64.b64encode(resumen).decode("ascii").rstrip("=")


def escanear_clave_host(host: str, puerto: int, timeout: float = _TIMEOUT) -> "paramiko.PKey":
    """Captura la clave pública del host **sin autenticar**.

    No se envía ningún secreto: sirve para mostrar la huella y anclarla antes de
    conectar (o para compararla con la que muestra el proveedor).
    """
    try:
        sock = socket.create_connection((host, puerto), timeout=timeout)
    except OSError as exc:
        raise ErrorRed(f"no se pudo conectar: {exc}") from exc
    transporte = paramiko.Transport(sock)
    try:
        _aplicar_algoritmos(transporte)
        transporte.start_client(timeout=timeout)
        clave = transporte.get_remote_server_key()
    except Exception as exc:  # noqa: BLE001
        raise ErrorRed(f"no se pudo conectar: {exc}") from exc
    finally:
        try:
            transporte.close()
        except Exception:  # noqa: BLE001
            pass
    if clave is None:
        raise ErrorRed("el servidor no entregó su clave")
    return clave


def cargar_firmante(ruta: str, passphrase: str = ""):
    """Lee una llave privada (con o sin passphrase) y devuelve el firmante."""
    try:
        return paramiko.PKey.from_path(ruta, password=passphrase or None)
    except paramiko.PasswordRequiredException as exc:
        raise ErrorPassphrase("la llave pide passphrase") from exc
    except FileNotFoundError as exc:
        raise ErrorAuth(f"no pude leer la llave privada: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        texto = str(exc).lower()
        if passphrase and ("decrypt" in texto or "password" in texto or "bad" in texto):
            raise ErrorAuth("passphrase incorrecta") from exc
        raise ErrorAuth(f"llave privada no válida: {exc}") from exc


def handler_interactivo(contrasena: str, totp: str) -> Callable[[str, str, list], list[str]]:
    """Responde los prompts del teclado-interactivo (contraseña y/o código TOTP).

    Misma lógica que el original: un prompt que pide un código se responde con el
    TOTP; cualquier otro, con la contraseña.

    Nota: según la versión de paramiko, cada prompt llega como texto o como tupla
    ``(texto, eco)``; aquí se aceptan las dos formas.
    """

    def responder(_titulo: str, _instruccion: str, preguntas: list) -> list[str]:
        respuestas = []
        for item in preguntas:
            texto = item[0] if isinstance(item, (tuple, list)) else item
            pl = str(texto).lower()
            if totp and any(
                k in pl for k in ("code", "código", "codigo", "otp", "token", "verification")
            ):
                respuestas.append(totp)
            elif contrasena:
                respuestas.append(contrasena)
            elif totp:
                respuestas.append(totp)
            else:
                respuestas.append("")
        return respuestas

    return responder


@dataclass
class Config:
    """Describe una conexión. Los secretos viven solo en memoria."""

    host: str
    puerto: int = 22
    usuario: str = ""
    contrasena: str = ""
    ruta_llave: str = ""
    passphrase: str = ""
    totp: str = ""
    anclada: "paramiko.PKey | None" = None
    timeout: float = _TIMEOUT

    def direccion(self) -> str:
        return f"{self.host}:{self.puerto}"


@dataclass
class Resultado:
    """Resultado de un comando remoto."""

    codigo: int = 0
    stdout: str = ""
    stderr: str = ""


@dataclass
class _Acumulador:
    tope: int
    datos: bytearray = field(default_factory=bytearray)

    def anexar(self, trozo: bytes) -> None:
        restante = self.tope - len(self.datos)
        if restante > 0:
            self.datos.extend(trozo[:restante])

    def texto(self) -> str:
        return self.datos.decode("utf-8", errors="replace")


class Cliente:
    """Conexión autenticada y reutilizable."""

    def __init__(self, transporte: "paramiko.Transport", cfg: Config) -> None:
        self._t = transporte
        self._cfg = cfg
        self._sem = threading.Semaphore(MAX_SESIONES)
        self._cerrado = False

    # -- ciclo de vida ------------------------------------------------------

    @classmethod
    def dial(cls, cfg: Config) -> "Cliente":
        """Abre una conexión con la clave del host **anclada**."""
        if cfg.anclada is None:
            raise ErrorAuth("falta la clave del host anclada")
        timeout = cfg.timeout if cfg.timeout > 0 else _TIMEOUT
        try:
            sock = socket.create_connection((cfg.host, cfg.puerto), timeout=timeout)
        except OSError as exc:
            raise ErrorRed(f"no se pudo conectar: {exc}") from exc
        transporte = paramiko.Transport(sock)
        try:
            _aplicar_algoritmos(transporte, cfg.anclada)
            transporte.start_client(timeout=timeout)
            presentada = transporte.get_remote_server_key()
            if presentada is None or presentada.asbytes() != cfg.anclada.asbytes():
                obtenida = huella(presentada) if presentada is not None else "(ninguna)"
                transporte.close()
                raise ErrorHuellaAnclada(obtenida, huella(cfg.anclada))
            cls._autenticar(transporte, cfg)
        except ErrorAuth:
            transporte.close()
            raise
        except ErrorHuellaAnclada:
            raise
        except paramiko.AuthenticationException as exc:
            transporte.close()
            raise ErrorAuth(f"no se pudo autenticar: {exc}") from exc
        except Exception as exc:  # noqa: BLE001
            transporte.close()
            raise ErrorRed(f"no se pudo conectar: {exc}") from exc
        transporte.set_keepalive(25)
        return cls(transporte, cfg)

    @staticmethod
    def _autenticar(transporte: "paramiko.Transport", cfg: Config) -> None:
        """Prueba los métodos en el mismo orden que el original: llave, contraseña, teclado-interactivo."""
        firmante = None
        if cfg.ruta_llave:
            firmante = cargar_firmante(cfg.ruta_llave, cfg.passphrase)

        intentos: list[tuple[str, Callable[[], None]]] = []
        if firmante is not None:
            intentos.append(
                ("llave", lambda: transporte.auth_publickey(cfg.usuario, firmante))
            )
        if cfg.contrasena:
            intentos.append(
                ("contraseña", lambda: transporte.auth_password(cfg.usuario, cfg.contrasena))
            )
        if cfg.totp or cfg.contrasena:
            intentos.append(
                (
                    "teclado-interactivo",
                    lambda: transporte.auth_interactive(
                        cfg.usuario, handler_interactivo(cfg.contrasena, cfg.totp)
                    ),
                )
            )

        if not intentos:
            raise ErrorAuth("falta un método de autenticación (llave o contraseña)")

        fallos: list[str] = []
        for nombre, intento in intentos:
            try:
                intento()
                return
            except paramiko.BadAuthenticationType:
                continue  # el servidor no ofrece este método: se prueba el siguiente
            except paramiko.AuthenticationException as exc:
                fallos.append(f"{nombre}: {exc}")
        raise ErrorAuth(
            "no se pudo autenticar ("
            + ("; ".join(fallos) if fallos else "ningún método aceptado por el servidor")
            + ")"
        )

    def _handler(self) -> Callable[[str, str, list[str]], list[str]]:
        """Responde los prompts del teclado-interactivo (contraseña y/o código TOTP)."""
        return handler_interactivo(self._cfg.contrasena, self._cfg.totp)

    def vivo(self) -> bool:
        """Indica si la conexión sigue utilizable.

        ``Transport.is_active`` de paramiko ya se entera de la caída en cuanto el
        hilo lector consume el FIN del servidor (milisegundos), sin sondas
        adicionales que compitan con el lector por el socket.
        """
        return not self._cerrado and self._t.is_active()

    def cerrar(self) -> None:
        self._cerrado = True
        try:
            self._t.close()
        except Exception:  # noqa: BLE001
            pass

    def __enter__(self) -> "Cliente":
        return self

    def __exit__(self, *_: object) -> None:
        self.cerrar()

    # -- ejecución ----------------------------------------------------------

    def ejecutar(
        self,
        cmd: str,
        *,
        stdin: str | bytes | None = None,
        salida: Callable[[str], None] | None = None,
        max_bytes: int = _TOPE_SALIDA,
    ) -> Resultado:
        """Ejecuta un comando fijo.

        ``stdin`` viaja por la entrada estándar (nunca en la línea de comandos).
        ``salida`` recibe la salida combinada **en tiempo real**, sin cortar
        caracteres multibyte.
        """
        if not self.vivo():
            raise ErrorRed("la sesión SSH se cerró")
        if not self._sem.acquire(timeout=self._cfg.timeout or None):
            raise ErrorCancelado("hay demasiadas operaciones en curso")

        chan = None
        try:
            chan = self._abrir_canal(cmd)
            acu_out = _Acumulador(max_bytes)
            acu_err = _Acumulador(max_bytes)
            dec_out = codecs.getincrementaldecoder("utf-8")(errors="replace")
            dec_err = codecs.getincrementaldecoder("utf-8")(errors="replace")

            def bombear(leer: Callable[[int], bytes], acu: _Acumulador, dec) -> None:
                while True:
                    try:
                        trozo = leer(65536)
                    except Exception:  # noqa: BLE001 - el canal se cerró a media lectura
                        return
                    if not trozo:
                        return
                    acu.anexar(trozo)
                    texto = dec.decode(trozo)
                    if texto and salida is not None:
                        try:
                            salida(texto)
                        except Exception:  # noqa: BLE001 - la interfaz ya no escucha
                            pass

            hilos = [
                threading.Thread(target=bombear, args=(chan.recv, acu_out, dec_out), daemon=True),
                threading.Thread(
                    target=bombear, args=(chan.recv_stderr, acu_err, dec_err), daemon=True
                ),
            ]
            for hilo in hilos:
                hilo.start()

            if stdin is None:
                chan.shutdown_write()
            else:
                datos = stdin.encode("utf-8") if isinstance(stdin, str) else stdin
                threading.Thread(target=_enviar, args=(chan, datos), daemon=True).start()

            try:
                codigo = chan.recv_exit_status()
            except Exception as exc:  # noqa: BLE001
                raise ErrorRed(f"la sesión se cortó durante el comando: {exc}") from exc
            finally:
                for hilo in hilos:
                    hilo.join(timeout=5)

            for dec, acu in ((dec_out, acu_out), (dec_err, acu_err)):
                resto = dec.decode(b"", final=True)
                if resto:
                    acu.anexar(resto.encode("utf-8"))

            return Resultado(codigo=codigo, stdout=acu_out.texto(), stderr=acu_err.texto())
        finally:
            if chan is not None:
                try:
                    chan.close()
                except Exception:  # noqa: BLE001
                    pass
            self._sem.release()

    def simple(self, cmd: str) -> str:
        """Ejecuta y devuelve stdout si el código es 0; si no, lanza con el stderr."""
        from .util import truncar

        r = self.ejecutar(cmd)
        if r.codigo != 0:
            msg = r.stderr.strip() or r.stdout.strip()
            raise ErrorRed(f"el comando falló (código {r.codigo}): {truncar(msg, 400)}")
        return r.stdout

    def ejecutar_sudo(
        self,
        cmd: str,
        contrasena: str,
        *,
        salida: Callable[[str], None] | None = None,
        max_bytes: int = _TOPE_SALIDA,
    ) -> Resultado:
        """Ejecuta ``cmd`` con sudo. La contraseña va por stdin (``sudo -S``), nunca por argumentos."""
        return self.ejecutar(
            f"sudo -S -p '' {cmd}",
            stdin=contrasena + "\n",
            salida=salida,
            max_bytes=max_bytes,
        )

    def escribir_archivo(self, ruta: str, modo: str, datos: str | bytes) -> None:
        """Guarda datos en una ruta remota (por stdin) con permisos restrictivos."""
        from .util import comillas, truncar

        cmd = f"umask 077; cat > {comillas(ruta)} && chmod {modo} {comillas(ruta)}"
        r = self.ejecutar(cmd, stdin=datos)
        if r.codigo != 0:
            raise ErrorRed(
                f"no pude escribir {ruta}: {truncar(r.stderr.strip(), 300)}"
            )

    # -- internos -----------------------------------------------------------

    def _abrir_canal(self, cmd: str):
        """Abre una sesión y envía la petición de ejecución del comando.

        Que el servidor rechace el canal por el límite de sesiones
        (``MaxSessions 2``) no significa que la conexión esté caída: se reintenta
        un momento, igual que el original.
        """
        ultimo: Exception | None = None
        for _ in range(8):
            try:
                chan = self._t.open_session()
            except paramiko.ChannelException as exc:
                ultimo = exc
                time.sleep(0.4)
                continue
            except Exception as exc:  # noqa: BLE001
                self._cerrado = True
                raise ErrorRed(f"la conexión se perdió: {exc}") from exc
            try:
                chan.exec_command(cmd)
            except paramiko.ChannelException as exc:
                ultimo = exc
                try:
                    chan.close()
                except Exception:  # noqa: BLE001
                    pass
                time.sleep(0.4)
                continue
            except Exception as exc:  # noqa: BLE001
                try:
                    chan.close()
                except Exception:  # noqa: BLE001
                    pass
                self._cerrado = True
                raise ErrorRed(f"la conexión se perdió: {exc}") from exc
            return chan
        raise ErrorRed(f"el servidor rechazó abrir la sesión: {ultimo}")


def _enviar(chan, datos: bytes) -> None:
    """Envía la entrada estándar y cierra la escritura (EOF)."""
    try:
        chan.sendall(datos)
    except Exception:  # noqa: BLE001 - si el remoto cerró antes, no hay nada que hacer
        pass
    finally:
        try:
            chan.shutdown_write()
        except Exception:  # noqa: BLE001
            pass
