"""Perfiles de conexión: solo datos NO secretos, en disco local.

Espejo de ``05-vps/app/internal/perfiles/perfiles.go``. Nunca guarda
contraseñas, passphrases ni tokens.
"""

from __future__ import annotations

import json
import os
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


def dir_config() -> Path:
    """Directorio de datos de la app (se crea si hace falta)."""
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    dir_ = base / "ux-infra"
    dir_.mkdir(parents=True, exist_ok=True, mode=0o700)
    return dir_


@dataclass
class Perfil:
    nombre: str = ""
    host: str = ""
    puerto: int = 22
    usuario: str = ""
    ruta_llave: str = ""
    metodo: str = ""  # "password" | "llave"
    huella: str = ""
    proveedor: str = ""
    actualizado: str = ""

    def json(self) -> dict:
        d = asdict(self)
        if not d["metodo"]:
            d.pop("metodo")
        if not d["proveedor"]:
            d.pop("proveedor")
        return d


class Almacen:
    """Persiste los perfiles en un JSON con permisos restrictivos."""

    def __init__(self, dir_: str | os.PathLike[str]) -> None:
        self._ruta = Path(dir_) / "perfiles.json"
        self._mu = threading.Lock()

    def ruta(self) -> str:
        return str(self._ruta)

    def _leer(self) -> list[Perfil]:
        try:
            datos = self._ruta.read_text(encoding="utf-8")
        except OSError:
            return []
        try:
            return [Perfil(**p) for p in json.loads(datos)]
        except (json.JSONDecodeError, TypeError):
            return []

    def _escribir(self, perfiles: list[Perfil]) -> None:
        datos = json.dumps([p.json() for p in perfiles], indent=2, ensure_ascii=False)
        try:
            fd = os.open(self._ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(datos)
            os.chmod(self._ruta, 0o600)
        except OSError:
            raise

    def listar(self) -> list[Perfil]:
        with self._mu:
            ps = sorted(self._leer(), key=lambda p: p.nombre)
        return ps

    def guardar(self, p: Perfil) -> None:
        if not p.host:
            raise ValueError("perfil sin host")
        if not p.nombre:
            p.nombre = p.host
        p.actualizado = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
        with self._mu:
            ps = self._leer()
            reemplazado = False
            for i, viejo in enumerate(ps):
                if viejo.host == p.host:
                    if not p.proveedor:
                        p.proveedor = viejo.proveedor
                    ps[i] = p
                    reemplazado = True
                    break
            if not reemplazado:
                ps.append(p)
            self._escribir(ps)

    def buscar(self, host: str) -> tuple[Perfil, bool]:
        for p in self.listar():
            if p.host == host:
                return p, True
        return Perfil(), False

    def eliminar(self, host: str) -> None:
        with self._mu:
            self._escribir([p for p in self._leer() if p.host != host])
