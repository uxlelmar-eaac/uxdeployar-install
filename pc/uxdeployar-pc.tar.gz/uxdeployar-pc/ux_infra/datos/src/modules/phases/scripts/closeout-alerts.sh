S="${UX_SUDO-sudo}"
# La revisión se lee del propio archivo: una ux-alerta antigua enviaría «version» como alerta.
b=$(readlink -f "$(command -v ux-alerta 2>/dev/null || echo /usr/local/bin/ux-alerta)" 2>/dev/null)
rev=$($S sed -n 's/^UX_ALERT_REV=\([0-9]*\).*/\1/p' "$b" 2>/dev/null | head -n 1)
case "$rev" in '' | *[!0-9]*) rev=0 ;; esac
if [ "$rev" -ge 2 ]; then
  out=$($S ux-alerta --estricto "prueba" 2>&1); rc=$?
else
  out=$($S ux-alerta "prueba" 2>&1); rc=0
  case "$out" in
    *"sin configuración"* | *"configuración inválida"*) rc=2 ;;
    *"no entregada"* | *"no enviada"*) rc=3 ;;
  esac
fi
[ -z "$out" ] || echo "$out"
# Desde la revisión 3, cada canal dice por qué no entregó: credenciales o un rechazo del
# servidor se corrigen en la configuración; un timeout o un error de red es externo.
motivos=$(printf '%s\n' "$out" | sed -n 's/^ux-alerta-canal \([a-z]*\) \([a-z_]*\)$/\1: \2/p' | grep -v ': ok$\|: no_configurado$' | paste -sd ',' - | sed 's/,/, /g')
causa=externo
printf '%s\n' "$out" | grep -Eq '^ux-alerta-canal [a-z]+ (credenciales|rechazado)$' && causa=valor_incorrecto
case "$rc" in
  0) echo "✔ servidor:alertas — la alerta de prueba salió por al menos un canal" ;;
  2) echo "✗ servidor:alertas — no hay ningún canal de aviso completo${motivos:+ ($motivos)} [causa=config_ausente]" ;;
  *) echo "✗ servidor:alertas — la alerta de prueba no se entregó por ningún canal${motivos:+ ($motivos)} [causa=$causa]" ;;
esac
[ "$rc" -eq 0 ]
