f=/etc/ux/firewall-inicial
if ! sudo test -s "$f"; then
  sudo mkdir -p /etc/ux
  {
    echo "registrado $(date -Is)"
    if command -v ufw >/dev/null 2>&1; then echo "ufw: $(sudo ufw status 2>/dev/null | head -1)"; else echo "ufw: no instalado"; fi
    echo "firewalld: $(sudo firewall-cmd --state 2>/dev/null || echo inactivo)"
    echo "nftables con policy drop: $(sudo nft list ruleset 2>/dev/null | grep -c 'policy drop')"
    echo "ssh: $(sudo ss -Hltnp 2>/dev/null | awk '/sshd/ {sub(/.*:/, "", $4); print $4}' | sort -un | tr '\n' ' ')"
  } | sudo tee "$f" >/dev/null
fi
echo "✔ Firewall de partida registrado en $f: E03 abre su puerto en él antes de mover SSH"
sudo cat "$f" 2>/dev/null
