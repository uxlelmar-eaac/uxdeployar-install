ss=$(sudo ss -Htln)
echo "$ss" | grep -E ':(80|443)\s' || true
echo "$ss" | grep -qE ':80\s' || { echo "Nada escucha en el 80"; exit 1; }
if ls /etc/ux/caddy/sitios/*.caddy >/dev/null 2>&1; then
  echo "$ss" | grep -qE ':443\s' || { echo "Hay sitios publicados pero nada escucha en el 443"; exit 1; }
else
  echo "Sin sitios publicados: el 443 se abrirá con el primero."
fi
