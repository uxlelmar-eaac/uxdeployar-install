f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
id ux-caddy >/dev/null 2>&1 || { echo "No aplica: Caddy (E12) todavía no está instalado"; exit 0; }
esc=$(sudo ss -Htln 2>/dev/null | awk '{print $4}' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
n=$(ls /etc/ux/caddy/sitios/*.caddy 2>/dev/null | wc -l)
for p in 80 443; do
  if grep -qx "$p" <<<"$esc"; then ok "el puerto $p escucha (Caddy)"
  elif [ "$p" = 443 ] && [ "$n" -eq 0 ]; then echo "· el 443 no escucha: aún no hay sitios publicados, Caddy lo abrirá con el primero"
  else ko "nada escucha en el puerto $p: Caddy no puede validar ni servir certificados (usa «Reparar la escucha web»)"; fi
done
l=$(sudo ux-as ux-caddy podman logs --since 24h caddy 2>&1 | grep -iE 'could not get certificate|obtaining certificate.*(error|fail)|challenge failed|no solvers|rate.?limit|too many certificates' | tail -n 2)
if [ -z "$l" ]; then ok "Caddy no registró errores de certificados en las últimas 24 h"
else
  while IFS= read -r x; do ko "Caddy: $(echo "$x" | sed -E 's/.*"msg":"([^"]*)".*"identifier":"([^"]*)".*/\1 (\2)/' | cut -c1-180)"; done <<<"$l"
fi
[ "$f" -eq 0 ]
