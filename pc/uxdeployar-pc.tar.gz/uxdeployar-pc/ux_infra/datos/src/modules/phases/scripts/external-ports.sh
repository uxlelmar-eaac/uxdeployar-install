p="${VPS_SSH_PORT:-2222}"
ext=$(sudo ss -Htln | awk '{print $4}' | grep -vE '^(127\.|\[::1\]|::1)' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
echo "Puertos a la escucha fuera de loopback: $(echo $ext)"
apr=$(sudo awk '!/^[[:space:]]*#/ && NF>=2 {print $1, $2}' /etc/ux/puertos.conf 2>/dev/null || true)
ufw_ab=$(sudo ufw status 2>/dev/null | sed 's/ (v6)//' | awk '$2=="ALLOW"||$2=="LIMIT"{print $1}' | sort -u)
decision(){ awk -v k="$1" '$1==k {print $2; exit}' <<<"$apr"; }
otros=""; mal=""
for x in $ext; do
  case "$x" in "$p"|80|443) continue ;; esac
  d=$(decision "$x/tcp")
  if [ "$d" = cerrado ] && grep -qxE "$x(/tcp)?" <<<"$ufw_ab"; then mal="$mal $x"
  elif [ -n "$d" ]; then echo "Aprobado en VPS → Puertos: $x/tcp ($d)"
  else otros="$otros $x"; fi
done
[ -z "$mal" ] || echo "✗ aprobados como cerrados, pero UFW los permite:$mal (VPS → Puertos)"
[ -z "$otros" ] || echo "✗ puertos de más sin aprobar:$otros (apruébalos o ciérralos en VPS → Puertos)"
[ -z "$mal$otros" ]
