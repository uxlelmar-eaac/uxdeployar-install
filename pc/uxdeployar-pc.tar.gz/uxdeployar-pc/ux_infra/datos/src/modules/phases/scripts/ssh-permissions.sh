d="$HOME/.ssh"; a="$d/authorized_keys"
pd=$(stat -c %a "$d" 2>/dev/null); pa=$(stat -c %a "$a" 2>/dev/null)
echo ".ssh: ${pd:-no existe} · authorized_keys: ${pa:-no existe}"
[ "$pd" = 700 ] && [ "$pa" = 600 ]
