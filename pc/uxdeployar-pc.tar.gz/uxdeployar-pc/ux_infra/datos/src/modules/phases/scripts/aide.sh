command -v aide >/dev/null 2>&1 || { echo "AIDE no está instalado (paso 9.7)"; exit 1; }
sudo test -s /var/lib/aide/aide.db || { echo "AIDE configurado; la base de referencia la genera E15 (paso 15.6)"; exit 0; }
cfg=/etc/aide/aide.conf; [ -f "$cfg" ] || cfg=/etc/aide.conf
sudo aide --config "$cfg" --check --limit '^/etc/' >/tmp/ux-aide.$$ 2>&1; rc=$?
tail -25 /tmp/ux-aide.$$; rm -f /tmp/ux-aide.$$
if [ "$rc" -ge 14 ]; then echo "AIDE no puede verificar (código $rc)"; sudo ls -l /var/lib/aide; exit 1; fi
if [ "$rc" -eq 0 ]; then echo "AIDE funciona: /etc coincide con la base (código 0)"
else echo "AIDE funciona y detectó diferencias con la base (código $rc = $( [ $((rc & 1)) -ne 0 ] && printf 'nuevos ')$( [ $((rc & 2)) -ne 0 ] && printf 'borrados ')$( [ $((rc & 4)) -ne 0 ] && printf 'cambiados')); antes de E15 es esperable, el paso 15.6 renueva la base"; fi
