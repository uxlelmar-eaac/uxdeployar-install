c="<proyecto>-<rol>-db"
if ! sudo ux-as <proyecto> podman container exists "$c" 2>/dev/null; then echo "$c: el rol no tiene base de datos (no aplica)"; exit 0; fi
sudo ux-as <proyecto> podman inspect "$c" --format '{{json .NetworkSettings.Networks}}'
pub=$(sudo ux-as <proyecto> podman port "$c" 2>/dev/null)
[ -z "$pub" ] || { echo "Publica puertos: $pub"; exit 1; }
