f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
command -v ux-as >/dev/null 2>&1 || { echo "No aplica: la plataforma UX (E11) todavía no está instalada"; exit 0; }
us=$(sudo find /etc/ux/projects -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | tr '\n' ' ')
caddy=""; id ux-caddy >/dev/null 2>&1 && caddy=ux-caddy
[ -n "$us$caddy" ] || { echo "No aplica: todavía no hay proyectos ni Caddy en Podman"; exit 0; }
for u in $caddy $us; do
  if ! id "$u" >/dev/null 2>&1; then ko "$u: el usuario Linux del proyecto no existe"; continue; fi
  if ! grep -q "^$u:" /etc/subuid || ! grep -q "^$u:" /etc/subgid; then ko "$u: falta su rango en /etc/subuid o /etc/subgid"; continue; fi
  r=$(sudo ux-as "$u" podman info --format '{{.Host.Security.Rootless}}' 2>&1 | tail -n 1)
  if [ "$r" = true ]; then ok "$u: Podman rootless responde"; else ko "$u: Podman no responde como $u: $(echo "$r" | cut -c1-140)"; fi
done
[ "$f" -eq 0 ]
