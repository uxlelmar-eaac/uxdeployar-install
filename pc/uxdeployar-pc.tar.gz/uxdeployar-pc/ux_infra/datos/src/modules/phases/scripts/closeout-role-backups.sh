E="${UX_ETC:-/etc/ux}"; S="${UX_SUDO-sudo}"; f=0; n=0
val(){ $S grep -m1 "^$1=" "$2" 2>/dev/null | cut -d= -f2- | sed "s/^['\"]//; s/['\"]$//"; }
# Las mismas condiciones con las que `ux-deploy` (instalar_timer) crea el temporizador de cada rol.
for reg in "$E"/projects/*/*.env; do
  [ -f "$reg" ] || continue
  p=$(basename "$(dirname "$reg")"); r=$(basename "$reg" .env); id="$p/$r"; n=$((n+1))
  h=$(getent passwd "$p" | cut -d: -f6); d="$h/roles/$r/deploy.env"
  if [ -z "$h" ] || ! $S test -f "$d"; then echo "· rol:$id — todavía sin versión publicada (no aplica)"; continue; fi
  if [ "$(val DEPLOY_HAS_DB "$d")" != true ]; then echo "· rol:$id — sin base de datos (no aplica)"; continue; fi
  falta=""
  [ -n "$(val DEPLOY_R2_BUCKET "$d")" ] || falta="DEPLOY_R2_BUCKET"
  [ -n "$(val DEPLOY_AGE_RECIPIENT "$d")" ] || falta="${falta:+$falta y }DEPLOY_AGE_RECIPIENT"
  if [ -n "$falta" ]; then echo "✗ rol:$id — deploy.env sin $falta: ux-deploy no instala el respaldo diario [causa=config_ausente]"; f=$((f+1)); continue; fi
  if ! $S test -s "$h/.config/rclone/rclone.conf"; then echo "✗ rol:$id — el proyecto no tiene credenciales de R2 (ux-proyecto r2 $p) [causa=dependencia]"; f=$((f+1)); continue; fi
  t="ux-respaldo-$r.timer"
  if ! $S test -f "$h/.config/systemd/user/$t"; then echo "✗ rol:$id — falta $t: se crea al publicar o con el asistente [causa=valor_incorrecto]"; f=$((f+1)); continue; fi
  if ! $S ux-as "$p" systemctl --user is-enabled "$t" >/dev/null 2>&1; then echo "✗ rol:$id — $t no está habilitado [causa=valor_incorrecto]"; f=$((f+1)); continue; fi
  echo "✔ rol:$id — $t activo"
done
[ "$n" -gt 0 ] || echo "No aplica: todavía no hay roles dados de alta"
[ "$f" -eq 0 ]
