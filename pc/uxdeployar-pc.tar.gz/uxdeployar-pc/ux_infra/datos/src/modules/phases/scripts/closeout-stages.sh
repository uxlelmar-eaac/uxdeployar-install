j=$(bash init-vps.sh --estado-json 2>/dev/null) || { echo "✗ no pude leer el estado de las etapas"; exit 1; }
echo "$j" | python3 -c '
import json,sys
malas=[]
for e in json.load(sys.stdin):
    n=e["etapa"].replace("E","")
    if n in ("00","13","16","17"): continue   # E00 es contexto; E13 es operación diaria; E16 es esta; E17 es consulta
    if e["estado"] not in ("completada","probada"): malas.append(e["etapa"]+" ("+e["estado"]+")")
    else: print("✔ "+e["etapa"]+" "+e["estado"])
if malas:
    print("✗ etapas sin completar: "+", ".join(malas)); sys.exit(1)
'
