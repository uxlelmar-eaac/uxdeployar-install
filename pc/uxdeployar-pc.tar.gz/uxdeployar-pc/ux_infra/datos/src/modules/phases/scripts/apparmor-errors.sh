l=$(sudo journalctl -k -b 2>/dev/null | grep -i apparmor | grep -iE 'error|fail' || true)
[ -z "$l" ] && echo "Sin errores de AppArmor en este arranque" || { echo "$l" | tail -20; exit 1; }
