s=$(sudo aa-status 2>/dev/null) || { echo "AppArmor no responde (aa-status falló)"; exit 1; }
echo "$s" | grep -E 'profiles are (loaded|in (enforce|complain) mode)'
enf=$(echo "$s" | awk '/profiles are in enforce mode/{e=1;next} /profiles are in|processes have/{e=0} e{print $1}')
f=0
for p in usr.sbin.sshd; do
  if [ ! -f "/etc/apparmor.d/$p" ]; then echo "ℹ $p: Debian no trae este perfil, no cuenta"; continue; fi
  n="/${p//.//}"
  if grep -qx "$n" <<<"$enf"; then echo "✔ $n en enforce"; else echo "✗ $n existe pero no está en enforce (paso 9.3)"; f=1; fi
done
for k in apparmor-profiles apparmor-profiles-extra; do
  if dpkg -s "$k" 2>/dev/null | grep -q '^Status: install ok installed'; then echo "✗ $k instalado: solo trae perfiles de escritorio (paso 9.1 lo quita)"; f=1; fi
done
exit $f
