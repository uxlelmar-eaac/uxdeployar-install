faltan=0
for t in apt-daily-upgrade.timer ux-backup-platform.timer aide-check.timer; do
  if systemctl list-timers --all "$t" 2>/dev/null | grep -q "$t"; then echo "✔ $t programado"
  elif [ "$t" = ux-backup-platform.timer ] && [ "$(systemctl is-enabled "$t" 2>/dev/null)" != enabled ]; then echo "· $t se activa al configurar los respaldos (E14, en el panel)"
  else echo "✗ $t no está programado"; faltan=$((faltan+1)); fi
done
echo "Mensual (actualización consciente) y trimestral (restauración, Lynis): se lanzan desde la app (Sistema, Respaldos, Seguridad)."
[ "$faltan" -eq 0 ]
