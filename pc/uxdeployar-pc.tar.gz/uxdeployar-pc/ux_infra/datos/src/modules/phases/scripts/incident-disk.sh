f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
while read -r fs uso mnt; do
  u=${uso%\%}
  case "$u" in ''|*[!0-9]*) continue ;; esac
  if [ "$u" -ge 85 ]; then ko "$mnt al $u % ($fs): libera espacio"; else ok "$mnt al $u %"; fi
done < <(df -P -x tmpfs -x devtmpfs -x overlay -x squashfs 2>/dev/null | awk 'NR>1{print $1, $5, $6}')
[ "$f" -eq 0 ] || echo "  journal: $(sudo journalctl --disk-usage 2>/dev/null | sed -E 's/.*take up ([^ ]+).*/\1/')"
[ "$f" -eq 0 ]
