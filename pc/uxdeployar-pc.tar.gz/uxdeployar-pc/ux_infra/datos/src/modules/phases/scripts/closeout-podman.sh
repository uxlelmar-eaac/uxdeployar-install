f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
r=$(sudo ux-as ux-caddy podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null)
[ "$r" = true ] && ok "Podman de ux-caddy corre rootless" || ko "Podman de ux-caddy no es rootless ($r)"
n=$(sudo podman ps -aq 2>/dev/null | wc -l)
[ "$n" -eq 0 ] && ok "root no tiene contenedores" || ko "root tiene $n contenedor(es): todo debe correr rootless"
l=$(loginctl show-user ux-caddy -p Linger --value 2>/dev/null)
[ "$l" = yes ] && ok "ux-caddy con linger (sobrevive a los reinicios)" || ko "ux-caddy sin linger ($l)"
st=$(sudo ux-as ux-caddy podman ps --filter name=caddy --format '{{.Names}} {{.Status}}' 2>/dev/null)
echo "$st" | grep -q 'Up' && ok "Caddy en ejecución: $st" || ko "Caddy no está corriendo ($st)"
insp=$(sudo ux-as ux-caddy podman inspect caddy --format '{{.HostConfig.RestartPolicy.Name}}|{{.HostConfig.ReadonlyRootfs}}|{{.HostConfig.SecurityOpt}}|{{.HostConfig.CapDrop}}' 2>/dev/null)
case "$insp" in *unless-stopped*|*always*) ok "Caddy se reinicia solo" ;; *) ko "Caddy sin política de reinicio ($insp)" ;; esac
case "$insp" in *'|true|'*) ok "sistema de archivos de Caddy en solo lectura" ;; *) ko "Caddy no es read_only ($insp)" ;; esac
case "$insp" in *no-new-privileges*) ok "no-new-privileges activo" ;; *) ko "falta no-new-privileges" ;; esac
ce=$(sudo ux-as ux-caddy podman exec caddy sh -c 'grep CapEff /proc/1/status' 2>/dev/null | awk '{print $2}')
case "$ce" in 0000000000000400|0000000000000000) ok "capacidades efectivas mínimas ($ce)" ;; *) ko "Caddy conserva capacidades de más (CapEff=${ce:-?}; permitido solo 0000000000000400)" ;; esac
c=$(curl -s -m 5 -o /dev/null -w '%{http_code}' http://127.0.0.1:80/ 2>/dev/null)
case "$c" in 2??|3??|4??) ok "Caddy responde en 127.0.0.1:80 (HTTP $c)" ;; *) ko "Caddy no responde en el 80 (HTTP ${c:-000})" ;; esac
if command -v ux-auditar >/dev/null 2>&1; then
  aud=$(sudo ux-auditar 2>&1)
  while IFS= read -r l; do ko "proyectos: ${l#*] }"; done < <(printf '%s\n' "$aud" | grep -F '[FALTA]')
  printf '%s\n' "$aud" | grep -qF '[FALTA]' || ok "contenedores de los proyectos: $(printf '%s\n' "$aud" | tail -n 1)"
else
  ko "falta ux-auditar (etapa E11): no se auditan los contenedores de los proyectos"
fi
[ "$f" -eq 0 ]
