f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
for c in age rclone zstd trivy lynis aide auditctl ufw fail2ban-client podman msmtp curl ux-proyecto ux-respaldo ux-deploy ux-alerta ux-as; do
  command -v "$c" >/dev/null 2>&1 && ok "$c instalado" || ko "falta $c"
done
i=$(sudo grep -s '^hardening_index=' /var/log/lynis-report.dat | tail -1 | cut -d= -f2)
if [ -z "$i" ]; then ko "no hay informe de Lynis (paso 15.4)"; elif [ "$i" -ge 70 ]; then ok "índice de hardening de Lynis: $i"; else ko "índice de hardening de Lynis bajo: $i (mínimo 70)"; fi
[ "$f" -eq 0 ]
