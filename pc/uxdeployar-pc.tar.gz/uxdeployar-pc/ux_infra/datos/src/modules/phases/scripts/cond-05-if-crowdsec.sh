if ! command -v cscli >/dev/null 2>&1; then echo 'No aplica: CrowdSec no está instalado (es opcional)'; exit 0; fi
f=0
for u in crowdsec crowdsec-firewall-bouncer; do
  if systemctl is-active --quiet "$u"; then echo "✔ $u activo"; else echo "✗ $u no está activo"; f=1; fi
done
j=$(sudo cscli bouncers list -o json 2>/dev/null) || { echo "✗ cscli no responde"; exit 1; }
printf '%s' "$j" | python3 -c '
import json, sys
vivos = 0
for b in json.load(sys.stdin) or []:
    lp = b.get("last_pull") or ""
    rev = bool(b.get("revoked"))
    vivo = bool(lp) and not lp.startswith("0001") and not rev
    vivos += vivo
    print(("✔" if vivo else "✗") + " bouncer " + str(b.get("name", "?")) + " · último contacto: " + (lp if vivo else "nunca") + (" · revocado" if rev else ""))
if not vivos:
    print("✗ ningún bouncer en contacto con CrowdSec: no se bloquea ninguna IP (repite E05, paso 5.5)")
sys.exit(0 if vivos else 1)
' || f=1
exit $f
