command -v trivy >/dev/null 2>&1 || { echo "Trivy no está instalado (paso 15.1)"; exit 1; }
img=$(sudo ux-as ux-caddy podman images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -v '<none>' | head -1)
if [ -z "$img" ]; then echo "Aún no hay imágenes que escanear; Trivy responde:"; sudo trivy --version; exit $?; fi
tar=/var/tmp/ux-scan-verificacion.tar; sudo rm -f "$tar"
echo "Escaneando $img…"
sudo ux-as ux-caddy podman save --format docker-archive -o "$tar" "$img" || exit 1
sudo trivy image --input "$tar" --severity HIGH,CRITICAL --scanners vuln --no-progress; rc=$?
sudo rm -f "$tar"; exit $rc
