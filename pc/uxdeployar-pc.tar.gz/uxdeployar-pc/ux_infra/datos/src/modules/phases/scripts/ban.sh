ip=203.0.113.254   # IP de documentación (RFC 5737): nunca es la tuya
sudo fail2ban-client status sshd >/dev/null 2>&1 || { echo "La cárcel sshd no está activa"; exit 1; }
sudo fail2ban-client set sshd banip "$ip" >/dev/null
if sudo fail2ban-client status sshd | grep -q "$ip"; then echo "Prueba: la IP $ip aparece en «Banned IP list»"; r=0; else echo "La IP de prueba no aparece en la lista de baneadas"; r=1; fi
sudo fail2ban-client set sshd unbanip "$ip" >/dev/null 2>&1
echo "IP de prueba desbloqueada"
exit $r
