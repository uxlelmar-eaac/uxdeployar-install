f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
perm "$HOME/.ssh" 700
perm "$HOME/.ssh/authorized_keys" "600 400"
for k in /etc/ssh/ssh_host_*_key; do [ -e "$k" ] && perm "$k" 600; done
perm /etc/shadow "640 600 000"; perm /etc/sudoers 440
for s in /etc/sudoers.d/*; do [ -e "$s" ] && perm "$s" "440 400"; done
# El CI corre como el usuario del proyecto y debe poder leer <p>/<r>.env
# (UX_PUERTO/UX_DOMINIO, no secretos). 750 root:root hacía «rol no registrado» falso.
# /etc/ux también: sin poder atravesarlo, el CI no llega a projects/.
if [ -d /etc/ux ]; then
  sudo chmod 755 /etc/ux
  perm /etc/ux "755"
fi
if [ -d /etc/ux/projects ]; then
  sudo chmod 755 /etc/ux/projects
  perm /etc/ux/projects "755"
  # Registro de roles: solo metadatos públicos. Secretos aquí serían legibles (644).
  while IFS= read -r reg; do
    [ -n "$reg" ] || continue
    if sudo grep -Eiq '^(VAULT_|.*_PASSWORD|.*_SECRET|.*_TOKEN|SOPS_|AGE_|AWS_SECRET|R2_.*KEY|GHCR_|GITHUB_TOKEN|CONTROL_PLANE_)' "$reg" 2>/dev/null; then
      ko "secreto en registro de rol (debe vivir en SOPS/bóveda, no en $reg)"
    else
      ok "registro sin secretos: $reg"
    fi
  done < <(sudo find /etc/ux/projects -mindepth 2 -maxdepth 2 -name '*.env' 2>/dev/null | sort)
fi
[ -f /etc/ux/plataforma.env ] && perm /etc/ux/plataforma.env 600
[ -f /etc/ux/rclone.conf ] && perm /etc/ux/rclone.conf 600
[ "$f" -eq 0 ]
