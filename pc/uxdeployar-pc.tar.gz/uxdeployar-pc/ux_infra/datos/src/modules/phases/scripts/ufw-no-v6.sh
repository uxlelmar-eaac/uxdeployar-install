if [ "$(cat /etc/ux/ipv6-proveedor 2>/dev/null)" = si ] || [ -n "$(ip -6 addr show scope global 2>/dev/null | grep inet6)" ]; then
  echo "No aplica: IPv6 del proveedor; las reglas (v6) son las que lo protegen"; exit 0
fi
s=$(sudo ufw status verbose); echo "$s"
! echo "$s" | grep -q '(v6)'
