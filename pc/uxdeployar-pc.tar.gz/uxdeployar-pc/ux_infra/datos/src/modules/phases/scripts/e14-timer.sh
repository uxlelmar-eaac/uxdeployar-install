# El respaldo que lo activa vive en diario/<prefijo>/; aquí solo se mira el timer.
u=/etc/systemd/system/ux-backup-platform.timer
if [ ! -f "$u" ]; then
  echo "✗ falta la unidad ux-backup-platform.timer (instálala en E11)"
  exit 1
fi
e=$(systemctl is-enabled ux-backup-platform.timer 2>/dev/null || true)
if [ "$e" != enabled ]; then
  echo "✗ el temporizador no está activado: E14.5 lo enciende tras un respaldo bueno"
  exit 1
fi
if systemctl list-timers ux-backup-platform.timer --no-pager 2>/dev/null | grep -q '0 timers listed'; then
  echo "✗ el temporizador está habilitado pero no tiene próximo disparo"
  exit 1
fi
echo "✔ ux-backup-platform.timer programado"
exit 0
