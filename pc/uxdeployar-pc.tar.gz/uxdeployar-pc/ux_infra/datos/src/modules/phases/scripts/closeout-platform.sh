S="${UX_SUDO-sudo}"
b=$(readlink -f "$(command -v ux-proyecto 2>/dev/null || echo /usr/local/bin/ux-proyecto)" 2>/dev/null)
rev=$($S sed -n 's/^UX_PROJECT_REV=\([0-9]*\).*/\1/p' "$b" 2>/dev/null | head -n 1)
case "$rev" in '' | *[!0-9]*) rev=0 ;; esac
if [ "$rev" -ge 1 ]; then
  out=$($S ux-proyecto verificar --maquina 2>&1); rc=$?
  echo "$out"
else
  # ux-proyecto anterior: se resume su salida por sujeto aquí (la plataforma y cada proyecto).
  out=$($S ux-proyecto verificar 2>&1); rc=$?
  echo "$out"
  echo "$out" | awk '
    function cierra() { if (s == "") return
      if (nf) printf "✗ %s — %s [causa=valor_incorrecto]\n", s, fs
      else if (na) printf "! %s — %s [causa=%s]\n", s, as, (c == "" ? "externo" : c)
      else printf "✔ %s — %d comprobaciones en orden\n", s, n }
    function suj(t) { if (match(t, /^[a-z][a-z0-9-]*: /)) return "proyecto:" substr(t, 1, RLENGTH - 2); return (s ~ /^proyecto:/) ? s : "servidor:plataforma" }
    /^\[(OK|AVISO|FALTA)\]/ {
      t = $0; sub(/^\[[A-Z]+\] +/, "", t); k = suj(t)
      if (k != s) { cierra(); s = k; n = 0; nf = 0; na = 0; fs = ""; as = ""; c = "" }
      m = t; sub(/^[a-z][a-z0-9-]*: /, "", m); n++
      # Un ux-lib anterior da por bueno un HTTPS que responde 5xx: es un sitio caído.
      if ($0 ~ /^\[OK\]/ && m ~ /HTTPS: .*\(HTTP 5[0-9][0-9]\)/) { na++; as = as (as == "" ? "" : " · ") m " (el sitio no responde)"; if (c == "") c = "externo"; next }
      if ($0 ~ /^\[FALTA\]/) { nf++; fs = fs (fs == "" ? "" : " · ") m }
      else if ($0 ~ /^\[AVISO\]/) { na++; as = as (as == "" ? "" : " · ") m
        if (c == "") c = (m ~ /credenciales de R2|GHCR/) ? "dependencia" : ((m ~ /UFW no lo permite/) ? "config_ausente" : ((m ~ /DNS|HTTPS|TLS|Cloudflare/) ? "externo" : "valor_incorrecto")) }
    }
    END { cierra() }'
fi
[ "$rc" -eq 0 ] && ! echo "$out" | grep -q '^\[FALTA\]'
