f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
u=$(sudo ss -Hulnp 2>/dev/null | awk '{print $4}' | grep -vE '^(127\.|\[?::1\]?:)' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un | grep -vxE '68|546' || true)
apr=$(sudo awk '!/^[[:space:]]*#/ && NF>=2 {print $1, $2}' /etc/ux/puertos.conf 2>/dev/null || true)
ufw_ab=$(sudo ufw status 2>/dev/null | sed 's/ (v6)//' | awk '$2=="ALLOW"||$2=="LIMIT"{print $1}' | sort -u)
decision(){ awk -v k="$1" '$1==k {print $2; exit}' <<<"$apr"; }
# Cliente UDP (QUIC de cloudflared, DNS…): rango efímero, número nuevo en cada reinicio; no expuesto si UFW deniega la entrada.
read -r ea eb < /proc/sys/net/ipv4/ip_local_port_range 2>/dev/null || { ea=32768; eb=60999; }
ent=$(sudo ufw status verbose 2>/dev/null | grep -cE '^Default: (deny|reject) \(incoming\)')
permite(){ awk -v p="$1" '{split($1,a,"/"); if (a[2]!="" && a[2]!="udp") next; n=split(a[1],r,":"); if ((n==1 && r[1]==p) || (n==2 && p+0>=r[1]+0 && p+0<=r[2]+0)) f=1} END{exit !f}' <<<"$ufw_ab"; }
prog(){ sudo ss -Hulnp "( sport = :$1 )" 2>/dev/null | grep -o '(("[^"]*"' | head -n 1 | cut -d'"' -f2; }
pend=""
for x in $u; do
  d=$(decision "$x/udp")
  if [ "$d" = cerrado ] && grep -qxE "$x(/udp)?" <<<"$ufw_ab"; then ko "UDP $x aprobado como cerrado, pero UFW lo permite (VPS → Puertos)"
  elif [ -n "$d" ]; then ok "UDP $x aprobado en VPS → Puertos ($d)"
  elif [ "${ent:-0}" -gt 0 ] && [ "$x" -ge "$ea" ] && [ "$x" -le "$eb" ] && ! permite "$x"; then ok "UDP $x efímero de un cliente ($(prog "$x")): UFW no lo permite, no está expuesto"
  else pend="$pend $x"; fi
done
[ -z "$pend" ] && ok "ningún puerto UDP expuesto sin aprobar (salvo el cliente DHCP)" || { ko "puertos UDP a la escucha fuera de loopback sin aprobar:$pend (apruébalos o ciérralos en VPS → Puertos)"; sudo ss -ulnp 2>/dev/null | grep -vE '127\.|::1'; }
[ "$f" -eq 0 ]
