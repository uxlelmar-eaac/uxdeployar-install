f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
s=$(sudo ufw status 2>&1)
echo "$s" | grep -q 'Status: active' && ok "UFW activo" || ko "UFW inactivo: E06 lo deja activo (repite E06)"
echo "$s" | grep -Eq '^80/tcp +ALLOW' && ok "80/tcp permitido" || ko "falta 80/tcp: sin él no se emiten certificados (repite E06, paso 6.2)"
echo "$s" | grep -Eq '^443/tcp +ALLOW' && ok "443/tcp permitido" || ko "falta 443/tcp: los sitios no serán accesibles (repite E06, paso 6.2)"
[ "$f" -eq 0 ]
