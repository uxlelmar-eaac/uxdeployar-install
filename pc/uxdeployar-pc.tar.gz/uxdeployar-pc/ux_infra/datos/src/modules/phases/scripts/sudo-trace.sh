h=/etc/sudoers.d/99-hardening
sudo test -f "$h" || { echo "✗ falta $h (paso 2.5)"; exit 1; }
sudo grep -Eq '^[[:space:]]*Defaults[[:space:]]+use_pty' "$h" && echo "✔ $h con use_pty" || { echo "✗ $h sin Defaults use_pty (paso 2.5)"; exit 1; }
if sudo test -f /var/log/sudo.log; then sudo tail -n 20 /var/log/sudo.log; exit 0; fi
if sudo grep -q logfile "$h"; then echo "✗ $h pide logfile pero falta /var/log/sudo.log (paso 2.5)"; exit 1; fi
echo "La traza de sudo está en el journal (sudo-rs no escribe /var/log/sudo.log)"
sudo journalctl -q --no-pager -n 20 _COMM=sudo
