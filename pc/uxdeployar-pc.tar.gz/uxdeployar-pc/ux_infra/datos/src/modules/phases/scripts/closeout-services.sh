f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
x=$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}')
otros=$(echo "$x" | grep -v '^cloud-init' | grep -v '^$' || true); ci=$(echo "$x" | grep '^cloud-init' || true)
if [ -z "$otros" ]; then ok "ninguna unidad systemd fallida (aparte de cloud-init)"; else
  ko "unidades fallidas: $(echo $otros)"
  for u in $otros; do echo "--- $u"; sudo journalctl -u "$u" -n 8 --no-pager 2>&1 | tail -8; done
fi
if [ -n "$ci" ]; then
  echo "ℹ cloud-init con fallos ($(echo $ci)): solo afecta al aprovisionamiento inicial del proveedor"
  sudo cloud-init status --long 2>&1 | head -10
  for u in $ci; do echo "--- $u"; sudo journalctl -u "$u" -n 12 --no-pager 2>&1 | tail -12; done
fi
if [ -f /var/run/reboot-required ]; then ko "el sistema pide reiniciar: $(cat /var/run/reboot-required.pkgs 2>/dev/null | tr '\n' ' ')"; else ok "sin reinicio pendiente"; fi
nuevo=$(ls -1 /boot/vmlinuz-* 2>/dev/null | sed 's#.*/vmlinuz-##' | sort -V | tail -1)
if [ -n "$nuevo" ] && [ "$(uname -r)" != "$nuevo" ]; then ko "arrancado con el kernel $(uname -r) pero hay uno más nuevo instalado ($nuevo): reinicia"; else ok "kernel en uso al día ($(uname -r))"; fi
a=/etc/apt/apt.conf.d/20auto-upgrades
grep -q 'Update-Package-Lists "1"' "$a" 2>/dev/null && grep -q 'Unattended-Upgrade "1"' "$a" 2>/dev/null && ok "actualizaciones automáticas activadas" || ko "20auto-upgrades no activa las actualizaciones"
systemctl is-enabled apt-daily-upgrade.timer >/dev/null 2>&1 && ok "apt-daily-upgrade.timer habilitado" || ko "apt-daily-upgrade.timer deshabilitado"
sec(){ apt list --upgradable 2>/dev/null | grep -- '-security' | cut -d/ -f1; }
nsec(){ sec | grep -c . || true; }
if [ "$(nsec)" -gt 0 ] && command -v unattended-upgrade >/dev/null 2>&1; then
  echo "ℹ $(nsec) actualización(es) de seguridad pendientes: las instalo ahora con unattended-upgrade (lo mismo que hace su temporizador diario)"
  for _ in $(seq 300); do systemctl is-active -q apt-daily.service apt-daily-upgrade.service || break; sleep 2; done
  sudo timeout 900 unattended-upgrade >/dev/null 2>&1 || true
  p=$(sec | tr '\n' ' ')
  if [ -n "$p" ]; then
    echo "ℹ unattended-upgrade dejó pendientes: $p— los instalo con apt-get"
    # shellcheck disable=SC2086
    sudo DEBIAN_FRONTEND=noninteractive timeout 900 apt-get install -y --only-upgrade -o DPkg::Lock::Timeout=600 -o APT::Get::Always-Include-Phased-Updates=true -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold $p >/dev/null 2>&1 || true
  fi
  [ -f /var/run/reboot-required ] && echo "ℹ los parches instalados piden reiniciar: hazlo en la próxima ventana de mantenimiento"
fi
n=$(apt list --upgradable 2>/dev/null | grep -c 'upgradable from' || true); s=$(nsec)
if [ "${s:-0}" -gt 0 ]; then ko "$s actualización(es) de seguridad sin instalar: $(sec | tr '\n' ' ')"
elif [ "${n:-0}" -gt 0 ]; then ok "sin actualizaciones de seguridad pendientes (ℹ $n paquete(s) normales: se instalan con apt upgrade cuando decidas)"
else ok "sin paquetes pendientes de actualizar"; fi
[ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" = yes ] && ok "hora sincronizada ($(timedatectl show -p Timezone --value 2>/dev/null))" || ko "la hora no está sincronizada"
us=$(df --output=pcent / | tail -1 | tr -dc 0-9); ui=$(df --output=ipcent / | tail -1 | tr -dc 0-9)
[ "${us:-100}" -lt 85 ] && ok "disco al ${us}%" || ko "disco al ${us}%"
[ "${ui:-100}" -lt 85 ] && ok "inodos al ${ui}%" || ko "inodos al ${ui}%"
[ "$f" -eq 0 ]
