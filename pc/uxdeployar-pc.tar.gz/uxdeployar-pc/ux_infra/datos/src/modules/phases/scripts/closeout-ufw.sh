f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
p="${VPS_SSH_PORT:-2222}"
s=$(sudo ufw status verbose 2>&1)
echo "$s" | grep -q 'Status: active' && ok "UFW activo" || ko "UFW inactivo"
echo "$s" | grep -q 'Default: deny (incoming), allow (outgoing)' && ok "política: denegar entrante, permitir saliente" || ko "política por defecto distinta: $(echo "$s" | grep '^Default')"
echo "$s" | grep -Eq "^$p/tcp +LIMIT" && ok "SSH ($p) con límite de intentos" || ko "el puerto $p no tiene regla LIMIT"
echo "$s" | grep -Eq '^80/tcp +ALLOW' && ok "80/tcp abierto" || ko "falta 80/tcp"
echo "$s" | grep -Eq '^443/tcp +ALLOW' && ok "443/tcp abierto" || ko "falta 443/tcp"
if sudo grep -qs '^IPV6=yes' /etc/default/ufw; then
  echo "$s" | grep -Eq "^$p/tcp [(]v6[)] +LIMIT" && ok "SSH ($p) con límite también en IPv6" || ko "el puerto $p no tiene regla LIMIT (v6)"
  echo "$s" | grep -Eq '^80/tcp [(]v6[)] +ALLOW' && ok "80/tcp (v6) abierto" || ko "falta 80/tcp (v6)"
  echo "$s" | grep -Eq '^443/tcp [(]v6[)] +ALLOW' && ok "443/tcp (v6) abierto" || ko "falta 443/tcp (v6)"
fi
abiertos=$(sudo awk '!/^[[:space:]]*#/ && ($2=="abierto"||$2=="pendiente") {print $1}' /etc/ux/puertos.conf 2>/dev/null | sed -E 's#/(tcp|udp)##' | sort -u)
otros=""
for x in $(echo "$s" | awk '/ALLOW|LIMIT/{print $1}' | sed -E 's#/(tcp|udp)##' | sort -u); do
  case "$x" in "$p"|80|443) continue ;; esac
  if grep -qx "$x" <<<"$abiertos"; then ok "regla de $x: aprobado como abierto en VPS → Puertos"; else otros="$otros $x"; fi
done
[ -z "$otros" ] && ok "sin reglas de más" || ko "reglas de más (puertos sin aprobar como abiertos):$otros"
[ "$f" -eq 0 ]
