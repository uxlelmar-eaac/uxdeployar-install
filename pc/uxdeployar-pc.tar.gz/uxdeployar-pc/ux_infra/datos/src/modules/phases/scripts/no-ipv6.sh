marca="$(cat /etc/ux/ipv6-proveedor 2>/dev/null || echo ninguna)"
vivo="$(ip -6 addr show scope global 2>/dev/null | grep inet6 || true)"
echo "Decisión guardada en 8.0: $marca · IPv6 global activo: $([ -n "$vivo" ] && echo sí || echo no)"
if [ "$marca" = si ] || [ -n "$vivo" ]; then
  echo "$vivo"
  echo "UFW: $(grep '^IPV6=' /etc/default/ufw 2>/dev/null || echo 'IPV6 sin definir') · $(sudo ufw status | head -1)"
  if grep -q '^IPV6=yes' /etc/default/ufw && sudo ufw status | grep -q 'Status: active'; then
    echo "No aplica: tu proveedor usa IPv6 en la red; queda activo y filtrado por el firewall (UFW con IPv6)"; exit 0
  fi
  echo "IPv6 activo y SIN filtrar por UFW: repite el paso 8.0 y el 8.2 (E08)"; exit 1
fi
l=$(ip a | grep inet6 || true)
[ -z "$l" ] && echo "Sin direcciones IPv6" || { echo "$l"; exit 1; }
