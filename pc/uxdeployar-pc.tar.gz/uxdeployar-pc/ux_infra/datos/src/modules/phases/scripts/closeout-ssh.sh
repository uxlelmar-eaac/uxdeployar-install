f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
t=$(sudo sshd -T 2>/dev/null) || { echo "✗ sshd -T falló"; exit 1; }
v(){ echo "$t" | awk -v k="$1" '$1==k{ $1=""; sub(/^ /,""); print; exit }'; }
chk(){ g="$(v "$1")"; if [ "$g" = "$2" ]; then ok "$1 = $2"; else ko "$1 = ${g:-?} (esperado $2)"; fi; }
chk port "${VPS_SSH_PORT:-2222}"; chk permitrootlogin no; chk passwordauthentication no; chk permitemptypasswords no
chk pubkeyauthentication yes; chk x11forwarding no; chk maxauthtries 3; chk maxsessions 2; chk logingracetime 20
if [ -f /etc/ssh/sshd_config.d/00-vps-mfa.conf ]; then chk kbdinteractiveauthentication yes; else chk kbdinteractiveauthentication no; fi
echo "$t" | grep -q '^allowgroups ' && ok "AllowGroups definido: $(v allowgroups)" || ko "falta AllowGroups"
c="$(v ciphers)"
case "$c" in *chacha20-poly1305*) ok "cifrados modernos" ;; *) ko "cifrados sin endurecer: $c" ;; esac
case "$c" in *cbc*|*3des*|*arcfour*) ko "cifrados débiles permitidos: $c" ;; *) ok "sin cifrados débiles" ;; esac
[ "$f" -eq 0 ]
