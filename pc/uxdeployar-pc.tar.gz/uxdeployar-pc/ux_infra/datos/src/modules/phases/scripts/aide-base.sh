sudo test -s /var/lib/aide/aide.db || { echo "✗ falta la base de AIDE /var/lib/aide/aide.db (paso 15.6)"; exit 1; }
f=0
for p in trivy lynis; do
  l=/var/lib/dpkg/info/$p.list
  [ -e "$l" ] || { echo "ℹ $p no está instalado todavía"; continue; }
  if sudo test /var/lib/aide/aide.db -nt "$l"; then echo "✔ base de AIDE posterior a la instalación de $p"; else echo "✗ la base de AIDE es anterior a la instalación de $p (paso 15.6 la renueva)"; f=1; fi
done
exit $f
