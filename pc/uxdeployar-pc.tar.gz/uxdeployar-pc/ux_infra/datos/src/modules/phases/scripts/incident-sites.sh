f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
n=0
regs=$(sudo find /etc/ux/projects -mindepth 2 -maxdepth 2 -name '*.env' 2>/dev/null | sort)
[ -n "$regs" ] || { echo "No aplica: todavía no hay roles dados de alta"; exit 0; }
for reg in $regs; do
  p=$(basename "$(dirname "$reg")"); r=$(basename "$reg" .env)
  pu=$(sudo sh -c ". '$reg'; printf %s \"\$UX_PUERTO\"" 2>/dev/null)
  h=$(getent passwd "$p" | cut -d: -f6)
  if [ -z "$h" ] || ! sudo test -f "$h/roles/$r/.current-tag"; then echo "· $p/$r: aún sin desplegar"; continue; fi
  case "$pu" in ''|*[!0-9]*) ko "$p/$r: su registro no tiene UX_PUERTO"; continue ;; esac
  n=$((n+1))
  c=$(curl -s -o /dev/null -m 5 -w '%{http_code}' "http://127.0.0.1:$pu/" 2>/dev/null)
  case "$c" in
    000|'') ko "$p/$r: la app no responde en 127.0.0.1:$pu (Caddy devuelve 502/504)" ;;
    502|503|504) ko "$p/$r: la app responde $c en 127.0.0.1:$pu" ;;
    *) ok "$p/$r responde en 127.0.0.1:$pu (HTTP $c)" ;;
  esac
done
[ "$f" -eq 0 ] || exit 1
[ "$n" -gt 0 ] || echo "No aplica: ningún rol desplegado todavía"
exit 0
