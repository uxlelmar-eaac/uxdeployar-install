e=$(systemctl --global is-enabled podman.socket 2>&1 || true); echo "$e"
[ "$e" = "masked" ]
