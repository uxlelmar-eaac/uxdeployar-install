out=$(sudo ux-proyecto verificar 2>&1)
echo "$out" | sed -E '/\[FALTA\].*E1[234]/s/\[FALTA\]/[PENDIENTE]/'
f=$(echo "$out" | grep '\[FALTA\]' | grep -vE 'E1[234]')
[ -z "$f" ] || { echo; echo "Faltas que no dependen de las etapas 12–14:"; echo "$f"; exit 1; }
echo 'Nada propio de E11 por resolver; lo marcado [PENDIENTE] llega con las etapas 12–14.'
