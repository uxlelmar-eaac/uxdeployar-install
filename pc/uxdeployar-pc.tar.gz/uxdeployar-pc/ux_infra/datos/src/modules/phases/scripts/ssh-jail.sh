sudo fail2ban-client status sshd || { echo "La cárcel sshd no está activa"; exit 1; }
p=$(sudo grep -E '^[[:space:]]*port[[:space:]]*=' /etc/fail2ban/jail.local 2>/dev/null | head -1 | sed -E 's/.*=[[:space:]]*//')
echo "Puerto que vigila la cárcel: ${p:-sin definir} (SSH usa ${VPS_SSH_PORT:-2222})"
m=$(sudo fail2ban-client get sshd maxretry 2>/dev/null)
echo "Intentos permitidos (cargados): ${m:-?} (jail.local pide 3)"
[ "$p" = "${VPS_SSH_PORT:-2222}" ] && [ "$m" = 3 ]
