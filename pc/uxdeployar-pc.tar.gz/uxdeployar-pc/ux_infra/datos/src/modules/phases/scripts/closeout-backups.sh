f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
unidad ux-backup-platform.timer timer
x=$(sudo bash -c '. /etc/ux/plataforma.env 2>/dev/null; printf "%s|%s|%s" "$UX_R2_BUCKET" "${UX_R2_PREFIJO:-}" "$UX_AGE_RECIPIENT"')
B=${x%%|*}; r=${x#*|}; P=${r%%|*}; A=${r#*|}
[ -n "$B" ] && ok "bucket configurado: $B" || { ko "sin bucket en /etc/ux/plataforma.env"; echo "✗ sin configuración de respaldos"; exit 1; }
case "$A" in age1*) ok "clave pública age configurada" ;; *) ko "UX_AGE_RECIPIENT inválido" ;; esac
if [ -z "$P" ]; then P=$(hostname -s | tr 'A-Z' 'a-z' | tr -c 'a-z0-9\n' '-' | sed 's/-*$//'); fi
ok "prefijo del VPS en el bucket: $P"
l=$(sudo rclone --config /etc/ux/rclone.conf lsf --max-age 48h "r2:$B/diario/$P/" 2>/dev/null)
echo "$l" | grep -q '\.tar\.age$' && ok "respaldo cifrado de las últimas 48 h en diario/$P/" || ko "ningún respaldo .age en diario/$P/ en las últimas 48 h"
echo "$l" | grep -q '\.sha256$' && ok "con su suma .sha256" || ko "falta la suma .sha256"
[ "$f" -eq 0 ]
