f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
u0=$(awk -F: '$3==0{print $1}' /etc/passwd | tr '\n' ' ')
[ "$u0" = "root " ] && ok "solo root tiene UID 0" || ko "cuentas con UID 0: $u0"
vac=$(sudo awk -F: '$2==""{print $1}' /etc/shadow | tr '\n' ' ')
[ -z "$vac" ] && ok "ninguna cuenta con contraseña vacía" || ko "contraseña vacía en: $vac"
a="${VPS_ADMIN_USER:-$(id -un)}"
id -nG "$a" | tr ' ' '\n' | grep -qx sudo && ok "$a pertenece al grupo sudo" || ko "$a no está en el grupo sudo"
echo "→ root: $(sudo passwd -S root 2>/dev/null | awk '{print $2}') (el acceso SSH de root ya está cerrado en la fila 1)"
[ "$f" -eq 0 ]
