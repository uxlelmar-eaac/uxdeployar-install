p="${UX_DIAG_PORT:-${VPS_SSH_PORT:-2222}}"
v() { echo "VEREDICTO=$1"; exit 0; }
pv=$(awk '/^vps:/ {f=1; next} /^[^[:space:]#]/ {f=0} f && /^[[:space:]]+proveedor:/ {sub(/^[^:]*:[[:space:]]*/, ""); sub(/[[:space:]]*#.*/, ""); gsub(/["\047]/, ""); print; exit}' inventory/inventory.yaml 2>/dev/null)
echo "PROVEEDOR=$pv"
if sudo ss -Hltn "( sport = :$p )" 2>/dev/null | grep -q .; then echo "✔ sshd escucha en el $p"; else echo "✗ nada escucha en el $p (revisa 10-ux-puerto.conf y sshd -t)"; v no-escucha; fi
if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q '^Status: active'; then
  if sudo ufw status 2>/dev/null | sed 's/ (v6)//' | grep -qE "^$p(/tcp)?[[:space:]]+(ALLOW|LIMIT)[[:space:]]+(IN[[:space:]]+)?Anywhere"; then echo "✔ UFW está activo y permite el $p"; else echo "✗ UFW está activo y no permite el $p"; v ufw; fi
fi
if command -v firewall-cmd >/dev/null 2>&1 && sudo firewall-cmd --state >/dev/null 2>&1; then
  if sudo firewall-cmd --list-ports 2>/dev/null | tr ' ' '\n' | grep -qx "$p/tcp"; then echo "✔ firewalld permite el $p"; else echo "✗ firewalld está activo y no permite el $p"; v firewalld; fi
fi
if command -v nft >/dev/null 2>&1; then
  for t in $(sudo nft list tables 2>/dev/null | awk '!($2 ~ /^ip6?$/ && $3 ~ /^(filter|nat|mangle|raw|security)$/) { print $2 "/" $3 }'); do
    r=$(sudo nft list table "${t%/*}" "${t#*/}" 2>/dev/null)
    if grep -q 'hook input.*policy drop' <<<"$r" && ! grep -qE "dport (\{[^}]*\b$p\b[^}]*\}|$p)\b.*accept" <<<"$r"; then echo "✗ la tabla nftables «$t» descarta la entrada y no permite el $p"; v nftables; fi
  done
fi
if ! sudo ufw status 2>/dev/null | grep -q '^Status: active' && command -v iptables >/dev/null 2>&1; then
  if sudo iptables -S INPUT 2>/dev/null | grep -qx -- '-P INPUT DROP' && ! sudo iptables -S INPUT 2>/dev/null | grep -qE -- "--dport $p( |$).*-j ACCEPT"; then echo "✗ iptables descarta la entrada y no permite el $p"; v iptables; fi
fi
echo "✔ el firewall del VPS no bloquea el $p: lo que lo filtra está fuera del VPS"
v proveedor
