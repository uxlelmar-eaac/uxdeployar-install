systemctl list-timers aide-check.timer --no-pager 2>/dev/null | grep aide-check.timer || { echo "✗ aide-check.timer no está programado (paso 9.7)"; exit 1; }
echo "✔ aide-check.timer programado"
d=$(systemctl is-enabled dailyaidecheck.timer 2>/dev/null)
case "$d" in
  ""|masked|disabled|not-found) echo "✔ dailyaidecheck.timer de Debian fuera de servicio (${d:-no instalado}): un solo chequeo de AIDE" ;;
  *) echo "✗ dailyaidecheck.timer de Debian sigue activo ($d): AIDE correría dos veces (paso 9.7 lo enmascara)"; exit 1 ;;
esac
