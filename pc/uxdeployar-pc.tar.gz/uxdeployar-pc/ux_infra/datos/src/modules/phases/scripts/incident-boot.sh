f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
command -v ux-as >/dev/null 2>&1 || { echo "No aplica: la plataforma UX (E11) todavía no está instalada"; exit 0; }
us=$(sudo find /etc/ux/projects -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | tr '\n' ' ')
caddy=""; id ux-caddy >/dev/null 2>&1 && caddy=ux-caddy
[ -n "$us$caddy" ] || { echo "No aplica: todavía no hay proyectos ni Caddy en Podman"; exit 0; }
for u in $caddy $us; do
  id "$u" >/dev/null 2>&1 || continue
  if [ "$(loginctl show-user "$u" -p Linger --value 2>/dev/null)" = yes ]; then ok "$u: linger activo"; else ko "$u: sin linger: sus contenedores no arrancan solos tras reiniciar"; fi
done
for u in $caddy $us; do
  id "$u" >/dev/null 2>&1 || continue
  e=$(sudo ux-as "$u" systemctl --user is-enabled podman-restart.service 2>/dev/null)
  if [ "$e" = enabled ]; then ok "$u: podman-restart.service habilitado"; else ko "$u: podman-restart.service no está habilitado (${e:-sin respuesta})"; fi
done
[ "$f" -eq 0 ]
