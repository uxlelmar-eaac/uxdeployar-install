f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
p="${VPS_SSH_PORT:-2222}"
lib=/usr/local/lib/ux/ux-lib.sh
if [ -r "$lib" ] && sudo bash -c ". '$lib'; declare -F ux_puertos_revision >/dev/null" 2>/dev/null; then
  while IFS=$'\t' read -r nivel texto; do
    case "$nivel" in OK) ok "$texto" ;; AVISO) echo "⚠ $texto" ;; FALTA) ko "$texto" ;; esac
  done < <(sudo bash -c ". '$lib'; ux_puertos_revision '$p'" 2>/dev/null)
else
  ext=$(sudo ss -Htln 2>/dev/null | awk '{print $4}' | grep -vE '^(127\.|\[::1\]|::1)' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
  otros=$(for x in $ext; do case "$x" in "$p"|80|443) ;; *) echo "$x" ;; esac; done)
  if [ -z "$otros" ]; then ok "fuera de loopback solo escuchan SSH, 80 y 443"; else ko "puertos a la escucha fuera de loopback: $(echo $otros) (ciérralos o apruébalos en VPS → Puertos)"; fi
fi
[ "$f" -eq 0 ]
