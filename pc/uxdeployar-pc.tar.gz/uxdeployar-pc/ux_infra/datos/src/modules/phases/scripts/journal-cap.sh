journalctl --disk-usage 2>/dev/null
v=$(cat /etc/systemd/journald.conf /etc/systemd/journald.conf.d/*.conf 2>/dev/null | grep -E '^[[:space:]]*SystemMaxUse=' | tail -n 1 | cut -d= -f2 | tr -d '[:space:]')
[ -n "$v" ] || { echo "✗ SystemMaxUse sin definir: el journal no tiene tope (paso 4.5)"; exit 1; }
m=$(awk -v v="$v" 'BEGIN{n=v+0; u=toupper(substr(v,length(v))); if(u=="K")n/=1024; else if(u=="G")n*=1024; else if(u=="T")n*=1048576; else if(u!="M")n/=1048576; print int(n)}')
[ "$m" -le 500 ] && echo "✔ SystemMaxUse=$v (tope ≤ 500M)" || { echo "✗ SystemMaxUse=$v supera los 500M (paso 4.5)"; exit 1; }
