sudo apt-get update -qq >/dev/null 2>&1 || { echo "apt update falló"; exit 1; }
# Simula la orden de 1.5: apt ya excluye los retenidos con hold y los diferidos por phasing de Ubuntu.
for p in $(apt-mark showhold 2>/dev/null); do echo "Retenido con hold (no cuenta): $p"; done
n=$(apt-get -s upgrade --with-new-pkgs 2>/dev/null | grep -c '^Inst ')
echo "Paquetes pendientes de actualizar: $n"
[ "$n" -eq 0 ]
