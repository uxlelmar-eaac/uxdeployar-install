x=$(sudo bash -c '. /etc/ux/plataforma.env 2>/dev/null; printf "%s|%s" "$UX_R2_BUCKET" "${UX_R2_PREFIJO:-}"')
B=${x%%|*}; P=${x#*|}
[ -n "$B" ] || { echo "✗ falta el bucket en /etc/ux/plataforma.env (E14.4)"; exit 1; }
if [ -z "$P" ]; then
  P=$(hostname -s | tr 'A-Z' 'a-z' | tr -c 'a-z0-9\n' '-' | sed 's/-*$//')
fi
[ -n "$P" ] || P=vps
f=$(sudo rclone --config /etc/ux/rclone.conf lsf "r2:$B/diario/$P/" 2>/dev/null | grep '\.tar\.age$' | sort | tail -1)
[ -n "$f" ] || { echo "✗ no hay un .tar.age en diario/$P/ (E14.5)"; exit 1; }
echo "Último respaldo: diario/$P/$f"
cab=$(sudo rclone --config /etc/ux/rclone.conf cat "r2:$B/diario/$P/$f" 2>/dev/null | head -c 21)
echo "Empieza con: $cab"
case "$cab" in
  age-encryption.org*) exit 0 ;;
  *) echo "✗ el respaldo no empieza con age-encryption.org"; exit 1 ;;
esac
