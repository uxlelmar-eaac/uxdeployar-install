f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
p="${VPS_SSH_PORT:-2222}"
[ "$p" = 22 ] && { echo "No aplica: el inventario usa el puerto 22"; exit 0; }
cfg=$(sudo sshd -T 2>/dev/null | awk '$1=="port"{print $2}' | sort -un)
esc=$(sudo ss -Htln 2>/dev/null | awk '{print $4}' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
grep -qx "$p" <<<"$cfg" || { echo "No aplica: E03 todavía no movió SSH al puerto $p (configurado: $(echo $cfg))"; exit 0; }
if grep -qx "$p" <<<"$esc"; then ok "sshd escucha en el puerto $p"; else ko "sshd está configurado en $p pero no escucha ahí"; fi
if grep -qx 22 <<<"$esc"; then
  if grep -qx 22 <<<"$cfg"; then ko "SSH sigue escuchando en el puerto 22: la configuración todavía lo incluye"; else ko "algo sigue escuchando en el puerto 22 (activación por socket de systemd o ssh sin reiniciar)"; fi
else ok "el puerto 22 ya no escucha"; fi
[ "$f" -eq 0 ]
