x=$(sudo bash -c '. /etc/ux/plataforma.env 2>/dev/null; printf "%s|%s" "$UX_R2_BUCKET" "${UX_R2_PREFIJO:-}"')
B=${x%%|*}; P=${x#*|}
[ -n "$B" ] || { echo "✗ falta el bucket en /etc/ux/plataforma.env (E14.4)"; exit 1; }
if [ -z "$P" ]; then
  P=$(hostname -s | tr 'A-Z' 'a-z' | tr -c 'a-z0-9\n' '-' | sed 's/-*$//')
fi
[ -n "$P" ] || P=vps
l=$(sudo rclone --config /etc/ux/rclone.conf lsf "r2:$B/diario/$P/" 2>/dev/null || true)
age=$(printf '%s\n' "$l" | grep '\.tar\.age$' | sort | tail -1)
[ -n "$age" ] || { echo "✗ no hay un .tar.age en diario/$P/ (E14.5)"; exit 1; }
printf '%s\n' "$l" | grep -qx "${age}.sha256" || {
  echo "✗ falta el .sha256 de $age en diario/$P/"
  exit 1
}
echo "✔ $age y su ${age}.sha256 en diario/$P/"
exit 0
