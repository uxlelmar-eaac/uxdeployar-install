sudo ux-proyecto verificar 2>&1 | grep -E 'Caddy' ; sudo ux-proyecto verificar 2>&1 | grep -q '\[OK\].*Caddy en ejecución'
