f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
pasada(){
  f=0
  while read -r k e; do
    [ -z "$k" ] && continue
    if ! sudo test -e "/proc/sys/${k//.//}"; then ok "$k no existe en este kernel (nada que endurecer)"; continue; fi
    if ! g=$(sudo sysctl -n "$k" 2>/dev/null); then ko "$k existe pero no se pudo leer"; continue; fi
    case "|$e|" in *"|$g|"*) ok "$k = $g" ;; *) ko "$k = ${g:-?} (esperado $e)" ;; esac
  done <<'LISTA'
net.ipv4.conf.all.rp_filter 1
net.ipv4.conf.default.rp_filter 1
net.ipv4.tcp_syncookies 1
net.ipv4.icmp_echo_ignore_broadcasts 1
net.ipv4.icmp_ignore_bogus_error_responses 1
net.ipv4.conf.all.accept_redirects 0
net.ipv4.conf.default.accept_redirects 0
net.ipv4.conf.all.secure_redirects 0
net.ipv4.conf.all.send_redirects 0
net.ipv4.conf.default.send_redirects 0
net.ipv4.conf.all.accept_source_route 0
net.ipv4.conf.default.accept_source_route 0
net.ipv4.conf.all.log_martians 1
net.ipv4.conf.default.log_martians 1
net.ipv4.ip_unprivileged_port_start 80
kernel.kptr_restrict 2
kernel.dmesg_restrict 1
kernel.yama.ptrace_scope 2
kernel.sysrq 0
kernel.unprivileged_bpf_disabled 1|2
net.core.bpf_jit_harden 2
dev.tty.ldisc_autoload 0
fs.suid_dumpable 0
fs.protected_hardlinks 1
fs.protected_symlinks 1
fs.protected_fifos 2
fs.protected_regular 2
kernel.randomize_va_space 2
LISTA
}
ufw_pisa(){
  u=$(. /etc/default/ufw 2>/dev/null; echo "${IPT_SYSCTL:-}")
  { [ -n "$u" ] && [ -f "$u" ]; } || return 0
  while read -r k v; do
    l=$(grep -E "^[[:space:]]*${k//.//}[[:space:]]*=" "$u" | tail -n 1)
    [ -n "$l" ] || continue
    uv=$(printf '%s' "${l#*=}" | tr -d '[:space:]')
    [ "$uv" = "$v" ] || ko "UFW pone $k = $uv en cada arranque ($u): repite E07, su paso 7.1 lo comenta"
  done < <(sed -nE 's/^[[:space:]]*([a-z0-9_.]+)[[:space:]]*=[[:space:]]*([0-9]+)[[:space:]]*$/\1 \2/p' /etc/sysctl.d/zz-ux-hardening.conf)
}
pasada
if [ ! -f /etc/sysctl.d/zz-ux-hardening.conf ]; then
  ko "E07 todavía no se aplicó: falta /etc/sysctl.d/zz-ux-hardening.conf"
elif [ "$f" -ne 0 ]; then
  echo "⚠ Diagnóstico: la clave cambió después de E07 ⚠"
  echo "Fuentes persistentes que mencionan log_martians:"
  fu=$(grep -rns "log_martians" /etc/sysctl.conf /etc/sysctl.d /run/sysctl.d /usr/lib/sysctl.d /etc/ufw/sysctl.conf)
  if [ -n "$fu" ]; then echo "$fu" | sed 's/^/  /'; else echo "  (ninguna)"; fi
  echo "Valores en vivo por interfaz:"; sysctl -a 2>/dev/null | grep "log_martians" | sed 's/^/  /'
  ls -l /etc/sysctl.d/zz-ux-hardening.conf 2>&1 | sed 's/^/  /'
  journalctl -b -u systemd-sysctl --no-pager 2>/dev/null | tail -3 | sed 's/^/  /'
  echo "⚠ Reaplicando la configuración persistente (sysctl --system) ⚠"
  sudo sysctl -q --system >/dev/null 2>&1 || true
  pasada
  [ "$f" -eq 0 ] && echo "✔ El valor en vivo se había desviado de la configuración persistente; ya quedó corregido. Revisa el diagnóstico de arriba para ver qué lo cambió."
fi
[ -f /etc/sysctl.d/zz-ux-hardening.conf ] && ufw_pisa
[ "$f" -eq 0 ] || echo "⚠ Repite la etapa E07 («Ejecutar esta etapa») y vuelve a validar: su paso 7.1 reaplica y comprueba estas claves."
[ "$f" -eq 0 ]
