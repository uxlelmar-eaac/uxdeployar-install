f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
command -v ux-as >/dev/null 2>&1 || { echo "No aplica: la plataforma UX (E11) todavía no está instalada"; exit 0; }
us=$(sudo find /etc/ux/projects -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | tr '\n' ' ')
caddy=""; id ux-caddy >/dev/null 2>&1 && caddy=ux-caddy
[ -n "$us$caddy" ] || { echo "No aplica: todavía no hay proyectos ni Caddy en Podman"; exit 0; }

# Slot app inactivo de blue/green (quedó detenido a propósito para rollback).
# Nombres: <proyecto>-<rol>-app (blue) y <proyecto>-<rol>-green-app (green).
idle_bg_slot() {
  local u="$1" n="$2" home rest role slot active
  case "$n" in
    "$u"-*-green-app)
      rest="${n#"$u"-}"
      role="${rest%-green-app}"
      slot=green
      ;;
    "$u"-*-app)
      rest="${n#"$u"-}"
      role="${rest%-app}"
      slot=blue
      ;;
    *) return 1 ;;
  esac
  [ -n "$role" ] && [[ "$role" != */* ]] || return 1
  home=$(getent passwd "$u" | cut -d: -f6)
  [ -n "$home" ] || return 1
  active=$(sudo cat "$home/roles/$role/.active-slot" 2>/dev/null || true)
  case "$active" in blue|green) ;; *) return 1 ;; esac
  [ "$active" != "$slot" ]
}

t=0
for u in $caddy $us; do
  id "$u" >/dev/null 2>&1 || continue
  while read -r n s c; do
    [ -n "$n" ] || continue
    t=$((t+1))
    case "$s" in
      restarting) ko "$u: $n se está reiniciando en bucle (revisa su registro)" ;;
      exited)
        if [ "$c" != 0 ]; then
          if idle_bg_slot "$u" "$n"; then
            ok "$u: $n es el slot blue/green inactivo (detenido para rollback; código $c)"
          else
            ko "$u: $n está detenido con código $c"
          fi
        fi
        ;;
    esac
  done < <(sudo ux-as "$u" podman ps -a --format '{{.Names}} {{.State}} {{.ExitCode}}' 2>/dev/null)
done
[ "$f" -eq 0 ] && ok "ningún contenedor reiniciándose ni el slot activo detenido con error ($t revisado(s))"
[ "$f" -eq 0 ]
