f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
command -v ux-as >/dev/null 2>&1 || { echo "No aplica: la plataforma UX (E11) todavía no está instalada"; exit 0; }
us=$(sudo find /etc/ux/projects -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | tr '\n' ' ')
caddy=""; id ux-caddy >/dev/null 2>&1 && caddy=ux-caddy
[ -n "$us$caddy" ] || { echo "No aplica: todavía no hay proyectos ni Caddy en Podman"; exit 0; }
t=0
for u in $caddy $us; do
  id "$u" >/dev/null 2>&1 || continue
  while read -r n s c; do
    [ -n "$n" ] || continue
    t=$((t+1))
    case "$s" in
      restarting) ko "$u: $n se está reiniciando en bucle (revisa su registro)" ;;
      exited) [ "$c" = 0 ] || ko "$u: $n está detenido con código $c" ;;
    esac
  done < <(sudo ux-as "$u" podman ps -a --format '{{.Names}} {{.State}} {{.ExitCode}}' 2>/dev/null)
done
[ "$f" -eq 0 ] && ok "ningún contenedor reiniciándose ni detenido con error ($t revisado(s))"
[ "$f" -eq 0 ]
