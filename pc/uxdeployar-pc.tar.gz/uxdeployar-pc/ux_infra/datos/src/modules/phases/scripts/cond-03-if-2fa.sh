if ! [ -f /etc/ssh/sshd_config.d/00-vps-mfa.conf ]; then echo 'No aplica: el 2FA no está activado'; exit 0; fi
sudo sshd -T | grep authenticationmethods
