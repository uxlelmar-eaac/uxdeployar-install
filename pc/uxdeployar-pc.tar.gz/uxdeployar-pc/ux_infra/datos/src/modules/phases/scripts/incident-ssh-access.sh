f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
if e=$(sudo sshd -t 2>&1); then ok "la configuración de sshd es válida (sshd -t)"; else ko "sshd -t encuentra errores: $(echo "$e" | head -n 2 | tr '\n' ' ')"; fi
esc=$(sudo ss -Htln 2>/dev/null | awk '{print $4}' | sed -E 's/.*:([0-9]+)$/\1/' | sort -un)
ufw=0; command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q '^Status: active' && ufw=1
for p in $(sudo sshd -T 2>/dev/null | awk '$1=="port"{print $2}' | sort -un); do
  if grep -qx "$p" <<<"$esc"; then ok "sshd escucha en el puerto $p"; else ko "sshd está configurado en el puerto $p pero nada escucha ahí (valida con sshd -t y reinicia ssh)"; fi
  [ "$ufw" -eq 1 ] || continue
  if sudo ufw status 2>/dev/null | grep -qE "^($p(/tcp)?|OpenSSH)[[:space:]]+(ALLOW|LIMIT)"; then ok "UFW permite el puerto SSH $p"; else ko "UFW está activo y no permite el puerto SSH $p: cualquier sesión nueva quedaría fuera"; fi
done
if command -v fail2ban-client >/dev/null 2>&1; then
  n=$(sudo fail2ban-client status sshd 2>/dev/null | awk -F: '/Currently banned/{gsub(/[[:space:]]/,"",$2); print $2}')
  if [ -n "$n" ]; then ok "Fail2Ban: $n IP(s) bloqueada(s) ahora en la cárcel sshd (si una es la tuya, desbloquéala)"; else ok "Fail2Ban no tiene la cárcel sshd activa"; fi
fi
[ "$f" -eq 0 ]
