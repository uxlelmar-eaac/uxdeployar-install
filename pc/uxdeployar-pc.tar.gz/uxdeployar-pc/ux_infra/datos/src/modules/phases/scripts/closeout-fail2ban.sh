f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
unidad fail2ban
chk(){ g=$(sudo fail2ban-client get sshd "$1" 2>/dev/null); if [ "$g" = "$2" ]; then ok "sshd $1 = $2"; else ko "sshd $1 = ${g:-?} (esperado $2)"; fi; }
chk maxretry 3; chk bantime 86400; chk findtime 600
sudo fail2ban-client status sshd >/dev/null 2>&1 && ok "cárcel sshd activa" || ko "cárcel sshd inactiva"
[ "$f" -eq 0 ]
