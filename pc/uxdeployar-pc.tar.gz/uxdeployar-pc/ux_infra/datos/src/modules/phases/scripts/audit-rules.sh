r=$(sudo auditctl -l 2>/dev/null) || { echo "✗ auditctl no responde (paso 9.6)"; exit 1; }
f=0
for w in /etc/passwd /etc/shadow /etc/sudoers /etc/sudoers.d /etc/ssh/sshd_config /etc/ssh/sshd_config.d; do
  if grep -qE -e "^-w $w -p [rwxa]*" -e "(path|dir)=$w( |$)" <<<"$r"; then echo "✔ vigilado: $w"; else echo "✗ falta la regla de auditoría sobre $w (paso 9.6)"; f=1; fi
done
exit $f
