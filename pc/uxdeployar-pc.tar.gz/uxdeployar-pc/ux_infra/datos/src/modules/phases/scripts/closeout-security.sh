f=0; ok(){ echo "✔ $*"; }; ko(){ echo "✗ $*"; f=$((f+1)); }
perm(){ p=$(sudo stat -c %a "$1" 2>/dev/null); o=$(sudo stat -c %U:%G "$1" 2>/dev/null)
  if [ -z "$p" ]; then ko "$1 no existe"; return; fi
  case " $2 " in *" $p "*) ok "$1 → $p $o" ;; *) ko "$1 → $p $o (esperado $2)" ;; esac; }
unidad(){ a=$(systemctl is-active "$1" 2>/dev/null); e=$(systemctl is-enabled "$1" 2>/dev/null)
  if [ "$a" = active ] || { [ "$2" = timer ] && [ "$a" = waiting ]; }; then ok "$1 activo ($e)"; else ko "$1 no está activo ($a)"; fi; }
sudo aa-status --enabled 2>/dev/null && ok "AppArmor habilitado" || ko "AppArmor deshabilitado"
sudo cat /sys/kernel/security/lsm 2>/dev/null | grep -qw apparmor && ok "AppArmor entre los módulos de seguridad del kernel" || ko "AppArmor no está entre los módulos de seguridad del kernel (/sys/kernel/security/lsm)"
e=$(sudo aa-status 2>/dev/null | awk '/profiles are in enforce mode/{print $1; exit}')
[ "${e:-0}" -gt 0 ] && ok "$e perfiles en modo enforce" || ko "ningún perfil en enforce"
unidad auditd
r=$(sudo auditctl -l 2>/dev/null | grep -vc 'No rules')
[ "${r:-0}" -gt 0 ] && ok "$r regla(s) de auditoría cargadas" || ko "auditd sin reglas"
en=$(sudo auditctl -s 2>/dev/null | awk '/^enabled/{print $2}')
case "$en" in 1|2) ok "auditoría habilitada (enabled=$en)" ;; *) ko "auditoría deshabilitada (enabled=${en:-?})" ;; esac
sudo test -s /var/lib/aide/aide.db && ok "base de datos de AIDE presente" || ko "falta /var/lib/aide/aide.db"
unidad aide-check.timer timer
systemctl is-enabled --quiet dailyaidecheck.timer 2>/dev/null && ko "dailyaidecheck.timer de Debian activo: AIDE correría dos veces (paso 9.7)" || ok "un solo timer de AIDE (aide-check.timer)"
[ "$f" -eq 0 ]
