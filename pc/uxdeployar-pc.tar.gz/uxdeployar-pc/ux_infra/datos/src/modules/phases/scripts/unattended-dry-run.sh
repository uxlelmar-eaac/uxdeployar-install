for i in $(seq 300); do
  systemctl is-active -q apt-daily.service apt-daily-upgrade.service || break
  [ "$i" -eq 1 ] && echo "ℹ apt-daily está trabajando (actualizaciones del sistema): espero a que termine"
  sleep 2
done
for _ in 1 2 3; do
  out=$(sudo unattended-upgrade --dry-run 2>&1); rc=$?
  printf '%s\n' "$out" | grep -q 'Lock could not be acquired' || break
  echo "ℹ otro gestor de paquetes tiene el candado: reintento en 20 s"
  sleep 20
done
printf '%s\n' "$out" | tail -n 15
[ "$rc" -eq 0 ] && echo "✔ unattended-upgrade --dry-run sin errores" || { echo "✗ unattended-upgrade --dry-run terminó con código $rc"; exit 1; }
