"""Archivos que la app comparte con el panel (scripts de verificación, tablas JSON).

En el repo se leen de su sitio (`src/...`); el paquete del programa del PC
(installer/release/paquete-pc.sh) los lleva copiados en `ux_infra/datos/` con la misma ruta relativa.
"""

from __future__ import annotations

from pathlib import Path

_AQUI = Path(__file__).resolve().parent
DATOS = _AQUI / "datos"
RAIZ_REPO = _AQUI.parents[2]

# Lo que paquete-pc.sh copia a `ux_infra/datos/` (rutas relativas a la raíz del repo).
EMPAQUETADOS = (
    "src/modules/phases/scripts",
    "src/modules/operations/domain/catalog/alert-keys.json",
)


def archivo(relativa: str) -> Path:
    empaquetado = DATOS / relativa
    return empaquetado if empaquetado.exists() else RAIZ_REPO / relativa
