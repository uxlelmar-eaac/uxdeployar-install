"""Segundo factor TOTP (RFC 6238): SHA-1, 30 s, 6 dígitos.

Compatible con ``libpam-google-authenticator``. Espejo de
``05-vps/app/internal/totp/totp.go``.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote

__all__ = [
    "nuevo_secreto",
    "codigo",
    "verificar",
    "uri",
    "codigos_respaldo",
    "archivo_google_authenticator",
]

_PERIODO = 30
_DIGITOS = 6


def nuevo_secreto() -> str:
    """Secreto aleatorio de 160 bits en base32 (sin relleno)."""
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def _decodificar(secreto: str) -> bytes:
    s = secreto.strip().upper()
    s += "=" * (-len(s) % 8)  # base32 sin relleno -> con relleno
    try:
        return base64.b32decode(s, casefold=True)
    except Exception as exc:  # noqa: BLE001 - mensaje espejo del original
        raise ValueError(f"secreto TOTP no válido: {exc}") from exc


def codigo(secreto: str, t: float | None = None) -> str:
    """Código TOTP del instante ``t`` (por defecto, ahora)."""
    clave = _decodificar(secreto)
    contador = int((time.time() if t is None else t) // _PERIODO)
    msg = struct.pack(">Q", contador)
    h = hmac.new(clave, msg, hashlib.sha1).digest()
    o = h[-1] & 0x0F
    n = (
        (h[o] & 0x7F) << 24
        | (h[o + 1] & 0xFF) << 16
        | (h[o + 2] & 0xFF) << 8
        | (h[o + 3] & 0xFF)
    )
    return f"{n % 10**_DIGITOS:0{_DIGITOS}d}"


def verificar(secreto: str, codigo_introducido: str, t: float | None = None) -> bool:
    """Acepta el código del intervalo actual y de los vecinos (±30 s)."""
    c = codigo_introducido.strip().replace(" ", "")
    if len(c) != _DIGITOS:
        return False
    ahora = time.time() if t is None else t
    for desfase in (0.0, -float(_PERIODO), float(_PERIODO)):
        try:
            if hmac.compare_digest(codigo(secreto, ahora + desfase), c):
                return True
        except ValueError:
            return False
    return False


def uri(emisor: str, cuenta: str, secreto: str) -> str:
    """URI ``otpauth://`` para las apps de autenticación (mismo orden de parámetros que el original)."""
    # Igual que url.PathEscape de Go: se conservan los sub-delims (salvo '/' ';' ',') y ':' '@'.
    etiqueta = quote(f"{emisor}:{cuenta}", safe="!$&'()*+=:@")
    # url.Values.Encode() ordena las claves alfabéticamente.
    consulta = (
        f"algorithm=SHA1&digits={_DIGITOS}&issuer={quote(emisor, safe='')}"
        f"&period={_PERIODO}&secret={quote(secreto, safe='')}"
    )
    return f"otpauth://totp/{etiqueta}?{consulta}"


def codigos_respaldo(n: int) -> list[str]:
    """``n`` códigos de emergencia de 8 dígitos (de un solo uso)."""
    return [f"{secrets.randbelow(90_000_000) + 10_000_000:08d}" for _ in range(n)]


def archivo_google_authenticator(secreto: str, respaldo: list[str]) -> str:
    """Contenido de ``~/.google_authenticator`` equivalente a
    ``google-authenticator -t -d -f -r 3 -R 30 -w 3`` (paso 3.5 del contrato)."""
    partes = [
        secreto,
        '" RATE_LIMIT 3 30',
        '" WINDOW_SIZE 3',
        '" DISALLOW_REUSE',
        '" TOTP_AUTH',
        *respaldo,
        "",
    ]
    return "\n".join(partes)
