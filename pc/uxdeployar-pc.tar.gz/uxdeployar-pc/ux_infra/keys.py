"""Llaves SSH del administrador (ed25519) y lectura de llaves locales.

Espejo de ``05-vps/app/internal/keys/keys.go``. Las llaves privadas nunca
salen de esta computadora.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import paramiko

from . import ssh as sshx
from .util import expandir_ruta


class ErrorExiste(Exception):
    """La llave ya existe y no se pidió sobrescribirla."""


class ErrorPassphrase(Exception):
    """La llave privada está cifrada y no se dio (o no coincide) la passphrase."""


@dataclass
class ParSSH:
    ruta_privada: str
    ruta_publica: str
    publica: str  # línea completa para authorized_keys
    huella: str


def generar_ssh(ruta: str, comentario: str = "", passphrase: str = "", sobrescribir: bool = False) -> ParSSH:
    """Crea una llave ed25519 (con passphrase opcional) en ``ruta`` y ``ruta.pub``.

    Se niega a sobrescribir salvo que se indique (``ErrorExiste``).
    """
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    ruta = expandir_ruta(ruta)
    if not ruta:
        raise ValueError("falta la ruta de la llave")
    destino = Path(ruta)
    if destino.exists() and not sobrescribir:
        raise ErrorExiste("la llave ya existe")
    if not comentario:
        comentario = "acceso-vps"
    if len(comentario) > 80:
        comentario = comentario[:80]

    privada = Ed25519PrivateKey.generate()
    cifrado = (
        serialization.NoEncryption()
        if not passphrase
        else serialization.BestAvailableEncryption(passphrase.encode("utf-8"))
    )
    pem = privada.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH, cifrado
    )

    destino.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    _escribir_privado(destino, pem)
    try:
        firmante = paramiko.Ed25519Key.from_private_key_file(str(destino), password=passphrase or None)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"no pude releer la llave generada: {exc}") from exc
    linea = f"{firmante.get_name()} {firmante.get_base64()} {comentario}"
    _escribir(destino.with_name(destino.name + ".pub"), (linea + "\n").encode(), 0o644)
    return ParSSH(
        ruta_privada=str(destino),
        ruta_publica=str(destino) + ".pub",
        publica=linea,
        huella=sshx.huella(firmante),
    )


def leer_publica(ruta: str) -> str:
    """Lee una llave pública local y valida que sea una línea SSH."""
    try:
        datos = Path(expandir_ruta(ruta)).read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError(f"no pude leer la llave pública '{ruta}': {exc}") from exc
    linea = datos.strip()
    partes = linea.split()
    if len(partes) < 2 or not any(
        partes[0].startswith(p) for p in ("ssh-", "ecdsa-", "sk-")
    ):
        raise ValueError(
            "el archivo no parece contener una llave pública SSH (debe empezar con ssh-ed25519 o ssh-rsa)"
        )
    if "\r" in linea or "\n" in linea:
        raise ValueError("la llave pública debe estar en una sola línea")
    return linea


@dataclass
class LlaveLocal:
    ruta: str
    ruta_publica: str
    tipo: str
    huella: str

    def json(self) -> dict:
        return {
            "ruta": self.ruta,
            "ruta_publica": self.ruta_publica,
            "tipo": self.tipo,
            "huella": self.huella,
        }


def listar_locales(dir_ssh: str | os.PathLike[str] | None = None) -> list[LlaveLocal]:
    """Busca pares de llaves (archivo + .pub) en ``~/.ssh`` (o en el directorio dado)."""
    dir_ = Path(dir_ssh) if dir_ssh else Path.home() / ".ssh"
    if not dir_.is_dir():
        return []
    res: list[LlaveLocal] = []
    for pub in sorted(dir_.iterdir()):
        if pub.is_dir() or not pub.name.endswith(".pub"):
            continue
        priv = pub.with_name(pub.name[: -len(".pub")])
        if not priv.is_file():
            continue
        try:
            linea = pub.read_text(encoding="utf-8")
        except OSError:
            continue
        try:
            clave = parsear_publica(linea)
        except ValueError:
            continue
        res.append(
            LlaveLocal(
                ruta=str(priv),
                ruta_publica=str(pub),
                tipo=clave.get_name(),
                huella=sshx.huella(clave),
            )
        )
    return res


def parsear_publica(linea: str) -> paramiko.PKey:
    """Devuelve la clave pública a partir de una línea de authorized_keys."""
    import base64

    partes = linea.split()
    if not partes:
        raise ValueError("línea de llave pública vacía")
    tipo, b64 = partes[0], partes[1] if len(partes) > 1 else ""
    try:
        datos = base64.b64decode(b64)
    except Exception as exc:  # noqa: BLE001
        raise ValueError("llave pública con codificación no válida") from exc
    intentos = []
    if tipo == "ssh-ed25519":
        intentos.append(lambda: paramiko.Ed25519Key(data=datos))
    elif tipo in ("ssh-rsa", "rsa-sha2-256", "rsa-sha2-512"):
        intentos.append(lambda: paramiko.RSAKey(data=datos))
    elif tipo.startswith("ecdsa-sha2-"):
        intentos.append(lambda: paramiko.ECDSAKey(data=datos))
    else:
        raise ValueError(f"no reconocí el tipo de llave '{tipo}'")
    ultimo: Exception | None = None
    for intento in intentos:
        try:
            return intento()
        except Exception as exc:  # noqa: BLE001
            ultimo = exc
    raise ValueError(f"llave pública '{tipo}' no válida: {ultimo}") from ultimo


def regenerar_publica(ruta: str, passphrase: str = "") -> str:
    """Recrea ``ruta.pub`` desde la llave privada (equivale a ``ssh-keygen -y -f``)."""
    destino = Path(expandir_ruta(ruta))
    try:
        firmante = paramiko.PKey.from_path(str(destino), password=passphrase or None)
    except paramiko.PasswordRequiredException as exc:
        raise ErrorPassphrase("la llave pide passphrase") from exc
    except Exception as exc:  # noqa: BLE001
        texto = str(exc).lower()
        if "decrypt" in texto or "bad" in texto:
            raise ErrorPassphrase("la llave pide passphrase") from exc
        raise ValueError(f"no es una llave privada válida: {exc}") from exc
    linea = f"{firmante.get_name()} {firmante.get_base64()} acceso-vps"
    _escribir(destino.with_name(destino.name + ".pub"), (linea + "\n").encode(), 0o644)
    return linea


def _escribir_privado(ruta: Path, datos: bytes) -> None:
    _escribir(ruta, datos, 0o600)


def _escribir(ruta: Path, datos: bytes, modo: int) -> None:
    fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, modo)
    with os.fdopen(fd, "wb") as fh:
        fh.write(datos)
    os.chmod(ruta, modo)
