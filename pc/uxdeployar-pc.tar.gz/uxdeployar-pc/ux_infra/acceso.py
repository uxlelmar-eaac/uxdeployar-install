"""Automatiza, en la PC del operador, los pasos «humanos» de la etapa E01:
limpiar huellas viejas de ``known_hosts`` (1.2), revisar la llave SSH (1.3) y
dejar el host verificado en ``known_hosts`` tras el primer acceso (1.4).

Espejo de ``05-vps/app/internal/acceso/``. Soporta el formato de OpenSSH,
incluidas las entradas con hash (``|1|sal|hash``).
"""

from __future__ import annotations

import base64
import hmac
import hashlib
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path

from . import keys, ssh as sshx, util

_NOMBRE_LLAVE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,60}$")


def es_nombre_llave(nombre: str) -> bool:
    return bool(_NOMBRE_LLAVE.match(nombre))


def ruta_known_hosts() -> str:
    return str(Path.home() / ".ssh" / "known_hosts")


def nombre_busqueda(host: str, puerto: int) -> str:
    if puerto in (0, 22):
        return host
    return f"[{host}]:{puerto}"


def coincidir_patron(patron: str, nombre: str) -> bool:
    patron = patron.strip()
    if patron.startswith("|1|"):
        partes = patron.split("|")
        if len(partes) != 4:
            return False
        try:
            sal = base64.b64decode(partes[2])
            esperado = base64.b64decode(partes[3])
        except Exception:  # noqa: BLE001
            return False
        return hmac.compare_digest(hmac.new(sal, nombre.encode(), hashlib.sha1).digest(), esperado)
    return patron.lower() == nombre.lower()


@dataclass
class Entrada:
    linea: int
    tipo: str
    huella: str

    def json(self) -> dict:
        return {"linea": self.linea, "tipo": self.tipo, "huella": self.huella}


@dataclass
class _LineaKH:
    patrones: list[str]
    clave: "object | None"
    marcador: str = ""

    def coincide(self, nombre: str) -> bool:
        if self.clave is None or self.marcador:
            return False
        hallado = False
        for p in self.patrones:
            if p.startswith("!"):
                if coincidir_patron(p[1:], nombre):
                    return False
                continue
            if coincidir_patron(p, nombre):
                hallado = True
        return hallado


def _analizar(linea: str) -> _LineaKH:
    t = linea.strip()
    if not t or t.startswith("#"):
        return _LineaKH([], None)
    campos = t.split()
    marcador = ""
    if campos[0].startswith("@"):
        marcador = campos.pop(0)
    if len(campos) < 3:
        return _LineaKH([], None, marcador)
    try:
        datos = base64.b64decode(campos[2])
    except Exception:  # noqa: BLE001
        return _LineaKH([], None, marcador)
    clave = keys.parsear_publica(f"{campos[1]} {campos[2]}")
    return _LineaKH(campos[0].split(","), clave, marcador)


def _leer_lineas(ruta: str) -> list[str]:
    try:
        return Path(ruta).read_text(encoding="utf-8", errors="replace").splitlines()
    except FileNotFoundError:
        return []


def buscar(ruta: str, host: str, puerto: int) -> list[Entrada]:
    nombre = nombre_busqueda(host, puerto)
    res = []
    for i, l in enumerate(_leer_lineas(ruta)):
        a = _analizar(l)
        if a.coincide(nombre):
            res.append(Entrada(linea=i + 1, tipo=a.clave.get_name(), huella=sshx.huella(a.clave)))
    return res


def quitar(ruta: str, host: str, puerto: int, conservar: str = "") -> tuple[int, str]:
    """Elimina de known_hosts las claves de host:puerto (conservando la huella indicada).

    Antes de modificar guarda una copia. Devuelve (quitadas, ruta de la copia).
    """
    lineas = _leer_lineas(ruta)
    if not lineas:
        return 0, ""
    nombre = nombre_busqueda(host, puerto)
    nuevas: list[str] = []
    quitadas = 0
    for l in lineas:
        a = _analizar(l)
        if not a.coincide(nombre) or (conservar and a.clave is not None and sshx.huella(a.clave) == conservar):
            nuevas.append(l)
            continue
        quitadas += 1
        if len(a.patrones) > 1:
            resto = [p for p in a.patrones if not coincidir_patron(p.lstrip("!"), nombre)]
            campos = l.strip().split()
            if campos[0].startswith("@"):
                campos[1] = ",".join(resto)
            else:
                campos[0] = ",".join(resto)
            nuevas.append(" ".join(campos))
    if quitadas == 0:
        return 0, ""
    copia = ruta + ".ux-copia-" + time.strftime("%Y%m%d-%H%M%S")
    original = Path(ruta).read_bytes()
    Path(copia).write_bytes(original)
    os.chmod(copia, 0o600)
    salida = "\n".join(nuevas)
    if nuevas:
        salida += "\n"
    _escribir(ruta, salida)
    return quitadas, copia


def anadir(ruta: str, host: str, puerto: int, clave) -> bool:
    """Agrega la clave del servidor a known_hosts (si no estaba). Devuelve True si escribió."""
    if not ruta:
        raise ValueError("no encuentro tu carpeta personal")
    huella_ = sshx.huella(clave)
    for e in buscar(ruta, host, puerto):
        if e.huella == huella_:
            return False
    Path(ruta).parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    linea = nombre_busqueda(host, puerto) + " " + f"{clave.get_name()} {clave.get_base64()}" + "\n"
    _anexar(ruta, linea)
    return True


def _escribir(ruta: str, contenido: str) -> None:
    fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(contenido)
    os.chmod(ruta, 0o600)


def _anexar(ruta: str, linea: str) -> None:
    try:
        contenido = Path(ruta).read_text(encoding="utf-8")
        if contenido and not contenido.endswith("\n"):
            linea = "\n" + linea
        contenido += linea
    except FileNotFoundError:
        contenido = linea
    _escribir(ruta, contenido)


# ───────────────────────────── llave SSH local ─────────────────────────


@dataclass
class EstadoLlave:
    ruta: str = ""
    ruta_publica: str = ""
    privada: bool = False
    publica: bool = False
    cifrada: bool = False
    huella: str = ""
    tipo: str = ""
    solo_privada: bool = False
    ruta_expandida: str = ""

    def json(self) -> dict:
        return {
            "ruta": self.ruta,
            "ruta_publica": self.ruta_publica,
            "privada": self.privada,
            "publica": self.publica,
            "cifrada": self.cifrada,
            "huella": self.huella,
            "tipo": self.tipo,
            "solo_privada": self.solo_privada,
            "ruta_expandida": self.ruta_expandida,
        }

    def completa(self) -> bool:
        return self.privada and self.publica


def inspeccionar_llave(ruta: str) -> EstadoLlave:
    """Revisa, sin pedir la passphrase, qué hay en ``ruta`` (y ``ruta.pub``)."""
    ruta = ruta.strip()
    e = EstadoLlave(ruta=ruta)
    if not ruta:
        return e
    priv = util.expandir_ruta(ruta)
    e.ruta_expandida = priv
    e.ruta_publica = priv + ".pub"
    if Path(priv).is_file():
        e.privada = True
        try:
            sshx.cargar_firmante(priv)
        except sshx.ErrorPassphrase:
            e.cifrada = True
        except sshx.ErrorAuth as exc:
            # paramiko puede reportar una llave cifrada sin la passphrase como
            # SSHException en lugar de PasswordRequiredException: se mira el texto.
            if any(k in str(exc).lower() for k in ("passphrase", "password", "encrypt", "cifrad")):
                e.cifrada = True
    if Path(e.ruta_publica).is_file():
        try:
            clave = keys.parsear_publica(Path(e.ruta_publica).read_text(encoding="utf-8"))
            e.publica = True
            e.huella = sshx.huella(clave)
            e.tipo = clave.get_name()
        except ValueError:
            pass
    e.solo_privada = e.privada and not e.publica
    return e
