"""``gh`` y ``minisign`` en el PC: se comprueban y, si faltan, se ofrecen instalar con el gestor del sistema."""

from __future__ import annotations

import platform
import shutil
from typing import Callable

from ..instalador.consola import Consola
from . import ErrorPublicacion
from .gh import Correr, Gh, correr

URLS = {
    "gh": "https://cli.github.com",
    "minisign": "https://github.com/jedisct1/minisign/releases",
}


def orden_instalacion(nombre: str, sistema: str, which: Callable[[str], str | None] = shutil.which) -> list[str]:
    """Orden que instala ``nombre`` en este sistema, o [] si no hay un gestor conocido."""
    if sistema == "darwin" and which("brew"):
        return ["brew", "install", nombre]
    if sistema == "linux" and which("apt-get"):
        return ["sudo", "apt-get", "install", "-y", nombre]
    if sistema == "linux" and which("dnf"):
        return ["sudo", "dnf", "install", "-y", nombre]
    if sistema == "windows":
        if nombre == "minisign" and which("scoop"):
            return ["scoop", "install", "minisign"]
        if which("winget"):
            paquete = "GitHub.cli" if nombre == "gh" else "jedisct1.minisign"
            return ["winget", "install", "-e", "--id", paquete]
    return []


def asegurar(
    consola: Consola,
    nombre: str,
    which: Callable[[str], str | None] = shutil.which,
    sistema: Callable[[], str] = platform.system,
    correr_: Correr = correr,
) -> None:
    if which(nombre):
        return
    consola.aviso(f"falta {nombre} en este PC")
    orden = orden_instalacion(nombre, sistema().lower(), which)
    if orden and consola.confirmar(f"¿Lo instalo con «{' '.join(orden)}»?"):
        correr_(orden, None, True)
        if which(nombre):
            consola.ok(f"{nombre} instalado")
            return
        consola.aviso("si acabas de instalarlo, abre una terminal nueva para que aparezca en el PATH")
    raise ErrorPublicacion(f"instala {nombre} ({URLS[nombre]}) y vuelve a ejecutar la orden")


def asegurar_sesion(consola: Consola, gh: Gh) -> str:
    """Inicia sesión en ``gh`` si hace falta y devuelve tu usuario de GitHub."""
    if gh.ejecutar("auth", "status").codigo != 0:
        consola.info("Inicia sesión en GitHub: se abrirá el navegador con un código de un solo uso.")
        gh.ejecutar(
            "auth", "login", "--hostname", "github.com", "--git-protocol", "https",
            "--web", "--scopes", "read:packages", en_vivo=True,
        )
        if gh.ejecutar("auth", "status").codigo != 0:
            raise ErrorPublicacion("no hay sesión de gh: ejecuta «gh auth login» y vuelve a intentarlo")
    r = gh.api("user")
    if r.estado != 200 or not isinstance(r.datos, dict):
        raise ErrorPublicacion(f"GitHub respondió {r.estado} al leer tu usuario")
    usuario = str(r.datos.get("login", ""))
    consola.ok(f"sesión de GitHub: {usuario}")
    return usuario
