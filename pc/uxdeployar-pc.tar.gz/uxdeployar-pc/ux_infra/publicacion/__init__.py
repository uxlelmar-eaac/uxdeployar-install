"""Configuración de GitHub y publicación de versiones desde el PC (``ux-infra github``).

Todo pasa por la CLI ``gh`` con la sesión del usuario; los secretos viajan por stdin.
"""

DUENO = "uxlelmar-eaac"
REPO_BACKEND = "uxdeployar-backend"
REPO_FRONTEND = "uxdeployar-frontend"
REPO_INSTALL = "uxdeployar-install"


class ErrorPublicacion(Exception):
    """Fallo que se explica al usuario y detiene la orden."""
