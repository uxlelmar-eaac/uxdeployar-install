"""Envoltorio de la CLI ``gh``: órdenes con stdin y llamadas a la API con su código HTTP."""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable

from .. import util
from . import ErrorPublicacion


@dataclass
class Resultado:
    codigo: int
    stdout: str = ""
    stderr: str = ""


@dataclass
class RespuestaApi:
    estado: int
    datos: Any = None
    cabeceras: dict[str, str] = field(default_factory=dict)


Correr = Callable[[list[str], "str | None", bool], Resultado]


def correr(args: list[str], entrada: str | None = None, en_vivo: bool = False) -> Resultado:
    """``en_vivo`` hereda la terminal (login, seguimiento del workflow); si no, captura la salida."""
    try:
        if en_vivo:
            p = subprocess.run(args, input=entrada, text=True)
            return Resultado(p.returncode)
        p = subprocess.run(args, input=entrada, capture_output=True, text=True)
        return Resultado(p.returncode, p.stdout, p.stderr)
    except FileNotFoundError as exc:
        raise ErrorPublicacion(f"no encuentro {args[0]}") from exc


_ESTADO = re.compile(r"^HTTP/[\d.]+ (\d{3})")


def parsear_api(r: Resultado) -> RespuestaApi:
    m = _ESTADO.match(r.stdout)
    if not m:
        raise ErrorPublicacion(f"gh api falló: {util.truncar((r.stderr or r.stdout).strip(), 300)}")
    partes = re.split(r"\r?\n\r?\n", r.stdout, maxsplit=1)
    cabeceras: dict[str, str] = {}
    for linea in partes[0].splitlines()[1:]:
        nombre, _, valor = linea.partition(":")
        cabeceras[nombre.strip().lower()] = valor.strip()
    cuerpo = partes[1] if len(partes) > 1 else ""
    try:
        datos = json.loads(cuerpo) if cuerpo.strip() else None
    except ValueError:
        datos = cuerpo
    return RespuestaApi(int(m.group(1)), datos, cabeceras)


class Gh:
    def __init__(self, correr_: Correr = correr) -> None:
        self._correr = correr_

    def ejecutar(self, *args: str, entrada: str | None = None, en_vivo: bool = False) -> Resultado:
        return self._correr(["gh", *args], entrada, en_vivo)

    def api(self, ruta: str, metodo: str = "GET", cuerpo: dict | None = None) -> RespuestaApi:
        args = ["api", "-i", "-X", metodo, ruta]
        entrada = None
        if cuerpo is not None:
            args += ["--input", "-"]
            entrada = json.dumps(cuerpo)
        return parsear_api(self.ejecutar(*args, entrada=entrada))

    def secretos(self, repo: str) -> set[str]:
        r = self.ejecutar("secret", "list", "-R", repo, "--json", "name")
        if r.codigo != 0:
            raise ErrorPublicacion(f"no puedo leer los secretos de {repo}: {r.stderr.strip()}")
        return {s["name"] for s in json.loads(r.stdout or "[]")}

    def guardar_secreto(self, repo: str, nombre: str, valor: str) -> None:
        r = self.ejecutar("secret", "set", nombre, "-R", repo, entrada=valor)
        if r.codigo != 0:
            raise ErrorPublicacion(f"no pude guardar {nombre} en {repo}: {r.stderr.strip()}")
