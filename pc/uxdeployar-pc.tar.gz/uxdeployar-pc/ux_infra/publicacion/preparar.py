"""``ux-infra github preparar``: deja GitHub listo para publicar versiones (se puede repetir sin miedo).

Repo público del instalador, llave de firma minisign (secreta en el repo del backend, pública por la API de
contenidos), llaves de despliegue del workflow de release (la privada como secreto del backend) y acceso de
Actions a los paquetes de GHCR. Todo con la sesión de gh: no hay que crear tokens a mano.
"""

from __future__ import annotations

import argparse
import base64
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from ..instalador import final
from ..instalador.consola import Consola
from . import DUENO, REPO_BACKEND, REPO_FRONTEND, REPO_INSTALL, ErrorPublicacion, herramientas
from .gh import Correr, Gh, correr

RUTA_PUB = "installer/minisign.pub"
SECRETO_FIRMA = "MINISIGN_SECRET_KEY"
_PUB = re.compile(r"^RW[A-Za-z0-9+/]{54}$")


@dataclass(frozen=True)
class LlaveDespliegue:
    secreto: str
    repo: str
    solo_lectura: bool

    @property
    def titulo(self) -> str:
        return f"uxdeployar release ({self.secreto})"


LLAVES = (
    LlaveDespliegue("FRONTEND_DEPLOY_KEY", REPO_FRONTEND, True),
    LlaveDespliegue("INSTALL_DEPLOY_KEY", REPO_INSTALL, False),
)

README_INSTALL = """# uxdeployar — instalador

Instala uxdeployar en un VPS recién creado desde tu PC; no hace falta abrir una sesión en el VPS.

- Linux o macOS: `curl -fsSL https://raw.githubusercontent.com/{dueno}/uxdeployar-install/main/instalar | bash`
- Windows (PowerShell): `irm https://raw.githubusercontent.com/{dueno}/uxdeployar-install/main/instalar.ps1 | iex`

Este repositorio lo actualiza el workflow de release de uxdeployar.
"""


def _repo_existe(gh: Gh, repo: str) -> bool:
    r = gh.api(f"repos/{repo}")
    if r.estado == 200:
        return True
    if r.estado == 404:
        return False
    raise ErrorPublicacion(f"GitHub respondió {r.estado} al leer {repo}")


def _subir_archivo(gh: Gh, repo: str, ruta: str, contenido: str, mensaje: str) -> None:
    actual = gh.api(f"repos/{repo}/contents/{ruta}")
    cuerpo = {"message": mensaje, "content": base64.b64encode(contenido.encode()).decode()}
    if actual.estado == 200 and isinstance(actual.datos, dict):
        cuerpo["sha"] = actual.datos["sha"]
    r = gh.api(f"repos/{repo}/contents/{ruta}", "PUT", cuerpo)
    if r.estado not in (200, 201):
        raise ErrorPublicacion(f"no pude escribir {ruta} en {repo} (HTTP {r.estado})")


def paso_repos(consola: Consola, gh: Gh, dueno: str) -> None:
    consola.titulo("Repositorios")
    for nombre in (REPO_BACKEND, REPO_FRONTEND):
        if not _repo_existe(gh, f"{dueno}/{nombre}"):
            raise ErrorPublicacion(f"no veo {dueno}/{nombre} con tu sesión de gh")
    consola.ok(f"{dueno}/{REPO_BACKEND} y {dueno}/{REPO_FRONTEND}")
    install = f"{dueno}/{REPO_INSTALL}"
    if _repo_existe(gh, install):
        consola.ok(f"{install} ya existe")
    else:
        r = gh.ejecutar("repo", "create", install, "--public", "--description", "Instalador público de uxdeployar")
        if r.codigo != 0:
            raise ErrorPublicacion(f"no pude crear {install}: {r.stderr.strip()}")
        consola.ok(f"{install} creado (público)")
    if gh.api(f"repos/{install}/contents/README.md").estado == 404:
        _subir_archivo(gh, install, "README.md", README_INSTALL.format(dueno=dueno), "docs: add installer readme")


def paso_firma(
    consola: Consola, gh: Gh, dueno: str, rotar: bool, secretos: set[str],
    correr_: Correr = correr, carpeta: Path | None = None,
) -> None:
    consola.titulo("Llave de firma de los releases")
    backend = f"{dueno}/{REPO_BACKEND}"
    tiene_pub = gh.api(f"repos/{backend}/contents/{RUTA_PUB}").estado == 200
    if tiene_pub and SECRETO_FIRMA in secretos and not rotar:
        consola.ok(f"{RUTA_PUB} y {SECRETO_FIRMA} ya están configurados")
        return
    if tiene_pub and not consola.confirmar(
        "Una llave nueva hace que los VPS ya instalados rechacen las actualizaciones hasta reinstalarlos. ¿Seguir?",
        defecto=False,
    ):
        raise ErrorPublicacion("se mantiene la llave actual")
    with tempfile.TemporaryDirectory() as tmp:
        pub, sec = Path(tmp, "minisign.pub"), Path(tmp, "minisign.key")
        r = correr_(["minisign", "-G", "-W", "-p", str(pub), "-s", str(sec)], None, False)
        if r.codigo != 0 or not pub.exists():
            raise ErrorPublicacion(f"minisign no generó la llave: {r.stderr.strip()}")
        publica, secreta = pub.read_text(encoding="utf-8"), sec.read_text(encoding="utf-8")
    lineas = publica.splitlines()
    if len(lineas) < 2 or not _PUB.match(lineas[1].strip()):
        raise ErrorPublicacion("minisign generó una llave pública con un formato inesperado")
    gh.guardar_secreto(backend, SECRETO_FIRMA, secreta)
    consola.ok(f"{SECRETO_FIRMA} guardado en {backend}")
    if consola.confirmar("¿Guardo una copia de la llave secreta en tu PC (solo tú podrás leerla)?"):
        destino = (carpeta or final.carpeta_config("github")) / "minisign.key"
        destino.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(destino, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(secreta)
        consola.info(f"copia en {destino}")
    _subir_archivo(gh, backend, RUTA_PUB, publica, "chore(installer): add release signing public key")
    consola.ok(f"{RUTA_PUB} subido a {backend}: haz «git pull» en tu copia local del backend")


def _generar_llave(correr_: Correr, titulo: str) -> tuple[str, str]:
    with tempfile.TemporaryDirectory() as tmp:
        ruta = Path(tmp, "llave")
        r = correr_(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", titulo, "-f", str(ruta)], None, False)
        if r.codigo != 0 or not ruta.exists():
            raise ErrorPublicacion(f"ssh-keygen no generó la llave: {r.stderr.strip()}")
        return Path(tmp, "llave.pub").read_text(encoding="utf-8").strip(), ruta.read_text(encoding="utf-8")


def paso_llaves(
    consola: Consola, gh: Gh, dueno: str, rotar: bool, secretos: set[str], correr_: Correr = correr,
) -> None:
    consola.titulo("Llaves de despliegue del workflow de release")
    backend = f"{dueno}/{REPO_BACKEND}"
    for llave in LLAVES:
        if llave.secreto in secretos and not rotar:
            consola.ok(f"{llave.secreto} ya está en {backend}")
            continue
        repo = f"{dueno}/{llave.repo}"
        publica, privada = _generar_llave(correr_, llave.titulo)
        actuales = gh.api(f"repos/{repo}/keys?per_page=100")
        if actuales.estado != 200 or not isinstance(actuales.datos, list):
            raise ErrorPublicacion(f"no puedo leer las llaves de despliegue de {repo} (HTTP {actuales.estado})")
        for vieja in actuales.datos:
            if vieja.get("title") == llave.titulo:
                gh.api(f"repos/{repo}/keys/{vieja['id']}", "DELETE")
        r = gh.api(f"repos/{repo}/keys", "POST", {"title": llave.titulo, "key": publica, "read_only": llave.solo_lectura})
        if r.estado != 201:
            raise ErrorPublicacion(f"no pude añadir la llave de despliegue a {repo} (HTTP {r.estado})")
        gh.guardar_secreto(backend, llave.secreto, privada)
        permiso = "lectura" if llave.solo_lectura else "escritura"
        consola.ok(f"{llave.secreto}: llave de {permiso} en {repo}, la privada guardada en {backend}")


def paso_paquetes(consola: Consola, gh: Gh, dueno: str) -> None:
    consola.titulo("Paquetes de GHCR")
    tipo = gh.api(f"users/{dueno}")
    base = "orgs" if isinstance(tipo.datos, dict) and tipo.datos.get("type") == "Organization" else "users"
    for nombre in (REPO_BACKEND, REPO_FRONTEND):
        r = gh.api(f"{base}/{dueno}/packages/container/{nombre}")
        if r.estado == 403:
            consola.info("Tu sesión de gh no puede leer paquetes: se amplía con read:packages.")
            gh.ejecutar("auth", "refresh", "--hostname", "github.com", "--scopes", "read:packages", en_vivo=True)
            r = gh.api(f"{base}/{dueno}/packages/container/{nombre}")
        if r.estado == 404:
            consola.ok(f"ghcr.io/{dueno}/{nombre}: se creará en el primer release, ligado a {REPO_BACKEND}")
            continue
        if r.estado != 200 or not isinstance(r.datos, dict):
            consola.aviso(f"no pude revisar ghcr.io/{dueno}/{nombre} (HTTP {r.estado})")
            continue
        ligado = (r.datos.get("repository") or {}).get("full_name", "")
        if ligado == f"{dueno}/{REPO_BACKEND}":
            consola.ok(f"ghcr.io/{dueno}/{nombre} ligado a {ligado}")
            continue
        consola.aviso(f"ghcr.io/{dueno}/{nombre} no está ligado a {REPO_BACKEND}: el release no podrá subirlo.")
        consola.info(f"Abre https://github.com/{base}/{dueno}/packages/container/{nombre}/settings,")
        consola.info(f"«Manage Actions access» → «Add repository» → {REPO_BACKEND} con rol Write.")
        consola.pausa("Cuando lo tengas")


def ejecutar(
    args: argparse.Namespace,
    consola: Consola | None = None,
    gh: Gh | None = None,
    correr_: Correr = correr,
    asegurar: Callable[[Consola, str], None] = herramientas.asegurar,
) -> int:
    consola = consola or Consola()
    gh = gh or Gh(correr_)
    dueno = args.dueno or DUENO
    consola.titulo("Herramientas")
    for nombre in ("gh", "minisign"):
        asegurar(consola, nombre)
    consola.ok("gh y minisign disponibles")
    herramientas.asegurar_sesion(consola, gh)
    paso_repos(consola, gh, dueno)
    secretos = gh.secretos(f"{dueno}/{REPO_BACKEND}")
    paso_firma(consola, gh, dueno, args.rotar, secretos, correr_)
    paso_llaves(consola, gh, dueno, args.rotar, secretos, correr_)
    paso_paquetes(consola, gh, dueno)
    consola.titulo("Listo")
    consola.ok("GitHub está preparado. Siguiente paso: ux-infra github publicar v1.0.0")
    return 0
