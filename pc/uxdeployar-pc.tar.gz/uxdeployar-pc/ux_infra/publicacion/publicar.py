"""``ux-infra github publicar vX.Y.Z``: etiqueta el frontend y el backend por la API y sigue el release.

El frontend se etiqueta primero porque el workflow del backend lo descarga con la misma etiqueta.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import time
from pathlib import Path
from typing import Callable

from ..instalador.consola import Consola
from . import DUENO, REPO_BACKEND, REPO_FRONTEND, REPO_INSTALL, ErrorPublicacion, herramientas
from .gh import Correr, Gh, correr

VERSION = re.compile(r"^v\d+\.\d+\.\d+(-rc\.\d+)?$")
WORKFLOW = "release.yml"
RAIZ_BACKEND = Path(__file__).resolve().parents[4]
FALLIDOS = ("failure", "cancelled", "timed_out", "action_required")

EXPLICACIONES = (
    ("pruebas", "fallaron las pruebas de ci.yml: corrígelas en main y publica una versión nueva."),
    ("imagenes", "no se compilaron o subieron las imágenes: revisa la llave FRONTEND_DEPLOY_KEY "
                 "de uxdeployar-frontend y el acceso de Actions a los paquetes de GHCR (ux-infra github preparar)."),
    ("paquete", "falló la firma: MINISIGN_SECRET_KEY no corresponde a installer/minisign.pub "
                "(ux-infra github preparar --rotar)."),
    ("e2e", "falló la instalación de prueba en la VM: descarga el artefacto e2e-… del run "
            "(diagnostico.txt y consola.log)."),
    ("publicar", "no se pudo publicar: revisa la llave de escritura INSTALL_DEPLOY_KEY de uxdeployar-install "
                 "(ux-infra github preparar --rotar)."),
)


def _git(ruta: Path, *args: str) -> str | None:
    try:
        p = subprocess.run(["git", "-C", str(ruta), *args], capture_output=True, text=True)
    except FileNotFoundError:
        return None
    return p.stdout.strip() if p.returncode == 0 else None


def comprobar_local(consola: Consola, nombre: str, ruta: Path, remoto: str, git: Callable[..., str | None] = _git) -> bool:
    """False si tu copia local de ``main`` no coincide con GitHub; sin copia local no hay nada que comparar."""
    local = git(ruta, "rev-parse", "main")
    if local is None:
        return True
    if git(ruta, "status", "--porcelain"):
        consola.aviso(f"{nombre}: tienes cambios sin commit en {ruta} (no entran en la versión)")
    if local != remoto:
        consola.aviso(f"{nombre}: tu main local ({local[:12]}) no coincide con GitHub ({remoto[:12]}): ¿falta push o pull?")
        return False
    return True


def comprobar_ci(consola: Consola, gh: Gh, repo: str, sha: str) -> bool:
    r = gh.api(f"repos/{repo}/commits/{sha}/check-runs?per_page=100")
    corridas = r.datos.get("check_runs", []) if isinstance(r.datos, dict) else []
    fallidas = [c["name"] for c in corridas if c.get("conclusion") in FALLIDOS]
    if fallidas:
        consola.aviso(f"{repo}: el CI de main falla ({', '.join(fallidas[:3])})")
        return False
    if any(c.get("status") != "completed" for c in corridas):
        consola.aviso(f"{repo}: el CI de main todavía no ha terminado")
    return True


def etiqueta_existente(gh: Gh, repo: str, version: str, sha: str) -> bool:
    """True si ya existe apuntando a ``sha``; error si apunta a otro commit."""
    r = gh.api(f"repos/{repo}/git/ref/tags/{version}")
    if r.estado == 404:
        return False
    if r.estado != 200 or not isinstance(r.datos, dict):
        raise ErrorPublicacion(f"GitHub respondió {r.estado} al buscar la etiqueta {version} en {repo}")
    if r.datos.get("object", {}).get("sha") != sha:
        raise ErrorPublicacion(f"la etiqueta {version} ya existe en {repo} y apunta a otro commit")
    return True


def _main(gh: Gh, repo: str) -> str:
    r = gh.api(f"repos/{repo}/commits/main")
    if r.estado != 200 or not isinstance(r.datos, dict):
        raise ErrorPublicacion(f"no puedo leer main de {repo} (HTTP {r.estado})")
    return str(r.datos["sha"])


def _etiquetar(consola: Consola, gh: Gh, repo: str, version: str, sha: str) -> None:
    r = gh.api(f"repos/{repo}/git/refs", "POST", {"ref": f"refs/tags/{version}", "sha": sha})
    if r.estado != 201:
        raise ErrorPublicacion(f"no pude crear la etiqueta {version} en {repo} (HTTP {r.estado})")
    consola.ok(f"{repo}: etiqueta {version} en {sha[:12]}")


def buscar_run(gh: Gh, repo: str, version: str, dormir: Callable[[float], None] = time.sleep, intentos: int = 24) -> dict:
    for _ in range(intentos):
        r = gh.ejecutar(
            "run", "list", "-R", repo, "--workflow", WORKFLOW, "--branch", version,
            "--limit", "1", "--json", "databaseId,url,status",
        )
        corridas = json.loads(r.stdout or "[]") if r.codigo == 0 else []
        if corridas:
            return corridas[0]
        dormir(5)
    raise ErrorPublicacion(f"el workflow {WORKFLOW} no arrancó con la etiqueta {version}: revisa la pestaña Actions de {repo}")


def explicar(consola: Consola, gh: Gh, repo: str, run_id: str) -> None:
    r = gh.ejecutar("run", "view", run_id, "-R", repo, "--json", "jobs")
    trabajos = json.loads(r.stdout or "{}").get("jobs", []) if r.codigo == 0 else []
    fallidos = [t["name"] for t in trabajos if t.get("conclusion") in FALLIDOS]
    vistos: set[str] = set()
    for nombre in fallidos:
        for prefijo, texto in EXPLICACIONES:
            if nombre.startswith(prefijo) and prefijo not in vistos:
                vistos.add(prefijo)
                consola.error(f"{nombre}: {texto}")
    if "e2e" in vistos:
        registro = gh.ejecutar("run", "view", run_id, "-R", repo, "--log-failed").stdout
        if re.search(r"/dev/kvm|\bKVM\b", registro, re.IGNORECASE):
            consola.info("El runner no tenía KVM: sin aceleración la VM no arranca a tiempo.")
            consola.info(f"Reintenta solo lo fallido con «gh run rerun {run_id} --failed -R {repo}».")
    if not vistos:
        consola.error(f"el release falló en: {', '.join(fallidos) or 'un paso desconocido'}")


def ejecutar(
    args: argparse.Namespace,
    consola: Consola | None = None,
    gh: Gh | None = None,
    correr_: Correr = correr,
    asegurar: Callable[[Consola, str], None] = herramientas.asegurar,
    git: Callable[..., str | None] = _git,
    dormir: Callable[[float], None] = time.sleep,
) -> int:
    consola = consola or Consola()
    gh = gh or Gh(correr_)
    version = args.version_publicar
    if not VERSION.match(version):
        raise ErrorPublicacion(f"versión inválida: {version} (usa vX.Y.Z o vX.Y.Z-rc.N)")
    dueno = args.dueno or DUENO
    asegurar(consola, "gh")
    herramientas.asegurar_sesion(consola, gh)

    consola.titulo(f"Comprobaciones antes de publicar {version}")
    locales = {
        REPO_FRONTEND: Path(args.frontend) if args.frontend else RAIZ_BACKEND.parent / REPO_FRONTEND,
        REPO_BACKEND: Path(args.backend) if args.backend else RAIZ_BACKEND,
    }
    shas: dict[str, str] = {}
    todo_bien = True
    for nombre in (REPO_FRONTEND, REPO_BACKEND):
        repo = f"{dueno}/{nombre}"
        shas[nombre] = _main(gh, repo)
        todo_bien &= comprobar_local(consola, nombre, locales[nombre], shas[nombre], git)
        todo_bien &= comprobar_ci(consola, gh, repo, shas[nombre])
    if not todo_bien and not consola.confirmar("¿Publicar de todos modos?", defecto=False):
        return 1
    existentes = {n: etiqueta_existente(gh, f"{dueno}/{n}", version, shas[n]) for n in shas}
    consola.ok(f"frontend {shas[REPO_FRONTEND][:12]} y backend {shas[REPO_BACKEND][:12]}")
    if not args.yes and not consola.confirmar(f"¿Etiqueto los dos repos como {version} y lanzo el release?"):
        return 1

    for nombre in (REPO_FRONTEND, REPO_BACKEND):
        if existentes[nombre]:
            consola.ok(f"{dueno}/{nombre}: la etiqueta {version} ya existía")
        else:
            _etiquetar(consola, gh, f"{dueno}/{nombre}", version, shas[nombre])

    backend = f"{dueno}/{REPO_BACKEND}"
    if args.sin_seguir:
        consola.info(f"Sigue el release en https://github.com/{backend}/actions")
        return 0
    consola.titulo("Release")
    run = buscar_run(gh, backend, version, dormir)
    consola.info(f"workflow: {run.get('url', '')}")
    run_id = str(run["databaseId"])
    if gh.ejecutar("run", "watch", run_id, "-R", backend, "--exit-status", "--interval", "30", en_vivo=True).codigo == 0:
        consola.ok(f"publicado: https://github.com/{backend}/releases/tag/{version}")
        if "-rc." in version:
            consola.info("Es una prerelease: el instalador público sigue en la última versión estable.")
        else:
            consola.info(f"Instalar en un VPS: https://github.com/{dueno}/{REPO_INSTALL}")
        return 0
    explicar(consola, gh, backend, run_id)
    return 1
