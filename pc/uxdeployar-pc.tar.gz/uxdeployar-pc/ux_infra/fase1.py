"""Fase 1: preparación inicial del VPS.

Espejo de ``05-vps/app/internal/fase1/fase1.go``: desde un Debian 13 limpio con
solo acceso root hasta el entorno base operativo (usuario administrador con
sudo y llave, protocolo instalado por la app e inventario pre-llenado). La
secuencia es fija e idempotente; los secretos viajan por stdin, nunca por
argumentos. No se deshabilita root ni se toca sshd: eso lo hacen las etapas.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from . import keys, fase2, inventario, ssh as sshx, util

REPO_DIR = "/opt/ux-infra"
REPO_SUBDIR = "05-vps"  # ruta EN EL VPS (/opt/ux-infra/05-vps/…); en este repo la carpeta es vps/
PAQUETES_BASE = "sudo git curl tmux ca-certificates gnupg nano"
ETAPAS_ESPERADAS = "18"
# Misma lista que ux_so_soportado (vps/agent/platform/lib/ux-lib.sh).
SISTEMAS_SOPORTADOS = {("debian", "13"), ("ubuntu", "26.04")}

INSTALADORES = {
    "claude-code": "curl -fsSL https://claude.ai/install.sh | bash",
    "opencode": "curl -fsSL https://opencode.ai/install | bash",
}


class ErrorPaso(Exception):
    """Un paso falló y la secuencia se detiene."""


@dataclass
class Config:
    host: str = ""
    puerto: int = 22
    metodo: str = "llave"  # llave | contrasena
    ruta_llave: str = ""
    ruta_llave_root: str = ""
    passphrase_root: str = ""
    ruta_llave_publica: str = ""
    passphrase: str = ""
    contrasena_root: str = ""
    huella_esperada: str = ""
    huella_sonda: str = ""
    huella_confirmada: bool = False
    confiar_primera: bool = False
    usuario_admin: str = ""
    password_sudo: str = ""
    agente_ia: str = ""  # claude-code | opencode | otro | ninguno
    agente_comando: str = ""
    proveedor: str = ""
    zona_horaria: str = ""
    puerto_ssh_futuro: int = 0
    dominio: str = ""
    email_acme: str = ""

    def json(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}

    def validar(self, existe: Callable[[str], bool]) -> list[str]:
        errs: list[str] = []

        def add(err: BaseException) -> None:
            if err is not None:
                errs.append(str(err))

        try:
            self.host = util.validar_host(self.host)
        except ValueError as exc:
            add(exc)
        try:
            self.puerto = util.validar_puerto(self.puerto)
        except ValueError as exc:
            add(exc)
        if self.metodo == "llave":
            if not self.ruta_llave_root.strip():
                errs.append("falta la llave privada con la que entrar como root")
            elif not existe(self.ruta_llave_root):
                errs.append("no existe la llave privada de root indicada")
        elif self.metodo == "contrasena":
            if not self.contrasena_root.strip():
                errs.append("falta la contraseña de root")
        else:
            errs.append("método de autenticación no válido (llave o contrasena)")
        if not self.ruta_llave.strip():
            errs.append("elige o crea la llave SSH del administrador")
        elif not existe(self.ruta_llave):
            errs.append("no existe la llave privada del administrador")
        if not self.ruta_llave_publica.strip():
            errs.append("falta la llave pública del administrador")
        elif not existe(self.ruta_llave_publica):
            errs.append("no existe la llave pública del administrador")
        if self.huella_esperada:
            try:
                self.huella_esperada = util.normalizar_huella(self.huella_esperada)
            except ValueError as exc:
                add(exc)
        try:
            self.usuario_admin = util.validar_usuario(self.usuario_admin)
        except ValueError as exc:
            add(exc)
        try:
            self.password_sudo = util.validar_password_sudo(self.password_sudo)
        except ValueError as exc:
            add(exc)
        if self.agente_ia not in ("claude-code", "opencode", "ninguno", "", "otro"):
            errs.append("agente de IA no soportado")
        if self.agente_ia == "otro" and not self.agente_comando.strip():
            errs.append("escribe el comando de instalación del agente")
        self.agente_comando = self.agente_comando.strip()
        if len(self.agente_comando) > 500 or "\x00" in self.agente_comando or "\r" in self.agente_comando or "\n" in self.agente_comando:
            errs.append("el comando de instalación del agente debe ser una sola línea de hasta 500 caracteres")
        if self.puerto_ssh_futuro == 0:
            self.puerto_ssh_futuro = 2222
        try:
            p = util.validar_puerto(self.puerto_ssh_futuro)
            if p < 1024:
                errs.append("el puerto SSH futuro debe estar entre 1024 y 65535")
            self.puerto_ssh_futuro = p
        except ValueError as exc:
            add(exc)
        if self.zona_horaria and not util.es_zona_horaria(self.zona_horaria):
            errs.append("zona horaria no válida")
        return errs


PASOS = [
    {"id": "conectar", "nombre": "Conectar como root y detectar el sistema"},
    {"id": "paquetes", "nombre": "Instalar paquetes base (sudo, git, curl, tmux…)"},
    {"id": "usuario", "nombre": "Crear el usuario administrativo con sudo"},
    {"id": "llave", "nombre": "Instalar la llave SSH del administrador"},
    {"id": "acceso_usuario", "nombre": "Verificar el acceso del nuevo usuario"},
    {"id": "protocolo", "nombre": "Instalar y verificar el protocolo en " + REPO_DIR},
    {"id": "inventario", "nombre": "Pre-llenar inventory.yaml con los datos recopilados"},
    {"id": "agente", "nombre": "Instalar o preparar el agente de IA elegido"},
]


@dataclass
class Pendiente:
    que: str = ""
    como: str = ""

    def json(self) -> dict:
        return {"que": self.que, "como": self.como}


@dataclass
class Informe:
    ok: bool = True
    error: str = ""
    huella: str = ""
    pendientes: list[Pendiente] = field(default_factory=list)
    siguiente: str = ""

    def json(self) -> dict:
        return {
            "ok": self.ok,
            "error": self.error,
            "huella": self.huella,
            "pendientes": [p.json() for p in self.pendientes],
            "siguiente": self.siguiente,
        }


class Preparador:
    """Ejecuta la secuencia de la Fase 1."""

    def __init__(self, cfg: Config, avance: Callable[[str, str, str], None] | None = None, salida: Callable[[str], None] | None = None) -> None:
        self.cfg = cfg
        self.avance = avance
        self.salida = salida
        self.root: "sshx.Cliente | None" = None
        self.admin: "sshx.Cliente | None" = None
        self.huella = ""
        self.clave = None

    def paso(self, id_: str, estado: str, detalle: str = "") -> None:
        if self.avance is not None:
            self.avance(id_, estado, detalle)

    def _ejecutar(self, c: "sshx.Cliente | None", cmd: str, stdin: bytes | None = None, long: bool = False) -> str:
        if c is None:
            raise ErrorPaso("no hay conexión SSH abierta")
        r = c.ejecutar(cmd, stdin=stdin, salida=self.salida if long else None)
        if r.codigo != 0:
            msg = (r.stderr or r.stdout).strip()
            raise ErrorPaso(f"el comando falló (código {r.codigo}): {util.truncar(msg, 300)}")
        return r.stdout

    def admin_entrega(self) -> "sshx.Cliente | None":
        a, self.admin = self.admin, None
        return a

    # -- pasos --------------------------------------------------------------

    def paso_conectar(self) -> None:
        self.paso("conectar", "en_curso")
        c = self.cfg
        try:
            clave = sshx.escanear_clave_host(c.host, c.puerto)
        except sshx.ErrorRed as exc:
            raise ErrorPaso(
                f"no pude contactar al servidor {c.host}:{c.puerto} ({exc}). Revisa la dirección, el puerto y que el VPS esté encendido."
            ) from exc
        actual = sshx.huella(clave)
        if c.huella_esperada and actual != c.huella_esperada:
            raise ErrorPaso(
                f"la huella del servidor ({actual}) NO coincide con la esperada ({c.huella_esperada}). "
                "Verifica contra la consola del proveedor y no continúes si no coincide."
            )
        if c.huella_sonda and actual != c.huella_sonda:
            raise ErrorPaso(
                "la huella del servidor cambió desde la prueba de conexión. Detenido: verifica contra la consola del proveedor antes de reintentar."
            )
        if not c.huella_confirmada:
            if not c.confiar_primera:
                raise ErrorPaso("no se confirmó la huella del servidor contra la consola del proveedor")
            if self.salida is not None:
                self.salida("Huella del servidor aceptada automáticamente en esta primera conexión: " + actual + "\n")
        cfg_ssh = sshx.Config(host=c.host, puerto=c.puerto, usuario="root", anclada=clave)
        if c.metodo == "llave":
            cfg_ssh.ruta_llave, cfg_ssh.passphrase = c.ruta_llave_root, c.passphrase_root
        else:
            cfg_ssh.contrasena = c.contrasena_root
        try:
            cli = sshx.Cliente.dial(cfg_ssh)
        except sshx.ErrorAuth as exc:
            raise ErrorPaso(
                "el servidor rechazó el acceso de root: revisa la contraseña (o la llave) de root que te dio tu "
                "proveedor. Algunos proveedores desactivan root por contraseña: en ese caso usa «Llave SSH de root»."
            ) from exc
        self.root, self.huella, self.clave = cli, actual, clave
        if self._ejecutar(self.root, "id -u").strip() != "0":
            raise ErrorPaso("la cuenta conectada no es root")
        nombre = self.validar_sistema()
        self.paso("conectar", "ok", f"{nombre} · huella {actual}")

    def validar_sistema(self) -> str:
        id_, ver, nombre = detectar_sistema(self.root)
        if (id_, ver) not in SISTEMAS_SOPORTADOS:
            n = nombre or f"{id_} {ver}"
            raise ErrorPaso(
                f"el estándar exige Debian 13 (trixie) o Ubuntu 26.04 LTS; el servidor es {n}. Reinstala uno de ellos desde el panel del proveedor."
            )
        return nombre

    def paso_paquetes(self) -> None:
        self.paso("paquetes", "en_curso")
        self._ejecutar(
            self.root,
            "export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a && "
            "apt-get -o DPkg::Lock::Timeout=600 -o Acquire::Retries=3 update -y && "
            "apt-get -o DPkg::Lock::Timeout=600 -o Acquire::Retries=3 -o Dpkg::Options::=--force-confold install -y " + PAQUETES_BASE,
            long=True,
        )
        self.paso("paquetes", "ok")

    def paso_usuario(self) -> None:
        self.paso("usuario", "en_curso")
        u = self.cfg.usuario_admin
        out = self._ejecutar(self.root, f"id -u {util.comillas(u)} 2>/dev/null || true")
        if not out.strip():
            self._ejecutar(self.root, f"adduser --disabled-password --gecos '' {util.comillas(u)}")
        self._ejecutar(self.root, f"usermod -aG sudo {util.comillas(u)}")
        self._ejecutar(self.root, "chpasswd", (u + ":" + self.cfg.password_sudo + "\n").encode())
        self.paso("usuario", "ok")

    def paso_llave(self) -> None:
        self.paso("llave", "en_curso")
        u = self.cfg.usuario_admin
        clave = keys.leer_publica(self.cfg.ruta_llave_publica)
        home = "/home/" + u
        self._ejecutar(self.root, f"install -d -m 700 -o {u} -g {u} {home}/.ssh")
        self._ejecutar(self.root, f"umask 077; cat > {home}/.ssh/authorized_keys", (clave + "\n").encode())
        self._ejecutar(self.root, f"chown {u}:{u} {home}/.ssh/authorized_keys && chmod 600 {home}/.ssh/authorized_keys")
        self.paso("llave", "ok")

    def paso_acceso_usuario(self) -> None:
        self.paso("acceso_usuario", "en_curso")
        if self.root is None or self.clave is None:
            raise ErrorPaso("no hay clave del host anclada")
        try:
            cli = sshx.Cliente.dial(
                sshx.Config(
                    host=self.cfg.host,
                    puerto=self.cfg.puerto,
                    usuario=self.cfg.usuario_admin,
                    ruta_llave=self.cfg.ruta_llave,
                    passphrase=self.cfg.passphrase,
                    anclada=self.clave,
                )
            )
        except sshx.ErrorAuth as exc:
            raise ErrorPaso(
                "el administrador NO pudo autenticarse con la llave; no se modificó nada más. Revisa la llave pública instalada y reintenta."
            ) from exc
        self.admin = cli
        if self._ejecutar(self.admin, "id -un").strip() != self.cfg.usuario_admin:
            raise ErrorPaso("acceso inesperado del usuario administrador")
        r = self.admin.ejecutar("sudo -S -p '' whoami", stdin=self.cfg.password_sudo + "\n")
        if r.codigo != 0 or r.stdout.strip() != "root":
            raise ErrorPaso("sudo no devolvió 'root': verifica la contraseña de sudo del usuario administrador")
        self.paso("acceso_usuario", "ok")

    def paso_protocolo(self) -> None:
        self.paso("protocolo", "en_curso")
        u = self.cfg.usuario_admin
        paquete, suma = fase2.empaquetar_protocolo()
        self._ejecutar(self.root, f"install -d -o {u} -g {u} {REPO_DIR} {REPO_DIR}/{REPO_SUBDIR}")
        tmp = "/tmp/ux-protocolo-" + suma[:12] + ".tgz"
        self.admin.escribir_archivo(tmp, "600", paquete)
        base = f"{REPO_DIR}/{REPO_SUBDIR}"
        self._ejecutar(
            self.admin,
            f"tar -xzf {util.comillas(tmp)} -C {util.comillas(base)} --no-same-owner --no-same-permissions --touch && rm -f {util.comillas(tmp)}",
        )
        self._ejecutar(
            self.admin,
            f"find {util.comillas(base)}/agent -type d -exec chmod 755 {{}} + && find {util.comillas(base)}/agent -type f \\( -name '*.sh' -o -name '*.py' -o -path '*/platform/bin/*' \\) -exec chmod 755 {{}} +",
        )
        dir_ = base + "/agent"
        for r in ("AGENTS.md", "PROTOCOLO.md", "inventory/load.sh", "init-vps.sh", "platform/install.sh"):
            self._ejecutar(self.admin, f"test -f '{dir_}/{r}'")
        n = self._ejecutar(self.admin, f"ls {dir_}/stages/[0-9][0-9]-*.md | wc -l").strip()
        if n != ETAPAS_ESPERADAS:
            raise ErrorPaso(f"se esperaban {ETAPAS_ESPERADAS} contratos de etapa; hay {n}")
        self.paso("protocolo", "ok", f"{dir_} (SHA-256 {suma[:12]}…)")

    def paso_inventario(self) -> None:
        self.paso("inventario", "en_curso")
        destino = f"{REPO_DIR}/{REPO_SUBDIR}/agent/inventory/inventory.yaml"
        out = self._ejecutar(self.admin, f"test -f '{destino}' && echo si || true")
        if out.strip():
            self.paso("inventario", "omitido", "ya existe inventory.yaml: no se pisa")
            return
        c = self.cfg
        contenido = inventario.generar(
            inventario.Datos(
                ip=c.host,
                huella=self.huella,
                proveedor=c.proveedor,
                zona_horaria=c.zona_horaria,
                puerto_ssh_futuro=c.puerto_ssh_futuro,
                usuario_admin=c.usuario_admin,
                ruta_llave=c.ruta_llave,
                ruta_llave_publica=c.ruta_llave_publica,
                dominio=c.dominio,
                email_acme=c.email_acme,
            )
        )
        self.admin.escribir_archivo(destino, "600", contenido)
        self.paso("inventario", "ok", "IP, huella, usuario y puerto pre-llenados")

    def paso_agente(self) -> None:
        self.paso("agente", "en_curso")
        agente = self.cfg.agente_ia
        if not agente or agente == "ninguno":
            self.paso("agente", "omitido", "se instalará después (requisito pendiente)")
            return
        inst = self.cfg.agente_comando or INSTALADORES.get(agente, "")
        if not inst:
            self.paso("agente", "omitido", f"agente '{agente}' sin comando de instalación: instálalo manualmente")
            return
        r = self.admin.ejecutar("bash -c " + util.comillas(inst), salida=self.salida)
        if r.codigo != 0:
            self.paso(
                "agente",
                "error",
                f"la instalación falló (código {r.codigo}); hazlo después desde tmux. {util.truncar(r.stderr.strip(), 200)}",
            )
            return
        self.paso("agente", "ok", agente + " instalado para el usuario administrador")

    # -- secuencia ----------------------------------------------------------

    def ejecutar(self) -> Informe:
        orden = [
            ("conectar", self.paso_conectar),
            ("paquetes", self.paso_paquetes),
            ("usuario", self.paso_usuario),
            ("llave", self.paso_llave),
            ("acceso_usuario", self.paso_acceso_usuario),
            ("protocolo", self.paso_protocolo),
            ("inventario", self.paso_inventario),
            ("agente", self.paso_agente),
        ]
        try:
            for id_, fn in orden:
                fn()
        except ErrorPaso as exc:
            self.paso("_global", "error", str(exc))
            if self.admin is not None:
                self.admin.cerrar()
                self.admin = None
            return self._informe(str(exc))
        finally:
            if self.root is not None:
                self.root.cerrar()
                self.root = None
        return self._informe("")

    def _informe(self, error: str) -> Informe:
        inf = Informe(ok=error == "", error=error, huella=self.huella)
        if not error:
            inf.siguiente = (
                f"Continúa en «Fase 2»: la sesión como {self.cfg.usuario_admin} ya está conectada. "
                f"(En el VPS equivale a: sudo -u {self.cfg.usuario_admin} -H tmux new -s agente · bash {REPO_DIR}/{REPO_SUBDIR}/agent/init-vps.sh)"
            )
        return inf


def detectar_sistema(cli) -> tuple[str, str, str]:
    """Lee /etc/os-release → (id, versión, nombre)."""
    r = cli.ejecutar(". /etc/os-release 2>/dev/null; printf '%s|%s|%s' \"$ID\" \"$VERSION_ID\" \"$PRETTY_NAME\"")
    partes = r.stdout.split("|", 2)
    while len(partes) < 3:
        partes.append("")
    return partes[0].strip(), partes[1].strip(), partes[2].strip()
