# ux-infra — app local del sistema (Python)

App de escritorio con dos papeles:

- **Programa del PC del instalador**: instala uxdeployar en un VPS recién creado sin entrar en él
  (`instalar`) y prepara GitHub y publica versiones (`github preparar` / `github publicar`). Es lo
  que descargan `instalar` e `instalar.ps1` como `uxdeployar-pc`; la guía está en el
  [instalador](../../installer/README.md).
- **Trabajo sin el panel**: prepara un repositorio según el estándar de
  [`deploy/`](../../deploy/README.md) y configura y opera un VPS ([`vps/`](../../vps/README.md))
  desde tu equipo.

## Instalador y publicación

```bash
python ux-infra.py instalar                      # guiado: IP, huella, llave, DNS, puertos, token…
python ux-infra.py instalar 203.0.113.10 --panel panel.tudominio.com --dns cloudflare
python ux-infra.py github preparar               # una vez: repo público, firma, llaves de despliegue, GHCR
python ux-infra.py github publicar v1.0.0        # etiqueta frontend y backend y sigue el release
```

`instalar` acepta `--dns cloudflare|manual|ninguno`, `--puerto-ssh`, `--version`, `--yes` y
`--no-abrir` (lista completa con `--help`). Las opciones del E2E (`--release-url`, `--acme-ca`,
`--registry`, `--puerto-root`, `--ip-publica`, `--install-sh`…) no salen en la ayuda. Si se
vuelve a ejecutar sobre un VPS cuya instalación ya empezó, la retoma.

## Uso sin el panel

```bash
python ux-infra.py --help
python ux-infra.py web               # abre la interfaz local en el navegador
python ux-infra.py web --no-abrir    # sin abrir el navegador (imprime la dirección)
```

El lanzador funciona en **Windows, Linux y macOS**: si falta `paramiko`, crea un
entorno aislado `.venv` junto a este archivo, la instala y se relanza dentro de él.
También sirve `python -m ux_infra` desde esta carpeta con `paramiko` ya instalado.

```bash
# Lee la clave del host SIN autenticar (para compararla con la del proveedor)
python ux-infra.py huella 203.0.113.10 --puerto 2222

# Revisión de solo lectura del VPS: ¿cumple el estándar?
UX_SUDO_PASS=… python ux-infra.py revisar 203.0.113.10 --puerto 2222 \
    --usuario vpsadmin --llave ~/.ssh/id_ed25519_vps \
    --huella SHA256:…
```

`revisar` comprueba, **sin modificar nada**: sistema operativo, Podman,
herramientas `ux-*`, disco, memoria, `sshd` efectivo (`MaxSessions 2`,
`PasswordAuthentication no`, `PermitRootLogin no`), puertos fuera de loopback,
`ufw` y `fail2ban`.

La contraseña de sudo **nunca** viaja como argumento: se lee de la variable de
entorno `UX_SUDO_PASS` (configurable con `--sudo-env`).

## Estructura

```
ux-infra/
├── ux-infra.py            lanzador multiplataforma (crea .venv si falta)
├── requisitos.txt         paramiko (única dependencia; el resto es biblioteca estándar)
├── ui/                    interfaz web (HTML/CSS/JS)
├── ux_infra/              la app: ssh, sesion, servidor, fase1, fase2, ops,
│   │                      inventario, claves, perfiles, trabajos, contratos,
│   │                      cloudflare, qr, acceso, totp, util
│   ├── instalador/        subcomando instalar (conexión, llave, dns/, puertos,
│   │                      token, seguimiento con reconexión, credenciales)
│   └── publicacion/       subcomando github (preparar y publicar con gh)
├── ux_prep/               lado proyecto (antes ux-prep)
└── tests/ · tests_ux_prep/  pruebas
```

## Pruebas

```bash
python -m unittest discover -s tests -t .          # sin red ni VPS (incluye instalador y github)
python -m unittest discover -s tests_ux_prep -t .  # 120 del lado proyecto (antes ux-prep)
```

Incluye un **servidor SSH en proceso** que reproduce el caso real: clave de host
propia, autenticación por contraseña / llave / teclado-interactivo con 2FA,
códigos de salida, `stderr`, salida en vivo, `sudo -S` por stdin y `cat >` remoto.

Integración contra un VPS real (opcional, **solo lectura**, se salta si no hay
variables de entorno):

```bash
UX_VPS_HOST=… UX_VPS_PORT=2222 UX_VPS_USER=… UX_VPS_KEY=~/.ssh/… \
UX_VPS_FINGERPRINT=SHA256:… UX_VPS_SUDO_PASS=… \
  python -m unittest tests.test_vps_real -v
```

## Reglas de diseño (y por qué)

Estas no son preferencias: salen de cómo está endurecido el servidor.

| Regla | Motivo |
|---|---|
| **La clave del host se ancla** y se compara byte a byte; si cambia, se detiene | Contra un servidor distinto (MITM). `escanear` la lee **sin autenticar**: no envía ningún secreto |
| **Los secretos van por stdin**, nunca como argumento | No aparecen en la lista de procesos ni en la `~/.bash_history` remota |
| **Como mucho 2 sesiones simultáneas** por conexión | `MaxSessions 2` (etapa E03) rechaza la tercera |
| **Una sola conexión por sesión de trabajo, sin ráfagas** | El estándar limita las conexiones SSH: `ufw limit` (E06: 6 conexiones nuevas por IP cada 30 s) y `MaxStartups 3:30:10` (E03). Abrir una conexión por operación activa el límite y el servidor deja de responder unos segundos |
| **Solo algoritmos modernos** | El `sshd` endurecido solo ofrece `curve25519-sha256`, chacha20/aes-gcm y MACs `*-etm` |
| **La contraseña de sudo no se guarda ni se imprime** | Vive en memoria durante la sesión; en la CLI llega por variable de entorno |

### Nota sobre paramiko y el KEX

paramiko solo registra el nombre **de borrador** `curve25519-sha256@libssh.org`,
mientras que el `sshd` endurecido anuncia el nombre **estándar** `curve25519-sha256`
(RFC 8731). Como SSH compara los nombres literalmente, no había ningún KEX en
común y la conexión fallaba con *«no acceptable kex algorithm»*. La app registra
el alias con **la misma implementación** (`_registrar_kex_estandar`): no agrega ni
debilita ningún algoritmo.

## Módulos

La referencia es **el manual y sus plantillas** (`deploy/` y `vps/manual/`).

| Módulo | Qué cubre |
|---|---|
| `ssh.py` | Transporte con anclaje de huella, llave/contraseña/2FA, salida en vivo, `sudo` por stdin |
| `sesion.py` | Sesión compartida, reconexión con freno de 45 s |
| `servidor.py` + `ui/` | Interfaz web local con la misma protección del original |
| `trabajos.py` | Trabajos en segundo plano + bitácora |
| `inventario.py` | Inventario y secretos del pack |
| `ops.py` | Catálogo completo de operación diaria |
| `contratos.py` + `fase2.py` | Las 18 etapas: plan, bloques, verificaciones, cierre E16 |
| `fase1.py` | Preparación inicial de un VPS limpio |
| `cloudflare.py` | DNS (registros A/AAAA, verificación de tokens) y R2 (token en memoria) |
| `instalador/` | `instalar`: de VPS recién creado a uxdeployar funcionando, desde el PC |
| `publicacion/` | `github preparar` y `github publicar` |
| `qr.py` + `totp.py` | Asistente de 2FA |
| `claves.py`, `perfiles.py`, `acceso.py` | Llaves SSH/age, perfiles, `known_hosts` |
| `ux_prep/` | Lado proyecto (`ux-infra.py prep` / `prep-gui`) |

**Fidelidad:** la fuente de verdad es el manual y sus plantillas; si la app
discrepa, se corrige la app.
